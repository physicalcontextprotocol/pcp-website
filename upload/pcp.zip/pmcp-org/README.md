# pmcp-org — Physical Model Context Protocol

An MCP-compatible protocol for commanding physical robots, with a
non-bypassable safety pipeline. This repository is a monorepo containing
the specification, the reference SDKs, the conformance suite, and the
subsystems (registry, safety modules, servers, labs) — mirroring the
`modelcontextprotocol` GitHub-organization layout.

[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![Protocol Version](https://img.shields.io/badge/P--MCP-v0.5-brightgreen.svg)](pmcp-spec/docs/PROTOCOL_SPEC.md)
[![MCP Compatible](https://img.shields.io/badge/MCP-2024--11--05-orange.svg)](https://modelcontextprotocol.io)

---

## Repository layout

Each of the nine sub-projects is independently versioned, has its own
LICENSE (Apache 2.0), and is designed to become its own git repository
once the layout stabilizes. Until then, they live here so cross-project
changes can be reviewed together.

| Sub-project | Purpose | Status |
|---|---|---|
| [`pmcp-spec/`](pmcp-spec/)                 | Protocol specification, safety architecture, JSON schemas, TLA+ formal models | Draft (spec v0.5, JSON schema v0.6.0) |
| [`pmcp-conformance/`](pmcp-conformance/)   | Conformance test suite any implementation must pass (42 tests, self-contained mock)         | Working |
| [`pmcp-python/`](pmcp-python/)             | Python SDK — `pip install pmcp`, includes v05 shipping code + auxiliary `pmcp/` and `sdk/` packages (see notes below) | Working (213 tests pass) |
| [`pmcp-typescript/`](pmcp-typescript/)     | TypeScript SDK skeleton (`@pmcp/client`)                                                    | Skeleton — no test suite |
| [`pmcp-rust/`](pmcp-rust/)                 | Rust crates: `pmcp-core` (protocol/consensus/transport), `pmcp-ledger` (CRDT storage)       | Real code, `cargo build` currently blocked by pyo3 misconfig (see below) |
| [`pmcp-servers/`](pmcp-servers/)           | Reference robot servers, examples, gateway, ROS 2 bridge, simulator                        | Illustrative — requires `pmcp-python` installed alongside |
| [`pmcp-registry/`](pmcp-registry/)         | HTTP fleet-registry server + Vite/React dashboard                                          | Experimental — auth and CORS need hardening before internet exposure |
| [`pmcp-safety/`](pmcp-safety/)             | Safety loop, TEE attestator, compliance harness, multi-sig gate, edge hardening            | Mixed — TEE and safety-loop are largely mock-backed today |
| [`pmcp-labs/`](pmcp-labs/)                 | Quarantine: v01–v04 legacy code, `pmcp_grand_unified.py`, cloud/depin/swarm/marketplace/physics-federation experiments, infra scaffolding | **Not stable, not supported.** Reference only. |

Sequencing (from [`MIGRATION_MAP.md`](MIGRATION_MAP.md)):
`pmcp-spec` + `pmcp-conformance` stabilize first, then SDKs (`pmcp-python`,
`pmcp-typescript`, `pmcp-rust`), then subsystems, with `pmcp-labs`
migrated/quarantined last.

## What P-MCP does

P-MCP is a thin protocol layer that lets any MCP-compatible AI client
(Claude, GPT, Grok, Gemini, local Ollama) command physical robots
through the standard MCP `tools/call` interface. Every actuation passes
through a mandatory safety pipeline before any motor moves:

```
Any LLM (Claude · GPT · Grok · Gemini · Ollama)
              │  Standard MCP JSON-RPC 2.0
              ▼
    ┌──────────────────────────────────────────────────┐
    │           P-MCP Server (robot-side)              │
    │                                                  │
    │  tools/list   → Robot actuations                 │
    │  tools/call   → E-Stop → Lease → Constitution →  │
    │                  Shadow → Execute                │
    │  resources/*  → Live sensor streams              │
    │  shadow/*     → Pre-flight simulation            │
    │  lease/*      → Zone ownership                   │
    └──────────────┬───────────────────────────────────┘
                   │  Safety Pipeline
       E-Stop (latch) → Lease → Constitution → Shadow → Execute
                   │
          Physical Robot Hardware
```

The gate order is normative and defined in
[`pmcp-spec/docs/PROTOCOL_SPEC.md §6`](pmcp-spec/docs/PROTOCOL_SPEC.md).

## Quick start — Python SDK

```bash
cd pmcp-python
pip install -e .[dev]
pytest -q                          # 213 tests pass
python -m v05.main_pmcp_v5 --demo arm   # in-memory demo, no hardware
```

Or, once published to PyPI:

```bash
pip install pmcp
```

See [`pmcp-python/README.md`](pmcp-python/README.md) for the SDK's own
notes, including the still-unresolved duplicate-client-implementation
issue flagged in `MIGRATION_MAP.md`.

## Quick start — Conformance suite

```bash
cd pmcp-conformance
pip install -e .
pytest -q                          # 42 tests pass against the built-in mock
```

To validate a real implementation, point the `mock_robot_server` fixture
at its base URL (see [`pmcp-conformance/README.md`](pmcp-conformance/README.md)).

## Contributing

Cross-project changes go through this monorepo's CI. Changes scoped to a
single sub-project should also work when the sub-project is later
extracted to its own repository — keep imports and paths sub-project-local
where you can. See each sub-project's README for its local guidelines.

For governance, see [`pmcp-spec/docs/FOUNDATION_CHARTER.md`](pmcp-spec/docs/FOUNDATION_CHARTER.md).

## Honest limitations (release notes for the current pass)

- **Duplicate implementations remain in `pmcp-python/`.** The `pmcp/`,
  `sdk/`, and `v05/` packages ship overlapping `PMCPServer` / `PMCPClient`
  / `ShadowPreview` classes. Picking one canonical implementation and
  deprecating the rest is called out as follow-up in `MIGRATION_MAP.md`
  and has **not** been done in this pass.
- **`pmcp-servers/` is not self-contained.** The reference robot servers
  hard-import `from v05...`, and several examples hard-import
  `pmcp_grand_unified` — the latter now only lives in `pmcp-labs/` and is
  itself flagged for a split/deprecate/archive decision. Run them with
  `pmcp-python` installed in the same environment and `pmcp-labs/` on
  `PYTHONPATH` if you want the `pmcp_grand_unified` examples.
- **`pmcp-rust/pmcp-core` does not build cleanly today.** `Cargo.toml`
  declares `pyo3` with `features = ["extension-module"]` but the
  `python` feature that gates `pub mod python` in `lib.rs` is never
  declared, so `python.rs` is inert and a plain `cargo build` needs the
  extension-module environment to succeed. See
  [`pmcp-rust/README.md`](pmcp-rust/README.md).
- **`pmcp-registry/` is not production-ready.** Neither aiohttp app has
  authentication, request-size limits, or host/port allowlists on
  `register`, and one enables CORS-`*` on POST/DELETE. Do not expose the
  registry to an untrusted network yet.
- **`pmcp-safety/` TEE attestator + safety-loop simulator are
  mock-backed** by default (see `pmcp-safety/tee-attestator/src/`
  and `pmcp-safety/safety-loop/src/safety_loop.py`). They demonstrate
  the interface; they do not verify real enclaves or drive Gazebo.
- **`pmcp-labs/infra/` Dockerfiles and docker-compose files reference
  pre-split paths** (`COPY v05/`, `python -m v05.robot_servers.*`,
  `COPY rust/pmcp-core/`) and will not build against this layout. They
  are preserved for reference until an infra pass rewires them or
  replaces them.

See [`CHANGELOG.md`](CHANGELOG.md) for the version-by-version history
and [`MIGRATION_MAP.md`](MIGRATION_MAP.md) for how the pre-split
monorepo maps into the current layout.

## License

Apache 2.0. Each sub-project carries its own copy of the license so it
remains self-contained when extracted.
