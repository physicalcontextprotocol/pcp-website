# pmcp-labs

Quarantine repo for everything without a clear current owner or clean
architectural home: legacy protocol versions, experimental subsystems,
and one large unowned file. Nothing here is guaranteed stable or
maintained — treat it as "may be promoted to a real repo, may be
deprecated."

## Contents
- `v01/` `v02/` `v03/` `v04/` — legacy pre-0.5 protocol versions.
- `legacy/` — (empty in this snapshot).
- `community/` — community driver contributions (turtlebot, spot, ur5,
  franka, generic serial) + features.py.
- `cloud/` — cloud backend (analytics, alerts, monitoring, backup,
  onboarding, reporting, twin) + a small frontend (hooks/services/types).
- `depin/` — DePIN node/server code.
- `physics-federation/` — federated physics learning.
- `swarm/` — swarm coordination (coo.py).
- `marketplace/` — plugin marketplace (plugin_sdk.py, server.py).
- `pmcp_grand_unified.py` — **161KB, no clear ownership.** This single
  file appears to duplicate/aggregate functionality that now lives
  across `pmcp-python`, `pmcp-safety`, and `pmcp-servers`. It needs a
  decision (split up / deprecate / archive) before this repo is treated
  as anything more than a holding pen.
- `infra/` — Dockerfiles, docker-compose, mosquitto.conf (root-level +
  `docker/` subfolder duplicates — worth deduplicating).
