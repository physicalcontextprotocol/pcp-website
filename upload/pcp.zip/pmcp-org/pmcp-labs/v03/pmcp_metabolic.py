"""
P-MCP v0.3 — Level 10: Metabolic Twin (Biotic Coupling)
=========================================================
"From Risk Flags to Metabolic Synchronization"

Architecture:
  ┌────────────────────────────────────────────────────┐
  │          CROP GROWTH MODEL (APSIM-inspired)        │
  │  Inputs: VPD, PAR, humidity, CO2, soil moisture   │
  │  Outputs: RGR, transpiration_rate, stress_index   │
  │           stomata_conductance, yield_forecast_g   │
  └──────────────────┬─────────────────────────────────┘
                     │  stomata close → trigger SLA
  ┌──────────────────▼─────────────────────────────────┐
  │            AUTONOMOUS SLA ENGINE                   │
  │  Bio-event → re-price robot utility scores        │
  │  → deprioritize HarvesterRobot                    │
  │  → grant ClimateRobot energy budget + priority    │
  └──────────────────┬─────────────────────────────────┘
                     │
  ┌──────────────────▼─────────────────────────────────┐
  │          BIO-ECONOMIC OPTIMIZER                    │
  │  Maximize: Σ yield_value_usd - Σ energy_cost_usd  │
  │  Subject to: SLA constraints, power budget        │
  └────────────────────────────────────────────────────┘

APSIM model references:
  - Monteith radiation-use efficiency (RUE) model
  - Penman-Monteith transpiration
  - VPD stress function (Ball-Berry stomatal model)
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("a2a_ps.pmcp.metabolic")


# ─────────────────────────────────────────────────────────────
#  CROP GROWTH MODEL  (APSIM-inspired RUE + VPD)
# ─────────────────────────────────────────────────────────────

@dataclass
class CropEnvironment:
    """
    Physical environment inputs for the crop model.
    Read from sensors: multispectral camera + climate controller.
    """
    vpd_kpa:          float   # Vapour Pressure Deficit
    par_umol_m2s:     float   # Photosynthetically Active Radiation
    air_temp_c:       float   # Air temperature
    humidity_pct:     float   # Relative humidity
    co2_ppm:          float   # CO2 concentration
    soil_moisture_pct: float  # 0–100% volumetric water content
    timestamp:        float = field(default_factory=time.time)


@dataclass
class CropState:
    """
    Current physiological state of one tray of crops.
    Evolves according to the growth model on each time step.
    """
    tray_id:              str
    crop_type:            str   = "basil"
    age_days:             float = 20.0
    biomass_g_m2:         float = 80.0
    leaf_area_index:      float = 3.0
    stomata_conductance:  float = 0.15   # mol H2O m-2 s-1
    stress_index:         float = 0.0   # 0=no stress, 1=critical
    transpiration_g_h:    float = 0.0
    rgr_g_g_day:          float = 0.0   # Relative Growth Rate
    yield_forecast_g:     float = 0.0
    harvest_quality:      float = 1.0   # 0–1 (drops under stress)
    days_to_maturity:     float = 5.0
    last_updated:         float = field(default_factory=time.time)

    def health_score(self) -> float:
        """Composite health: growth rate × quality × (1 - stress)."""
        rgr_norm = min(self.rgr_g_g_day / 0.08, 1.0)
        return round(rgr_norm * self.harvest_quality * (1 - self.stress_index), 3)

    def harvest_value_usd(self, price_per_g: float = 0.02) -> float:
        """Economic value of harvesting this tray right now."""
        return self.yield_forecast_g * self.harvest_quality * price_per_g


class CropGrowthModel:
    """
    APSIM-inspired simplified growth model for vertical farm crops.

    Core physics:
        RUE (Radiation Use Efficiency): biomass accumulation from PAR
        Penman-Monteith: transpiration demand from VPD + humidity
        Ball-Berry: stomatal conductance model
        VPD stress function: reduces RGR + conductance above threshold
    """

    # Basil crop parameters
    PARAMS = {
        "basil": {
            "rue_g_mj":        3.2,    # Radiation Use Efficiency g biomass / MJ PAR
            "vpd_threshold":   1.2,    # kPa — stomata begin closing
            "vpd_critical":    2.5,    # kPa — stomata fully closed
            "temp_opt_c":      24.0,   # Optimal temperature
            "temp_base_c":     10.0,   # Base temperature for growth
            "temp_max_c":      38.0,   # Maximum temperature
            "harvest_biomass": 120.0,  # g/m2 — harvest at this threshold
        }
    }

    def step(self, state: CropState, env: CropEnvironment,
             dt_hours: float = 1.0) -> CropState:
        """
        Advance crop state by dt_hours under given environment.

        Returns new CropState (immutable update).
        """
        p = self.PARAMS.get(state.crop_type, self.PARAMS["basil"])

        # ── Stomatal conductance (Ball-Berry model) ───────────
        # g_s = m * A * h_s / c_s + b
        # Simplified: g_s decreases linearly with VPD above threshold
        vpd = env.vpd_kpa
        if vpd < p["vpd_threshold"]:
            stomata = 0.18  # Fully open
        elif vpd > p["vpd_critical"]:
            stomata = 0.03  # Almost closed
        else:
            frac = (vpd - p["vpd_threshold"]) / (p["vpd_critical"] - p["vpd_threshold"])
            stomata = 0.18 - 0.15 * frac

        # ── VPD stress index ───────────────────────────────────
        stress = max(0.0, min(1.0, (vpd - p["vpd_threshold"]) /
                              (p["vpd_critical"] - p["vpd_threshold"])))

        # ── Temperature factor ─────────────────────────────────
        t = env.air_temp_c
        if t <= p["temp_base_c"] or t >= p["temp_max_c"]:
            temp_factor = 0.0
        elif t <= p["temp_opt_c"]:
            temp_factor = (t - p["temp_base_c"]) / (p["temp_opt_c"] - p["temp_base_c"])
        else:
            temp_factor = (p["temp_max_c"] - t) / (p["temp_max_c"] - p["temp_opt_c"])

        # ── PAR to biomass (RUE model) ─────────────────────────
        # Convert μmol photons → MJ: 1 MJ PAR ≈ 4.57e6 μmol
        par_mj_h = env.par_umol_m2s * 3600 / 4.57e6 * state.leaf_area_index
        rue_effective = p["rue_g_mj"] * temp_factor * (1 - stress * 0.8)
        delta_biomass = par_mj_h * rue_effective * dt_hours

        # ── Transpiration (Penman-Monteith simplified) ─────────
        # E ≈ Δ/(Δ+γ) * Rn + γ/(Δ+γ) * (e_s-e_a) / r_a
        # Simplified to VPD × conductance
        WATER_DENSITY = 997.0   # g/L
        MOLAR_VOLUME  = 0.04089 # m3/mol at 25°C
        transpiration_mol_m2_h = stomata * vpd * dt_hours
        transpiration_g_h = transpiration_mol_m2_h * 18.015 * state.leaf_area_index

        # ── Leaf area expansion ────────────────────────────────
        new_biomass = state.biomass_g_m2 + delta_biomass
        sla = 250.0  # cm2/g specific leaf area
        new_lai = new_biomass * sla / 10000

        # ── RGR (relative growth rate) ─────────────────────────
        rgr = (delta_biomass / max(state.biomass_g_m2, 1.0)) / dt_hours

        # ── Harvest quality decay under stress ─────────────────
        quality_decay = stress * 0.02 * dt_hours
        new_quality   = max(0.0, state.harvest_quality - quality_decay)

        # ── Yield forecast ─────────────────────────────────────
        days_left = max(0.0, state.days_to_maturity - dt_hours / 24)
        yield_now = new_biomass * new_quality * 0.6  # 60% harvest fraction

        return CropState(
            tray_id            = state.tray_id,
            crop_type          = state.crop_type,
            age_days           = state.age_days + dt_hours / 24,
            biomass_g_m2       = round(new_biomass, 2),
            leaf_area_index    = round(min(new_lai, 8.0), 3),
            stomata_conductance = round(stomata, 4),
            stress_index       = round(stress, 3),
            transpiration_g_h  = round(transpiration_g_h, 2),
            rgr_g_g_day        = round(rgr * 24, 4),
            yield_forecast_g   = round(yield_now, 1),
            harvest_quality    = round(new_quality, 3),
            days_to_maturity   = round(days_left, 2),
            last_updated       = time.time(),
        )


# ─────────────────────────────────────────────────────────────
#  AUTONOMOUS SLA ENGINE
# ─────────────────────────────────────────────────────────────

class SLATrigger(str, Enum):
    STOMATA_CLOSING  = "stomata_closing"     # VPD > threshold
    STRESS_CRITICAL  = "stress_critical"     # stress_index > 0.7
    HARVEST_WINDOW   = "harvest_window"      # biomass > harvest threshold
    QUALITY_DECAY    = "quality_decay"       # harvest_quality < 0.8
    CROP_EMERGENCY   = "crop_emergency"      # imminent loss


@dataclass
class SLAEvent:
    """An autonomous service level agreement trigger."""
    trigger:         SLATrigger
    tray_id:         str
    severity:        float      # 0–1
    description:     str
    timestamp:       float = field(default_factory=time.time)

    # Economic impact
    value_at_risk_usd: float = 0.0

    # Robot re-prioritization directives
    deprioritize_robots: List[str] = field(default_factory=list)
    prioritize_robots:   List[str] = field(default_factory=list)

    # Energy reallocation
    energy_grant_j:  float = 0.0   # Extra energy budget for priority robots
    energy_revoke_j: float = 0.0   # Energy withdrawn from deprioritized robots


class AutonomousSLAEngine:
    """
    Monitors crop states and fires Autonomous SLA events that
    dynamically re-price robot utility scores without human intervention.

    This is the "Metabolic Synchronization" layer:
        Plant stomata close (multispectral) →
        SLA fires →
        HarvesterRobot utility → 0.1 (de-prioritized) →
        ClimateRobot gets +500J energy budget + utility → 0.95
    """

    # SLA thresholds
    STOMATA_CLOSE_THRESHOLD = 0.08   # mol H2O m-2 s-1
    STRESS_CRITICAL         = 0.7
    QUALITY_DECAY_THRESHOLD = 0.8
    HARVEST_WINDOW_BIOMASS  = 110.0  # g/m2

    def __init__(self):
        self._active_slas:    Dict[str, SLAEvent] = {}
        self._sla_history:    List[SLAEvent]      = []
        self._utility_overrides: Dict[str, float] = {}   # robot_id → utility
        self._energy_grants:     Dict[str, float] = {}   # robot_id → extra_J

    def evaluate(self, state: CropState, env: CropEnvironment,
                 harvester_ids: List[str], climate_ids: List[str]) -> List[SLAEvent]:
        """
        Evaluate crop state → fire SLA events → adjust utility scores.
        Called after every CropGrowthModel.step().
        """
        events = []

        # ── Stomata closing → humidifier emergency ─────────────
        if state.stomata_conductance < self.STOMATA_CLOSE_THRESHOLD:
            severity = 1.0 - (state.stomata_conductance / self.STOMATA_CLOSE_THRESHOLD)
            value_risk = state.harvest_value_usd() * severity

            event = SLAEvent(
                trigger          = SLATrigger.STOMATA_CLOSING,
                tray_id          = state.tray_id,
                severity         = round(severity, 3),
                description      = (
                    f"Stomata conductance {state.stomata_conductance:.3f} < "
                    f"threshold {self.STOMATA_CLOSE_THRESHOLD} — "
                    f"VPD={env.vpd_kpa:.2f}kPa. Humidifier emergency."
                ),
                value_at_risk_usd = round(value_risk, 2),
                deprioritize_robots = harvester_ids,
                prioritize_robots   = climate_ids,
                energy_grant_j   = 800.0 * severity,  # Power humidifiers
                energy_revoke_j  = 400.0 * severity,  # Pull from harvesters
            )
            events.append(event)

            # Apply utility override
            for rid in harvester_ids:
                self._utility_overrides[rid] = max(0.05, 0.4 - severity * 0.35)
            for rid in climate_ids:
                self._utility_overrides[rid] = min(1.0, 0.7 + severity * 0.3)
                self._energy_grants[rid] = event.energy_grant_j

            logger.warning(
                f"  🌱  SLA [{SLATrigger.STOMATA_CLOSING.value}] tray=[{state.tray_id}] "
                f"severity={severity:.2f} value_at_risk=${value_risk:.2f} "
                f"→ deprioritize={harvester_ids} prioritize={climate_ids}"
            )

        # ── Critical stress → emergency climate response ───────
        if state.stress_index > self.STRESS_CRITICAL:
            event = SLAEvent(
                trigger          = SLATrigger.STRESS_CRITICAL,
                tray_id          = state.tray_id,
                severity         = state.stress_index,
                description      = (
                    f"Crop stress CRITICAL: index={state.stress_index:.2f}. "
                    f"Quality decaying at {state.harvest_quality:.2f}. "
                    f"All non-essential robot ops suspended."
                ),
                value_at_risk_usd = state.harvest_value_usd(),
                deprioritize_robots = harvester_ids,
                prioritize_robots   = climate_ids,
                energy_grant_j   = 1200.0,
                energy_revoke_j  = 600.0,
            )
            events.append(event)

            # Emergency override — harvesters yield all budget
            for rid in harvester_ids:
                self._utility_overrides[rid] = 0.05
            for rid in climate_ids:
                self._utility_overrides[rid] = 0.98
                self._energy_grants[rid] = 1200.0

            logger.warning(
                f"  🚨  SLA EMERGENCY [{state.tray_id}]: stress={state.stress_index:.2f} "
                f"quality={state.harvest_quality:.2f}"
            )

        # ── Harvest window open → elevate harvester utility ────
        if (state.biomass_g_m2 >= self.HARVEST_WINDOW_BIOMASS
                and state.stress_index < 0.3
                and state.harvest_quality > 0.85):
            event = SLAEvent(
                trigger          = SLATrigger.HARVEST_WINDOW,
                tray_id          = state.tray_id,
                severity         = 0.5,
                description      = (
                    f"Harvest window OPEN: biomass={state.biomass_g_m2:.0f}g/m2 "
                    f"quality={state.harvest_quality:.2f} → elevate harvester priority"
                ),
                value_at_risk_usd = 0.0,
                prioritize_robots = harvester_ids,
                energy_grant_j    = 200.0,
            )
            events.append(event)

            for rid in harvester_ids:
                self._utility_overrides[rid] = min(1.0, 0.85 + state.harvest_quality * 0.1)

            logger.info(
                f"  🌾  SLA HARVEST WINDOW [{state.tray_id}]: "
                f"biomass={state.biomass_g_m2:.0f}g utility→{self._utility_overrides.get(harvester_ids[0] if harvester_ids else '', 0.85):.2f}"
            )

        # ── Quality decay → urgent harvest ─────────────────────
        if (state.harvest_quality < self.QUALITY_DECAY_THRESHOLD
                and state.harvest_quality > 0.5):
            urgency = (self.QUALITY_DECAY_THRESHOLD - state.harvest_quality) / 0.3
            event = SLAEvent(
                trigger          = SLATrigger.QUALITY_DECAY,
                tray_id          = state.tray_id,
                severity         = urgency,
                description      = (
                    f"Quality decaying: {state.harvest_quality:.2f} — "
                    f"harvest within {state.days_to_maturity:.1f} days or lose value"
                ),
                value_at_risk_usd = state.harvest_value_usd() * urgency,
                prioritize_robots = harvester_ids,
                energy_grant_j    = 400.0 * urgency,
            )
            events.append(event)

        for e in events:
            self._active_slas[f"{e.trigger.value}:{e.tray_id}"] = e
            self._sla_history.append(e)

        return events

    def get_robot_utility(self, robot_id: str, base_utility: float) -> float:
        """Return SLA-adjusted utility for a robot."""
        return self._utility_overrides.get(robot_id, base_utility)

    def get_energy_grant(self, robot_id: str) -> float:
        """Extra energy budget granted by SLA for this robot."""
        return self._energy_grants.get(robot_id, 0.0)

    def clear_sla(self, trigger: SLATrigger, tray_id: str):
        """Mark SLA as resolved (plant recovered)."""
        key = f"{trigger.value}:{tray_id}"
        if key in self._active_slas:
            del self._active_slas[key]
            logger.info(f"  ✅  SLA cleared: {key}")

    def active_summary(self) -> List[dict]:
        return [
            {
                "trigger":             e.trigger.value,
                "tray_id":             e.tray_id,
                "severity":            e.severity,
                "description":         e.description,
                "value_at_risk_usd":   e.value_at_risk_usd,
                "deprioritize_robots": e.deprioritize_robots,
                "prioritize_robots":   e.prioritize_robots,
                "energy_grant_j":      e.energy_grant_j,
                "age_s":               round(time.time() - e.timestamp, 1),
            }
            for e in self._active_slas.values()
        ]


# ─────────────────────────────────────────────────────────────
#  METABOLIC TWIN  (extends DigitalTwin)
# ─────────────────────────────────────────────────────────────

class MetabolicTwin:
    """
    Wraps DigitalTwin to add:
      - Per-tray CropGrowthModel simulation
      - AutonomousSLA engine integration
      - Bio-Economic value tracking
      - Stomata event → robot auction re-pricing

    Usage:
        mtwin = MetabolicTwin(digital_twin)
        mtwin.register_tray("tray-1-0", crop_type="basil")
        env = CropEnvironment(vpd_kpa=1.8, ...)  # from sensors
        await mtwin.step_all_trays(env)
        # SLA events automatically adjust robot priorities
    """

    def __init__(self, digital_twin):
        self.twin      = digital_twin
        self.model     = CropGrowthModel()
        self.sla       = AutonomousSLAEngine()
        self._trays:   Dict[str, CropState]   = {}
        self._history: Dict[str, List[CropState]] = {}

        # Robot role registry
        self._harvester_ids: List[str] = []
        self._climate_ids:   List[str] = []

        logger.info("  🌱  MetabolicTwin initialised")

    def register_tray(self, tray_id: str, crop_type: str = "basil",
                      initial_state: Optional[CropState] = None):
        state = initial_state or CropState(
            tray_id=tray_id, crop_type=crop_type,
            age_days=20.0, biomass_g_m2=80.0,
        )
        self._trays[tray_id]   = state
        self._history[tray_id] = [state]
        logger.info(f"  🌿  Tray [{tray_id}] registered ({crop_type})")

    def register_harvester(self, robot_id: str):
        if robot_id not in self._harvester_ids:
            self._harvester_ids.append(robot_id)

    def register_climate_robot(self, robot_id: str):
        if robot_id not in self._climate_ids:
            self._climate_ids.append(robot_id)

    def step_tray(self, tray_id: str, env: CropEnvironment,
                  dt_hours: float = 1.0) -> Tuple[CropState, List[SLAEvent]]:
        """
        Advance one tray by dt_hours.
        Returns (new_state, sla_events_fired).
        """
        state = self._trays.get(tray_id)
        if not state:
            raise KeyError(f"Tray [{tray_id}] not registered")

        new_state = self.model.step(state, env, dt_hours)
        self._trays[tray_id] = new_state
        self._history[tray_id].append(new_state)

        # Sync back to DigitalTwin for ShadowValidator biological risk checks
        self.twin.update_plant_health(tray_id, {
            "health_score":        new_state.health_score(),
            "humidity_pct":        env.humidity_pct,
            "days_to_harvest":     new_state.days_to_maturity,
            "harvest_window_open": new_state.biomass_g_m2 >= CropGrowthModel.PARAMS["basil"]["harvest_biomass"],
            "vpd_kpa":             env.vpd_kpa,
            "stomata_conductance": new_state.stomata_conductance,
            "stress_index":        new_state.stress_index,
            "yield_forecast_g":    new_state.yield_forecast_g,
        })

        # Fire SLA evaluation
        events = self.sla.evaluate(
            new_state, env, self._harvester_ids, self._climate_ids
        )

        return new_state, events

    def step_all_trays(self, env: CropEnvironment,
                       dt_hours: float = 1.0) -> Dict[str, List[SLAEvent]]:
        """Advance all registered trays simultaneously."""
        all_events = {}
        for tray_id in list(self._trays.keys()):
            _, events = self.step_tray(tray_id, env, dt_hours)
            all_events[tray_id] = events
        return all_events

    def bio_economic_utility(self, robot_id: str, tray_id: str,
                              base_utility: float = 0.5) -> float:
        """
        SLA-adjusted utility for a robot acting on a tray.
        This is what the Vickrey auction should use for bid valuation.
        """
        state = self._trays.get(tray_id)
        if not state:
            return base_utility

        # Base: harvest urgency × quality × (1 - stress)
        days_left = max(state.days_to_maturity, 0.1)
        urgency   = min(1.0, 2.0 / days_left)
        bio_util  = state.health_score() * urgency

        # SLA adjustment
        return round(self.sla.get_robot_utility(robot_id, bio_util), 3)

    def farm_economic_summary(self, price_per_g: float = 0.02) -> dict:
        """Total farm yield value and risk snapshot."""
        total_value    = sum(s.harvest_value_usd(price_per_g)
                             for s in self._trays.values())
        total_biomass  = sum(s.biomass_g_m2 for s in self._trays.values())
        stressed_trays = [tid for tid, s in self._trays.items()
                          if s.stress_index > 0.5]
        active_slas    = self.sla.active_summary()

        return {
            "total_trays":          len(self._trays),
            "total_biomass_g_m2":   round(total_biomass, 1),
            "total_value_usd":      round(total_value, 2),
            "stressed_trays":       stressed_trays,
            "active_slas":          len(active_slas),
            "sla_details":          active_slas,
            "energy_grants": {
                rid: self.sla.get_energy_grant(rid)
                for rid in self._harvester_ids + self._climate_ids
            },
        }

    def tray_report(self, tray_id: str) -> dict:
        state = self._trays.get(tray_id)
        if not state:
            return {}
        return {
            "tray_id":             tray_id,
            "crop_type":           state.crop_type,
            "age_days":            state.age_days,
            "biomass_g_m2":        state.biomass_g_m2,
            "health_score":        state.health_score(),
            "stomata_conductance": state.stomata_conductance,
            "stress_index":        state.stress_index,
            "rgr_g_g_day":         state.rgr_g_g_day,
            "transpiration_g_h":   state.transpiration_g_h,
            "yield_forecast_g":    state.yield_forecast_g,
            "harvest_quality":     state.harvest_quality,
            "days_to_maturity":    state.days_to_maturity,
            "harvest_value_usd":   round(state.harvest_value_usd(), 2),
        }
