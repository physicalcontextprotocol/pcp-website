"""
P-MCP v0.3 — Level 9: Trusted Execution Environment (TEE) Layer
================================================================
"The Safety Constitution Written in Silicon"

Architecture:
  ┌─────────────────────────────────────────────────────┐
  │                    NORMAL WORLD                     │
  │   LLM Agent → PMCPServer → ShadowValidator         │
  │              ↓ signed ToolCall                      │
  │         TEECommandGate.submit()                     │
  └──────────────────────┬──────────────────────────────┘
                         │  Ed25519 proof required
  ┌──────────────────────▼──────────────────────────────┐
  │                   TEE WORLD                         │
  │   SafetyConstitution (immutable rules)              │
  │   → verify signature → re-validate physics         │
  │   → emit HardwareToken (one-time use, 500ms TTL)   │
  └──────────────────────┬──────────────────────────────┘
                         │  HardwareToken
  ┌──────────────────────▼──────────────────────────────┐
  │              HARDWARE DRIVER LAYER                  │
  │   ROS2 / OPC UA / Viam — only accept HardwareToken │
  └─────────────────────────────────────────────────────┘

Real TEE integration notes:
  - ARM TrustZone: run SafetyConstitution in Secure World via OP-TEE
  - Intel SGX: enclave signs with SGX attestation key
  - This module simulates TEE boundary with Ed25519 keys + policy engine
  - Production: replace TEESimulator with OP-TEE PTA or SGX enclave call
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding, PublicFormat, PrivateFormat, NoEncryption,
)
from cryptography.exceptions import InvalidSignature

logger = logging.getLogger("a2a_ps.pmcp.tee")


# ─────────────────────────────────────────────────────────────
#  SAFETY CONSTITUTION  (the immutable ruleset inside TEE)
# ─────────────────────────────────────────────────────────────

@dataclass
class ConstitutionRule:
    """One immutable safety rule embedded in the TEE."""
    rule_id:     str
    description: str
    check:       Any      # callable(tool_call_payload: dict) → bool
    veto_reason: str      # emitted if check returns False


class SafetyConstitution:
    """
    Immutable safety rules that run INSIDE the TEE.
    Even if the normal-world OS is compromised, these rules
    cannot be bypassed — they run before any HardwareToken is issued.

    In ARM TrustZone production:
        These rules compile into the Secure World binary (ta.c)
        and are signed with the device OEM key during manufacturing.
    """

    RULES: List[ConstitutionRule] = [
        ConstitutionRule(
            rule_id     = "CONST-01",
            description = "Maximum speed hard limit — 1.5 m/s absolute",
            check       = lambda p: float(p.get("speed", 0)) <= 1.5,
            veto_reason = "Speed exceeds TEE hard limit of 1.5 m/s",
        ),
        ConstitutionRule(
            rule_id     = "CONST-02",
            description = "Z-axis floor guard — robot cannot go below 0 m",
            check       = lambda p: float(p.get("z", 1)) >= 0.0,
            veto_reason = "Z target below floor — collision with grow rack",
        ),
        ConstitutionRule(
            rule_id     = "CONST-03",
            description = "Energy burst limit — single call max 5000 J",
            check       = lambda p: float(p.get("_energy_j", 0)) <= 5000.0,
            veto_reason = "Energy burst exceeds TEE limit — power rail protection",
        ),
        ConstitutionRule(
            rule_id     = "CONST-04",
            description = "Unconfirmed call freshness — token must be < 500ms old",
            check       = lambda p: (
                time.time() - float(p.get("_shadow_ts", 0)) < 0.5
            ),
            veto_reason = "Shadow validation stale — re-validate required",
        ),
        ConstitutionRule(
            rule_id     = "CONST-05",
            description = "Robot ID whitelist — only registered robots accepted",
            check       = lambda p: p.get("robot_id", "") in SafetyConstitution.WHITELISTED_ROBOTS,
            veto_reason = "Robot ID not in TEE whitelist — registration required",
        ),
    ]

    # Robots cleared for operation (set at device provisioning time)
    WHITELISTED_ROBOTS = {"arm-01", "arm-02", "amr-01", "amr-02", "harvester-01"}

    @classmethod
    def evaluate(cls, payload: dict) -> Tuple[bool, List[str]]:
        """
        Run all constitution rules against a tool call payload.
        Returns (cleared, list_of_violations).
        """
        violations = []
        for rule in cls.RULES:
            try:
                if not rule.check(payload):
                    violations.append(f"[{rule.rule_id}] {rule.veto_reason}")
            except Exception as e:
                violations.append(f"[{rule.rule_id}] Rule evaluation error: {e}")
        return len(violations) == 0, violations


# ─────────────────────────────────────────────────────────────
#  HARDWARE TOKEN  (one-time use, short-lived)
# ─────────────────────────────────────────────────────────────

@dataclass
class HardwareToken:
    """
    One-time cryptographic proof that the TEE approved this command.
    Hardware bridge MUST verify this before sending any motor command.

    TTL: 500ms — robot must ACK within this window or token expires.
    In production: token is signed with TEE attestation key (not robot key).
    """
    token_id:      str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    call_id:       str   = ""
    robot_id:      str   = ""
    tool_name:     str   = ""
    issued_at:     float = field(default_factory=time.time)
    ttl_ms:        float = 500.0
    signature:     bytes = b""
    payload_hash:  str   = ""
    used:          bool  = False

    def is_valid(self) -> bool:
        age_ms = (time.time() - self.issued_at) * 1000
        return not self.used and age_ms < self.ttl_ms

    def consume(self) -> bool:
        """Mark as used — prevents replay attacks."""
        if not self.is_valid():
            return False
        self.used = True
        return True

    def age_ms(self) -> float:
        return (time.time() - self.issued_at) * 1000


# ─────────────────────────────────────────────────────────────
#  ROBOT DID IDENTITY  (real Ed25519)
# ─────────────────────────────────────────────────────────────

class RobotDID:
    """
    W3C Decentralized Identifier for a robot.
    Each robot holds an Ed25519 keypair — private key stored in TEE,
    public key published to the P-MCP discovery registry.

    DID document: did:pmcp:{robot_id}
    Verification method: did:pmcp:{robot_id}#key-1
    """

    def __init__(self, robot_id: str):
        self.robot_id = robot_id
        self.did      = f"did:pmcp:{robot_id}"
        # Generate fresh keypair (in production: load from secure storage)
        self._privkey  = Ed25519PrivateKey.generate()
        self._pubkey   = self._privkey.public_key()
        logger.info(f"  🔑  DID created: {self.did} ({self.pubkey_b64[:20]}...)")

    @property
    def pubkey_b64(self) -> str:
        raw = self._pubkey.public_bytes(Encoding.Raw, PublicFormat.Raw)
        return base64.b64encode(raw).decode()

    def sign(self, payload: dict) -> str:
        """Sign payload dict, return base64 signature."""
        message = json.dumps(payload, sort_keys=True).encode()
        sig = self._privkey.sign(message)
        return base64.b64encode(sig).decode()

    def verify(self, payload: dict, signature_b64: str) -> bool:
        """Verify a signature against this DID's public key."""
        try:
            message = json.dumps(payload, sort_keys=True).encode()
            sig = base64.b64decode(signature_b64)
            self._pubkey.verify(sig, message)
            return True
        except InvalidSignature:
            return False

    def did_document(self) -> dict:
        return {
            "@context":          ["https://www.w3.org/ns/did/v1"],
            "id":                self.did,
            "verificationMethod": [{
                "id":                 f"{self.did}#key-1",
                "type":               "Ed25519VerificationKey2020",
                "controller":         self.did,
                "publicKeyMultibase": "z" + base64.b64encode(
                    self._pubkey.public_bytes(Encoding.Raw, PublicFormat.Raw)
                ).decode(),
            }],
            "authentication":    [f"{self.did}#key-1"],
            "assertionMethod":   [f"{self.did}#key-1"],
        }


# ─────────────────────────────────────────────────────────────
#  TEE SIMULATOR  (boundary between normal world and secure world)
# ─────────────────────────────────────────────────────────────

class TEESimulator:
    """
    Simulates the ARM TrustZone / Intel SGX Secure World boundary.

    In real deployment:
        Normal World → SMC (Secure Monitor Call) → Secure World
        Secure World runs SafetyConstitution + signs HardwareToken
        Normal World never sees private attestation key

    This simulator:
        - Enforces SafetyConstitution rules
        - Signs HardwareToken with its own Ed25519 key (simulating TEE attestation key)
        - Maintains token registry with replay protection
    """

    def __init__(self):
        # TEE attestation key — in real SGX this is the MRSIGNER key
        self._attestation_key = Ed25519PrivateKey.generate()
        self._attestation_pub = self._attestation_key.public_key()
        self._issued_tokens:  Dict[str, HardwareToken] = {}
        self._veto_log:       List[dict] = []
        self._tokens_issued   = 0
        self._tokens_consumed = 0
        self._constitution_vetoes = 0

        pub_raw = self._attestation_pub.public_bytes(Encoding.Raw, PublicFormat.Raw)
        logger.info(
            f"  🔒  TEE Simulator started | "
            f"attestation_key={base64.b64encode(pub_raw).decode()[:20]}..."
        )

    # ── SECURE WORLD ENTRY POINT ──────────────────────────────

    def request_hardware_token(
        self,
        call_id:      str,
        robot_id:     str,
        tool_name:    str,
        arguments:    dict,
        energy_j:     float,
        shadow_ts:    float,
        caller_did:   Optional[RobotDID] = None,
        caller_sig:   str = "",
    ) -> Tuple[Optional[HardwareToken], List[str]]:
        """
        SECURE WORLD ENTRY — this is the SMC call boundary.

        Steps:
        1. Verify caller DID signature (prove the call came from a legitimate agent)
        2. Run SafetyConstitution rules (immutable, cannot be bypassed)
        3. If cleared: issue signed HardwareToken
        4. Log everything to TEE audit ledger

        Returns (token, violations) — token is None if any rule failed.
        """
        violations = []

        # ── Step 1: Verify caller identity ────────────────────
        if caller_did and caller_sig:
            payload_to_verify = {
                "call_id":   call_id,
                "robot_id":  robot_id,
                "tool_name": tool_name,
                "arguments": arguments,
            }
            if not caller_did.verify(payload_to_verify, caller_sig):
                violations.append("[TEE-SIG] Invalid caller signature — identity rejected")
                self._log_veto(call_id, robot_id, tool_name, violations)
                return None, violations

        # ── Step 2: Run Safety Constitution ───────────────────
        constitution_payload = {
            **arguments,
            "robot_id":  robot_id,
            "_energy_j": energy_j,
            "_shadow_ts": shadow_ts,
        }
        cleared, const_violations = SafetyConstitution.evaluate(constitution_payload)

        if not cleared:
            violations.extend(const_violations)
            self._constitution_vetoes += 1
            self._log_veto(call_id, robot_id, tool_name, violations)
            logger.warning(
                f"  🔒  TEE VETO [{call_id}]: "
                f"{'; '.join(violations)}"
            )
            return None, violations

        # ── Step 3: Issue HardwareToken ────────────────────────
        payload_hash = hashlib.sha256(
            json.dumps({
                "call_id":   call_id,
                "robot_id":  robot_id,
                "tool_name": tool_name,
                "arguments": arguments,
                "issued_at": time.time(),
            }, sort_keys=True).encode()
        ).hexdigest()

        token = HardwareToken(
            call_id      = call_id,
            robot_id     = robot_id,
            tool_name    = tool_name,
            issued_at    = time.time(),
            ttl_ms       = 500.0,
            payload_hash = payload_hash,
        )

        # Sign the token with TEE attestation key
        token_payload = {
            "token_id":     token.token_id,
            "call_id":      call_id,
            "robot_id":     robot_id,
            "payload_hash": payload_hash,
            "issued_at":    token.issued_at,
        }
        message = json.dumps(token_payload, sort_keys=True).encode()
        token.signature = self._attestation_key.sign(message)

        self._issued_tokens[token.token_id] = token
        self._tokens_issued += 1

        logger.info(
            f"  🔒  TEE TOKEN issued [{token.token_id}]: "
            f"[{robot_id}].{tool_name} | "
            f"TTL={token.ttl_ms:.0f}ms | "
            f"hash={payload_hash[:12]}..."
        )

        return token, []

    def verify_and_consume_token(self, token: HardwareToken) -> Tuple[bool, str]:
        """
        Hardware driver calls this before sending ANY motor command.
        Verifies TEE signature + consumes token (prevents replay).
        """
        # Check token is in our registry
        stored = self._issued_tokens.get(token.token_id)
        if not stored:
            return False, "Token not in TEE registry — possible forgery"

        # Check TTL
        if not token.is_valid():
            age = token.age_ms()
            return False, f"Token expired (age={age:.0f}ms > TTL={token.ttl_ms:.0f}ms)"

        # Verify TEE attestation signature
        token_payload = {
            "token_id":     token.token_id,
            "call_id":      token.call_id,
            "robot_id":     token.robot_id,
            "payload_hash": token.payload_hash,
            "issued_at":    token.issued_at,
        }
        message = json.dumps(token_payload, sort_keys=True).encode()
        try:
            self._attestation_pub.verify(token.signature, message)
        except InvalidSignature:
            return False, "TEE attestation signature invalid — token tampered"

        # Consume (one-time use)
        if not token.consume():
            return False, "Token already consumed — replay attack detected"

        self._tokens_consumed += 1
        logger.info(f"  🔒  TEE TOKEN consumed [{token.token_id}] ✓")
        return True, "ok"

    def _log_veto(self, call_id, robot_id, tool_name, violations):
        self._veto_log.append({
            "ts":         time.time(),
            "call_id":    call_id,
            "robot_id":   robot_id,
            "tool_name":  tool_name,
            "violations": violations,
        })

    def stats(self) -> dict:
        return {
            "tokens_issued":        self._tokens_issued,
            "tokens_consumed":      self._tokens_consumed,
            "constitution_vetoes":  self._constitution_vetoes,
            "veto_log_entries":     len(self._veto_log),
            "active_tokens":        sum(
                1 for t in self._issued_tokens.values() if t.is_valid()
            ),
        }

    def constitution_rules(self) -> List[dict]:
        return [
            {"id": r.rule_id, "description": r.description, "veto_reason": r.veto_reason}
            for r in SafetyConstitution.RULES
        ]


# ─────────────────────────────────────────────────────────────
#  TEE COMMAND GATE  (wraps PMCPServer.confirm)
# ─────────────────────────────────────────────────────────────

class TEECommandGate:
    """
    Drop-in wrapper around PMCPServer that enforces TEE approval
    before any hardware command reaches the bridge layer.

    Usage:
        gate = TEECommandGate(server, tee, robot_dids)
        result = await gate.tee_confirm(call_id, caller_did=arm_did)

    The hardware bridge MUST call gate.release_to_hardware(token)
    which does final TEE signature verification before the motor moves.
    """

    def __init__(self, server, tee: TEESimulator,
                 robot_dids: Optional[Dict[str, RobotDID]] = None):
        self.server     = server
        self.tee        = tee
        self.robot_dids = robot_dids or {}
        self._pending_tokens: Dict[str, HardwareToken] = {}

    async def tee_confirm(
        self,
        call_id:    str,
        caller_did: Optional[RobotDID] = None,
    ):
        """
        Extended confirm() that routes through TEE before hardware execution.
        """
        from a2a_ps.pmcp.schemas import ToolCallStatus

        call = self.server._calls.get(call_id)
        if not call:
            raise KeyError(f"No call: {call_id}")

        # Sign the call payload with caller DID
        caller_sig = ""
        if caller_did:
            sig_payload = {
                "call_id":   call_id,
                "robot_id":  call.robot_id,
                "tool_name": call.tool_name,
                "arguments": call.arguments,
            }
            caller_sig = caller_did.sign(sig_payload)

        projected = call.projected
        energy_j  = projected.energy_j if projected else 0.0
        shadow_ts = call.timestamp

        # Request TEE token (SMC boundary crossing)
        token, violations = self.tee.request_hardware_token(
            call_id    = call_id,
            robot_id   = call.robot_id,
            tool_name  = call.tool_name,
            arguments  = call.arguments,
            energy_j   = energy_j,
            shadow_ts  = shadow_ts,
            caller_did = caller_did,
            caller_sig = caller_sig,
        )

        if token is None:
            # TEE vetoed — abort call
            await self.server.abort(call_id, f"TEE veto: {'; '.join(violations)}")
            from a2a_ps.pmcp.schemas import ToolResult
            return ToolResult(
                call_id = call_id,
                success = False,
                message = f"TEE Constitution veto: {'; '.join(violations)}",
            )

        # Stash token for hardware layer to consume
        self._pending_tokens[call_id] = token

        # Proceed with normal confirm → execute
        result = await self.server.confirm(call_id)

        # Mark token consumed (if hardware didn't do it — cleanup)
        t = self._pending_tokens.pop(call_id, None)
        if t and not t.used:
            t.consume()  # Force-consume to prevent stale tokens

        return result

    def get_pending_token(self, call_id: str) -> Optional[HardwareToken]:
        """Hardware bridge calls this to retrieve the TEE token."""
        return self._pending_tokens.get(call_id)

    def release_to_hardware(self, token: HardwareToken) -> Tuple[bool, str]:
        """
        FINAL GATE — hardware bridge MUST call this.
        Verifies TEE signature and consumes token before motor command.
        """
        return self.tee.verify_and_consume_token(token)


# ─────────────────────────────────────────────────────────────
#  AAS CERTIFICATION EXTENSION
# ─────────────────────────────────────────────────────────────

@dataclass
class SafetyCertification:
    """
    A third-party safety certification a robot must hold
    before the PMCPServer allows it to register MOTION category tools.

    Issuer signs a certificate over the robot's DID public key.
    Server verifies signature before accepting tool registration.
    """
    cert_id:      str
    robot_did:    str
    issuer:       str           # e.g. "TÜV-SÜD", "CE-Mark", "ISO10218"
    standard:     str           # e.g. "ISO 10218-2:2011"
    issued_at:    float = field(default_factory=time.time)
    expires_at:   float = 0.0
    signature:    str  = ""     # Issuer's Ed25519 sig over (robot_did + cert_id)
    pubkey_b64:   str  = ""     # Robot's public key at certification time

    def is_valid(self) -> bool:
        if self.expires_at and time.time() > self.expires_at:
            return False
        return bool(self.signature)

    def to_aas_property(self) -> dict:
        return {
            "cert_id":   self.cert_id,
            "issuer":    self.issuer,
            "standard":  self.standard,
            "valid":     self.is_valid(),
            "expires":   time.strftime("%Y-%m-%d", time.localtime(self.expires_at))
                         if self.expires_at else "never",
        }


class CertificationAuthority:
    """
    Simulated third-party certification body (TÜV, CE, etc).
    Signs robot safety certifications using its own Ed25519 key.
    """

    def __init__(self, name: str = "PMCP-SafetyAuthority-v1"):
        self.name     = name
        self._privkey = Ed25519PrivateKey.generate()
        self._pubkey  = self._privkey.public_key()
        pub_raw = self._pubkey.public_bytes(Encoding.Raw, PublicFormat.Raw)
        self.pubkey_b64 = base64.b64encode(pub_raw).decode()
        logger.info(f"  🏛️   CA [{name}] initialised (key={self.pubkey_b64[:16]}...)")

    def certify(
        self,
        robot_did:  RobotDID,
        standard:   str = "ISO 10218-2:2011",
        valid_days: int = 365,
    ) -> SafetyCertification:
        cert_id  = f"CERT-{robot_did.robot_id.upper()}-{int(time.time())}"
        message  = f"{robot_did.did}:{cert_id}".encode()
        sig      = self._privkey.sign(message)

        cert = SafetyCertification(
            cert_id    = cert_id,
            robot_did  = robot_did.did,
            issuer     = self.name,
            standard   = standard,
            expires_at = time.time() + valid_days * 86400,
            signature  = base64.b64encode(sig).decode(),
            pubkey_b64 = robot_did.pubkey_b64,
        )
        logger.info(
            f"  🏛️   Certified [{robot_did.did}] under {standard} "
            f"(cert={cert_id}, expires={valid_days}d)"
        )
        return cert

    def verify_cert(self, cert: SafetyCertification, robot_did: RobotDID) -> bool:
        """Verify a cert was issued by this CA for this robot."""
        try:
            message = f"{robot_did.did}:{cert.cert_id}".encode()
            sig     = base64.b64decode(cert.signature)
            self._pubkey.verify(sig, message)
            return cert.is_valid()
        except InvalidSignature:
            return False
