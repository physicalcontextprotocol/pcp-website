"""
P-MCP v0.3 — Level 12: Decentralized Spatiotemporal Ledger
============================================================
"Blockchain for Spacetime — Emergent Swarm Intelligence"

Architecture:
  ┌─────────────────────────────────────────────────────────┐
  │            SPATIOTEMPORAL LEDGER (mesh-native)          │
  │                                                         │
  │  Robot joins mesh → reads occupied 4D envelopes →      │
  │  finds own gap in schedule → reserves → publishes      │
  │                                                         │
  │  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐    │
  │  │ARM-01│  │ARM-02│  │AMR-01│  │AMR-02│  │HAR-01│    │
  │  └──┬───┘  └──┬───┘  └──┬───┘  └──┬───┘  └──┬───┘    │
  │     └─────────┴──────────┴──────────┴──────────┘       │
  │                      P2P MESH                          │
  │              (Zenoh / CRDT ledger)                     │
  └─────────────────────────────────────────────────────────┘

No central server required. Works across network segments.
Each robot is a full peer — adds 100 robots without reconfiguration.

CRDT (Conflict-free Replicated Data Type):
    SpaceTimeSlot claims use CRDT Grow-Only Set (G-Set)
    Merging: union of all peers' slot sets
    Conflict: deterministic winner by (energy_bid DESC, robot_id ASC)

Zenoh integration:
    Key space: farm/{wing}/{zone}/{slot_id}
    Peers auto-discover via multicast or configured locators
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("a2a_ps.pmcp.ledger")


# ─────────────────────────────────────────────────────────────
#  LEDGER ENTRY  (the atom of spacetime coordination)
# ─────────────────────────────────────────────────────────────

@dataclass
class LedgerEntry:
    """
    One immutable spacetime reservation claim on the mesh ledger.
    Once published, only the originating robot can retract it.
    """
    entry_id:     str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    robot_id:     str   = ""
    zone_id:      str   = ""
    start_ms:     float = 0.0
    end_ms:       float = 0.0
    tool_name:    str   = ""
    energy_bid_j: float = 0.0    # For conflict resolution (higher wins)
    state:        str   = "claimed"   # claimed | confirmed | released | expired
    published_at: float = field(default_factory=time.time)
    signature:    str   = ""          # Robot DID signature (optional)

    def is_active(self) -> bool:
        return self.state in ("claimed", "confirmed") and self.end_ms > time.time() * 1000

    def overlaps(self, other: "LedgerEntry") -> bool:
        """4D conflict check: same zone, overlapping time, different robots."""
        if self.zone_id != other.zone_id:
            return False
        if self.robot_id == other.robot_id:
            return False
        same_time = self.start_ms < other.end_ms and self.end_ms > other.start_ms
        return same_time

    def conflict_winner(self, other: "LedgerEntry") -> "LedgerEntry":
        """Deterministic conflict resolution — higher bid wins, ties broken by robot_id."""
        if self.energy_bid_j > other.energy_bid_j:
            return self
        if other.energy_bid_j > self.energy_bid_j:
            return other
        # Tie-break: lexicographically smaller robot_id wins (deterministic)
        return self if self.robot_id < other.robot_id else other

    def to_dict(self) -> dict:
        return {
            "entry_id":     self.entry_id,
            "robot_id":     self.robot_id,
            "zone_id":      self.zone_id,
            "start_ms":     self.start_ms,
            "end_ms":       self.end_ms,
            "tool_name":    self.tool_name,
            "energy_bid_j": self.energy_bid_j,
            "state":        self.state,
            "published_at": self.published_at,
            "signature":    self.signature,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "LedgerEntry":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    def ledger_key(self) -> str:
        """Zenoh key for this entry: farm/{zone}/{entry_id}"""
        return f"farm/{self.zone_id}/{self.entry_id}"


# ─────────────────────────────────────────────────────────────
#  CRDT G-SET  (Conflict-free Replicated Data Type)
# ─────────────────────────────────────────────────────────────

class SpatiotemporalGSet:
    """
    CRDT Grow-Only Set of LedgerEntry claims.

    Properties:
        - Monotonically growing (entries only added, never truly deleted)
        - Released entries tombstoned (state → "released")
        - Merge = union, conflict resolution = deterministic winner
        - Convergent: any order of merges produces same final state

    In production: backed by Zenoh pub/sub for P2P synchronization.
    Each peer maintains a local copy, merges on message receipt.
    """

    def __init__(self, node_id: str):
        self.node_id  = node_id
        self._entries: Dict[str, LedgerEntry] = {}
        self._version = 0

    def claim(self, entry: LedgerEntry) -> Tuple[bool, Optional[str]]:
        """
        Attempt to claim a spacetime slot.
        Returns (success, conflicting_entry_id).
        """
        # Check for conflicts with active entries
        for existing in self._entries.values():
            if not existing.is_active():
                continue
            if entry.overlaps(existing):
                winner = entry.conflict_winner(existing)
                if winner.entry_id != entry.entry_id:
                    logger.warning(
                        f"  📒  LEDGER conflict: [{entry.robot_id}] "
                        f"lost to [{existing.robot_id}] in [{entry.zone_id}] "
                        f"(bid={entry.energy_bid_j}J vs {existing.energy_bid_j}J)"
                    )
                    return False, existing.entry_id
                else:
                    # We won — retract the loser
                    existing.state = "released"
                    logger.info(
                        f"  📒  LEDGER [{entry.robot_id}] outbid [{existing.robot_id}] "
                        f"in [{entry.zone_id}] ({entry.energy_bid_j}J vs {existing.energy_bid_j}J)"
                    )

        self._entries[entry.entry_id] = entry
        self._version += 1
        logger.info(
            f"  📒  LEDGER claim: [{entry.robot_id}] → [{entry.zone_id}] "
            f"{entry.start_ms:.0f}–{entry.end_ms:.0f}ms bid={entry.energy_bid_j}J"
        )
        return True, None

    def release(self, entry_id: str, robot_id: str) -> bool:
        """Tombstone an entry (only originating robot can release)."""
        entry = self._entries.get(entry_id)
        if not entry or entry.robot_id != robot_id:
            return False
        entry.state = "released"
        self._version += 1
        logger.info(f"  📒  LEDGER release: [{entry_id}] by [{robot_id}]")
        return True

    def merge(self, remote: "SpatiotemporalGSet"):
        """
        CRDT merge: union of entries.
        For conflicts: deterministic winner resolution.
        """
        merged = 0
        for entry_id, remote_entry in remote._entries.items():
            if entry_id not in self._entries:
                self._entries[entry_id] = remote_entry
                merged += 1
            else:
                local = self._entries[entry_id]
                # Later state wins (claimed < confirmed < released)
                state_order = {"claimed": 0, "confirmed": 1, "released": 2, "expired": 3}
                if state_order.get(remote_entry.state, 0) > state_order.get(local.state, 0):
                    self._entries[entry_id] = remote_entry
        if merged:
            logger.debug(f"  📒  Merged {merged} remote entries into [{self.node_id}] ledger")
            self._version += 1

    def get_zone_schedule(self, zone_id: str) -> List[LedgerEntry]:
        """Return all active entries for a zone, sorted by start time."""
        return sorted(
            [e for e in self._entries.values()
             if e.zone_id == zone_id and e.is_active()],
            key=lambda e: e.start_ms,
        )

    def find_next_free_slot(self, zone_id: str,
                             duration_ms: float,
                             earliest_ms: Optional[float] = None) -> float:
        """
        Find the earliest time when zone_id is free for duration_ms.
        O(n log n) where n = active entries in zone.
        """
        start = earliest_ms or time.time() * 1000
        schedule = self.get_zone_schedule(zone_id)

        candidate = start
        for slot in schedule:
            if slot.end_ms <= candidate:
                continue   # Already past
            if slot.start_ms > candidate + duration_ms:
                break      # Gap found before this slot
            candidate = slot.end_ms  # Push past this slot

        return candidate

    def cleanup_expired(self):
        now_ms = time.time() * 1000
        expired = [
            eid for eid, e in self._entries.items()
            if e.end_ms < now_ms and e.state in ("claimed", "confirmed")
        ]
        for eid in expired:
            self._entries[eid].state = "expired"

    def active_count(self) -> int:
        return sum(1 for e in self._entries.values() if e.is_active())

    def snapshot(self) -> List[dict]:
        return [e.to_dict() for e in self._entries.values() if e.is_active()]


# ─────────────────────────────────────────────────────────────
#  MESH LEDGER NODE  (each robot runs one of these)
# ─────────────────────────────────────────────────────────────

class MeshLedgerNode:
    """
    A single robot's view of the decentralized spatiotemporal ledger.

    Each robot runs a MeshLedgerNode which:
      1. Maintains its local CRDT G-Set
      2. Publishes claims to the Zenoh mesh
      3. Subscribes to other robots' claims and merges them
      4. Finds available 4D slots without asking a central server

    Scales to 100+ robots: no central coordinator needed.
    Add a robot → it joins the mesh, reads existing slots, self-schedules.
    """

    def __init__(self, robot_id: str,
                 zone_ids: Optional[List[str]] = None,
                 zenoh_locators: Optional[List[str]] = None):
        self.robot_id  = robot_id
        self.ledger    = SpatiotemporalGSet(node_id=robot_id)
        self._zones    = zone_ids or []
        self._locators = zenoh_locators or ["tcp/localhost:7447"]
        self._peers:   Dict[str, MeshLedgerNode] = {}  # Simulated peer registry
        self._claims:  List[str] = []  # entry_ids owned by this node
        self._session  = None          # Zenoh session (when enabled)

        logger.info(
            f"  🌐  MeshLedgerNode [{robot_id}] started | "
            f"zones={zone_ids} locators={self._locators}"
        )

    # ── Peer management (simulation) ─────────────────────────

    def connect_peer(self, peer: "MeshLedgerNode"):
        """In simulation: directly connect two nodes for CRDT sync."""
        self._peers[peer.robot_id] = peer
        peer._peers[self.robot_id] = self
        logger.debug(f"  📒  [{self.robot_id}] ↔ [{peer.robot_id}] peered")

    def sync_with_peers(self):
        """Pull and merge all peer ledgers (CRDT merge)."""
        for peer in self._peers.values():
            self.ledger.merge(peer.ledger)

    # ── Slot negotiation ──────────────────────────────────────

    def claim_slot(
        self,
        zone_id:      str,
        duration_ms:  float,
        tool_name:    str,
        energy_bid_j: float = 0.0,
        earliest_ms:  Optional[float] = None,
    ) -> Tuple[bool, Optional[LedgerEntry]]:
        """
        Autonomous slot acquisition:
        1. Sync with peers to get current state
        2. Find next free slot
        3. Claim it
        4. Broadcast to peers

        Returns (success, LedgerEntry).
        """
        # Step 1: Sync
        self.sync_with_peers()
        self.ledger.cleanup_expired()

        # Step 2: Find free slot
        start_ms = self.ledger.find_next_free_slot(zone_id, duration_ms, earliest_ms)
        end_ms   = start_ms + duration_ms

        # Step 3: Claim
        entry = LedgerEntry(
            robot_id     = self.robot_id,
            zone_id      = zone_id,
            start_ms     = start_ms,
            end_ms       = end_ms,
            tool_name    = tool_name,
            energy_bid_j = energy_bid_j,
        )
        success, conflict_id = self.ledger.claim(entry)

        if success:
            self._claims.append(entry.entry_id)
            # Step 4: Broadcast to peers (simulate Zenoh PUT)
            self._broadcast_claim(entry)

        return success, (entry if success else None)

    def release_slot(self, entry_id: str) -> bool:
        """Release a previously claimed slot."""
        success = self.ledger.release(entry_id, self.robot_id)
        if success and entry_id in self._claims:
            self._claims.remove(entry_id)
            self._broadcast_release(entry_id)
        return success

    def find_available_slot(self, zone_id: str,
                             duration_ms: float) -> Tuple[float, float]:
        """
        Read-only: find next available slot without claiming it.
        Used by orchestrators for pre-planning.
        """
        self.sync_with_peers()
        start_ms = self.ledger.find_next_free_slot(zone_id, duration_ms)
        return start_ms, start_ms + duration_ms

    # ── Broadcast (Zenoh stub → real) ─────────────────────────

    def _broadcast_claim(self, entry: LedgerEntry):
        """
        Publish claim to mesh. All peers subscribe and merge.

        Replace with real Zenoh:
            key = entry.ledger_key()
            payload = json.dumps(entry.to_dict()).encode()
            self._session.put(key, payload)
        """
        # Simulation: push directly to all peer ledgers
        for peer in self._peers.values():
            remote_gset = SpatiotemporalGSet(self.robot_id)
            remote_gset._entries[entry.entry_id] = entry
            peer.ledger.merge(remote_gset)

    def _broadcast_release(self, entry_id: str):
        """Broadcast release to peers."""
        for peer in self._peers.values():
            peer.ledger.release(entry_id, self.robot_id)

    # ── Introspection ─────────────────────────────────────────

    def zone_schedule(self, zone_id: str) -> List[dict]:
        """Return full schedule for a zone across all known peers."""
        self.sync_with_peers()
        return [
            {
                "robot_id":     e.robot_id,
                "start_ms":     e.start_ms,
                "end_ms":       e.end_ms,
                "duration_ms":  e.end_ms - e.start_ms,
                "tool_name":    e.tool_name,
                "energy_bid_j": e.energy_bid_j,
                "state":        e.state,
            }
            for e in self.ledger.get_zone_schedule(zone_id)
        ]

    def my_schedule(self) -> List[dict]:
        """Return this robot's current claimed slots."""
        return [
            e.to_dict() for e in self.ledger._entries.values()
            if e.robot_id == self.robot_id and e.is_active()
        ]

    def farm_utilization(self) -> dict:
        """Overall farm space-time utilization across all zones."""
        self.sync_with_peers()
        now_ms = time.time() * 1000
        horizon_ms = now_ms + 60_000  # 1-minute lookahead

        utilization = {}
        for zone_id in self._zones:
            schedule = self.ledger.get_zone_schedule(zone_id)
            occupied_ms = sum(
                min(e.end_ms, horizon_ms) - max(e.start_ms, now_ms)
                for e in schedule
                if e.start_ms < horizon_ms and e.end_ms > now_ms
            )
            utilization[zone_id] = round(
                100 * occupied_ms / max(horizon_ms - now_ms, 1), 1
            )

        active_robots = {
            e.robot_id for e in self.ledger._entries.values()
            if e.is_active()
        }
        return {
            "zone_utilization_pct": utilization,
            "active_robots":        list(active_robots),
            "total_claims":         self.ledger.active_count(),
            "ledger_version":       self.ledger._version,
        }

    def stats(self) -> dict:
        return {
            "robot_id":      self.robot_id,
            "peers":         list(self._peers.keys()),
            "my_claims":     len(self._claims),
            "total_entries": len(self.ledger._entries),
            "active_entries": self.ledger.active_count(),
            "ledger_version": self.ledger._version,
        }


# ─────────────────────────────────────────────────────────────
#  DECENTRALIZED FARM COORDINATOR
# ─────────────────────────────────────────────────────────────

class DecentralizedFarmCoordinator:
    """
    Replaces PMCPServer's central zone management with mesh-native coordination.

    Drop-in replacement for DigitalTwin.reserve_zone() and release_zone_reservation():
        coordinator.claim(robot_id, zone_id, duration_ms, ...) → LedgerEntry
        coordinator.release(robot_id, entry_id)

    Scales horizontally: adding robot_id "arm-99" just requires:
        coordinator.add_robot("arm-99")
    No server reconfiguration. No central database.
    """

    FARM_ZONES = [
        "grow_zone_a", "grow_zone_b", "grow_zone_c",
        "charging_dock", "harvest_station", "maintenance_corridor",
        "transit_lane_1", "transit_lane_2",
    ]

    def __init__(self):
        self._nodes: Dict[str, MeshLedgerNode] = {}
        logger.info("  🌐  DecentralizedFarmCoordinator started (mesh mode)")

    def add_robot(self, robot_id: str,
                  zenoh_locators: Optional[List[str]] = None) -> MeshLedgerNode:
        """
        Add a robot to the mesh. It will auto-discover existing claims.
        """
        node = MeshLedgerNode(
            robot_id     = robot_id,
            zone_ids     = self.FARM_ZONES,
            zenoh_locators = zenoh_locators or [],
        )
        # Connect to all existing nodes (full mesh topology)
        for existing_node in self._nodes.values():
            node.connect_peer(existing_node)
        # Sync existing state
        node.sync_with_peers()

        self._nodes[robot_id] = node
        logger.info(
            f"  🌐  Robot [{robot_id}] joined mesh | "
            f"peers={list(self._nodes.keys())[:-1]}"
        )
        return node

    def claim(
        self,
        robot_id:     str,
        zone_id:      str,
        duration_ms:  float,
        tool_name:    str,
        energy_bid_j: float = 0.0,
    ) -> Tuple[bool, Optional[LedgerEntry]]:
        """Reserve a spacetime slot for robot_id in zone_id."""
        node = self._nodes.get(robot_id)
        if not node:
            node = self.add_robot(robot_id)

        return node.claim_slot(zone_id, duration_ms, tool_name, energy_bid_j)

    def release(self, robot_id: str, entry_id: str) -> bool:
        node = self._nodes.get(robot_id)
        if not node:
            return False
        return node.release_slot(entry_id)

    def find_slot(self, robot_id: str, zone_id: str,
                  duration_ms: float) -> Tuple[float, float]:
        node = self._nodes.get(robot_id)
        if not node:
            node = self.add_robot(robot_id)
        return node.find_available_slot(zone_id, duration_ms)

    def zone_schedule(self, zone_id: str) -> List[dict]:
        """Get full zone schedule from any node (all converge to same view)."""
        if not self._nodes:
            return []
        node = next(iter(self._nodes.values()))
        node.sync_with_peers()
        return node.zone_schedule(zone_id)

    def farm_utilization(self) -> dict:
        """Farm-wide utilization from any node's perspective."""
        if not self._nodes:
            return {}
        node = next(iter(self._nodes.values()))
        return node.farm_utilization()

    def global_stats(self) -> dict:
        return {
            "robots_in_mesh": len(self._nodes),
            "per_robot":      {rid: n.stats() for rid, n in self._nodes.items()},
            "farm_utilization": self.farm_utilization(),
        }
