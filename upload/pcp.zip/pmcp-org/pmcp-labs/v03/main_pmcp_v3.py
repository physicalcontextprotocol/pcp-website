"""
P-MCP v0.3 Demo — Sovereign Infrastructure Layer
==================================================
Complete integration of all four "deep tech" frontiers:

  Level 9:  TEE Safety Constitution (Ed25519 DID + hardware token gate)
  Level 10: Metabolic Twin (APSIM crop model + Autonomous SLA engine)
  Level 11: Real-Time Physics HIL (PyBullet ghost robot / geometric fallback)
  Level 12: Decentralized Spatiotemporal Ledger (mesh-native CRDT)

Run:
    python main_pmcp_v3.py

Architecture stack:
    LLM Agent
       ↓  signed DID call
    TEECommandGate (Level 9)
       ↓  HardwareToken
    PMCPServer v0.2
       ↓  validate
    ShadowValidator + HILShadowExtension (Level 11)
       ↓  ghost collision check
    DigitalTwin + MetabolicTwin (Level 10)
       ↓  SLA events → re-price auction bids
    DecentralizedFarmCoordinator (Level 12)
       ↓  mesh CRDT reservation
    Robot Hardware
"""

import asyncio
import logging
import sys
import time

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("pmcp.v3.demo")
logging.getLogger("asyncio").setLevel(logging.WARNING)

sys.path.insert(0, "/home/claude/pmcp_v3")
sys.path.insert(0, "/home/claude")

# ── v0.2 core ─────────────────────────────────────────────────
from a2a_ps.pmcp.shadow import DigitalTwin
from a2a_ps.pmcp.server import PMCPServer
from a2a_ps.pmcp.schemas import Vec3, Pose
from a2a_ps.robots.agents import RoboticArmAgent, AMRAgent, HarvesterRobot

# ── v0.3 sovereign infrastructure ─────────────────────────────
from pmcp_tee      import (
    TEESimulator, TEECommandGate, RobotDID,
    SafetyConstitution, CertificationAuthority,
)
from pmcp_metabolic import (
    MetabolicTwin, CropEnvironment, CropState,
    CropGrowthModel, AutonomousSLAEngine,
)
from pmcp_physics_hil import (
    PyBulletGhostSimulator, HILShadowExtension,
)
from pmcp_ledger import (
    DecentralizedFarmCoordinator, MeshLedgerNode, LedgerEntry,
)


def banner(title: str, subtitle: str = ""):
    w = 68
    print(f"\n{'═'*w}")
    print(f"  {title}")
    if subtitle:
        print(f"  {subtitle}")
    print(f"{'═'*w}")


def section(n: int, title: str):
    print(f"\n  ── Level {n}: {title} {'─'*(52-len(title))}")


# ─────────────────────────────────────────────────────────────
#  LEVEL 9 DEMO: TEE + DID
# ─────────────────────────────────────────────────────────────

async def demo_tee_layer(server: PMCPServer, twin: DigitalTwin):
    section(9, "TEE Safety Constitution + DID Identity")

    # Boot TEE and create robot DIDs
    tee = TEESimulator()
    ca  = CertificationAuthority("PMCP-SafetyAuthority-v1")

    arm_did = RobotDID("arm-01")
    amr_did = RobotDID("amr-01")

    # Certify robots for MOTION category
    arm_cert = ca.certify(arm_did, standard="ISO 10218-2:2011", valid_days=365)
    amr_cert = ca.certify(amr_did, standard="ISO 3691-4:2020",  valid_days=365)

    logger.info(f"\n  📋  Constitution rules embedded in TEE:")
    for rule in tee.constitution_rules():
        logger.info(f"       [{rule['id']}] {rule['description']}")

    # Set up TEE gate
    gate = TEECommandGate(
        server     = server,
        tee        = tee,
        robot_dids = {"arm-01": arm_did, "amr-01": amr_did},
    )

    # ── Test 1: Valid call — should get token ──────────────────
    logger.info(f"\n  🔑  Test 1: Valid move — TEE should approve")
    call = await server.invoke(
        "move_to", caller_id="demo-agent",
        x=0.8, y=0.6, z=0.5, speed=0.3,
    )
    if call.projected and call.projected.safe_to_execute:
        result = await gate.tee_confirm(call.call_id, caller_did=arm_did)
        status = "✅  TEE APPROVED" if result.success else f"❌  {result.message}"
        logger.info(f"  {status}")

    # ── Test 2: Speed violation — Constitution CONST-01 ────────
    logger.info(f"\n  🔑  Test 2: Speed=2.5 m/s — TEE CONST-01 should veto")
    call2 = await server.invoke(
        "move_to", caller_id="fast-agent",
        x=1.0, y=1.0, z=0.5, speed=2.5,   # Violates CONST-01
    )
    # Manually test TEE (shadow might also block, but TEE is independent)
    token, violations = tee.request_hardware_token(
        call_id   = "test-speed",
        robot_id  = "arm-01",
        tool_name = "move_to",
        arguments = {"x": 1.0, "y": 1.0, "z": 0.5, "speed": 2.5},
        energy_j  = 120.0,
        shadow_ts = time.time() - 0.1,  # Fresh shadow
    )
    if violations:
        logger.info(f"  🔒  TEE VETO (as expected):")
        for v in violations:
            logger.warning(f"       {v}")
    await server.abort(call2.call_id, "tee-veto-demo")

    # ── Test 3: Stale shadow — Constitution CONST-04 ───────────
    logger.info(f"\n  🔑  Test 3: Stale shadow (0.8s old) — TEE CONST-04")
    token3, violations3 = tee.request_hardware_token(
        call_id   = "test-stale",
        robot_id  = "arm-01",
        tool_name = "move_to",
        arguments = {"x": 0.5, "y": 0.5, "z": 0.4, "speed": 0.2},
        energy_j  = 80.0,
        shadow_ts = time.time() - 0.8,   # 800ms old — violates CONST-04
    )
    if violations3:
        logger.info(f"  🔒  TEE VETO stale shadow (as expected): {violations3[0]}")

    # ── Test 4: Token replay attack ────────────────────────────
    logger.info(f"\n  🔑  Test 4: Token replay attack prevention")
    valid_call = await server.invoke(
        "move_to", caller_id="demo-agent",
        x=0.5, y=0.5, z=0.4, speed=0.2,
    )
    if valid_call.projected and valid_call.projected.safe_to_execute:
        token4, _ = tee.request_hardware_token(
            call_id   = valid_call.call_id,
            robot_id  = "arm-01",
            tool_name = "move_to",
            arguments = valid_call.arguments,
            energy_j  = valid_call.projected.energy_j,
            shadow_ts = time.time() - 0.05,
        )
        if token4:
            # First use
            ok1, msg1 = tee.verify_and_consume_token(token4)
            # Replay
            ok2, msg2 = tee.verify_and_consume_token(token4)
            logger.info(f"  First use:  {'✅' if ok1 else '❌'}  {msg1}")
            logger.info(f"  Replay:     {'✅' if ok2 else '🛡️  BLOCKED'} {msg2}")
        await server.abort(valid_call.call_id, "demo-cleanup")

    tee_stats = tee.stats()
    logger.info(f"\n  📊  TEE Stats:")
    for k, v in tee_stats.items():
        logger.info(f"       {k}: {v}")

    return tee, gate, arm_did, arm_cert


# ─────────────────────────────────────────────────────────────
#  LEVEL 10 DEMO: METABOLIC TWIN
# ─────────────────────────────────────────────────────────────

async def demo_metabolic_twin(server: PMCPServer, twin: DigitalTwin):
    section(10, "Metabolic Twin — Bio-Economic SLA Optimization")

    mtwin = MetabolicTwin(twin)

    # Register trays and robot roles
    for tray_id in ["tray-1-0", "tray-1-1", "tray-2-0"]:
        mtwin.register_tray(tray_id, crop_type="basil")

    mtwin.register_harvester("harvester-01")
    mtwin.register_harvester("arm-01")
    mtwin.register_climate_robot("amr-01")   # AMR operates humidifiers in demo

    model = CropGrowthModel()

    # ── Scenario A: Healthy conditions ─────────────────────────
    logger.info(f"\n  🌿  Scenario A: Optimal growing conditions")
    env_good = CropEnvironment(
        vpd_kpa          = 0.8,
        par_umol_m2s     = 350.0,
        air_temp_c       = 23.0,
        humidity_pct     = 68.0,
        co2_ppm          = 800.0,
        soil_moisture_pct = 75.0,
    )
    state_a, events_a = mtwin.step_tray("tray-1-0", env_good, dt_hours=1.0)
    logger.info(f"  📊  tray-1-0 after 1h (optimal):")
    logger.info(f"       RGR: {state_a.rgr_g_g_day:.4f} g/g/day")
    logger.info(f"       Health: {state_a.health_score():.3f}")
    logger.info(f"       Stomata conductance: {state_a.stomata_conductance:.3f}")
    logger.info(f"       Transpiration: {state_a.transpiration_g_h:.1f} g/h")
    logger.info(f"       Yield forecast: {state_a.yield_forecast_g:.0f}g")
    logger.info(f"       SLA events fired: {len(events_a)}")

    # ── Scenario B: VPD spike — stomata close → SLA fires ──────
    logger.info(f"\n  🌿  Scenario B: VPD spike to 2.1 kPa — stomata closing")
    env_stress = CropEnvironment(
        vpd_kpa          = 2.1,    # High — stomata will close
        par_umol_m2s     = 350.0,
        air_temp_c       = 32.0,   # Hot
        humidity_pct     = 40.0,   # Low humidity
        co2_ppm          = 800.0,
        soil_moisture_pct = 60.0,
    )
    state_b, events_b = mtwin.step_tray("tray-1-1", env_stress, dt_hours=1.0)
    logger.info(f"  📊  tray-1-1 after 1h (stress):")
    logger.info(f"       Stomata: {state_b.stomata_conductance:.4f} (was ~0.15)")
    logger.info(f"       Stress index: {state_b.stress_index:.3f}")
    logger.info(f"       Health: {state_b.health_score():.3f}")
    logger.info(f"       Yield forecast: {state_b.yield_forecast_g:.0f}g")
    logger.info(f"       SLA events fired: {len(events_b)}")

    for e in events_b:
        logger.warning(f"\n  🚨  SLA EVENT: [{e.trigger.value}]")
        logger.warning(f"       {e.description}")
        logger.warning(f"       Value at risk: ${e.value_at_risk_usd:.2f}")
        logger.warning(f"       Deprioritize: {e.deprioritize_robots}")
        logger.warning(f"       Prioritize:   {e.prioritize_robots}")
        logger.warning(f"       Energy grant: +{e.energy_grant_j:.0f}J to priority robots")

    # Show bio-economic utility re-pricing
    logger.info(f"\n  💹  Bio-Economic Utility After SLA (tray-1-1):")
    for rid in ["arm-01", "harvester-01", "amr-01"]:
        util = mtwin.bio_economic_utility(rid, "tray-1-1")
        energy_grant = mtwin.sla.get_energy_grant(rid)
        logger.info(
            f"       [{rid}]: utility={util:.3f} "
            + (f"energy_grant=+{energy_grant:.0f}J" if energy_grant else "")
        )

    # ── Scenario C: Harvest window opens ───────────────────────
    logger.info(f"\n  🌿  Scenario C: Mature crop — harvest window")
    mature_state = CropState(
        tray_id       = "tray-2-0",
        biomass_g_m2  = 118.0,   # Near harvest threshold
        harvest_quality = 0.92,
        stress_index  = 0.1,
        days_to_maturity = 1.2,
        leaf_area_index = 4.0,
    )
    mtwin._trays["tray-2-0"] = mature_state
    _, events_c = mtwin.step_tray("tray-2-0", env_good, dt_hours=0.5)
    for e in events_c:
        logger.info(f"  🌾  SLA: [{e.trigger.value}] → {e.description}")

    # Farm economic summary
    summary = mtwin.farm_economic_summary()
    logger.info(f"\n  💰  Farm Economic Summary:")
    logger.info(f"       Total trays:       {summary['total_trays']}")
    logger.info(f"       Total biomass:     {summary['total_biomass_g_m2']:.0f} g/m²")
    logger.info(f"       Total value:       ${summary['total_value_usd']:.2f}")
    logger.info(f"       Stressed trays:    {summary['stressed_trays']}")
    logger.info(f"       Active SLAs:       {summary['active_slas']}")

    return mtwin


# ─────────────────────────────────────────────────────────────
#  LEVEL 11 DEMO: PHYSICS HIL
# ─────────────────────────────────────────────────────────────

async def demo_physics_hil(server: PMCPServer, twin: DigitalTwin):
    section(11, "Real-Time Physics HIL — Ghost Robot Simulation")

    ghost = PyBulletGhostSimulator()
    hil   = HILShadowExtension(ghost)

    # Register arm joints with initial physics state
    for j in range(6):
        ghost.register_joint("arm-01", j, f"joint_{j}")

    # Add grow rack obstacles
    ghost.add_obstacle("rack_A", center_x=1.0, center_y=0.5, center_z=1.2,
                        radius_x=0.3, radius_y=0.05, radius_z=0.5)
    ghost.add_obstacle("rack_B", center_x=1.0, center_y=1.5, center_z=1.2,
                        radius_x=0.3, radius_y=0.05, radius_z=0.5)
    ghost.add_obstacle("pipe_top", center_x=1.5, center_y=1.0, center_z=2.3,
                        radius_x=2.0, radius_y=2.0, radius_z=0.05)

    logger.info(f"  {'🔬' if ghost._use_pybullet else '📐'}  "
                f"Using: {'PyBullet full mesh' if ghost._use_pybullet else 'Geometric capsule fallback'}")

    # ── Test 1: Safe trajectory ────────────────────────────────
    logger.info(f"\n  👻  Test 1: Safe trajectory (1.5, 1.0, 0.5) → (0.8, 0.6, 0.4)")
    result1 = ghost.check_trajectory(
        "arm-01",
        start_x=1.5, start_y=1.0, start_z=0.5,
        target_x=0.8, target_y=0.6, target_z=0.4,
        n_steps=15,
    )
    logger.info(f"  Safe: {result1.safe}  min_dist: {result1.min_distance_m:.3f}m  "
                f"sim_time: {result1.simulation_time_ms:.2f}ms")
    logger.info(f"  Ghost joint torques (predicted): "
                f"{[round(t, 2) for t in result1.joint_torques_nm]}")

    # ── Test 2: Near-obstacle trajectory ──────────────────────
    logger.info(f"\n  👻  Test 2: Path near rack_A obstacle")
    result2 = ghost.check_trajectory(
        "arm-01",
        start_x=1.5, start_y=1.0, start_z=0.5,
        target_x=0.7, target_y=0.5, target_z=1.1,   # Close to rack_A
        n_steps=20,
    )
    logger.info(f"  Safe: {result2.safe}  min_dist: {result2.min_distance_m:.3f}m")
    if not result2.safe:
        for c in result2.collisions[:3]:
            logger.warning(f"  ⚠  {c}")

    # ── HIL feedback loop ──────────────────────────────────────
    logger.info(f"\n  👻  HIL Feedback Loop — 10 executions with torque data")
    for i in range(10):
        # Simulate increasing wear (torque errors grow over time)
        torque_errors = [0.3 + i * 0.15 + (j * 0.1) for j in range(6)]
        hil.ingest_hil_feedback("arm-01", torque_errors)

    # Show evolved joint physics
    logger.info(f"\n  📊  Joint Physics After HIL Calibration:")
    for j in range(6):
        js = ghost.get_joint("arm-01", j)
        if js:
            logger.info(
                f"       joint_{j}: friction={js.friction_nm:.3f}Nm "
                f"wear={js.wear_factor:.3f} "
                + ("⚠ MAINTENANCE" if js.maintenance_required() else "✓")
            )

    # Updated ghost sim uses calibrated physics
    logger.info(f"\n  👻  Test 3: Same trajectory with calibrated physics")
    result3 = ghost.check_trajectory(
        "arm-01",
        start_x=1.5, start_y=1.0, start_z=0.5,
        target_x=0.8, target_y=0.6, target_z=0.4,
        n_steps=15,
    )
    logger.info(
        f"  Updated torques: {[round(t, 2) for t in result3.joint_torques_nm]} "
        f"(vs {[round(t, 2) for t in result1.joint_torques_nm]} before)"
    )

    stats = ghost.stats()
    logger.info(f"\n  📊  Ghost Sim Stats:")
    for k, v in stats.items():
        logger.info(f"       {k}: {v}")

    return ghost, hil


# ─────────────────────────────────────────────────────────────
#  LEVEL 12 DEMO: DECENTRALIZED LEDGER
# ─────────────────────────────────────────────────────────────

async def demo_decentralized_ledger():
    section(12, "Decentralized Spatiotemporal Ledger — Emergent Swarm")

    coordinator = DecentralizedFarmCoordinator()

    # Add initial robots to mesh
    for rid in ["arm-01", "amr-01", "harvester-01"]:
        coordinator.add_robot(rid)

    logger.info(f"\n  📒  Test 1: Simultaneous slot claims — no central server")

    # Three robots claim different zones simultaneously
    claims = {}
    for robot_id, zone_id, duration, bid in [
        ("arm-01",       "grow_zone_a", 3000.0, 80.0),
        ("amr-01",       "harvest_station", 8000.0, 40.0),
        ("harvester-01", "grow_zone_a", 5000.0, 60.0),  # Competing with arm-01
    ]:
        success, entry = coordinator.claim(
            robot_id     = robot_id,
            zone_id      = zone_id,
            duration_ms  = duration,
            tool_name    = "demo_tool",
            energy_bid_j = bid,
        )
        claims[robot_id] = (success, entry)
        status = f"✅ CLAIMED [{entry.entry_id if entry else '?'}] " \
                 f"start={entry.start_ms:.0f}ms" if success and entry else "⏳ QUEUED"
        logger.info(
            f"  [{robot_id}] zone=[{zone_id}] bid={bid}J → {status}"
        )

    # Show zone schedule — who owns grow_zone_a?
    schedule = coordinator.zone_schedule("grow_zone_a")
    logger.info(f"\n  📒  grow_zone_a schedule (from any peer — all converge):")
    for slot in schedule:
        logger.info(
            f"       [{slot['robot_id']}] {slot['start_ms']:.0f}–{slot['end_ms']:.0f}ms "
            f"bid={slot['energy_bid_j']}J state={slot['state']}"
        )

    # ── Scale test: add 10 more robots ─────────────────────────
    logger.info(f"\n  📒  Test 2: Scale to 13 robots — no server reconfiguration")
    for i in range(4, 14):
        rid = f"arm-{i:02d}"
        coordinator.add_robot(rid)
        success, entry = coordinator.claim(
            robot_id     = rid,
            zone_id      = f"grow_zone_{'abc'[i % 3]}",
            duration_ms  = 2000.0 + i * 100,
            tool_name    = "move_to",
            energy_bid_j = 50.0 + i * 5,
        )

    util = coordinator.farm_utilization()
    logger.info(f"\n  📒  Farm Utilization (60s lookahead) after scale:")
    logger.info(f"       Active robots: {util['active_robots']}")
    logger.info(f"       Total claims:  {util['total_claims']}")
    for zone, pct in util["zone_utilization_pct"].items():
        bar = "▓" * int(pct / 5)
        logger.info(f"       {zone:<25} {pct:>5.1f}%  {bar}")

    # ── Release and re-claim ────────────────────────────────────
    logger.info(f"\n  📒  Test 3: Release arm-01's slot → harvester-01 fills gap")
    arm_entry = claims.get("arm-01", (None, None))[1]
    if arm_entry:
        coordinator.release("arm-01", arm_entry.entry_id)
        logger.info(f"  arm-01 released [{arm_entry.entry_id}] in grow_zone_a")

    # harvester-01 finds earlier slot now
    new_start, new_end = coordinator.find_slot("harvester-01", "grow_zone_a", 3000.0)
    logger.info(
        f"  harvester-01 can now claim grow_zone_a at "
        f"{new_start:.0f}ms (earlier than before)"
    )

    # ── CRDT merge verification ─────────────────────────────────
    logger.info(f"\n  📒  Test 4: CRDT convergence verification")
    stats = coordinator.global_stats()
    logger.info(f"  Robots in mesh: {stats['robots_in_mesh']}")

    # All nodes should have same active count (CRDT convergence)
    active_counts = [
        n["active_entries"] for n in stats["per_robot"].values()
    ]
    converged = len(set(active_counts)) == 1
    logger.info(
        f"  Active entries per node: {set(active_counts)} "
        f"({'✅ CONVERGED' if converged else '⚠ DIVERGED'})"
    )
    logger.info(
        f"  Ledger versions: "
        f"{set(n['ledger_version'] for n in stats['per_robot'].values())}"
    )

    return coordinator


# ─────────────────────────────────────────────────────────────
#  INTEGRATED DEMO: ALL LEVELS TOGETHER
# ─────────────────────────────────────────────────────────────

async def demo_integrated_harvest(
    server: PMCPServer, twin: DigitalTwin,
    tee: TEESimulator, arm_did: RobotDID,
    mtwin: MetabolicTwin, ghost: PyBulletGhostSimulator,
    coordinator: DecentralizedFarmCoordinator,
):
    section(0, "INTEGRATED: All 4 Levels — Full Autonomous Harvest")

    logger.info("  🎯  Goal: Harvest tray-1-0 using all sovereign infrastructure layers")
    logger.info("  Flow: Metabolic check → Ledger reservation → Ghost sim → TEE gate → Execute\n")

    TRAY_ID  = "tray-1-0"
    ROBOT_ID = "arm-01"
    ZONE_ID  = "grow_zone_a"

    # ── Step 1: Bio-economic utility check (Level 10) ──────────
    logger.info("  [L10] Metabolic Twin: checking bio-economic utility...")
    env = CropEnvironment(
        vpd_kpa=0.9, par_umol_m2s=320.0, air_temp_c=23.0,
        humidity_pct=65.0, co2_ppm=800.0, soil_moisture_pct=72.0,
    )
    state, sla_events = mtwin.step_tray(TRAY_ID, env, dt_hours=0.1)
    utility = mtwin.bio_economic_utility(ROBOT_ID, TRAY_ID)
    harvest_value = state.harvest_value_usd()

    logger.info(f"  [L10] Tray health: {state.health_score():.3f}  "
                f"utility: {utility:.3f}  value: ${harvest_value:.2f}")

    if sla_events:
        logger.warning(f"  [L10] {len(sla_events)} SLA events — checking robot priority...")
    else:
        logger.info(f"  [L10] No SLA restrictions — harvester has full priority")

    # ── Step 2: Ledger reservation (Level 12) ─────────────────
    logger.info(f"\n  [L12] Decentralized Ledger: claiming spacetime slot...")
    success, ledger_entry = coordinator.claim(
        robot_id     = ROBOT_ID,
        zone_id      = ZONE_ID,
        duration_ms  = 5000.0,
        tool_name    = "move_to",
        energy_bid_j = utility * 120,   # Bid proportional to bio-economic utility
    )
    if success and ledger_entry:
        logger.info(
            f"  [L12] ✅ Slot reserved: [{ledger_entry.entry_id}] "
            f"bid={ledger_entry.energy_bid_j:.0f}J"
        )
    else:
        logger.warning(f"  [L12] Zone conflict — will retry with higher bid")

    # ── Step 3: Ghost collision check (Level 11) ───────────────
    logger.info(f"\n  [L11] Ghost Robot: pre-flight collision simulation...")
    current_pose = twin.get_pose(ROBOT_ID)
    start = current_pose.position if current_pose else Vec3(1.5, 1.0, 0.5)
    target = Vec3(1.0, 0.8, 0.45)

    hil_ext = HILShadowExtension(ghost)
    ghost_risks = hil_ext.check(ROBOT_ID, start, target)

    if ghost_risks:
        logger.warning(f"  [L11] Ghost BLOCKED:")
        for r in ghost_risks:
            logger.warning(f"         {r}")
        # Release ledger slot
        if success and ledger_entry:
            coordinator.release(ROBOT_ID, ledger_entry.entry_id)
        logger.info("  [L11] Ledger slot released — aborting harvest")
        return
    else:
        logger.info(f"  [L11] ✅ Ghost CLEAR — path safe for hardware execution")

    # ── Step 4: TEE gate (Level 9) ────────────────────────────
    logger.info(f"\n  [L9]  TEE Gate: requesting hardware token...")
    call = await server.invoke(
        "move_to", caller_id="integrated-demo",
        x=target.x, y=target.y, z=target.z, speed=0.25,
    )

    if call.projected and call.projected.safe_to_execute:
        token, tee_violations = tee.request_hardware_token(
            call_id   = call.call_id,
            robot_id  = ROBOT_ID,
            tool_name = "move_to",
            arguments = call.arguments,
            energy_j  = call.projected.energy_j,
            shadow_ts = time.time() - 0.05,
        )

        if token:
            logger.info(
                f"  [L9]  ✅ TEE TOKEN: [{token.token_id}] "
                f"TTL={token.ttl_ms:.0f}ms"
            )
            # Verify and consume before hardware executes
            ok, msg = tee.verify_and_consume_token(token)
            logger.info(f"  [L9]  Hardware gate: {'✅ OPEN' if ok else '🛑 BLOCKED'} — {msg}")

            if ok:
                # Execute
                result = await server.confirm(call.call_id)
                logger.info(
                    f"\n  🤖  HARDWARE EXECUTED: "
                    f"{'✅' if result.success else '❌'} {result.message}"
                )
                # Feed torques back to ghost sim (self-healing)
                if result.joint_torque_error_nm:
                    hil_ext.ingest_hil_feedback(ROBOT_ID, result.joint_torque_error_nm)
                    logger.info(f"  [L11] HIL torques ingested → ghost model updated")
        else:
            logger.warning(f"  [L9]  TEE VETO: {tee_violations}")
            await server.abort(call.call_id, "tee-veto")
    else:
        risks = call.projected.risk_reasons if call.projected else []
        logger.warning(f"  Shadow blocked: {risks}")
        await server.abort(call.call_id, "shadow-blocked")

    # Release ledger
    if success and ledger_entry:
        coordinator.release(ROBOT_ID, ledger_entry.entry_id)
        logger.info(f"  [L12] Ledger slot released")

    logger.info(f"\n  ✅  Integrated harvest demo complete")
    logger.info(f"  All 4 sovereign infrastructure layers exercised.")


# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

async def main():
    banner(
        "P-MCP v0.3  |  Sovereign Infrastructure Layer",
        "TEE · Metabolic Twin · Physics HIL · Decentralized Ledger",
    )

    # ── Bootstrap v0.2 core ────────────────────────────────────
    print("\n  Bootstrapping P-MCP v0.2 core...")
    twin   = DigitalTwin(power_budget_w=8000.0)
    server = PMCPServer("farm-pmcp-v3", twin, confirm_timeout_ms=8000)

    arm       = RoboticArmAgent(server, robot_id="arm-01",
                                base_pose=Pose(position=Vec3(1.5, 1.0, 0.5)))
    amr       = AMRAgent(server, robot_id="amr-01",
                          initial_pose=Pose(position=Vec3(4.5, 0.5, 0.0)))
    harvester = HarvesterRobot(server, robot_id="harvester-01",
                                initial_pose=Pose(position=Vec3(2.0, 2.0, 0.0)))

    print(f"  ✅  v0.2 core ready: {len(server._tools)} tools, "
          f"{len(server._resources)} resources\n")

    # ── Level 9: TEE ────────────────────────────────────────────
    tee, gate, arm_did, arm_cert = await demo_tee_layer(server, twin)

    # ── Level 10: Metabolic Twin ────────────────────────────────
    mtwin = await demo_metabolic_twin(server, twin)

    # ── Level 11: Physics HIL ────────────────────────────────────
    ghost, hil = await demo_physics_hil(server, twin)

    # ── Level 12: Decentralized Ledger ──────────────────────────
    coordinator = await demo_decentralized_ledger()

    # ── Integrated: all 4 layers ────────────────────────────────
    await demo_integrated_harvest(
        server, twin, tee, arm_did, mtwin, ghost, coordinator
    )

    # ── Final stats ──────────────────────────────────────────────
    banner("P-MCP v0.3 Session Complete")
    stats = server.stats()
    logger.info(f"  Tool calls:      {stats['calls_total']}")
    logger.info(f"  By status:       {stats['calls_by_status']}")
    logger.info(f"  Block rate:      {stats['shadow']['block_rate_pct']}%")
    logger.info(f"  TEE tokens:      {tee.stats()['tokens_issued']} issued, "
                f"{tee.stats()['tokens_consumed']} consumed")
    logger.info(f"  TEE vetoes:      {tee.stats()['constitution_vetoes']}")
    logger.info(f"  Ghost sim calls: {ghost.stats()['sim_calls']}")
    logger.info(f"  Mesh robots:     {coordinator.global_stats()['robots_in_mesh']}")
    logger.info(f"  Ledger entries:  "
                f"{coordinator.global_stats()['farm_utilization'].get('total_claims', '?')}")
    print()
    print("  P-MCP v0.3 — Sovereign Infrastructure Layer demo complete. 🔒🌱👻🌐\n")


if __name__ == "__main__":
    asyncio.run(main())
