"""
P-MCP v0.3 — Level 11: Real-Time Physics HIL (PyBullet Integration)
=====================================================================
"The Ghost Robot — Every move simulated before silicon moves"

Architecture:
  ┌─────────────────────────────────────────────────────────┐
  │                GHOST SIMULATION WORLD                   │
  │                                                         │
  │  PyBullet DIRECT (headless, sub-ms per step)           │
  │                                                         │
  │  ┌──────────┐   ┌──────────┐   ┌───────────────────┐  │
  │  │ Ghost ARM│   │ Obstacles│   │  Grow Rack Mesh   │  │
  │  │ (URDF)   │   │ (capsules│   │  (box primitives) │  │
  │  └────┬─────┘   └──────────┘   └───────────────────┘  │
  │       │                                                 │
  │  Ghost moves → getClosestPoints() → collision?        │
  │  Ghost computes joint torques → compare with model    │
  └───────┬─────────────────────────────────────────────────┘
          │  safe_to_execute=False if collision detected
  ┌───────▼─────────────────────────────────────────────────┐
  │              SELF-HEALING TWIN UPDATE                   │
  │  joint_torque_error_nm from HIL →                      │
  │  update friction_coeff, gravity_comp per joint         │
  │  → next shadow prediction is more accurate             │
  └─────────────────────────────────────────────────────────┘

PyBullet installation: pip install pybullet
When PyBullet unavailable: falls back to enhanced geometric simulation
(tube check + capsule approximation) which runs in pure Python.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("a2a_ps.pmcp.physics_hil")


# ─────────────────────────────────────────────────────────────
#  PYBULLET AVAILABILITY CHECK
# ─────────────────────────────────────────────────────────────

try:
    import pybullet as p
    import pybullet_data
    PYBULLET_AVAILABLE = True
    logger.info("  ⚙️   PyBullet available — using real physics simulation")
except ImportError:
    PYBULLET_AVAILABLE = False
    logger.info("  ⚙️   PyBullet not installed — using high-fidelity geometric fallback")


# ─────────────────────────────────────────────────────────────
#  JOINT PHYSICS MODEL (per-joint self-healing)
# ─────────────────────────────────────────────────────────────

@dataclass
class JointPhysicsState:
    """
    Learned per-joint physics parameters.
    Updated from HIL torque feedback after every real execution.
    """
    joint_id:          int
    name:              str
    friction_nm:       float = 0.5    # Viscous friction torque
    gravity_comp_nm:   float = 0.0    # Gravity compensation offset
    backlash_rad:      float = 0.001  # Mechanical backlash
    stiffness:         float = 100.0  # N/m joint stiffness
    damping:           float = 10.0   # N·s/m
    wear_factor:       float = 1.0    # Degrades over time (>1 = worn)

    # Torque history for drift detection
    _torque_history: List[float] = field(default_factory=list, repr=False)

    def update_from_hil(self, torque_error_nm: float):
        """
        Bayesian-style update: blend HIL observation into model.
        High error → increase friction estimate.
        """
        self._torque_history.append(abs(torque_error_nm))
        if len(self._torque_history) > 20:
            self._torque_history.pop(0)

        if len(self._torque_history) >= 5:
            avg_error = sum(self._torque_history) / len(self._torque_history)
            # Friction estimate: blend 80% old + 20% new observation
            self.friction_nm = round(0.80 * self.friction_nm + 0.20 * avg_error, 4)
            # Wear factor: exceeding 5Nm sustained → motor wear signal
            if avg_error > 5.0:
                self.wear_factor = round(min(2.0, self.wear_factor + 0.01), 3)

    def predicted_torque(self, velocity_rad_s: float, load_kg: float = 0.0) -> float:
        """Predict joint torque given motion state."""
        viscous    = self.friction_nm * abs(velocity_rad_s) * self.wear_factor
        gravity    = self.gravity_comp_nm
        load_torque = load_kg * 9.81 * 0.3  # Approximate lever arm
        return round(viscous + gravity + load_torque, 3)

    def maintenance_required(self) -> bool:
        return self.wear_factor > 1.3 or self.friction_nm > 5.0


# ─────────────────────────────────────────────────────────────
#  COLLISION RESULT
# ─────────────────────────────────────────────────────────────

@dataclass
class CollisionResult:
    """Result from ghost robot collision check."""
    safe:              bool
    collisions:        List[str]
    min_distance_m:    float   # Closest approach distance
    contact_force_n:   float   # Estimated contact force if collision
    joint_torques_nm:  List[float]  # Predicted joint torques along path
    simulation_time_ms: float  # How long the ghost sim took


# ─────────────────────────────────────────────────────────────
#  PYBULLET GHOST SIMULATOR
# ─────────────────────────────────────────────────────────────

class PyBulletGhostSimulator:
    """
    Runs a "Ghost" robot in PyBullet DIRECT (headless) mode.
    Before real hardware moves, the ghost executes the full trajectory
    and reports any collisions, force violations, or reachability issues.

    PyBullet DIRECT mode is sub-millisecond for simple scenes —
    suitable for real-time validation of tool calls.
    """

    # Geometric parameters for capsule approximation (fallback)
    ARM_LINK_LENGTHS = [0.15, 0.30, 0.25, 0.20, 0.15, 0.10]  # meters
    ARM_LINK_RADIUS  = 0.06   # meters
    END_EFFECTOR_RADIUS = 0.04

    def __init__(self, urdf_dir: str = "robots/urdfs/"):
        self.urdf_dir = urdf_dir
        self._sim_id  = None
        self._use_pybullet = PYBULLET_AVAILABLE
        self._obstacles:    List[dict] = []  # Capsule/box descriptions
        self._joint_states: Dict[str, JointPhysicsState] = {}
        self._collision_count = 0
        self._sim_calls       = 0
        self._total_sim_ms    = 0.0

    def add_obstacle(self, name: str, center_x: float, center_y: float,
                     center_z: float, radius_x: float = 0.1,
                     radius_y: float = 0.1, radius_z: float = 0.1):
        """Register a workspace obstacle for ghost collision checking."""
        self._obstacles.append({
            "name": name, "cx": center_x, "cy": center_y, "cz": center_z,
            "rx": radius_x, "ry": radius_y, "rz": radius_z,
        })

    def register_joint(self, robot_id: str, joint_id: int, name: str):
        key = f"{robot_id}:{joint_id}"
        self._joint_states[key] = JointPhysicsState(joint_id=joint_id, name=name)

    def get_joint(self, robot_id: str, joint_id: int) -> Optional[JointPhysicsState]:
        return self._joint_states.get(f"{robot_id}:{joint_id}")

    def update_joints_from_hil(self, robot_id: str,
                                torque_errors_nm: List[float]):
        """Feed HIL telemetry into per-joint physics models."""
        for i, error in enumerate(torque_errors_nm):
            key = f"{robot_id}:{i}"
            if key in self._joint_states:
                self._joint_states[key].update_from_hil(error)
            else:
                # Auto-register joints
                js = JointPhysicsState(joint_id=i, name=f"joint_{i}")
                js.update_from_hil(error)
                self._joint_states[key] = js

    def check_trajectory(
        self,
        robot_id:    str,
        start_x:     float, start_y:     float, start_z:     float,
        target_x:    float, target_y:    float, target_z:    float,
        joint_angles: Optional[List[float]] = None,
        n_steps:     int    = 20,
    ) -> CollisionResult:
        """
        Ghost robot executes the trajectory in simulation.
        Returns CollisionResult with collision flag and predicted torques.
        """
        t0 = time.perf_counter()
        self._sim_calls += 1

        if self._use_pybullet:
            result = self._pybullet_check(
                robot_id, start_x, start_y, start_z,
                target_x, target_y, target_z, joint_angles, n_steps
            )
        else:
            result = self._geometric_check(
                robot_id, start_x, start_y, start_z,
                target_x, target_y, target_z, n_steps
            )

        elapsed_ms = (time.perf_counter() - t0) * 1000
        result.simulation_time_ms = round(elapsed_ms, 3)
        self._total_sim_ms += elapsed_ms

        if not result.safe:
            self._collision_count += 1
            logger.warning(
                f"  👻  Ghost [{robot_id}] COLLISION: "
                f"{'; '.join(result.collisions)} "
                f"(sim={elapsed_ms:.2f}ms)"
            )
        else:
            logger.info(
                f"  👻  Ghost [{robot_id}] CLEAR: "
                f"min_dist={result.min_distance_m:.3f}m "
                f"(sim={elapsed_ms:.2f}ms)"
            )

        return result

    def _pybullet_check(
        self,
        robot_id:    str,
        sx: float, sy: float, sz: float,
        tx: float, ty: float, tz: float,
        joint_angles: Optional[List[float]],
        n_steps: int,
    ) -> CollisionResult:
        """
        Full PyBullet mesh collision check.
        Loads URDF, moves ghost along trajectory, checks getClosestPoints().
        """
        collisions    = []
        min_dist      = float("inf")
        contact_force = 0.0
        torques       = [0.0] * 6

        try:
            # Connect to PyBullet in DIRECT (headless) mode
            sim_id = p.connect(p.DIRECT)
            p.setAdditionalSearchPath(pybullet_data.getDataPath(),
                                       physicsClientId=sim_id)
            p.setGravity(0, 0, -9.81, physicsClientId=sim_id)

            # Load ground plane
            plane = p.loadURDF(
                "plane.urdf", physicsClientId=sim_id
            )

            # Load robot URDF (try standard UR5 if custom not found)
            import os
            urdf_path = os.path.join(self.urdf_dir, f"{robot_id}.urdf")
            if not os.path.exists(urdf_path):
                # Fall back to kuka IIWA from pybullet_data
                urdf_path = "kuka_iiwa/model.urdf"

            robot = p.loadURDF(
                urdf_path,
                basePosition=[sx, sy, 0],
                physicsClientId=sim_id,
            )

            # Load obstacle boxes
            obstacle_ids = []
            for obs in self._obstacles:
                col = p.createCollisionShape(
                    p.GEOM_BOX,
                    halfExtents=[obs["rx"], obs["ry"], obs["rz"]],
                    physicsClientId=sim_id,
                )
                body = p.createMultiBody(
                    baseMass=0,
                    baseCollisionShapeIndex=col,
                    basePosition=[obs["cx"], obs["cy"], obs["cz"]],
                    physicsClientId=sim_id,
                )
                obstacle_ids.append(body)

            num_joints = p.getNumJoints(robot, physicsClientId=sim_id)

            # Interpolate trajectory
            for step in range(n_steps + 1):
                frac   = step / max(n_steps, 1)
                pos_x  = sx + frac * (tx - sx)
                pos_y  = sy + frac * (ty - sy)
                pos_z  = sz + frac * (tz - sz)

                # Simple IK: move end-effector (for ghost visualization)
                # In production: use p.calculateInverseKinematics()
                target_pos = [pos_x, pos_y, pos_z]
                if num_joints > 0:
                    ik = p.calculateInverseKinematics(
                        robot, num_joints - 1, target_pos,
                        physicsClientId=sim_id,
                    )
                    for j, angle in enumerate(ik[:num_joints]):
                        p.resetJointState(
                            robot, j, angle, physicsClientId=sim_id
                        )

                # Check against all obstacles
                for obs_id in obstacle_ids:
                    contacts = p.getClosestPoints(
                        robot, obs_id,
                        distance=0.05,
                        physicsClientId=sim_id,
                    )
                    for c in (contacts or []):
                        dist = c[8]  # contact distance (negative = penetration)
                        min_dist = min(min_dist, dist)
                        if dist < 0.02:
                            collisions.append(
                                f"Collision at step {step}/{n_steps}: "
                                f"dist={dist:.3f}m pos=({pos_x:.2f},{pos_y:.2f},{pos_z:.2f})"
                            )
                            # Estimate contact force from penetration depth
                            contact_force = max(contact_force, abs(dist) * 1000.0)

                # Check self-collision
                self_contacts = p.getClosestPoints(
                    robot, robot, distance=0.01, physicsClientId=sim_id
                )
                for c in (self_contacts or []):
                    if c[1] != c[2]:  # different links
                        dist = c[8]
                        if dist < 0.0:
                            collisions.append(
                                f"Self-collision links {c[1]}/{c[2]} at step {step}"
                            )

            # Get final joint torques for HIL comparison
            for j in range(min(6, num_joints)):
                js = p.getJointState(robot, j, physicsClientId=sim_id)
                torques[j] = round(js[3], 3) if len(js) > 3 else 0.0

            p.disconnect(physicsClientId=sim_id)

        except Exception as e:
            logger.warning(f"  PyBullet error (falling back to geometric): {e}")
            return self._geometric_check(
                robot_id, sx, sy, sz, tx, ty, tz, n_steps
            )

        return CollisionResult(
            safe           = len(collisions) == 0,
            collisions     = collisions,
            min_distance_m = min_dist if min_dist < float("inf") else 1.0,
            contact_force_n = contact_force,
            joint_torques_nm = torques,
            simulation_time_ms = 0.0,
        )

    def _geometric_check(
        self,
        robot_id:    str,
        sx: float, sy: float, sz: float,
        tx: float, ty: float, tz: float,
        n_steps: int,
    ) -> CollisionResult:
        """
        High-fidelity geometric fallback when PyBullet unavailable.
        Uses capsule approximation of 6-DOF arm links.
        Checks each link capsule against all registered obstacles.
        """
        collisions = []
        min_dist   = float("inf")

        # Forward kinematics approximation: distribute arm links along path
        for step in range(n_steps + 1):
            frac  = step / max(n_steps, 1)
            # Smooth step (ease-in-ease-out)
            smooth = frac * frac * (3 - 2 * frac)
            cx = sx + smooth * (tx - sx)
            cy = sy + smooth * (ty - sy)
            cz = sz + smooth * (tz - sz)

            # Check each arm link as a capsule segment
            for i, (link_len, link_rad) in enumerate(
                zip(self.ARM_LINK_LENGTHS, [self.ARM_LINK_RADIUS] * 6)
            ):
                # Approximate link position along the path
                link_frac = i / len(self.ARM_LINK_LENGTHS)
                lx = sx + link_frac * (cx - sx)
                ly = sy + link_frac * (cy - sy)
                lz = max(0.0, sz + link_frac * (cz - sz))

                # Check link capsule against each obstacle box
                for obs in self._obstacles:
                    # AABB distance from link center to obstacle box
                    dx = max(0, abs(lx - obs["cx"]) - obs["rx"] - link_rad)
                    dy = max(0, abs(ly - obs["cy"]) - obs["ry"] - link_rad)
                    dz = max(0, abs(lz - obs["cz"]) - obs["rz"] - link_rad)
                    dist = math.sqrt(dx*dx + dy*dy + dz*dz)
                    min_dist = min(min_dist, dist)

                    if dist < 0.02:
                        collisions.append(
                            f"Link {i} capsule intersects [{obs['name']}] "
                            f"at step {step}/{n_steps} dist={dist:.3f}m "
                            f"pos=({lx:.2f},{ly:.2f},{lz:.2f})"
                        )

        # Predict joint torques from joint physics models
        torques = []
        for j in range(6):
            js = self.get_joint(robot_id, j)
            if js:
                vel = 0.3  # nominal velocity
                torques.append(js.predicted_torque(vel, load_kg=0.5))
            else:
                torques.append(1.0 + j * 0.3)

        return CollisionResult(
            safe            = len(collisions) == 0,
            collisions      = collisions,
            min_distance_m  = min_dist if min_dist < float("inf") else 2.0,
            contact_force_n = 0.0 if not collisions else abs(min_dist) * 800,
            joint_torques_nm = torques,
            simulation_time_ms = 0.0,
        )

    def stats(self) -> dict:
        worn_joints = [
            f"{k}: wear={js.wear_factor:.2f}"
            for k, js in self._joint_states.items()
            if js.maintenance_required()
        ]
        return {
            "mode":             "PyBullet" if self._use_pybullet else "Geometric",
            "sim_calls":        self._sim_calls,
            "collision_count":  self._collision_count,
            "collision_rate":   round(self._collision_count / max(1, self._sim_calls), 3),
            "avg_sim_ms":       round(self._total_sim_ms / max(1, self._sim_calls), 2),
            "joints_modelled":  len(self._joint_states),
            "worn_joints":      worn_joints,
        }


# ─────────────────────────────────────────────────────────────
#  ENHANCED SHADOW VALIDATOR WITH HIL
# ─────────────────────────────────────────────────────────────

class HILShadowExtension:
    """
    Extends ShadowValidator with PyBullet ghost robot checks.
    Plug into existing ShadowValidator._pybullet_check() slot.

    Usage in ShadowValidator:
        self._hil = HILShadowExtension(ghost_sim)
        # Replace _pybullet_check stub:
        def _pybullet_check(self, robot_id, start, end):
            return self._hil.check(robot_id, start, end)
    """

    def __init__(self, ghost: PyBulletGhostSimulator):
        self.ghost = ghost

    def check(self, robot_id: str, start, end) -> List[str]:
        """
        Returns list of risk strings (empty = safe).
        Integrates directly into existing ShadowValidator.validate().
        """
        result = self.ghost.check_trajectory(
            robot_id,
            start.x, start.y, start.z,
            end.x,   end.y,   end.z,
        )

        risks = []
        for c in result.collisions:
            risks.append(f"[Ghost] {c}")

        if result.contact_force_n > 10.0:
            risks.append(
                f"[Ghost] Contact force {result.contact_force_n:.0f}N exceeds 10N limit"
            )

        if result.min_distance_m < 0.03:
            risks.append(
                f"[Ghost] Clearance {result.min_distance_m*100:.1f}cm < 3cm safety margin"
            )

        return risks

    def ingest_hil_feedback(self, robot_id: str,
                              torque_errors_nm: List[float]):
        """
        Feed real execution torque errors back into ghost joint models.
        Called automatically by PMCPServer after every ToolResult.
        """
        self.ghost.update_joints_from_hil(robot_id, torque_errors_nm)

        # Log maintenance warnings
        for i, err in enumerate(torque_errors_nm):
            js = self.ghost.get_joint(robot_id, i)
            if js and js.maintenance_required():
                logger.warning(
                    f"  🔧  HIL [{robot_id}] joint {i} [{js.name}]: "
                    f"wear_factor={js.wear_factor:.2f} — schedule maintenance"
                )
