"""
P-MCP Federated Physics Sharing
=================================
Implements federated learning over robot physics models:

  - Each robot trains a local physics model on its own trajectory data
  - A central Aggregator collects model weight updates (gradients / deltas)
  - FedAvg aggregation produces a global model
  - Robots pull the global model and fine-tune locally

The implementation is framework-agnostic: weights are plain numpy arrays.
Drop-in support for PyTorch via the `torch_adapter` utility.

Architecture:
  FederatedNode   — per-robot participant: train, upload, download
  PhysicsModel    — lightweight MLP that predicts next state from (state, action)
  Aggregator      — weighted FedAvg server
  FedServer       — HTTP JSON-RPC server wrapping the Aggregator
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger("pmcp.federated_physics")


# ─────────────────────────────────────────────────────────────────────────────
#  Physics Model (NumPy MLP)
# ─────────────────────────────────────────────────────────────────────────────

class PhysicsModel:
    """
    Two-layer MLP: (state_dim + action_dim) → hidden_dim → state_dim
    Predicts Δstate = f(state, action)
    """

    def __init__(self, state_dim: int = 12, action_dim: int = 6, hidden_dim: int = 64) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        rng = np.random.default_rng(42)
        in_dim = state_dim + action_dim
        self.W1 = rng.normal(0, 0.1, (hidden_dim, in_dim)).astype(np.float32)
        self.b1 = np.zeros(hidden_dim, dtype=np.float32)
        self.W2 = rng.normal(0, 0.1, (state_dim, hidden_dim)).astype(np.float32)
        self.b2 = np.zeros(state_dim, dtype=np.float32)

    def forward(self, state: np.ndarray, action: np.ndarray) -> np.ndarray:
        x = np.concatenate([state, action])
        h = np.tanh(self.W1 @ x + self.b1)
        return self.W2 @ h + self.b2

    def predict_next(self, state: np.ndarray, action: np.ndarray) -> np.ndarray:
        return state + self.forward(state, action)

    def get_weights(self) -> Dict[str, np.ndarray]:
        return {"W1": self.W1.copy(), "b1": self.b1.copy(),
                "W2": self.W2.copy(), "b2": self.b2.copy()}

    def set_weights(self, weights: Dict[str, np.ndarray]) -> None:
        self.W1 = weights["W1"].copy()
        self.b1 = weights["b1"].copy()
        self.W2 = weights["W2"].copy()
        self.b2 = weights["b2"].copy()

    def train_step(self, states: np.ndarray, actions: np.ndarray,
                   next_states: np.ndarray, lr: float = 1e-3) -> float:
        """Single SGD step over a batch, returns MSE loss."""
        total_loss = 0.0
        dW1 = np.zeros_like(self.W1)
        db1 = np.zeros_like(self.b1)
        dW2 = np.zeros_like(self.W2)
        db2 = np.zeros_like(self.b2)

        n = len(states)
        for s, a, ns in zip(states, actions, next_states):
            x = np.concatenate([s, a])
            h = np.tanh(self.W1 @ x + self.b1)
            y_hat = self.W2 @ h + self.b2
            target = ns - s
            e = y_hat - target
            total_loss += float(np.mean(e ** 2))

            dL_dy = 2 * e / len(e)
            dW2 += np.outer(dL_dy, h)
            db2 += dL_dy
            dh = self.W2.T @ dL_dy * (1 - h ** 2)
            dW1 += np.outer(dh, x)
            db1 += dh

        self.W1 -= lr * dW1 / n
        self.b1 -= lr * db1 / n
        self.W2 -= lr * dW2 / n
        self.b2 -= lr * db2 / n
        return total_loss / n

    def serialize(self) -> Dict:
        w = self.get_weights()
        return {k: v.tolist() for k, v in w.items()}

    @classmethod
    def deserialize(cls, data: Dict, state_dim: int = 12,
                    action_dim: int = 6, hidden_dim: int = 64) -> "PhysicsModel":
        model = cls(state_dim, action_dim, hidden_dim)
        model.set_weights({k: np.array(v, dtype=np.float32) for k, v in data.items()})
        return model


# ─────────────────────────────────────────────────────────────────────────────
#  Experience Buffer
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Transition:
    state: np.ndarray
    action: np.ndarray
    next_state: np.ndarray


class ExperienceBuffer:
    def __init__(self, capacity: int = 10_000) -> None:
        self._buf: List[Transition] = []
        self._capacity = capacity

    def push(self, state: np.ndarray, action: np.ndarray, next_state: np.ndarray) -> None:
        if len(self._buf) >= self._capacity:
            self._buf.pop(0)
        self._buf.append(Transition(state, action, next_state))

    def sample(self, n: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        idx = np.random.choice(len(self._buf), min(n, len(self._buf)), replace=False)
        transitions = [self._buf[i] for i in idx]
        return (
            np.stack([t.state for t in transitions]),
            np.stack([t.action for t in transitions]),
            np.stack([t.next_state for t in transitions]),
        )

    def __len__(self) -> int:
        return len(self._buf)


# ─────────────────────────────────────────────────────────────────────────────
#  FedAvg Aggregator
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ModelUpdate:
    robot_id: str
    round_id: str
    weights: Dict[str, np.ndarray]
    num_samples: int
    local_loss: float
    submitted_at: float = field(default_factory=time.time)


class Aggregator:
    """Weighted FedAvg aggregation server."""

    def __init__(self, min_participants: int = 2) -> None:
        self.min_participants = min_participants
        self._global_model: Optional[Dict[str, np.ndarray]] = None
        self._round_id: str = str(uuid.uuid4())
        self._updates: List[ModelUpdate] = []
        self._round_history: List[Dict] = []

    def get_global_model(self) -> Optional[Dict]:
        """Return serialised global model or None if not yet aggregated."""
        if self._global_model is None:
            return None
        return {k: v.tolist() for k, v in self._global_model.items()}

    def submit_update(self, robot_id: str, round_id: str,
                      weights_serial: Dict, num_samples: int, local_loss: float) -> str:
        weights = {k: np.array(v, dtype=np.float32) for k, v in weights_serial.items()}
        self._updates.append(ModelUpdate(
            robot_id=robot_id, round_id=round_id, weights=weights,
            num_samples=num_samples, local_loss=local_loss
        ))
        log.info("Update from %s: %d samples, loss=%.4f", robot_id, num_samples, local_loss)
        if len(self._updates) >= self.min_participants:
            return self._aggregate()
        return "pending"

    def _aggregate(self) -> str:
        total_samples = sum(u.num_samples for u in self._updates)
        if total_samples == 0:
            return "empty"

        # Weighted average of all weight tensors
        aggregated: Dict[str, np.ndarray] = {}
        for key in self._updates[0].weights.keys():
            weighted_sum = sum(
                u.weights[key] * (u.num_samples / total_samples)
                for u in self._updates
            )
            aggregated[key] = weighted_sum

        self._global_model = aggregated
        avg_loss = sum(u.local_loss * u.num_samples for u in self._updates) / total_samples
        self._round_history.append({
            "round_id": self._round_id,
            "participants": [u.robot_id for u in self._updates],
            "total_samples": total_samples,
            "avg_loss": avg_loss,
            "aggregated_at": time.time(),
        })
        log.info("FedAvg round %s complete: %d participants, avg_loss=%.4f",
                 self._round_id, len(self._updates), avg_loss)
        self._updates.clear()
        self._round_id = str(uuid.uuid4())
        return "aggregated"

    def status(self) -> Dict:
        return {
            "round_id": self._round_id,
            "updates_received": len(self._updates),
            "min_participants": self.min_participants,
            "rounds_completed": len(self._round_history),
            "last_round": self._round_history[-1] if self._round_history else None,
        }


# ─────────────────────────────────────────────────────────────────────────────
#  Federated Node (per-robot)
# ─────────────────────────────────────────────────────────────────────────────

class FederatedNode:
    """
    Per-robot federated learning participant.
    Trains a local PhysicsModel and submits updates to a central Aggregator.
    """

    def __init__(self, robot_id: str, aggregator_url: str = "",
                 state_dim: int = 12, action_dim: int = 6) -> None:
        self.robot_id = robot_id
        self.aggregator_url = aggregator_url
        self.model = PhysicsModel(state_dim, action_dim)
        self.buffer = ExperienceBuffer()
        self._round_id: str = str(uuid.uuid4())
        self._local_loss: float = float("inf")
        self._http_session: Optional[Any] = None

    def observe(self, state: np.ndarray, action: np.ndarray, next_state: np.ndarray) -> None:
        """Record a transition to the local experience buffer."""
        self.buffer.push(state, action, next_state)

    def train_local(self, epochs: int = 5, batch_size: int = 64, lr: float = 1e-3) -> float:
        """Train the local model; returns final epoch loss."""
        if len(self.buffer) < batch_size:
            return float("inf")
        for _ in range(epochs):
            s, a, ns = self.buffer.sample(batch_size)
            self._local_loss = self.model.train_step(s, a, ns, lr)
        log.debug("Robot %s local training loss: %.4f", self.robot_id, self._local_loss)
        return self._local_loss

    async def submit_update(self, aggregator: Optional[Aggregator] = None) -> str:
        """Submit model update to aggregator (direct or HTTP)."""
        if aggregator is not None:
            return aggregator.submit_update(
                self.robot_id, self._round_id,
                self.model.serialize(), len(self.buffer), self._local_loss
            )
        if not self.aggregator_url:
            raise RuntimeError("No aggregator configured")

        try:
            import aiohttp
            payload = {
                "jsonrpc": "2.0", "id": 1,
                "method": "fed/submit_update",
                "params": {
                    "robot_id": self.robot_id,
                    "round_id": self._round_id,
                    "weights": self.model.serialize(),
                    "num_samples": len(self.buffer),
                    "local_loss": self._local_loss,
                },
            }
            async with aiohttp.ClientSession() as sess:
                async with sess.post(f"{self.aggregator_url}/rpc", json=payload) as resp:
                    data = await resp.json()
                    return data.get("result", {}).get("status", "unknown")
        except Exception as exc:
            log.error("Failed to submit update: %s", exc)
            return "error"

    async def pull_global_model(self, aggregator: Optional[Aggregator] = None) -> bool:
        """Download and apply the global model weights."""
        if aggregator is not None:
            model_data = aggregator.get_global_model()
        else:
            try:
                import aiohttp
                payload = {"jsonrpc": "2.0", "id": 2, "method": "fed/global_model", "params": {}}
                async with aiohttp.ClientSession() as sess:
                    async with sess.post(f"{self.aggregator_url}/rpc", json=payload) as resp:
                        data = await resp.json()
                        model_data = data.get("result", {}).get("model")
            except Exception as exc:
                log.error("Failed to pull global model: %s", exc)
                return False

        if model_data is None:
            return False
        global_weights = {k: np.array(v, dtype=np.float32) for k, v in model_data.items()}
        self.model.set_weights(global_weights)
        log.info("Robot %s applied global model", self.robot_id)
        return True


# ─────────────────────────────────────────────────────────────────────────────
#  HTTP Federation Server
# ─────────────────────────────────────────────────────────────────────────────

def create_fed_server_app(aggregator: Aggregator) -> Any:
    """Create aiohttp Application exposing the federation server."""
    from aiohttp import web

    async def handle_rpc(req: web.Request) -> web.Response:
        try:
            body = await req.json()
        except Exception:
            return web.json_response({"error": "parse error"}, status=400)
        method = body.get("method", "")
        params = body.get("params", {})
        rpc_id = body.get("id")

        try:
            if method == "fed/submit_update":
                status = aggregator.submit_update(
                    params["robot_id"], params["round_id"],
                    params["weights"], params["num_samples"], params["local_loss"]
                )
                result = {"status": status}
            elif method == "fed/global_model":
                model = aggregator.get_global_model()
                result = {"model": model}
            elif method == "fed/status":
                result = aggregator.status()
            else:
                return web.json_response(
                    {"jsonrpc": "2.0", "id": rpc_id,
                     "error": {"code": -32601, "message": f"Unknown method: {method}"}},
                )
            return web.json_response({"jsonrpc": "2.0", "id": rpc_id, "result": result})
        except Exception as exc:
            return web.json_response(
                {"jsonrpc": "2.0", "id": rpc_id,
                 "error": {"code": -32603, "message": str(exc)}},
            )

    app = web.Application()
    app["aggregator"] = aggregator
    app.router.add_post("/rpc", handle_rpc)
    app.router.add_get("/health", lambda r: web.json_response({"status": "ok"}))
    return app


async def run_fed_server(port: int = 9002, min_participants: int = 2) -> None:
    logging.basicConfig(level=logging.INFO)
    aggregator = Aggregator(min_participants=min_participants)
    app = create_fed_server_app(aggregator)
    from aiohttp import web
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    log.info("Federated physics server running on port %d", port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(run_fed_server())
