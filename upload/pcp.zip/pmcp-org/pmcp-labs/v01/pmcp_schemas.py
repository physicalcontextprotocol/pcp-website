"""
P-MCP Schemas — Physical Model Context Protocol  v0.2
======================================================
Upgrades over v0.1:
  - ProjectedOutcome gains utility_score, temporal_envelope
  - ToolCall gains bid_energy_j (Vickrey auction support)
  - ToolResult gains joint_torque_error_nm (HIL feedback)
  - TemporalEnvelope: 4D space-time reservation data
  - AASCapability: Asset Administration Shell semantic manifest
"""

from __future__ import annotations
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple


# ─────────────────────────────────────────────────────────────
#  COORDINATE SYSTEM
# ─────────────────────────────────────────────────────────────

@dataclass
class Vec3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def __repr__(self):
        return f"({self.x:.3f}, {self.y:.3f}, {self.z:.3f})"

    def distance_to(self, other: "Vec3") -> float:
        return ((self.x - other.x)**2 + (self.y - other.y)**2 + (self.z - other.z)**2) ** 0.5


@dataclass
class Pose:
    position: Vec3 = field(default_factory=Vec3)
    roll:  float = 0.0
    pitch: float = 0.0
    yaw:   float = 0.0
    frame: str   = "world"

    def __repr__(self):
        return (f"Pose[{self.frame}] pos={self.position} "
                f"rpy=({self.roll:.2f},{self.pitch:.2f},{self.yaw:.2f})")


# ─────────────────────────────────────────────────────────────
#  4D TEMPORAL ENVELOPE  (NEW in v0.2)
# ─────────────────────────────────────────────────────────────

@dataclass
class SpaceTimeSlot:
    """One occupied voxel during [start_ms, end_ms]."""
    zone_id:    str
    robot_id:   str
    start_ms:   float   # epoch ms
    end_ms:     float   # epoch ms
    position:   Vec3 = field(default_factory=Vec3)

    def overlaps(self, other: "SpaceTimeSlot") -> bool:
        same_zone = self.zone_id == other.zone_id
        time_clash = self.start_ms < other.end_ms and self.end_ms > other.start_ms
        return same_zone and time_clash and self.robot_id != other.robot_id


@dataclass
class TemporalEnvelope:
    """Full 4D space-time trajectory for one tool call."""
    slots: List[SpaceTimeSlot] = field(default_factory=list)

    def conflicts_with(self, other: "TemporalEnvelope") -> List[str]:
        clashes = []
        for s in self.slots:
            for o in other.slots:
                if s.overlaps(o):
                    clashes.append(
                        f"Zone [{s.zone_id}] clash: {s.robot_id} @ "
                        f"{s.start_ms:.0f}–{s.end_ms:.0f}ms vs "
                        f"{o.robot_id} @ {o.start_ms:.0f}–{o.end_ms:.0f}ms"
                    )
        return clashes


# ─────────────────────────────────────────────────────────────
#  ASSET ADMINISTRATION SHELL  (NEW in v0.2)
# ─────────────────────────────────────────────────────────────

@dataclass
class AASCapability:
    """
    RAMI 4.0 / Industry 4.0 semantic capability descriptor.
    Allows LLMs to discover robots by capability, not by name.

    Example query: "Find robots with Gripper.MaxPayload > 2.0 kg"
    """
    capability_type: str        # "Gripper", "MobileBase", "Camera", "Arm"
    properties: Dict[str, Any]  # {"MaxPayload_kg": 3.0, "DOF": 6, ...}
    unit_map: Dict[str, str]    # {"MaxPayload_kg": "kg", "Reach_m": "m"}
    semantic_uri: str = ""      # Optional RDF/OWL URI

    def matches_query(self, prop: str, op: str, value: float) -> bool:
        v = self.properties.get(prop)
        if v is None:
            return False
        if op == ">":  return float(v) > value
        if op == ">=": return float(v) >= value
        if op == "<":  return float(v) < value
        if op == "<=": return float(v) <= value
        if op == "==": return float(v) == value
        return False

    def to_json_ld(self) -> dict:
        return {
            "@type": f"pmcp:{self.capability_type}",
            "@context": {"pmcp": "https://pmcp.ai/schema/v1/"},
            "semantic_uri": self.semantic_uri,
            **{k: {"value": v, "unit": self.unit_map.get(k, "")}
               for k, v in self.properties.items()},
        }


# ─────────────────────────────────────────────────────────────
#  TOOL CATEGORY & PARAMETER
# ─────────────────────────────────────────────────────────────

class ToolCategory(str, Enum):
    MOTION       = "motion"
    MANIPULATION = "manipulation"
    SENSING      = "sensing"
    NAVIGATION   = "navigation"
    UTILITY      = "utility"


@dataclass
class ToolParameter:
    name:     str
    type:     str
    description: str
    required: bool = True
    default:  Any  = None
    min_val:  Optional[float] = None
    max_val:  Optional[float] = None
    unit:     str  = ""


# ─────────────────────────────────────────────────────────────
#  P-MCP TOOL DEFINITION
# ─────────────────────────────────────────────────────────────

@dataclass
class PMCPTool:
    name:        str
    description: str
    category:    ToolCategory
    robot_id:    str
    parameters:  List[ToolParameter]
    handler:     Callable

    estimated_duration_s:  float = 1.0
    estimated_energy_j:    float = 10.0
    max_speed_ms:          float = 0.5
    requires_workspace_clear: bool = True
    min_human_clearance_m: float = 0.5
    requires_confirmation: bool  = True

    # AAS capability list for this tool
    capabilities: List[AASCapability] = field(default_factory=list)

    def to_llm_schema(self) -> dict:
        return {
            "name":        self.name,
            "description": self.description,
            "category":    self.category.value,
            "robot_id":    self.robot_id,
            "parameters": [
                {
                    "name":        p.name,
                    "type":        p.type,
                    "description": p.description,
                    "required":    p.required,
                    "unit":        p.unit,
                    **({"min": p.min_val} if p.min_val is not None else {}),
                    **({"max": p.max_val} if p.max_val is not None else {}),
                }
                for p in self.parameters
            ],
            "physics": {
                "estimated_duration_s": self.estimated_duration_s,
                "estimated_energy_j":   self.estimated_energy_j,
                "max_speed_ms":         self.max_speed_ms,
            },
            "safety": {
                "min_human_clearance_m":    self.min_human_clearance_m,
                "requires_confirmation":    self.requires_confirmation,
                "requires_workspace_clear": self.requires_workspace_clear,
            },
            "capabilities": [c.to_json_ld() for c in self.capabilities],
        }


# ─────────────────────────────────────────────────────────────
#  P-MCP RESOURCE
# ─────────────────────────────────────────────────────────────

class ResourceType(str, Enum):
    JOINT_STATES = "joint_states"
    END_EFFECTOR = "end_effector"
    FORCE_TORQUE = "force_torque"
    CAMERA_RGB   = "camera_rgb"
    LIDAR_SCAN   = "lidar_scan"
    BATTERY      = "battery"
    PROXIMITY    = "proximity"
    PLANT_HEALTH = "plant_health"   # NEW: biological coupling
    MARKET_PRICE = "market_price"   # NEW: energy/carbon spot price
    CUSTOM       = "custom"


@dataclass
class PMCPResource:
    uri:             str
    robot_id:        str
    resource_type:   ResourceType
    description:     str
    update_rate_hz:  float = 10.0
    coordinate_frame: str  = "world"
    _value:          Any   = field(default=None, repr=False)
    _timestamp:      float = field(default_factory=time.time, repr=False)

    def read(self) -> dict:
        return {
            "uri":       self.uri,
            "type":      self.resource_type.value,
            "frame":     self.coordinate_frame,
            "value":     self._value,
            "timestamp": self._timestamp,
            "age_ms":    round((time.time() - self._timestamp) * 1000, 1),
        }

    def write(self, value: Any):
        self._value     = value
        self._timestamp = time.time()


# ─────────────────────────────────────────────────────────────
#  TOOL CALL PIPELINE
# ─────────────────────────────────────────────────────────────

class ToolCallStatus(str, Enum):
    PENDING     = "PENDING"
    SHADOW_OK   = "SHADOW_OK"
    SHADOW_FAIL = "SHADOW_FAIL"
    CONFIRMED   = "CONFIRMED"
    EXECUTING   = "EXECUTING"
    SUCCESS     = "SUCCESS"
    FAILED      = "FAILED"
    ABORTED     = "ABORTED"
    TIMEOUT     = "TIMEOUT"         # NEW: confirm gate timed out


@dataclass
class ProjectedOutcome:
    """
    What WILL happen if this tool call executes.
    v0.2 adds: utility_score, temporal_envelope, auction_price
    """
    duration_s:          float
    energy_j:            float
    final_pose:          Optional[Pose]
    risk_level:          str            # "low" | "medium" | "high"
    risk_reasons:        List[str]
    carbon_g:            float = 0.0
    cost_usd:            float = 0.0
    workspace_conflicts: List[str] = field(default_factory=list)
    safe_to_execute:     bool = True

    # NEW v0.2
    utility_score:       float = 0.0   # 0–1, economic value of this action
    temporal_envelope:   Optional[TemporalEnvelope] = None
    auction_price:       float = 0.0   # Vickrey second price if auctioned
    drift_warning:       str   = ""    # Physics model drift alert


@dataclass
class ToolCall:
    call_id:    str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    tool_name:  str = ""
    robot_id:   str = ""
    caller_id:  str = ""
    arguments:  Dict[str, Any] = field(default_factory=dict)
    status:     ToolCallStatus = ToolCallStatus.PENDING
    projected:  Optional[ProjectedOutcome] = None
    result:     Optional["ToolResult"] = None
    timestamp:  float = field(default_factory=time.time)
    confirmed_at: Optional[float] = None

    # NEW v0.2
    bid_energy_j: float = 0.0   # Energy units bid for Vickrey auction
    confirm_deadline_ms: float = 0.0  # Epoch ms by which confirm() must arrive


@dataclass
class ToolResult:
    call_id:           str   = ""
    success:           bool  = False
    message:           str   = ""
    data:              Dict[str, Any] = field(default_factory=dict)
    duration_actual_s: float = 0.0
    energy_actual_j:   float = 0.0
    final_pose:        Optional[Pose] = None
    timestamp:         float = field(default_factory=time.time)

    # NEW v0.2 — HIL torque feedback for self-healing twin
    joint_torque_error_nm: List[float] = field(default_factory=list)
    projected_duration_s:  float = 0.0   # Copy of shadow projection for drift calc