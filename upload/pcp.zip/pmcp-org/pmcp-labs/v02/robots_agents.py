"""
P-MCP Robot Agents v0.2
========================
Upgrades over v0.1:
  - AASCapability attached to every tool (semantic discovery)
  - joint_torque_error_nm in every ToolResult (HIL self-healing)
  - MARKET_PRICE resource (energy spot price stream)
  - PLANT_HEALTH resource (biological coupling)
  - Drift-aware timing simulation (arm slows as it "ages")
  - HarvesterRobot: dedicated combined arm+AMR agent
"""

import asyncio
import logging
import math
import random
import time
from typing import List, Optional

from a2a_ps.pmcp.server import PMCPServer
from a2a_ps.pmcp.schemas import (
    ToolResult, ToolParameter, ToolCategory, ResourceType,
    Pose, Vec3, AASCapability,
)
from a2a_ps.pmcp.shadow import DigitalTwin

logger = logging.getLogger("a2a_ps.robots")


def _torque_sim(n_joints: int = 6, base: float = 1.0) -> List[float]:
    """Simulate joint torque errors (replace with real F/T sensor read)."""
    return [round(random.gauss(0, base * 0.3), 3) for _ in range(n_joints)]


# ─────────────────────────────────────────────────────────────
#  1. ROBOTIC ARM AGENT
# ─────────────────────────────────────────────────────────────

class RoboticArmAgent:
    """
    6-DOF collaborative arm — UR5e / Franka / Kinova / any MoveIt robot.

    v0.2 adds:
      - AAS capabilities (Gripper, Arm) on every tool
      - Simulated motor aging (duration_scale drifts up over time)
      - joint_torque_error_nm in every ToolResult
      - inspect_plant returns biological plant data to digital twin
    """

    ARM_REACH_M       = 0.85
    GRIPPER_MAX_FORCE = 40.0
    MOTOR_WEAR_RATE   = 0.0002   # Fraction of extra duration per call (aging sim)

    def __init__(self, server: PMCPServer, robot_id: str = "arm-01",
                 base_pose: Optional[Pose] = None):
        self.robot_id     = robot_id
        self.server       = server
        self._current_pose = base_pose or Pose(position=Vec3(1.5, 1.0, 0.5))
        self._gripper_open = True
        self._gripper_force_n = 0.0
        self._is_moving   = False
        self._joint_angles = [0.0] * 6
        self._call_count  = 0   # For motor aging simulation

        server.twin.register_robot(robot_id, self._current_pose)
        logger.info(f"🦾  Arm [{robot_id}] v0.2 registered at {self._current_pose.position}")

        self._register_tools()
        self._register_resources()

    def _arm_caps(self) -> List[AASCapability]:
        return [AASCapability(
            capability_type = "Arm",
            properties      = {"DOF": 6, "Reach_m": self.ARM_REACH_M,
                               "MaxPayload_kg": 3.0, "Accuracy_mm": 0.1},
            unit_map        = {"Reach_m": "m", "MaxPayload_kg": "kg", "Accuracy_mm": "mm"},
            semantic_uri    = "https://pmcp.ai/schema/v1/capabilities/Arm",
        )]

    def _gripper_caps(self) -> List[AASCapability]:
        return [AASCapability(
            capability_type = "Gripper",
            properties      = {"MaxForce_n": self.GRIPPER_MAX_FORCE,
                               "MaxOpening_mm": 85.0, "MaxPayload_kg": 2.0},
            unit_map        = {"MaxForce_n": "N", "MaxOpening_mm": "mm", "MaxPayload_kg": "kg"},
            semantic_uri    = "https://pmcp.ai/schema/v1/capabilities/Gripper",
        )]

    def _register_tools(self):
        s   = self.server
        rid = self.robot_id

        @s.tool(
            category=ToolCategory.MOTION, robot_id=rid,
            description=(
                "Move the robot arm's TCP to a target Cartesian position "
                "in the world frame. Shadow validates and returns ProjectedOutcome "
                "before executing. Agent must confirm."
            ),
            parameters=[
                ToolParameter("x",     "float", "Target X (m)",   unit="m",   min_val=-1.0, max_val=3.0),
                ToolParameter("y",     "float", "Target Y (m)",   unit="m",   min_val=-1.0, max_val=3.0),
                ToolParameter("z",     "float", "Target Z (m)",   unit="m",   min_val=0.0,  max_val=2.5),
                ToolParameter("speed", "float", "Speed (m/s)",    unit="m/s", min_val=0.01, max_val=1.0,
                              required=False, default=0.25),
            ],
            estimated_duration_s=3.0, estimated_energy_j=120.0,
            max_speed_ms=1.0, min_human_clearance_m=0.35,
            capabilities=self._arm_caps(),
        )
        async def move_to(x: float, y: float, z: float, speed: float = 0.25):
            return await self._execute_move_to(x, y, z, speed)

        @s.tool(
            category=ToolCategory.MANIPULATION, robot_id=rid,
            description="Close gripper using force control. Stops at target force.",
            parameters=[
                ToolParameter("target_force_n", "float", "Target force (N)", unit="N",
                              min_val=5.0, max_val=self.GRIPPER_MAX_FORCE,
                              required=False, default=15.0),
                ToolParameter("width_mm", "float", "Object width (mm)", unit="mm",
                              min_val=0.0, max_val=85.0, required=False, default=0.0),
            ],
            estimated_duration_s=1.5, estimated_energy_j=20.0,
            max_speed_ms=0.05, min_human_clearance_m=0.1,
            requires_confirmation=False,
            capabilities=self._gripper_caps(),
        )
        async def grab(target_force_n: float = 15.0, width_mm: float = 0.0):
            return await self._execute_grab(target_force_n, width_mm)

        @s.tool(
            category=ToolCategory.MANIPULATION, robot_id=rid,
            description="Open the gripper to release held object.",
            parameters=[
                ToolParameter("width_mm", "float", "Opening width (mm)", unit="mm",
                              min_val=0.0, max_val=85.0, required=False, default=85.0),
            ],
            estimated_duration_s=0.8, estimated_energy_j=10.0,
            max_speed_ms=0.05, min_human_clearance_m=0.1,
            requires_confirmation=False,
            capabilities=self._gripper_caps(),
        )
        async def release(width_mm: float = 85.0):
            return await self._execute_release(width_mm)

        @s.tool(
            category=ToolCategory.SENSING, robot_id=rid,
            description=(
                "Move arm to inspection pose above tray, capture plant health data "
                "(colour index, height, disease flags). Updates DigitalTwin plant health."
            ),
            parameters=[
                ToolParameter("tray_x",        "float", "Tray X centre (m)", unit="m"),
                ToolParameter("tray_y",        "float", "Tray Y centre (m)", unit="m"),
                ToolParameter("height_above_m","float", "Inspection height (m)", unit="m",
                              min_val=0.1, max_val=0.5, required=False, default=0.3),
            ],
            estimated_duration_s=5.0, estimated_energy_j=180.0,
            max_speed_ms=0.2,
            capabilities=self._arm_caps(),
        )
        async def inspect_plant(tray_x: float, tray_y: float,
                                height_above_m: float = 0.3):
            return await self._execute_inspect(tray_x, tray_y, height_above_m)

        @s.tool(
            category=ToolCategory.MOTION, robot_id=rid,
            description="Return arm to safe home configuration (joints at zero).",
            parameters=[],
            estimated_duration_s=4.0, estimated_energy_j=100.0,
            max_speed_ms=0.3, requires_confirmation=False,
            capabilities=self._arm_caps(),
        )
        async def home():
            return await self._execute_home()

    def _register_resources(self):
        s   = self.server
        rid = self.robot_id

        @s.resource(robot_id=rid, resource_type=ResourceType.END_EFFECTOR,
                    description="Current TCP pose in world frame", update_rate_hz=20.0)
        async def end_effector_pose():
            return {
                "x": self._current_pose.position.x,
                "y": self._current_pose.position.y,
                "z": self._current_pose.position.z,
                "roll":  self._current_pose.roll,
                "pitch": self._current_pose.pitch,
                "yaw":   self._current_pose.yaw,
            }

        @s.resource(robot_id=rid, resource_type=ResourceType.JOINT_STATES,
                    description="Joint angles (rad) and velocities",
                    update_rate_hz=50.0)
        async def joint_states():
            return {"angles_rad": self._joint_angles,
                    "velocities": [0.0] * 6,
                    "is_moving":  self._is_moving}

        @s.resource(robot_id=rid, resource_type=ResourceType.FORCE_TORQUE,
                    description="Wrist F/T sensor", update_rate_hz=100.0)
        async def force_torque():
            return {
                "fx": random.uniform(-0.5, 0.5),
                "fy": random.uniform(-0.5, 0.5),
                "fz": (-2.1 if not self._gripper_open else random.uniform(-0.2, 0.2)),
                "gripper_force_n": self._gripper_force_n,
            }

    # ── Hardware simulation ───────────────────────────────────

    def _aging_factor(self) -> float:
        """Simulate motor aging — arm gets fractionally slower each call."""
        return 1.0 + self._call_count * self.MOTOR_WEAR_RATE

    async def _execute_move_to(self, x, y, z, speed):
        self._call_count += 1
        start  = self._current_pose.position
        target = Vec3(x, y, z)
        dist   = start.distance_to(target)
        aging  = self._aging_factor()
        duration = (dist / max(speed, 0.01)) * aging

        self._is_moving = True
        logger.info(
            f"  🦾  [{self.robot_id}] move_to {target} | "
            f"{dist:.2f}m @ {speed}m/s → {duration:.1f}s (aging×{aging:.3f})"
        )

        steps = max(int(duration * 4), 2)
        for i in range(steps):
            frac = (i + 1) / steps
            smooth = math.sin(frac * math.pi / 2) if frac < 0.5 else \
                     1.0 - math.sin((1 - frac) * math.pi / 2)
            self._current_pose.position.x = start.x + smooth * (x - start.x)
            self._current_pose.position.y = start.y + smooth * (y - start.y)
            self._current_pose.position.z = start.z + smooth * (z - start.z)
            self._joint_angles = [
                math.atan2(y, x),
                math.atan2(z, math.sqrt(x**2 + y**2)),
                random.uniform(-0.1, 0.1),
                random.uniform(-0.1, 0.1),
                random.uniform(-0.1, 0.1),
                0.0,
            ]
            await asyncio.sleep(duration / steps)

        self._is_moving = False
        self._current_pose = Pose(position=Vec3(x, y, z))
        self.server.twin.update_pose(self.robot_id, self._current_pose)

        return ToolResult(
            success=True,
            message=f"Moved to ({x:.3f}, {y:.3f}, {z:.3f})",
            data={"distance_m": round(dist, 3), "duration_s": round(duration, 2),
                  "aging_factor": round(aging, 3)},
            final_pose=self._current_pose,
            joint_torque_error_nm=_torque_sim(6, base=aging),
        )

    async def _execute_grab(self, target_force_n, width_mm):
        if not self._gripper_open:
            return ToolResult(success=False, message="Gripper already closed")
        logger.info(f"  🤏  [{self.robot_id}] grab | force: {target_force_n}N")
        await asyncio.sleep(1.2)
        grasped = random.random() > 0.05
        self._gripper_open     = False
        self._gripper_force_n  = target_force_n if grasped else 0.0
        return ToolResult(
            success=grasped,
            message="Object grasped" if grasped else "Grasp failed — no contact",
            data={"force_n": self._gripper_force_n, "object_detected": grasped},
            joint_torque_error_nm=_torque_sim(6, base=0.5),
        )

    async def _execute_release(self, width_mm):
        logger.info(f"  🖐  [{self.robot_id}] release | {width_mm}mm")
        await asyncio.sleep(0.6)
        self._gripper_open    = True
        self._gripper_force_n = 0.0
        return ToolResult(success=True, message=f"Gripper opened to {width_mm}mm",
                          joint_torque_error_nm=_torque_sim(6, base=0.2))

    async def _execute_inspect(self, tray_x, tray_y, height):
        inspect_z = height + 0.5
        logger.info(f"  🔬  [{self.robot_id}] inspecting tray at ({tray_x:.2f}, {tray_y:.2f})")
        await self._execute_move_to(tray_x, tray_y, inspect_z, speed=0.2)
        await asyncio.sleep(1.0)

        health_score  = random.uniform(0.7, 1.0)
        height_cm     = random.uniform(8, 25)
        ripe_fraction = random.uniform(0.1, 0.9)
        humidity_pct  = random.uniform(55, 90)
        days_left     = random.uniform(0.5, 5.0)

        tray_id = f"tray-{int(tray_x)}-{int(tray_y)}"
        self.server.twin.update_plant_health(tray_id, {
            "health_score":        round(health_score, 3),
            "humidity_pct":        round(humidity_pct, 1),
            "days_to_harvest":     round(days_left, 1),
            "harvest_window_open": ripe_fraction > 0.6,
            "vpd_kpa":             round(random.uniform(0.4, 1.4), 2),
        })

        return ToolResult(
            success=True,
            message=f"Inspection complete. Health: {health_score:.0%}",
            data={
                "health_score":    round(health_score, 3),
                "height_cm":       round(height_cm, 1),
                "ripe_fraction":   round(ripe_fraction, 2),
                "disease_detected": health_score < 0.75,
                "harvest_ready":   ripe_fraction > 0.6,
                "humidity_pct":    round(humidity_pct, 1),
                "days_to_harvest": round(days_left, 1),
                "tray_id":         tray_id,
            },
            final_pose=self._current_pose,
            joint_torque_error_nm=_torque_sim(6, base=0.4),
        )

    async def _execute_home(self):
        logger.info(f"  🏠  [{self.robot_id}] returning home")
        self._is_moving = True
        await asyncio.sleep(3.0)
        self._joint_angles = [0.0] * 6
        home_pose = Pose(position=Vec3(1.5, 1.0, 0.5))
        self._current_pose = home_pose
        self._is_moving    = False
        self.server.twin.update_pose(self.robot_id, home_pose)
        return ToolResult(success=True, message="Arm at home",
                          final_pose=home_pose,
                          joint_torque_error_nm=_torque_sim(6, base=0.3))


# ─────────────────────────────────────────────────────────────
#  2. AMR AGENT
# ─────────────────────────────────────────────────────────────

class AMRAgent:
    """
    Autonomous Mobile Robot — MiR100 / TurtleBot3 / Clearpath Ridgeback.

    v0.2 adds:
      - AAS MobileBase capability
      - MARKET_PRICE resource
      - Vickrey bid support in navigate_to
      - joint_torque_error_nm (wheel motor feedback)
    """

    def __init__(self, server: PMCPServer, robot_id: str = "amr-01",
                 initial_pose: Optional[Pose] = None):
        self.robot_id      = robot_id
        self.server        = server
        self._current_pose = initial_pose or Pose(position=Vec3(4.5, 0.5, 0.0))
        self._battery_pct  = 85.0
        self._is_docked    = False
        self._is_moving    = False
        self._cargo        = None

        server.twin.register_robot(robot_id, self._current_pose)
        logger.info(f"🚗  AMR [{robot_id}] v0.2 registered at {self._current_pose.position}")

        self._register_tools()
        self._register_resources()

    def _mobile_caps(self) -> List[AASCapability]:
        return [AASCapability(
            capability_type = "MobileBase",
            properties      = {"MaxSpeed_ms": 1.5, "MaxPayload_kg": 100.0,
                               "BatteryCapacity_wh": 2000.0, "Nav2Compatible": 1.0},
            unit_map        = {"MaxSpeed_ms": "m/s", "MaxPayload_kg": "kg",
                               "BatteryCapacity_wh": "Wh"},
            semantic_uri    = "https://pmcp.ai/schema/v1/capabilities/MobileBase",
        )]

    def _register_tools(self):
        s   = self.server
        rid = self.robot_id

        @s.tool(
            category=ToolCategory.NAVIGATION, robot_id=rid,
            description=(
                "Navigate AMR to a 2D map position using ROS2 Nav2. "
                "Avoids obstacles. Supports bid_energy_j for zone auction."
            ),
            parameters=[
                ToolParameter("target_x", "float", "Target X (m)", unit="m"),
                ToolParameter("target_y", "float", "Target Y (m)", unit="m"),
                ToolParameter("speed",    "float", "Max speed (m/s)", unit="m/s",
                              min_val=0.1, max_val=1.5, required=False, default=0.5),
            ],
            estimated_duration_s=10.0, estimated_energy_j=300.0,
            max_speed_ms=1.5, min_human_clearance_m=0.5,
            capabilities=self._mobile_caps(),
        )
        async def navigate_to(target_x: float, target_y: float, speed: float = 0.5):
            return await self._execute_navigate(target_x, target_y, speed)

        @s.tool(
            category=ToolCategory.NAVIGATION, robot_id=rid,
            description="Navigate to charging dock and initiate charging.",
            parameters=[], estimated_duration_s=15.0, estimated_energy_j=100.0,
            max_speed_ms=0.3, requires_confirmation=False,
            capabilities=self._mobile_caps(),
        )
        async def dock():
            return await self._execute_dock()

        @s.tool(
            category=ToolCategory.NAVIGATION, robot_id=rid,
            description="Leave docking station and enter ready state.",
            parameters=[], estimated_duration_s=3.0, estimated_energy_j=20.0,
            max_speed_ms=0.2, requires_confirmation=False,
            capabilities=self._mobile_caps(),
        )
        async def undock():
            return await self._execute_undock()

        @s.tool(
            category=ToolCategory.MANIPULATION, robot_id=rid,
            description=(
                "Full pickup-and-deliver cycle: navigate to pickup, "
                "receive cargo, transit to dropoff."
            ),
            parameters=[
                ToolParameter("pickup_x",    "float", "Pickup X (m)", unit="m"),
                ToolParameter("pickup_y",    "float", "Pickup Y (m)", unit="m"),
                ToolParameter("dropoff_x",   "float", "Dropoff X (m)", unit="m"),
                ToolParameter("dropoff_y",   "float", "Dropoff Y (m)", unit="m"),
                ToolParameter("cargo_label", "str",   "Cargo description"),
            ],
            estimated_duration_s=30.0, estimated_energy_j=900.0,
            max_speed_ms=0.8,
            capabilities=self._mobile_caps(),
        )
        async def pickup_and_deliver(pickup_x, pickup_y, dropoff_x,
                                     dropoff_y, cargo_label):
            return await self._execute_pickup_deliver(
                pickup_x, pickup_y, dropoff_x, dropoff_y, cargo_label
            )

    def _register_resources(self):
        s   = self.server
        rid = self.robot_id

        @s.resource(robot_id=rid, resource_type=ResourceType.BATTERY,
                    description="Battery: %, voltage, runtime, charging flag",
                    update_rate_hz=1.0)
        async def battery_state():
            return {
                "percent":     round(self._battery_pct, 1),
                "voltage_v":   round(24.0 * (self._battery_pct / 100), 2),
                "runtime_min": round(self._battery_pct * 2.4, 0),
                "charging":    self._is_docked,
            }

        @s.resource(robot_id=rid, resource_type=ResourceType.LIDAR_SCAN,
                    description="2D safety laser scanner — obstacle distances (m)",
                    update_rate_hz=25.0)
        async def lidar_scan():
            dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
            return {d: round(random.uniform(0.5, 4.0), 2) for d in dirs}

        @s.resource(robot_id=rid, resource_type=ResourceType.MARKET_PRICE,
                    description="Live energy market: carbon intensity & electricity price",
                    update_rate_hz=0.1)
        async def market_price():
            # Simulate daily carbon intensity variation (low overnight, high daytime)
            hour = time.localtime().tm_hour
            carbon = 300 + 200 * math.sin((hour - 6) * math.pi / 12)
            price  = 0.05 + 0.08 * math.sin((hour - 6) * math.pi / 12)
            self.server.twin.update_market_price(carbon, max(price, 0.03))
            return {
                "carbon_intensity_g_kwh": round(carbon, 1),
                "energy_price_usd_kwh":   round(max(price, 0.03), 4),
                "timestamp_utc":          time.strftime("%H:%M:%S"),
            }

    # ── Hardware simulation ───────────────────────────────────

    async def _execute_navigate(self, tx, ty, speed):
        start    = self._current_pose.position
        dist     = start.distance_to(Vec3(tx, ty, 0))
        duration = dist / max(speed, 0.01)

        self._is_moving = True
        logger.info(f"  🚗  [{self.robot_id}] navigate ({tx:.2f}, {ty:.2f}) | {dist:.2f}m")

        steps = max(int(duration * 3), 2)
        for i in range(steps):
            frac = (i + 1) / steps
            self._current_pose.position.x = start.x + frac * (tx - start.x)
            self._current_pose.position.y = start.y + frac * (ty - start.y)
            self._battery_pct = max(0, self._battery_pct - (0.5 / steps))
            self.server.twin.update_pose(self.robot_id, self._current_pose)
            await asyncio.sleep(duration / steps)

        self._is_moving    = False
        self._current_pose = Pose(position=Vec3(tx, ty, 0))
        self.server.twin.update_pose(self.robot_id, self._current_pose)

        return ToolResult(
            success=True,
            message=f"Arrived at ({tx:.3f}, {ty:.3f})",
            data={"distance_m": round(dist, 3), "battery_pct": round(self._battery_pct, 1)},
            final_pose=self._current_pose,
            joint_torque_error_nm=_torque_sim(4, base=0.8),   # 4 wheel motors
        )

    async def _execute_dock(self):
        if self._is_docked:
            return ToolResult(success=False, message="Already docked")
        await self._execute_navigate(4.5, 0.2, speed=0.3)
        await asyncio.sleep(2.0)
        self._is_docked = True
        logger.info(f"  🔌  [{self.robot_id}] docked — charging")
        return ToolResult(success=True, message="Docked and charging",
                          data={"battery_pct": round(self._battery_pct, 1)})

    async def _execute_undock(self):
        if not self._is_docked:
            return ToolResult(success=False, message="Not docked")
        await asyncio.sleep(2.0)
        self._is_docked = False
        logger.info(f"  🔓  [{self.robot_id}] undocked")
        return ToolResult(success=True, message="Undocked — ready")

    async def _execute_pickup_deliver(self, px, py, dx, dy, label):
        logger.info(f"  📦  [{self.robot_id}] pickup [{label}] ({px},{py})→({dx},{dy})")
        await self._execute_navigate(px, py, speed=0.6)
        await asyncio.sleep(2.0)
        self._cargo = label
        await self._execute_navigate(dx, dy, speed=0.5)
        await asyncio.sleep(1.5)
        self._cargo = None
        return ToolResult(
            success=True,
            message=f"Delivered [{label}] to ({dx:.2f}, {dy:.2f})",
            data={"cargo": label, "delivered": True},
            final_pose=self._current_pose,
            joint_torque_error_nm=_torque_sim(4, base=1.2),
        )


# ─────────────────────────────────────────────────────────────
#  3. HARVESTER ROBOT (combined agent — NEW in v0.2)
# ─────────────────────────────────────────────────────────────

class HarvesterRobot:
    """
    Dedicated harvester that combines arm + AMR in a single agent.
    Registers its own tools on the server as a single logical unit.
    Use when physical arm+AMR are mounted together (e.g. mobile manipulator).
    """

    def __init__(self, server: PMCPServer, robot_id: str = "harvester-01",
                 initial_pose: Optional[Pose] = None):
        self.robot_id = robot_id
        self.server   = server
        self._pose    = initial_pose or Pose(position=Vec3(2.0, 2.0, 0.0))
        self._holding = False

        server.twin.register_robot(robot_id, self._pose)
        logger.info(f"🌾  HarvesterRobot [{robot_id}] registered")
        self._register_tools()

    def _register_tools(self):
        s   = self.server
        rid = self.robot_id

        @s.tool(
            category=ToolCategory.MANIPULATION, robot_id=rid,
            description=(
                "Full autonomous harvest: navigate to tray, inspect, "
                "grasp plant, transport to collection station."
            ),
            parameters=[
                ToolParameter("tray_x",   "float", "Tray X (m)", unit="m"),
                ToolParameter("tray_y",   "float", "Tray Y (m)", unit="m"),
                ToolParameter("dropoff_x","float", "Collection station X (m)", unit="m",
                              required=False, default=0.5),
                ToolParameter("dropoff_y","float", "Collection station Y (m)", unit="m",
                              required=False, default=3.5),
            ],
            estimated_duration_s=45.0, estimated_energy_j=1500.0,
            max_speed_ms=0.8,
            capabilities=[AASCapability(
                capability_type="Harvester",
                properties={"MaxReach_m": 0.85, "MaxPayload_kg": 1.5,
                            "CropTypes": 3.0},
                unit_map={"MaxReach_m": "m", "MaxPayload_kg": "kg"},
                semantic_uri="https://pmcp.ai/schema/v1/capabilities/Harvester",
            )],
        )
        async def harvest(tray_x: float, tray_y: float,
                          dropoff_x: float = 0.5, dropoff_y: float = 3.5):
            return await self._execute_harvest(tray_x, tray_y, dropoff_x, dropoff_y)

    async def _execute_harvest(self, tx, ty, dx, dy):
        logger.info(f"  🌾  [{self.robot_id}] full harvest cycle tray ({tx},{ty})")
        await asyncio.sleep(5.0)   # Simulate full cycle
        self._holding = False
        return ToolResult(
            success=True,
            message=f"Harvested tray ({tx:.2f}, {ty:.2f}) → delivered to ({dx:.2f}, {dy:.2f})",
            data={"tray_x": tx, "tray_y": ty,
                  "dropoff_x": dx, "dropoff_y": dy,
                  "cycle_complete": True},
            final_pose=Pose(position=Vec3(dx, dy, 0.0)),
            joint_torque_error_nm=_torque_sim(6, base=1.0),
        )