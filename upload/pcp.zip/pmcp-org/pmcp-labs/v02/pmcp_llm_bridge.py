"""
P-MCP LLM Bridge v0.2
=====================
Upgrades over v0.1:
  - RealClaudeAgent: actual Anthropic API tool-use calls
  - PlanningAgent: utility-aware decisions, auction bids
  - HarvestOrchestrator: market-price awareness, temporal pipelining
  - print_plan() shows utility scores and auction prices

Replace ANTHROPIC_API_KEY env var or pass api_key= to use real Claude.
Falls back to simulation if no key is set.
"""

import asyncio
import logging
import os
import time
from typing import Any, Dict, List, Optional

from a2a_ps.pmcp.server import PMCPServer
from a2a_ps.pmcp.schemas import ToolCall, ToolResult, ToolCallStatus

logger = logging.getLogger("a2a_ps.pmcp.llm_bridge")

# ── Optional real Claude import ───────────────────────────────
try:
    import anthropic as _anthropic
    _CLAUDE_AVAILABLE = True
except ImportError:
    _CLAUDE_AVAILABLE = False


# ─────────────────────────────────────────────────────────────
#  REAL CLAUDE AGENT  (NEW v0.2)
# ─────────────────────────────────────────────────────────────

class RealClaudeAgent:
    """
    Wraps the actual Anthropic API tool-use loop.

    P-MCP tool schemas → Claude tool-use → invoke() → confirm()

    Usage:
        agent = RealClaudeAgent(server, api_key="sk-ant-...")
        result = await agent.complete_goal("Harvest the basil in tray at (1.0, 0.8)")
    """

    MODEL = "claude-sonnet-4-20250514"

    def __init__(self, server: PMCPServer,
                 api_key: Optional[str] = None,
                 agent_id: str = "claude-agent-01"):
        self.server   = server
        self.agent_id = agent_id
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")

        if not _CLAUDE_AVAILABLE:
            logger.warning(
                "  ⚠  anthropic package not installed — "
                "RealClaudeAgent will not function. "
                "Run: pip install anthropic"
            )
        elif not self._api_key:
            logger.warning(
                "  ⚠  No ANTHROPIC_API_KEY set — "
                "RealClaudeAgent will not function."
            )

    def _build_tool_list(self) -> List[dict]:
        """
        Convert P-MCP tool schemas to Anthropic tool-use format.
        """
        tools = []
        for t in self.server.list_tools():
            properties = {}
            required   = []
            for p in t["parameters"]:
                prop = {"type": p["type"], "description": p["description"]}
                if p.get("unit"):
                    prop["description"] += f" (unit: {p['unit']})"
                if p.get("min") is not None:
                    prop["description"] += f" [min={p['min']}]"
                if p.get("max") is not None:
                    prop["description"] += f" [max={p['max']}]"
                properties[p["name"]] = prop
                if p["required"]:
                    required.append(p["name"])

            tools.append({
                "name":        t["name"],
                "description": (
                    f"[{t['robot_id']}] {t['description']} "
                    f"Physics: est. {t['physics']['estimated_duration_s']}s, "
                    f"{t['physics']['estimated_energy_j']}J"
                ),
                "input_schema": {
                    "type":       "object",
                    "properties": properties,
                    "required":   required,
                },
            })
        return tools

    async def complete_goal(self, goal: str,
                             system_context: str = "") -> List[ToolResult]:
        """
        Run a full tool-use loop with real Claude.

        1. Build tool list from server
        2. Call Claude with goal + tool schemas
        3. For each tool_use block:
           a. server.invoke() → get ProjectedOutcome
           b. Append outcome to context
           c. server.confirm() → execute
           d. Append result to context
        5. Repeat until Claude stops calling tools
        """
        if not _CLAUDE_AVAILABLE or not self._api_key:
            logger.warning("  Falling back to simulated planning — no real Claude available")
            return []

        client   = _anthropic.Anthropic(api_key=self._api_key)
        tools    = self._build_tool_list()
        messages = [{"role": "user", "content": goal}]

        if system_context:
            messages.insert(0, {"role": "user",
                                 "content": f"System context: {system_context}"})

        results = []

        logger.info(f"  🤖  [RealClaude] Starting tool-use loop for: {goal[:60]}...")

        for _round in range(20):   # Max 20 tool-use rounds
            response = client.messages.create(
                model      = self.MODEL,
                max_tokens = 2048,
                tools      = tools,
                messages   = messages,
                system     = (
                    "You are a robot farm orchestrator. "
                    "Use the available P-MCP tools to complete the goal. "
                    "Always inspect the projected_outcome before confirming a move. "
                    "Prefer lower energy actions when utility scores are equal."
                ),
            )

            # Append assistant turn
            messages.append({"role": "assistant", "content": response.content})

            if response.stop_reason != "tool_use":
                logger.info(f"  🤖  [RealClaude] Done. stop_reason={response.stop_reason}")
                break

            # Process tool-use blocks
            tool_results_content = []
            for block in response.content:
                if block.type != "tool_use":
                    continue

                tool_name = block.name
                tool_args = block.input
                logger.info(f"  🤖  [RealClaude] Calling [{tool_name}]({tool_args})")

                # Invoke through P-MCP
                call   = await self.server.invoke(
                    tool_name, caller_id=self.agent_id, **tool_args
                )
                p = call.projected

                # Build a rich result description for Claude
                outcome_text = (
                    f"ProjectedOutcome: duration={p.duration_s}s "
                    f"energy={p.energy_j}J carbon={p.carbon_g}g "
                    f"risk={p.risk_level} safe={p.safe_to_execute} "
                    f"utility={p.utility_score:.2f}"
                )
                if p.risk_reasons:
                    outcome_text += f" risks={p.risk_reasons}"
                if p.drift_warning:
                    outcome_text += f" DRIFT_WARNING={p.drift_warning}"

                if call.status == ToolCallStatus.SHADOW_FAIL:
                    result_text = f"BLOCKED: {outcome_text}"
                    result = ToolResult(
                        call_id=call.call_id, success=False,
                        message=f"Shadow blocked: {'; '.join(p.risk_reasons)}",
                    )
                else:
                    # Confirm and execute
                    result = await self.server.confirm(call.call_id)
                    result_text = (
                        f"{outcome_text} | "
                        f"RESULT: success={result.success} msg={result.message}"
                    )

                results.append(result)
                tool_results_content.append({
                    "type":        "tool_result",
                    "tool_use_id": block.id,
                    "content":     result_text,
                })

            messages.append({"role": "user", "content": tool_results_content})

        return results


# ─────────────────────────────────────────────────────────────
#  PLANNING AGENT (simulation — no API key needed)
# ─────────────────────────────────────────────────────────────

class PlanningAgent:
    """
    Simulated LLM agent with v0.2 enhancements:
      - Utility-weighted decision making
      - Auction bidding (bid based on utility score)
      - Drift warning awareness
      - Market price check before high-energy moves
    """

    def __init__(self, server: PMCPServer, agent_id: str = "harvest-llm-01"):
        self.server   = server
        self.agent_id = agent_id
        self._plan_log: List[dict] = []

    def _log(self, step: str, detail: str = ""):
        entry = {"ts": time.time(), "step": step, "detail": detail}
        self._plan_log.append(entry)
        logger.info(f"  🧠  [{self.agent_id}] {step}" + (f": {detail}" if detail else ""))

    async def read_context(self) -> dict:
        context = {}
        for r in self.server.list_resources():
            try:
                val = await self.server.read_resource(r["uri"])
                context[r["uri"]] = val
            except Exception:
                pass
        return context

    async def call_tool(
        self,
        tool_name:    str,
        auto_confirm: bool  = True,
        bid_energy_j: float = 0.0,
        **kwargs,
    ) -> ToolResult:
        """
        v0.2 decision loop:
          invoke → inspect ProjectedOutcome + utility_score
          → if utility justifies cost → confirm
          → else abort
          → if conflict + bid → auction
        """
        self._log(f"calling [{tool_name}]", str(kwargs))

        call = await self.server.invoke(
            tool_name,
            caller_id=self.agent_id,
            bid_energy_j=bid_energy_j,
            **kwargs,
        )

        if call.status == ToolCallStatus.SHADOW_FAIL:
            self._log("BLOCKED by shadow",
                      "; ".join(call.projected.risk_reasons))
            return ToolResult(
                call_id=call.call_id, success=False,
                message=f"Shadow blocked: {'; '.join(call.projected.risk_reasons)}",
            )

        p = call.projected

        # Log drift warning if present
        if p.drift_warning:
            self._log(f"DRIFT WARNING", p.drift_warning)

        self._log(
            "reviewing projection",
            f"dur={p.duration_s:.1f}s energy={p.energy_j:.0f}J "
            f"risk={p.risk_level} utility={p.utility_score:.2f} "
            f"auction_price={p.auction_price:.0f}J",
        )

        # v0.2: Utility-based abort — don't move if utility < energy cost threshold
        energy_threshold = p.energy_j / 1000.0   # crude: 1J → 0.001 utility
        if p.utility_score < energy_threshold and not auto_confirm:
            await self.server.abort(call.call_id, "utility below energy threshold")
            self._log("ABORTED (low utility)")
            return ToolResult(
                call_id=call.call_id, success=False,
                message=f"Aborted: utility {p.utility_score:.2f} < threshold {energy_threshold:.2f}",
            )

        # Abort if risk HIGH and not auto-confirmed
        if p.risk_level == "high" and not auto_confirm:
            await self.server.abort(call.call_id, "high risk — agent declined")
            self._log("ABORTED (high risk)")
            return ToolResult(
                call_id=call.call_id, success=False,
                message="Aborted: risk level high",
            )

        # Workspace conflict with bid → run auction
        if p.workspace_conflicts and bid_energy_j > 0:
            winner = await self.server.run_auction(p.workspace_conflicts[0])
            if winner and winner.call_id != call.call_id:
                self._log("LOST AUCTION", f"outbid for {p.workspace_conflicts[0]}")
                return ToolResult(
                    call_id=call.call_id, success=False,
                    message="Lost zone auction — will retry",
                )

        self._log(f"confirming [{call.call_id}]")
        result = await self.server.confirm(call.call_id)

        if result.success:
            self._log("SUCCESS", result.message)
        else:
            self._log("FAILED", result.message)

        return result

    def plan_summary(self) -> List[dict]:
        return list(self._plan_log)


# ─────────────────────────────────────────────────────────────
#  HARVEST ORCHESTRATOR  v0.2
# ─────────────────────────────────────────────────────────────

class HarvestOrchestrator:
    """
    v0.2 upgrades:
      - Market price awareness (defers low-utility moves during peak energy)
      - Temporal pipelining (arm + AMR launch in parallel without blocking)
      - Utility score logging
      - Auction bids for zone conflicts
    """

    def __init__(self, server: PMCPServer,
                 arm_id: str = "arm-01", amr_id: str = "amr-01"):
        self.server = server
        self.arm_id = arm_id
        self.amr_id = amr_id
        self.agent  = PlanningAgent(server, agent_id="harvest-orchestrator")
        self._harvest_log: List[dict] = []

    async def run_harvest_cycle(self, tray_x: float = 1.0,
                                 tray_y: float = 0.8) -> dict:
        cycle_start = time.time()
        logger.info(f"\n{'━'*60}")
        logger.info(f"  🌱  HARVEST CYCLE v0.2 — Tray at ({tray_x}, {tray_y})")
        logger.info(f"{'━'*60}")

        results = {}

        # ── Check market price before starting ────────────────
        market_uri = f"robot://{self.amr_id}/market_price"
        try:
            market = await self.server.read_resource(market_uri)
            carbon = market["value"]["carbon_intensity_g_kwh"]
            price  = market["value"]["energy_price_usd_kwh"]
            logger.info(
                f"  💹  Market: carbon={carbon:.0f}gCO₂/kWh  price=${price:.4f}/kWh"
            )
            if carbon > 600:
                logger.warning(
                    "  ⚠  High grid carbon intensity — consider deferring "
                    "non-urgent cycles"
                )
        except Exception:
            pass   # Market resource not available — proceed anyway

        # ── Phase 1: Inspect ──────────────────────────────────
        logger.info(f"\n  [Phase 1] Inspection")
        inspect = await self.agent.call_tool(
            "inspect_plant",
            tray_x=tray_x, tray_y=tray_y, height_above_m=0.3,
        )
        results["inspection"] = inspect.data

        if not inspect.success:
            return {"success": False, "phase": "inspect",
                    "reason": inspect.message}

        harvest_ready = inspect.data.get("harvest_ready", False)
        health_score  = inspect.data.get("health_score", 0)
        tray_id       = inspect.data.get("tray_id", "unknown")
        utility       = self.server.twin.harvest_utility(tray_id)

        logger.info(
            f"  📊  Health: {health_score:.0%}  Ready: {harvest_ready}  "
            f"Utility: {utility:.2f}"
        )

        if not harvest_ready:
            logger.info("  ℹ  Not ready — cycle aborted")
            return {"success": True, "harvested": False,
                    "reason": "plants_not_ready",
                    "health_score": health_score, "utility": utility}

        # ── Phase 2: Parallel position (temporal pipelining) ──
        logger.info(f"\n  [Phase 2] Parallel positioning (arm + AMR)")
        arm_task = self.agent.call_tool(
            "move_to",
            x=tray_x, y=tray_y - 0.1, z=0.35, speed=0.3,
            bid_energy_j=utility * 100,   # Bid proportional to utility
        )
        amr_task = self.agent.call_tool(
            "navigate_to",
            target_x=tray_x - 0.3, target_y=tray_y, speed=0.4,
            bid_energy_j=utility * 80,
        )
        arm_r, amr_r = await asyncio.gather(arm_task, amr_task)
        results["positioning"] = {"arm": arm_r.success, "amr": amr_r.success}

        # ── Phase 3: Harvest ───────────────────────────────────
        logger.info(f"\n  [Phase 3] Harvesting (utility={utility:.2f})")
        grab_r = await self.agent.call_tool(
            "grab", target_force_n=12.0, width_mm=30.0,
        )
        results["grab"] = grab_r.success

        if not grab_r.success:
            await self.agent.call_tool("home")
            return {"success": False, "phase": "harvest",
                    "reason": grab_r.message}

        # Lift
        await self.agent.call_tool(
            "move_to", x=tray_x, y=tray_y - 0.1, z=0.65, speed=0.15,
        )
        # Transfer to AMR bin
        await self.agent.call_tool(
            "move_to", x=tray_x - 0.3, y=tray_y, z=0.4, speed=0.2,
        )
        await self.agent.call_tool("release", width_mm=70.0)

        # ── Phase 4: Transport ─────────────────────────────────
        logger.info(f"\n  [Phase 4] Transport to processing station")
        transport_r = await self.agent.call_tool(
            "pickup_and_deliver",
            pickup_x=tray_x - 0.3, pickup_y=tray_y,
            dropoff_x=0.5, dropoff_y=3.5,
            cargo_label="harvested_basil",
        )
        results["transport"] = transport_r.success

        await self.agent.call_tool("home")

        duration = time.time() - cycle_start
        summary = {
            "success":      True,
            "harvested":    True,
            "tray":         (tray_x, tray_y),
            "duration_s":   round(duration, 1),
            "health_score": health_score,
            "utility_score": utility,
            "plan_steps":   len(self.agent.plan_summary()),
            "phases":       results,
        }

        logger.info(f"\n{'━'*60}")
        logger.info(f"  ✅  HARVEST COMPLETE in {duration:.1f}s  utility={utility:.2f}")
        logger.info(f"{'━'*60}\n")
        return summary

    def print_plan(self):
        print(f"\n{'─'*60}")
        print(f"  LLM Plan Log — {self.agent.agent_id}")
        print(f"{'─'*60}")
        for e in self.agent.plan_summary():
            t = time.strftime("%H:%M:%S", time.localtime(e["ts"]))
            print(f"  {t}  {e['step']}"
                  + (f"\n         → {e['detail']}" if e["detail"] else ""))
        print(f"{'─'*60}\n")