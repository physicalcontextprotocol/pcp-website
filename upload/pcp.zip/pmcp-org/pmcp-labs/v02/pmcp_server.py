"""
P-MCP Server v0.2 — Physical Tool Registry
===========================================
Upgrades over v0.1:
  - Confirmation timeout gate (auto-abort if agent goes silent)
  - Vickrey second-price auction for conflicting zone requests
  - AAS semantic capability query (find robots by property)
  - HIL feedback ingestion → self-healing twin
  - Market price resource (energy/carbon spot price stream)
  - Zenoh-ready stub (transport abstraction layer)
"""

import asyncio
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from a2a_ps.pmcp.schemas import (
    PMCPTool, PMCPResource, ToolCall, ToolResult, ToolParameter,
    ToolCallStatus, ToolCategory, ResourceType, ProjectedOutcome,
    Pose, Vec3, AASCapability,
)
from a2a_ps.pmcp.shadow import ShadowValidator, DigitalTwin

logger = logging.getLogger("a2a_ps.pmcp.server")

# Default confirmation window — hardware must not idle longer than this
DEFAULT_CONFIRM_TIMEOUT_MS = 5000   # 5 seconds


class PMCPServer:
    """
    P-MCP Server v0.2 — Physical Model Context Protocol Server.

    invoke() → shadow validate → [auction if conflict] → confirm() → execute()

    New in v0.2:
      - server.find_robots(capability="Gripper", MaxPayload_kg__gt=2.0)
      - server.invoke(..., bid_energy_j=50.0) triggers auction on conflict
      - Auto-abort if confirm() not called within confirm_timeout_ms
      - server.ingest_hil_feedback() feeds torque data to self-healing twin
    """

    def __init__(self, server_id: str, twin: DigitalTwin,
                 confirm_timeout_ms: float = DEFAULT_CONFIRM_TIMEOUT_MS):
        self.server_id          = server_id
        self.twin               = twin
        self.shadow             = ShadowValidator(twin)
        self.confirm_timeout_ms = confirm_timeout_ms

        self._tools:     Dict[str, PMCPTool]     = {}
        self._resources: Dict[str, PMCPResource] = {}
        self._calls:     Dict[str, ToolCall]     = {}
        self._audit:     List[dict]              = []

        # Pending auction rounds: zone_id → list of ToolCall
        self._auction_pool: Dict[str, List[ToolCall]] = {}

        logger.info(f"🖥️   P-MCP Server [{server_id}] v0.2 started "
                    f"(confirm_timeout={confirm_timeout_ms}ms)")

    # ─────────────────────────────────────────────────────────
    #  REGISTRATION
    # ─────────────────────────────────────────────────────────

    def tool(
        self,
        *,
        category:             ToolCategory,
        robot_id:             str,
        description:          str,
        parameters:           List[ToolParameter],
        estimated_duration_s: float = 1.0,
        estimated_energy_j:   float = 50.0,
        max_speed_ms:         float = 0.5,
        min_human_clearance_m: float = 0.5,
        requires_confirmation: bool  = True,
        capabilities:         Optional[List[AASCapability]] = None,
    ):
        def decorator(fn: Callable):
            t = PMCPTool(
                name                  = fn.__name__,
                description           = description,
                category              = category,
                robot_id              = robot_id,
                parameters            = parameters,
                handler               = fn,
                estimated_duration_s  = estimated_duration_s,
                estimated_energy_j    = estimated_energy_j,
                max_speed_ms          = max_speed_ms,
                min_human_clearance_m = min_human_clearance_m,
                requires_confirmation = requires_confirmation,
                capabilities          = capabilities or [],
            )
            self._tools[fn.__name__] = t
            logger.info(f"  🔧  Tool registered: [{robot_id}].{fn.__name__} "
                        f"({category.value})")
            return fn
        return decorator

    def resource(
        self,
        *,
        robot_id:         str,
        resource_type:    ResourceType,
        description:      str,
        update_rate_hz:   float = 10.0,
        coordinate_frame: str   = "world",
    ):
        def decorator(fn: Callable):
            uri = f"robot://{robot_id}/{resource_type.value}"
            r   = PMCPResource(
                uri              = uri,
                robot_id         = robot_id,
                resource_type    = resource_type,
                description      = description,
                update_rate_hz   = update_rate_hz,
                coordinate_frame = coordinate_frame,
            )
            r._updater = fn
            self._resources[uri] = r
            logger.info(f"  📡  Resource registered: {uri} @ {update_rate_hz}Hz")
            return fn
        return decorator

    # ─────────────────────────────────────────────────────────
    #  AAS SEMANTIC DISCOVERY  (NEW v0.2)
    # ─────────────────────────────────────────────────────────

    def find_robots(self, capability_type: str, **constraints) -> List[str]:
        """
        Semantic capability query — find robot_ids that match.

        Example:
            server.find_robots("Gripper", MaxPayload_kg__gt=2.0)
            server.find_robots("MobileBase", MaxSpeed_ms__gte=1.0)

        Constraint format: property__op=value
          ops: gt, gte, lt, lte, eq
        """
        op_map = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<=", "eq": "=="}
        matched = set()

        for tool in self._tools.values():
            for cap in tool.capabilities:
                if cap.capability_type != capability_type:
                    continue
                all_match = True
                for key, val in constraints.items():
                    parts = key.rsplit("__", 1)
                    prop  = parts[0]
                    op    = op_map.get(parts[1], "==") if len(parts) == 2 else "=="
                    if not cap.matches_query(prop, op, float(val)):
                        all_match = False
                        break
                if all_match:
                    matched.add(tool.robot_id)

        return list(matched)

    def list_capabilities(self) -> List[dict]:
        """Return all AAS capability manifests across registered tools."""
        caps = []
        for tool in self._tools.values():
            for cap in tool.capabilities:
                caps.append({
                    "robot_id":        tool.robot_id,
                    "tool":            tool.name,
                    "capability_type": cap.capability_type,
                    "manifest":        cap.to_json_ld(),
                })
        return caps

    # ─────────────────────────────────────────────────────────
    #  TOOL INVOCATION PIPELINE
    # ─────────────────────────────────────────────────────────

    async def invoke(
        self,
        tool_name:          str,
        caller_id:          str   = "agent",
        bid_energy_j:       float = 0.0,
        confirm_timeout_ms: Optional[float] = None,
        **kwargs,
    ) -> ToolCall:
        """
        Stage 1: Submit a tool call.

        If bid_energy_j > 0 and there's a zone conflict, an auction
        round is triggered automatically.

        confirm_timeout_ms: override the server default per-call.
        """
        if tool_name not in self._tools:
            raise ValueError(f"Unknown tool: {tool_name!r}. "
                             f"Available: {list(self._tools)}")

        tool = self._tools[tool_name]
        timeout = confirm_timeout_ms if confirm_timeout_ms is not None \
                  else self.confirm_timeout_ms

        call = ToolCall(
            tool_name           = tool_name,
            robot_id            = tool.robot_id,
            caller_id           = caller_id,
            arguments           = kwargs,
            status              = ToolCallStatus.PENDING,
            bid_energy_j        = bid_energy_j,
            confirm_deadline_ms = time.time() * 1000 + timeout,
        )
        self._calls[call.call_id] = call

        logger.info(
            f"\n  ▶  P-MCP invoke [{call.call_id}]: "
            f"{caller_id} → [{tool.robot_id}].{tool_name}({_fmt_args(kwargs)})"
            + (f" bid={bid_energy_j}J" if bid_energy_j else "")
        )

        schema    = tool.to_llm_schema()
        projected = self.shadow.validate(call, schema)
        call.projected = projected

        # ── Auction if conflict and bid provided ───────────────
        if projected.workspace_conflicts and bid_energy_j > 0:
            zone_key = projected.workspace_conflicts[0]
            logger.info(f"  🏛️   Auction triggered for zone conflict: {zone_key}")
            self._auction_pool.setdefault(zone_key, []).append(call)
            # Auction resolves asynchronously — call remains PENDING until winner
            call.status = ToolCallStatus.SHADOW_OK   # allow confirm from auction winner
        elif projected.safe_to_execute:
            call.status = ToolCallStatus.SHADOW_OK
            logger.info(f"  ✅  Shadow OK → awaiting confirmation "
                        f"(deadline in {timeout:.0f}ms)")
            # Start timeout watchdog
            asyncio.ensure_future(self._confirm_watchdog(call.call_id, timeout))
        else:
            call.status = ToolCallStatus.SHADOW_FAIL
            logger.warning(f"  🚫  Shadow BLOCKED → {'; '.join(projected.risk_reasons)}")

        self._audit_event(call, "invoke")
        return call

    async def _confirm_watchdog(self, call_id: str, timeout_ms: float):
        """
        Auto-abort if agent doesn't confirm within timeout_ms.
        Prevents robot from holding high-torque state indefinitely.
        """
        await asyncio.sleep(timeout_ms / 1000)
        call = self._calls.get(call_id)
        if call and call.status == ToolCallStatus.SHADOW_OK:
            call.status = ToolCallStatus.TIMEOUT
            logger.warning(
                f"  ⏱️   TIMEOUT [{call_id}]: agent did not confirm within "
                f"{timeout_ms:.0f}ms — auto-aborted for safety"
            )
            self._audit_event(call, f"timeout:{timeout_ms}ms")

    async def confirm(self, call_id: str) -> ToolResult:
        """Stage 2: Agent confirms → hardware executes."""
        if call_id not in self._calls:
            raise KeyError(f"No call with id: {call_id}")

        call = self._calls[call_id]

        if call.status == ToolCallStatus.SHADOW_FAIL:
            raise PermissionError(
                f"Cannot confirm blocked call [{call_id}]. "
                f"Risks: {call.projected.risk_reasons}"
            )
        if call.status == ToolCallStatus.TIMEOUT:
            raise RuntimeError(
                f"Call [{call_id}] timed out — re-invoke to retry"
            )
        if call.status not in (ToolCallStatus.SHADOW_OK, ToolCallStatus.PENDING):
            raise RuntimeError(
                f"Call [{call_id}] is in state {call.status}, cannot confirm"
            )

        call.status       = ToolCallStatus.CONFIRMED
        call.confirmed_at = time.time()
        logger.info(f"  ✔  Confirmed [{call_id}] — executing hardware")

        # Reserve temporal zone if envelope available
        if call.projected and call.projected.temporal_envelope:
            for slot in call.projected.temporal_envelope.slots:
                self.twin.reserve_zone(
                    slot.robot_id, slot.zone_id,
                    slot.start_ms, slot.end_ms, slot.position,
                )

        self._audit_event(call, "confirm")
        return await self._execute(call)

    async def invoke_and_confirm(self, tool_name: str, caller_id: str = "agent",
                                  **kwargs) -> ToolResult:
        call = await self.invoke(tool_name, caller_id=caller_id, **kwargs)
        if call.status == ToolCallStatus.SHADOW_FAIL:
            return ToolResult(
                call_id = call.call_id,
                success = False,
                message = f"Blocked: {'; '.join(call.projected.risk_reasons)}",
            )
        return await self.confirm(call.call_id)

    async def abort(self, call_id: str, reason: str = "agent abort"):
        if call_id in self._calls:
            call = self._calls[call_id]
            call.status = ToolCallStatus.ABORTED
            logger.warning(f"  ⛔  Aborted [{call_id}]: {reason}")
            self._audit_event(call, f"abort:{reason}")

    # ─────────────────────────────────────────────────────────
    #  VICKREY AUCTION  (NEW v0.2)
    # ─────────────────────────────────────────────────────────

    async def run_auction(self, zone_key: str) -> Optional[ToolCall]:
        """
        Vickrey second-price auction for competing tool calls.

        Winner = highest bidder.
        Winner pays second-highest bid (truth-revelation incentive).
        All losers are aborted with reason "outbid".

        Returns winning ToolCall (or None if pool is empty).
        """
        candidates = self._auction_pool.pop(zone_key, [])
        if not candidates:
            return None
        if len(candidates) == 1:
            winner = candidates[0]
            winner.projected.auction_price = winner.bid_energy_j
            logger.info(f"  🏛️   Auction [{zone_key}]: sole bidder [{winner.caller_id}] wins")
            return winner

        candidates.sort(key=lambda c: c.bid_energy_j, reverse=True)
        winner       = candidates[0]
        second_price = candidates[1].bid_energy_j

        winner.projected.auction_price = second_price
        logger.info(
            f"  🏛️   Auction [{zone_key}]: winner=[{winner.caller_id}] "
            f"bid={winner.bid_energy_j}J pays={second_price}J (Vickrey)"
        )

        for loser in candidates[1:]:
            await self.abort(loser.call_id, reason=f"outbid in zone [{zone_key}]")
            logger.info(
                f"       ↳ [{loser.caller_id}] outbid "
                f"({loser.bid_energy_j}J < {winner.bid_energy_j}J)"
            )

        return winner

    # ─────────────────────────────────────────────────────────
    #  HIL FEEDBACK  (NEW v0.2)
    # ─────────────────────────────────────────────────────────

    def ingest_hil_feedback(self, call_id: str,
                             torque_errors_nm: List[float]):
        """
        Feed hardware-in-the-loop telemetry back to the self-healing twin.
        Call this after a ToolResult arrives with joint_torque_error_nm data.
        """
        call = self._calls.get(call_id)
        if not call or not call.result:
            return
        result    = call.result
        projected = call.projected
        if projected:
            self.twin.record_tool_outcome(
                robot_id    = call.robot_id,
                projected_s = projected.duration_s,
                actual_s    = result.duration_actual_s,
                torque_errors = torque_errors_nm,
            )
            logger.info(
                f"  📈  HIL feedback [{call_id}]: "
                f"projected={projected.duration_s:.2f}s "
                f"actual={result.duration_actual_s:.2f}s "
                f"torque_err={[round(t,2) for t in torque_errors_nm]}"
            )

    # ─────────────────────────────────────────────────────────
    #  RESOURCES
    # ─────────────────────────────────────────────────────────

    async def read_resource(self, uri: str) -> dict:
        if uri not in self._resources:
            raise ValueError(f"Unknown resource URI: {uri}")
        r = self._resources[uri]
        if hasattr(r, "_updater"):
            val = await r._updater()
            r.write(val)
        return r.read()

    def list_resources(self) -> List[dict]:
        return [
            {"uri": uri, "type": r.resource_type.value,
             "robot": r.robot_id, "rate_hz": r.update_rate_hz}
            for uri, r in self._resources.items()
        ]

    # ─────────────────────────────────────────────────────────
    #  INTROSPECTION
    # ─────────────────────────────────────────────────────────

    def list_tools(self) -> List[dict]:
        return [t.to_llm_schema() for t in self._tools.values()]

    def get_tool_schema(self, tool_name: str) -> dict:
        return self._tools[tool_name].to_llm_schema()

    def stats(self) -> dict:
        counts: Dict[str, int] = {}
        for c in self._calls.values():
            counts[c.status.value] = counts.get(c.status.value, 0) + 1
        return {
            "server_id":        self.server_id,
            "tools":            len(self._tools),
            "resources":        len(self._resources),
            "calls_total":      len(self._calls),
            "calls_by_status":  counts,
            "shadow":           self.shadow.stats(),
            "auction_pools":    {k: len(v) for k, v in self._auction_pool.items()},
        }

    # ─────────────────────────────────────────────────────────
    #  INTERNAL
    # ─────────────────────────────────────────────────────────

    async def _execute(self, call: ToolCall) -> ToolResult:
        tool = self._tools[call.tool_name]
        t0   = time.time()
        call.status = ToolCallStatus.EXECUTING

        try:
            result: ToolResult = await tool.handler(**call.arguments)
            result.call_id             = call.call_id
            result.duration_actual_s   = round(time.time() - t0, 3)
            result.projected_duration_s = call.projected.duration_s if call.projected else 0.0
            call.status                = ToolCallStatus.SUCCESS
            call.result                = result

            if result.final_pose:
                self.twin.update_pose(call.robot_id, result.final_pose)

            # Auto-ingest HIL feedback if torque data present
            if result.joint_torque_error_nm:
                self.ingest_hil_feedback(call.call_id, result.joint_torque_error_nm)

            # Release temporal reservation
            if call.projected and call.projected.temporal_envelope:
                for slot in call.projected.temporal_envelope.slots:
                    self.twin.release_zone_reservation(slot.robot_id, slot.zone_id)

            logger.info(
                f"  🤖  Executed [{call.call_id}] in {result.duration_actual_s:.2f}s → "
                f"{'OK' if result.success else 'FAIL'}: {result.message}"
            )
            self._audit_event(call, "execute_ok")
            return result

        except Exception as e:
            call.status = ToolCallStatus.FAILED
            result = ToolResult(
                call_id          = call.call_id,
                success          = False,
                message          = f"Hardware error: {e}",
                duration_actual_s = round(time.time() - t0, 3),
            )
            call.result = result
            logger.error(f"  ❌  Execution failed [{call.call_id}]: {e}")
            self._audit_event(call, f"execute_fail:{e}")
            return result

    def _audit_event(self, call: ToolCall, event: str):
        self._audit.append({
            "ts":      time.time(),
            "call_id": call.call_id,
            "tool":    call.tool_name,
            "robot":   call.robot_id,
            "caller":  call.caller_id,
            "event":   event,
            "status":  call.status.value,
        })


def _fmt_args(kwargs: dict) -> str:
    return ", ".join(f"{k}={v}" for k, v in kwargs.items())