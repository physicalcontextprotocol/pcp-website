"""
P-MCP Full Demo v0.2 — Physical Model Context Protocol
=======================================================
Complete end-to-end demonstration of all upgrades:

  LLM Agent (simulated or real Claude via API)
      ↓
  P-MCP Server v0.2 (confirm timeout gate, Vickrey auctions, AAS discovery)
      ↓
  Shadow Validator v0.2 (tube collision, 4D temporal, self-healing physics)
      ↓
  Digital Twin v0.2 (plant health, market prices, temporal reservations)
      ↓
  Robot Agents v0.2 (AAS caps, HIL torque feedback, motor aging)
      ↓
  [Production: ROS2 / OPC UA / Zenoh / Viam + DID signing]

Scenarios:
  1. Tool discovery + AAS semantic query
  2. Sensor context + market price reading
  3. Move with shadow validation (tube check)
  4. Safety block — human in zone
  5. Workspace conflict + Vickrey auction
  6. 4D temporal reservation — parallel pipelining
  7. Self-healing physics — drift detection
  8. Autonomous harvest cycle (full multi-robot)
  9. Session stats + physics model report

Run:
    python main_pmcp.py
"""

import asyncio
import logging
import sys
import time

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("a2a_ps.pmcp_demo")
logging.getLogger("asyncio").setLevel(logging.WARNING)

sys.path.insert(0, "/home/claude")

from a2a_ps.pmcp.shadow import DigitalTwin, WorkspaceZone
from a2a_ps.pmcp.server import PMCPServer
from a2a_ps.pmcp.schemas import Vec3, Pose
from a2a_ps.pmcp.llm_bridge import PlanningAgent, HarvestOrchestrator
from a2a_ps.robots.agents import RoboticArmAgent, AMRAgent, HarvesterRobot


# ─────────────────────────────────────────────────────────────
#  DISPLAY HELPERS
# ─────────────────────────────────────────────────────────────

def banner(title: str, subtitle: str = ""):
    w = 64
    print(f"\n{'═'*w}")
    print(f"  {title}")
    if subtitle:
        print(f"  {subtitle}")
    print(f"{'═'*w}")


def section(title: str):
    pad = max(0, 54 - len(title))
    print(f"\n  ── {title} {'─'*pad}")


# ─────────────────────────────────────────────────────────────
#  SCENARIO 1: Tool discovery + AAS semantic query
# ─────────────────────────────────────────────────────────────

async def scenario_tool_discovery(server: PMCPServer):
    section("Tool Catalog Discovery + AAS Semantic Query")

    tools = server.list_tools()
    logger.info(f"  📖  P-MCP server exposes {len(tools)} tools:")
    for t in tools:
        params = ", ".join(
            f"{p['name']}:{p['type']}"
            + (f"({p.get('unit','')})" if p.get("unit") else "")
            for p in t["parameters"]
        )
        logger.info(f"       [{t['robot_id']}].{t['name']}({params})")

    resources = server.list_resources()
    logger.info(f"\n  📡  {len(resources)} live resources:")
    for r in resources:
        logger.info(f"       {r['uri']}  @ {r['rate_hz']}Hz")

    # v0.2: AAS semantic query
    logger.info(f"\n  🔍  AAS Query: robots with Gripper.MaxPayload > 1.5kg")
    grippers = server.find_robots("Gripper", MaxPayload_kg__gt=1.5)
    logger.info(f"       → {grippers}")

    logger.info(f"  🔍  AAS Query: robots with MobileBase.MaxSpeed >= 1.0 m/s")
    fast_amrs = server.find_robots("MobileBase", MaxSpeed_ms__gte=1.0)
    logger.info(f"       → {fast_amrs}")

    caps = server.list_capabilities()
    logger.info(f"\n  📋  {len(caps)} AAS capability manifests registered")


# ─────────────────────────────────────────────────────────────
#  SCENARIO 2: Sensor context + market price
# ─────────────────────────────────────────────────────────────

async def scenario_sensor_context(server: PMCPServer):
    section("Sensor Context + Market Price Reading")
    logger.info("  🧠  Agent reading environment state before planning...")

    context = {}
    for r in server.list_resources():
        val = await server.read_resource(r["uri"])
        context[r["uri"]] = val

    for uri, data in context.items():
        age_ms = data.get("age_ms", 0)
        val    = data.get("value", {})
        if isinstance(val, dict):
            summary = "  ".join(f"{k}={v}" for k, v in list(val.items())[:3])
        else:
            summary = str(val)
        label = uri.split("/")[-1]
        logger.info(f"  📊  {label:<22} age={age_ms:.0f}ms  {summary}")


# ─────────────────────────────────────────────────────────────
#  SCENARIO 3: Move with shadow validation (tube check)
# ─────────────────────────────────────────────────────────────

async def scenario_shadow_check(server: PMCPServer):
    section("Move with Shadow Validation (Tube Collision + Temporal)")
    logger.info("  🧠  Agent: 'Move arm to inspect tray at (0.8, 0.6)'")

    call = await server.invoke(
        "move_to", caller_id="demo-agent",
        x=0.8, y=0.6, z=0.5, speed=0.3,
    )
    p = call.projected

    logger.info(f"\n  🔮  Projected Outcome:")
    logger.info(f"       Duration:    {p.duration_s:.1f}s")
    logger.info(f"       Energy:      {p.energy_j:.0f}J  ({p.carbon_g*1000:.2f}mgCO₂)")
    logger.info(f"       Risk:        {p.risk_level}")
    logger.info(f"       Safe:        {p.safe_to_execute}")
    logger.info(f"       Utility:     {p.utility_score:.2f}")
    if p.drift_warning:
        logger.warning(f"       ⚙️  Drift:  {p.drift_warning}")
    if p.temporal_envelope and p.temporal_envelope.slots:
        slot = p.temporal_envelope.slots[0]
        dur  = slot.end_ms - slot.start_ms
        logger.info(f"       4D Reserve: [{slot.zone_id}] for {dur:.0f}ms")

    logger.info(f"\n  🧠  Agent approves (risk=low, utility={p.utility_score:.2f})")
    result = await server.confirm(call.call_id)
    logger.info(f"  {'✅' if result.success else '❌'}  {result.message}")

    # Feed HIL torque data back
    if result.joint_torque_error_nm:
        server.ingest_hil_feedback(call.call_id, result.joint_torque_error_nm)


# ─────────────────────────────────────────────────────────────
#  SCENARIO 4: Safety block — human in zone
# ─────────────────────────────────────────────────────────────

async def scenario_safety_block(server: PMCPServer, twin: DigitalTwin):
    section("Safety Block — Human Detected in Zone")
    logger.info("  👤  Safety scanner: human detected in grow_zone_a!")

    twin.set_human_present("grow_zone_a", True)

    call = await server.invoke(
        "move_to", caller_id="demo-agent",
        x=1.0, y=1.0, z=0.4, speed=0.5,
    )
    p = call.projected
    logger.info(f"\n  🔮  Shadow: safe={p.safe_to_execute} risk={p.risk_level}")
    for r in p.risk_reasons:
        logger.warning(f"  🚫  {r}")
    logger.info(f"  🧠  Agent: cannot confirm — human clearance violation")
    logger.info(f"  🛑  Call status: {call.status.value} — hardware never touched")

    twin.set_human_present("grow_zone_a", False)
    logger.info(f"  ✅  Human cleared — zone safe again")


# ─────────────────────────────────────────────────────────────
#  SCENARIO 5: Workspace conflict + Vickrey auction
# ─────────────────────────────────────────────────────────────

async def scenario_vickrey_auction(server: PMCPServer, twin: DigitalTwin):
    section("Workspace Conflict + Vickrey Second-Price Auction")
    logger.info("  🏛️   Two agents compete for the same zone")

    twin.update_pose("amr-01", Pose(position=Vec3(1.4, 0.9, 0.0)))

    # Simulate two competing agents invoking the same tool concurrently
    logger.info("  🧠  [harvest-agent]  bids 80J for zone (utility=0.80)")
    logger.info("  🧠  [maintenance-agent] bids 30J for zone (utility=0.30)")

    call_a = await server.invoke(
        "move_to", caller_id="harvest-agent",
        x=1.5, y=0.9, z=0.4, speed=0.25,
        bid_energy_j=80.0,
    )
    p = call_a.projected

    logger.info(f"\n  🔮  Shadow: conflicts={p.workspace_conflicts}")
    logger.info(f"             risk={p.risk_level}")

    if p.workspace_conflicts:
        # Run auction
        logger.info(f"\n  🏛️   Running Vickrey auction for zone conflict...")
        # Simulate second bidder
        call_b = await server.invoke(
            "move_to", caller_id="maintenance-agent",
            x=1.5, y=0.9, z=0.4, speed=0.1,
            bid_energy_j=30.0,
        )
        # Add both to auction pool
        zone_key = p.workspace_conflicts[0]
        server._auction_pool.setdefault(zone_key, [])
        server._auction_pool[zone_key] = [call_a, call_b]
        winner = await server.run_auction(zone_key)

        if winner:
            logger.info(f"\n  🏆  Winner: [{winner.caller_id}] "
                        f"bid={winner.bid_energy_j}J "
                        f"pays={winner.projected.auction_price:.0f}J (Vickrey)")
            twin.update_pose("amr-01", Pose(position=Vec3(4.5, 0.5, 0.0)))
            result = await server.confirm(winner.call_id)
            logger.info(f"  {'✅' if result.success else '❌'}  {result.message}")
    else:
        result = await server.confirm(call_a.call_id)
        logger.info(f"  ✅  {result.message}")

    # Reset
    twin.update_pose("amr-01", Pose(position=Vec3(4.5, 0.5, 0.0)))


# ─────────────────────────────────────────────────────────────
#  SCENARIO 6: 4D temporal reservation — pipelining
# ─────────────────────────────────────────────────────────────

async def scenario_temporal_reservation(server: PMCPServer, twin: DigitalTwin):
    section("4D Temporal Reservation — Parallel Motion Pipelining")
    logger.info("  ⏰  Arm and AMR launch in parallel — shadow reserves time slots")

    arm_start = time.time()

    # Launch both tools truly in parallel — temporal reservations prevent conflict
    arm_task = server.invoke(
        "move_to", caller_id="arm-pipeline",
        x=1.0, y=0.8, z=0.4, speed=0.3,
    )
    amr_task = server.invoke(
        "navigate_to", caller_id="amr-pipeline",
        target_x=0.7, target_y=0.8, speed=0.4,
    )

    arm_call, amr_call = await asyncio.gather(arm_task, amr_task)

    for call, label in [(arm_call, "ARM"), (amr_call, "AMR")]:
        p = call.projected
        if p.temporal_envelope and p.temporal_envelope.slots:
            slot = p.temporal_envelope.slots[0]
            logger.info(
                f"  ⏰  [{label}] reserved [{slot.zone_id}] "
                f"{slot.end_ms - slot.start_ms:.0f}ms window"
            )

    # Confirm both
    if arm_call.status.value == "SHADOW_OK":
        await server.confirm(arm_call.call_id)
    if amr_call.status.value == "SHADOW_OK":
        await server.confirm(amr_call.call_id)

    elapsed = time.time() - arm_start
    logger.info(f"  ✅  Parallel execution completed in {elapsed:.1f}s "
                f"(serial would have been ~{elapsed*1.8:.1f}s)")


# ─────────────────────────────────────────────────────────────
#  SCENARIO 7: Self-healing physics drift detection
# ─────────────────────────────────────────────────────────────

async def scenario_drift_detection(server: PMCPServer, twin: DigitalTwin):
    section("Self-Healing Physics — Drift Detection Simulation")
    logger.info("  ⚙️   Simulating 15 moves with increasing motor wear...")

    model = twin.get_physics_model("arm-01")
    arm_call_count = 0

    for i in range(15):
        # Inject synthetic drift — actual duration 20% longer than projected
        projected_s = 2.0
        actual_s    = 2.0 + i * 0.05   # Gets slower each call
        torques     = [float(i) * 0.15 for _ in range(6)]
        model.record_outcome(projected_s, actual_s, torques)
        arm_call_count += 1

    stats = server.shadow.stats()
    logger.info(f"\n  📊  Physics Model Report:")
    for rid, m in stats["physics_models"].items():
        logger.info(f"       [{rid}]")
        logger.info(f"         duration_scale: {m['duration_scale']:.3f}")
        logger.info(f"         energy_scale:   {m['energy_scale']:.3f}")
        if m["drift_warning"]:
            logger.warning(f"         ⚠  {m['drift_warning']}")

    # Now invoke a tool — shadow uses corrected model
    call = await server.invoke(
        "move_to", caller_id="drift-test",
        x=0.5, y=0.5, z=0.5, speed=0.2,
    )
    p = call.projected
    logger.info(
        f"\n  🔮  Shadow with corrected model: "
        f"duration={p.duration_s:.1f}s (was ~2.0s before correction)"
    )
    if p.drift_warning:
        logger.warning(f"  ⚠  {p.drift_warning}")
    await server.abort(call.call_id, "drift test — no hardware")


# ─────────────────────────────────────────────────────────────
#  SCENARIO 8: Full harvest cycle
# ─────────────────────────────────────────────────────────────

async def scenario_harvest_cycle(server: PMCPServer):
    section("Autonomous Harvest Cycle v0.2")
    logger.info("  🌱  Goal: Harvest basil from Tray at (1.0, 0.8)")
    logger.info("  🧠  HarvestOrchestrator: market-aware, utility-weighted...\n")

    orchestrator = HarvestOrchestrator(server, arm_id="arm-01", amr_id="amr-01")
    result       = await orchestrator.run_harvest_cycle(tray_x=1.0, tray_y=0.8)

    logger.info(f"\n  📋  Harvest Result:")
    for k, v in result.items():
        if k != "phases":
            logger.info(f"       {k}: {v}")

    orchestrator.print_plan()


# ─────────────────────────────────────────────────────────────
#  SCENARIO 9: Session stats + physics model report
# ─────────────────────────────────────────────────────────────

async def print_final_stats(server: PMCPServer):
    stats = server.stats()
    banner("P-MCP v0.2 Session Stats")

    logger.info(f"  Tools registered:   {stats['tools']}")
    logger.info(f"  Resources:          {stats['resources']}")
    logger.info(f"  Tool calls total:   {stats['calls_total']}")
    logger.info(f"  By status:")
    for status, count in stats["calls_by_status"].items():
        bar = "█" * min(count * 2, 20)
        logger.info(f"    {status:<20} {count:>3}  {bar}")

    logger.info(f"\n  Shadow validator:")
    s = stats["shadow"]
    logger.info(f"    Validations run:       {s['validations_run']}")
    logger.info(f"    Calls blocked:         {s['validations_blocked']}")
    logger.info(f"    Block rate:            {s['block_rate_pct']}%")
    logger.info(f"    Active reservations:   {s['active_reservations']}")

    logger.info(f"\n  Physics models (self-healing):")
    for rid, m in s["physics_models"].items():
        drift = f"  ⚠ {m['drift_warning']}" if m["drift_warning"] else ""
        logger.info(
            f"    [{rid}]  "
            f"dur_scale={m['duration_scale']:.3f}  "
            f"energy_scale={m['energy_scale']:.3f}"
            f"{drift}"
        )

    if stats.get("auction_pools"):
        logger.info(f"\n  Active auction pools: {stats['auction_pools']}")

    print()


# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

async def main():
    banner(
        "P-MCP v0.2  |  Physical Model Context Protocol",
        "Robot control via tool-calling  |  Full upgrade stack",
    )

    # 1. Digital twin with higher power budget for demo
    twin = DigitalTwin(power_budget_w=5000.0)

    # 2. P-MCP server with 5-second confirm timeout gate
    server = PMCPServer("farm-pmcp-v2", twin, confirm_timeout_ms=5000)

    # 3. Register all robot agents
    print("\n  Registering robot agents...")
    arm = RoboticArmAgent(
        server, robot_id="arm-01",
        base_pose=Pose(position=Vec3(1.5, 1.0, 0.5)),
    )
    amr = AMRAgent(
        server, robot_id="amr-01",
        initial_pose=Pose(position=Vec3(4.5, 0.5, 0.0)),
    )
    # HarvesterRobot (combined agent)
    harvester = HarvesterRobot(
        server, robot_id="harvester-01",
        initial_pose=Pose(position=Vec3(2.0, 2.0, 0.0)),
    )

    print(f"\n  ✅  P-MCP v0.2 server ready:")
    print(f"       Tools:        {len(server._tools)}")
    print(f"       Resources:    {len(server._resources)}")
    print(f"       Confirm gate: {server.confirm_timeout_ms:.0f}ms timeout")

    # ── Run all scenarios ──────────────────────────────────────
    await scenario_tool_discovery(server)
    await asyncio.sleep(0.2)

    await scenario_sensor_context(server)
    await asyncio.sleep(0.2)

    await scenario_shadow_check(server)
    await asyncio.sleep(0.2)

    await scenario_safety_block(server, twin)
    await asyncio.sleep(0.2)

    await scenario_vickrey_auction(server, twin)
    await asyncio.sleep(0.2)

    await scenario_temporal_reservation(server, twin)
    await asyncio.sleep(0.2)

    await scenario_drift_detection(server, twin)
    await asyncio.sleep(0.2)

    await scenario_harvest_cycle(server)

    await print_final_stats(server)

    print("  P-MCP v0.2 demo complete. 🤖🌱\n")


if __name__ == "__main__":
    asyncio.run(main())