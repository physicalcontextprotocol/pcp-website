"""
P-MCP Shadow Layer v0.2 — Digital Twin Pre-Validation
======================================================
Upgrades over v0.1:
  1. 4D Temporal Reservations — space-time zone locking
  2. Self-Healing Physics Model — drift correction from HIL feedback
  3. Biological Coupling — plant health affects risk level
  4. PyBullet-ready hook — drop-in slot for real collision engine
  5. Reachability tube — checks path volume, not just endpoint
"""

import logging
import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from a2a_ps.pmcp.schemas import (
    ToolCall, ProjectedOutcome, Pose, Vec3, ToolCallStatus,
    TemporalEnvelope, SpaceTimeSlot,
)

logger = logging.getLogger("a2a_ps.pmcp.shadow")


# ─────────────────────────────────────────────────────────────
#  WORKSPACE ZONE
# ─────────────────────────────────────────────────────────────

class WorkspaceZone:
    def __init__(self, name: str, min_corner: Vec3, max_corner: Vec3,
                 zone_type: str = "clear"):
        self.name = name
        self.min  = min_corner
        self.max  = max_corner
        self.zone_type = zone_type

    def contains(self, point: Vec3) -> bool:
        return (self.min.x <= point.x <= self.max.x and
                self.min.y <= point.y <= self.max.y and
                self.min.z <= point.z <= self.max.z)

    def intersects_path(self, start: Vec3, end: Vec3, steps: int = 30) -> bool:
        for i in range(steps + 1):
            t = i / steps
            p = Vec3(
                start.x + t * (end.x - start.x),
                start.y + t * (end.y - start.y),
                start.z + t * (end.z - start.z),
            )
            if self.contains(p):
                return True
        return False

    def intersects_tube(self, start: Vec3, end: Vec3,
                        radius: float = 0.15, steps: int = 30) -> bool:
        """
        Reachability TUBE check — not just the centreline.
        Checks a cylinder of `radius` metres around the path.
        In production, replace with PyBullet getClosestPoints().
        """
        for i in range(steps + 1):
            t = i / steps
            centre = Vec3(
                start.x + t * (end.x - start.x),
                start.y + t * (end.y - start.y),
                start.z + t * (end.z - start.z),
            )
            # Check 8 radial offsets around centreline
            for angle in [k * math.pi / 4 for k in range(8)]:
                probe = Vec3(
                    centre.x + radius * math.cos(angle),
                    centre.y + radius * math.sin(angle),
                    centre.z,
                )
                if self.contains(probe):
                    return True
        return False


# ─────────────────────────────────────────────────────────────
#  ROBOT PHYSICS MODEL  (self-healing)
# ─────────────────────────────────────────────────────────────

@dataclass
class RobotPhysicsModel:
    """
    Per-robot learned physics parameters.
    Starts from tool defaults and drifts-corrects over time.
    """
    robot_id: str
    duration_scale: float = 1.0      # Multiplier on estimated_duration_s
    energy_scale:   float = 1.0      # Multiplier on estimated_energy_j
    friction_coeff: float = 1.0      # Joint friction factor
    torque_baseline_nm: List[float] = field(default_factory=lambda: [0.0]*6)

    # Rolling window of (projected, actual) duration pairs
    _duration_history: deque = field(default_factory=lambda: deque(maxlen=50))
    _torque_history:   deque = field(default_factory=lambda: deque(maxlen=50))

    DRIFT_THRESHOLD = 0.10   # 10% sustained drift triggers recalibration

    def record_outcome(self, projected_s: float, actual_s: float,
                       torque_errors: List[float]):
        self._duration_history.append((projected_s, actual_s))
        if torque_errors:
            self._torque_history.append(torque_errors)
        self._recalibrate()

    def _recalibrate(self):
        if len(self._duration_history) < 10:
            return
        ratios = [a / max(p, 0.001) for p, a in self._duration_history]
        mean_ratio = sum(ratios) / len(ratios)
        if abs(mean_ratio - 1.0) > self.DRIFT_THRESHOLD:
            old = self.duration_scale
            self.duration_scale = round(mean_ratio, 3)
            logger.warning(
                f"  ⚙️  [{self.robot_id}] physics drift detected: "
                f"duration_scale {old:.3f} → {self.duration_scale:.3f} "
                f"(mean ratio={mean_ratio:.3f} over {len(self._duration_history)} calls)"
            )
            # Predict motor wear from torque errors
            if self._torque_history:
                recent = list(self._torque_history)[-10:]
                avg_err = sum(max(e) for e in recent if e) / len(recent)
                if avg_err > 2.0:
                    logger.warning(
                        f"  🔧  [{self.robot_id}] HIGH torque error avg={avg_err:.2f}Nm — "
                        f"motor wear predicted — schedule maintenance"
                    )

    def drift_warning(self) -> str:
        if self.duration_scale > 1.0 + self.DRIFT_THRESHOLD:
            pct = (self.duration_scale - 1.0) * 100
            return f"Motor drift +{pct:.0f}% — maintenance recommended"
        return ""

    def adjusted_duration(self, base: float) -> float:
        return base * self.duration_scale * self.friction_coeff

    def adjusted_energy(self, base: float) -> float:
        return base * self.energy_scale * self.friction_coeff


# ─────────────────────────────────────────────────────────────
#  DIGITAL TWIN
# ─────────────────────────────────────────────────────────────

class DigitalTwin:
    """
    v0.2: adds 4D temporal reservations, plant health state,
    market price stream, per-robot physics models.
    """

    def __init__(self, power_budget_w: float = 2000.0):
        self.power_budget_w = power_budget_w
        self.power_in_use_w = 0.0

        self._robot_poses:   Dict[str, Pose]  = {}
        self._zones:         List[WorkspaceZone] = []
        self._humans_present: Dict[str, bool] = {}
        self.grid_carbon_g_kwh: float = 450.0

        # NEW v0.2
        self._temporal_reservations: List[SpaceTimeSlot] = []
        self._physics_models: Dict[str, RobotPhysicsModel] = {}
        self._plant_health: Dict[str, dict] = {}   # tray_id → health metrics
        self._market_price: dict = {               # live energy market
            "carbon_intensity_g_kwh": 450.0,
            "energy_price_usd_kwh":   0.08,
            "carbon_credit_usd_g":    0.00002,
        }

        self._setup_default_workspace()

    def _setup_default_workspace(self):
        self._zones = [
            WorkspaceZone("grow_zone_a",
                          Vec3(0, 0, 0), Vec3(3, 2, 2.5), "clear"),
            WorkspaceZone("charging_dock",
                          Vec3(4, 0, 0), Vec3(5, 1, 0.5), "clear"),
            WorkspaceZone("harvest_station",
                          Vec3(0, 3, 0), Vec3(2, 4, 1.5), "clear"),
            WorkspaceZone("maintenance_corridor",
                          Vec3(3, 0, 0), Vec3(3.5, 4, 2), "clear"),
        ]

    # ── Robot management ──────────────────────────────────────

    def register_robot(self, robot_id: str, initial_pose: Pose):
        self._robot_poses[robot_id] = initial_pose
        self._physics_models[robot_id] = RobotPhysicsModel(robot_id=robot_id)

    def update_pose(self, robot_id: str, pose: Pose):
        self._robot_poses[robot_id] = pose

    def get_pose(self, robot_id: str) -> Optional[Pose]:
        return self._robot_poses.get(robot_id)

    def get_physics_model(self, robot_id: str) -> RobotPhysicsModel:
        if robot_id not in self._physics_models:
            self._physics_models[robot_id] = RobotPhysicsModel(robot_id=robot_id)
        return self._physics_models[robot_id]

    def record_tool_outcome(self, robot_id: str, projected_s: float,
                             actual_s: float, torque_errors: List[float]):
        """Feed back HIL telemetry to self-healing physics model."""
        model = self.get_physics_model(robot_id)
        model.record_outcome(projected_s, actual_s, torque_errors)

    # ── Temporal reservations (4D) ────────────────────────────

    def reserve_zone(self, robot_id: str, zone_id: str,
                     start_ms: float, end_ms: float,
                     position: Optional[Vec3] = None) -> bool:
        """
        Reserve a zone for a time window. Returns False if conflicted.
        """
        slot = SpaceTimeSlot(
            zone_id=zone_id, robot_id=robot_id,
            start_ms=start_ms, end_ms=end_ms,
            position=position or Vec3(),
        )
        # Check against existing reservations
        for existing in self._temporal_reservations:
            if slot.overlaps(existing):
                logger.warning(
                    f"  ⏰  Temporal conflict: [{robot_id}] wanted zone [{zone_id}] "
                    f"{start_ms:.0f}–{end_ms:.0f}ms, "
                    f"but [{existing.robot_id}] holds it {existing.start_ms:.0f}–{existing.end_ms:.0f}ms"
                )
                return False
        self._temporal_reservations.append(slot)
        return True

    def release_zone_reservation(self, robot_id: str, zone_id: str):
        self._temporal_reservations = [
            s for s in self._temporal_reservations
            if not (s.robot_id == robot_id and s.zone_id == zone_id)
        ]

    def get_next_available_slot(self, zone_id: str, duration_ms: float) -> float:
        """Return earliest start_ms when zone_id is free for duration_ms."""
        now_ms = time.time() * 1000
        relevant = sorted(
            [s for s in self._temporal_reservations if s.zone_id == zone_id],
            key=lambda s: s.end_ms
        )
        candidate = now_ms
        for slot in relevant:
            if slot.end_ms > candidate:
                candidate = slot.end_ms
        return candidate

    def cleanup_expired_reservations(self):
        now_ms = time.time() * 1000
        self._temporal_reservations = [
            s for s in self._temporal_reservations if s.end_ms > now_ms
        ]

    # ── Biological coupling ───────────────────────────────────

    def update_plant_health(self, tray_id: str, metrics: dict):
        """
        Update plant health metrics for a tray.
        Shadow uses this to dynamically adjust risk levels and utility scores.

        metrics keys: vpd_kpa, humidity_pct, health_score,
                      days_to_harvest, harvest_window_open
        """
        self._plant_health[tray_id] = {**metrics, "updated_at": time.time()}

    def get_plant_health(self, tray_id: str) -> Optional[dict]:
        return self._plant_health.get(tray_id)

    def harvest_utility(self, tray_id: str) -> float:
        """
        Returns 0–1 utility score for harvesting a given tray now.
        Decays toward 0 as harvest window closes.
        """
        h = self._plant_health.get(tray_id)
        if not h:
            return 0.5   # Unknown — neutral
        score      = h.get("health_score", 0.5)
        days_left  = max(h.get("days_to_harvest", 1), 0.001)
        urgency    = min(1.0, 1.0 / days_left)
        return round(score * urgency, 3)

    def high_humidity_risk(self, tray_id: str) -> bool:
        """True if ambient humidity raises motor oxidation risk."""
        h = self._plant_health.get(tray_id)
        if not h:
            return False
        return h.get("humidity_pct", 50) > 85

    # ── Zone and human management ─────────────────────────────

    def set_human_present(self, zone_name: str, present: bool):
        self._humans_present[zone_name] = present
        if present:
            logger.warning(f"  👤  Human detected in zone [{zone_name}]")

    def set_zone_type(self, zone_name: str, zone_type: str):
        for z in self._zones:
            if z.name == zone_name:
                z.zone_type = zone_type

    def get_zone_at(self, point: Vec3) -> Optional[WorkspaceZone]:
        for z in self._zones:
            if z.contains(point):
                return z
        return None

    def available_power_w(self) -> float:
        return self.power_budget_w - self.power_in_use_w

    def reserve_power(self, watts: float) -> bool:
        if watts <= self.available_power_w():
            self.power_in_use_w += watts
            return True
        return False

    def release_power(self, watts: float):
        self.power_in_use_w = max(0, self.power_in_use_w - watts)

    def update_market_price(self, carbon_intensity: float, energy_price: float):
        self._market_price["carbon_intensity_g_kwh"] = carbon_intensity
        self._market_price["energy_price_usd_kwh"]   = energy_price
        self.grid_carbon_g_kwh = carbon_intensity


# ─────────────────────────────────────────────────────────────
#  SHADOW VALIDATOR  v0.2
# ─────────────────────────────────────────────────────────────

class ShadowValidator:
    """
    v0.2 upgrades:
      - Tube-based reachability (not just endpoint)
      - 4D temporal conflict detection
      - Biological risk modifier (humidity → motor risk)
      - Self-healing physics model integration
      - Utility score computation
      - PyBullet hook (slot for real collision engine)
    """

    USE_PYBULLET = False   # Set True and implement _pybullet_check() to enable

    def __init__(self, twin: DigitalTwin):
        self.twin = twin
        self._validations_run     = 0
        self._validations_blocked = 0

    def validate(self, call: ToolCall, tool_schema: dict) -> ProjectedOutcome:
        self._validations_run += 1
        self.twin.cleanup_expired_reservations()

        risks:     List[str] = []
        conflicts: List[str] = []
        safe = True

        args       = call.arguments
        physics    = tool_schema.get("physics", {})
        safety_cfg = tool_schema.get("safety", {})

        # ── Get physics model (self-healing) ───────────────────
        phys_model = self.twin.get_physics_model(call.robot_id)

        # ── Extract target position ────────────────────────────
        target: Optional[Vec3] = None
        if "x" in args and "y" in args and "z" in args:
            target = Vec3(args["x"], args["y"], args["z"])
        elif "target_x" in args:
            target = Vec3(args["target_x"], args.get("target_y", 0),
                          args.get("target_z", 0))

        current_pose = self.twin.get_pose(call.robot_id)
        current_pos  = current_pose.position if current_pose else Vec3(0, 0, 0)

        # ── 1. Physics-engine collision check ─────────────────
        if target:
            if self.USE_PYBULLET:
                pybullet_risks = self._pybullet_check(call.robot_id, current_pos, target)
                risks.extend(pybullet_risks)
                if pybullet_risks:
                    safe = False
            else:
                # Tube-based geometric fallback
                for zone in self.twin._zones:
                    if zone.zone_type == "human_zone":
                        if zone.intersects_tube(current_pos, target, radius=0.2):
                            risks.append(f"Path tube intersects human zone [{zone.name}]")
                            safe = False
                    if zone.zone_type == "obstacle":
                        if zone.intersects_tube(current_pos, target, radius=0.12):
                            risks.append(f"Collision risk (tube) with obstacle [{zone.name}]")
                            safe = False

        # ── 2. Human proximity ────────────────────────────────
        min_clear = safety_cfg.get("min_human_clearance_m", 0.5)
        for zone_name, present in self.twin._humans_present.items():
            if present:
                risks.append(
                    f"Human in [{zone_name}] — {min_clear}m clearance required"
                )
                safe = False

        # ── 3. Power budget ───────────────────────────────────
        needed_w = _estimate_power(physics, args)
        avail_w  = self.twin.available_power_w()
        if needed_w > avail_w:
            risks.append(
                f"Insufficient power: need {needed_w:.0f}W, only {avail_w:.0f}W"
            )
            safe = False

        # ── 4. Robot workspace conflicts (spatial) ─────────────
        if target:
            for other_id, other_pose in self.twin._robot_poses.items():
                if other_id == call.robot_id:
                    continue
                dist = target.distance_to(other_pose.position)
                if dist < 0.3:
                    conflicts.append(f"[{other_id}] is {dist:.2f}m from target")
                    risks.append(f"Workspace conflict with [{other_id}]")

        # ── 5. 4D Temporal conflicts ───────────────────────────
        if target:
            base_dur = phys_model.adjusted_duration(
                physics.get("estimated_duration_s", 1.0)
            )
            now_ms   = time.time() * 1000
            end_ms   = now_ms + base_dur * 1000
            zone_at_target = self.twin.get_zone_at(target)
            if zone_at_target:
                test_slot = SpaceTimeSlot(
                    zone_id=zone_at_target.name,
                    robot_id=call.robot_id,
                    start_ms=now_ms, end_ms=end_ms,
                    position=target,
                )
                for existing in self.twin._temporal_reservations:
                    if test_slot.overlaps(existing):
                        conflicts.append(
                            f"Temporal conflict: [{existing.robot_id}] holds "
                            f"[{zone_at_target.name}] until {existing.end_ms:.0f}ms"
                        )
                        risks.append(
                            f"4D conflict with [{existing.robot_id}] in "
                            f"[{zone_at_target.name}]"
                        )

        # ── 6. Arm reachability ────────────────────────────────
        if target and call.robot_id.startswith("arm"):
            arm_base = self.twin.get_pose(call.robot_id)
            if arm_base:
                reach = target.distance_to(arm_base.position)
                max_reach = args.get("_max_reach", 0.85)
                if reach > max_reach:
                    risks.append(
                        f"Target {reach:.2f}m exceeds arm reach {max_reach}m"
                    )
                    safe = False

        # ── 7. Biological risk modifier ────────────────────────
        tray_id = f"tray-{int(args.get('tray_x', 0))}-{int(args.get('tray_y', 0))}"
        if self.twin.high_humidity_risk(tray_id):
            risks.append(
                f"High humidity in [{tray_id}] — elevated motor oxidation risk"
            )

        # ── 8. Physics model drift warning ────────────────────
        drift_msg = phys_model.drift_warning()

        # ── 9. Build ProjectedOutcome ─────────────────────────
        base_dur    = physics.get("estimated_duration_s", 1.0)
        base_energy = physics.get("estimated_energy_j", 50.0)
        duration_s  = phys_model.adjusted_duration(
            _estimate_duration(physics, current_pos, target)
        )
        energy_j    = phys_model.adjusted_energy(
            base_energy * (duration_s / max(base_dur, 0.001))
        )
        kwh         = energy_j / 3_600_000
        carbon_g    = kwh * self.twin.grid_carbon_g_kwh
        cost_usd    = kwh * self.twin._market_price["energy_price_usd_kwh"]

        final_pose  = Pose(position=target) if target else None
        risk_level  = "low" if not risks else ("high" if not safe else "medium")

        # ── 10. Utility score ─────────────────────────────────
        utility = self.twin.harvest_utility(tray_id)
        if utility == 0.5:   # Unknown tray — infer from tool category
            cat = tool_schema.get("category", "")
            utility = 0.8 if cat in ("motion", "manipulation") else 0.5

        # ── 11. Temporal envelope ─────────────────────────────
        now_ms  = time.time() * 1000
        end_ms  = now_ms + duration_s * 1000
        envelope = TemporalEnvelope()
        if target:
            zone_at = self.twin.get_zone_at(target)
            if zone_at:
                envelope.slots.append(SpaceTimeSlot(
                    zone_id=zone_at.name, robot_id=call.robot_id,
                    start_ms=now_ms, end_ms=end_ms, position=target,
                ))

        if not safe:
            self._validations_blocked += 1

        outcome = ProjectedOutcome(
            duration_s          = round(duration_s, 2),
            energy_j            = round(energy_j, 1),
            final_pose          = final_pose,
            risk_level          = risk_level,
            risk_reasons        = risks,
            carbon_g            = round(carbon_g, 4),
            cost_usd            = round(cost_usd, 6),
            workspace_conflicts = conflicts,
            safe_to_execute     = safe,
            utility_score       = utility,
            temporal_envelope   = envelope,
            drift_warning       = drift_msg,
        )

        logger.info(
            f"  🔮  Shadow [{call.call_id}] → risk={risk_level} "
            f"dur={duration_s:.1f}s energy={energy_j:.0f}J "
            f"utility={utility:.2f} safe={safe}"
        )
        for r in risks:
            logger.warning(f"     ⚠  {r}")

        return outcome

    def _pybullet_check(self, robot_id: str,
                         start: Vec3, end: Vec3) -> List[str]:
        """
        PyBullet hook — replace stub with:

            import pybullet as p
            import pybullet_data

            p.connect(p.DIRECT)
            p.setAdditionalSearchPath(pybullet_data.getDataPath())
            robot_urdf = f"robots/{robot_id}.urdf"
            robot = p.loadURDF(robot_urdf, basePosition=[start.x, start.y, start.z])
            obstacle = p.loadURDF("obstacle.urdf")
            contacts = p.getClosestPoints(robot, obstacle, distance=0.05)
            p.disconnect()
            return [f"PyBullet collision at {c[5]}" for c in contacts]
        """
        logger.debug(f"  [PyBullet stub] collision check {start} → {end}")
        return []   # Stub: no collisions detected

    def stats(self) -> dict:
        return {
            "validations_run":     self._validations_run,
            "validations_blocked": self._validations_blocked,
            "block_rate_pct": round(
                100 * self._validations_blocked / max(1, self._validations_run), 1
            ),
            "active_reservations": len(self.twin._temporal_reservations),
            "physics_models": {
                rid: {
                    "duration_scale": m.duration_scale,
                    "energy_scale":   m.energy_scale,
                    "drift_warning":  m.drift_warning(),
                }
                for rid, m in self.twin._physics_models.items()
            }
        }


# ─────────────────────────────────────────────────────────────
#  PHYSICS HELPERS
# ─────────────────────────────────────────────────────────────

def _estimate_power(physics: dict, args: dict) -> float:
    base  = physics.get("estimated_energy_j", 50.0)
    speed = args.get("speed", physics.get("max_speed_ms", 0.3))
    return base * (speed / max(physics.get("max_speed_ms", 0.5), 0.001))


def _estimate_duration(physics: dict,
                        start: Optional[Vec3], end: Optional[Vec3]) -> float:
    base = physics.get("estimated_duration_s", 1.0)
    if start and end:
        dist  = start.distance_to(end)
        speed = max(physics.get("max_speed_ms", 0.3), 0.01)
        return max(base, dist / speed)
    return base