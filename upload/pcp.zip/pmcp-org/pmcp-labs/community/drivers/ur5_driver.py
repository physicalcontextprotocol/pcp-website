"""
P-MCP Community Driver — Universal Robots UR5 / UR10
======================================================
Wraps the UR RTDE interface (or URx over TCP/IP) to expose the robot
via the P-MCP protocol. Falls back to a mock mode if ur_rtde is absent.

Requirements (optional):
    pip install ur_rtde      # UR Robot Real-Time Data Exchange
    pip install urx           # Alternative TCP/IP driver

Usage:
    python -m community.drivers.ur5_driver --host 192.168.1.100
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from aiohttp import web

log = logging.getLogger("pmcp.driver.ur5")

PMCP_VERSION = "0.5"

# Try to import UR RTDE — fall back to mock
try:
    import rtde_control
    import rtde_receive
    UR_RTDE_AVAILABLE = True
except ImportError:
    UR_RTDE_AVAILABLE = False

# ─────────────────────────────────────────────────────────────────────────────
#  Mock UR5 (used when hardware is not available)
# ─────────────────────────────────────────────────────────────────────────────

class MockUR5:
    """Minimal UR5 mock for testing without hardware."""

    def __init__(self) -> None:
        self._joints = [0.0, -1.57, 1.57, -1.57, -1.57, 0.0]  # home pose (rad)
        self._tcp_pose = [0.4, 0.0, 0.5, 0.0, 3.14, 0.0]  # [x,y,z,rx,ry,rz] m/rad
        self._speed_fraction = 0.5
        self._connected = True
        self._estop = False

    def moveJ(self, target_joints: List[float], speed: float = 1.05, accel: float = 1.4) -> bool:
        self._joints = list(target_joints)
        return True

    def moveL(self, pose: List[float], speed: float = 0.25, accel: float = 1.2) -> bool:
        self._tcp_pose = list(pose)
        return True

    def stopJ(self, decel: float = 0.5) -> None:
        pass

    def speedStop(self, decel: float = 0.5) -> None:
        pass

    def getActualQ(self) -> List[float]:
        return list(self._joints)

    def getActualTCPPose(self) -> List[float]:
        return list(self._tcp_pose)

    def getRobotMode(self) -> int:
        return 7  # ROBOT_MODE_RUNNING

    def getJointTemperatures(self) -> List[float]:
        return [35.0] * 6

    def getRobotVoltage(self) -> float:
        return 48.0

    def isConnected(self) -> bool:
        return self._connected


# ─────────────────────────────────────────────────────────────────────────────
#  UR5 Driver
# ─────────────────────────────────────────────────────────────────────────────

class UR5Driver:
    def __init__(self, robot_id: str, host: str = "192.168.1.100", mock: bool = False) -> None:
        self.robot_id = robot_id
        self.host = host
        self._use_mock = mock or not UR_RTDE_AVAILABLE
        self._ctrl: Any = None
        self._recv: Any = None
        self._start_time = time.time()
        self._req_count = 0
        self._estop = False

    async def connect(self) -> None:
        if self._use_mock:
            self._ctrl = MockUR5()
            self._recv = self._ctrl
            log.info("UR5 driver using mock (hardware not available)")
            return
        loop = asyncio.get_event_loop()
        self._ctrl = await loop.run_in_executor(None, rtde_control.RTDEControlInterface, self.host)
        self._recv = await loop.run_in_executor(None, rtde_receive.RTDEReceiveInterface, self.host)
        log.info("Connected to UR5 at %s", self.host)

    async def disconnect(self) -> None:
        if self._ctrl and not self._use_mock:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._ctrl.disconnect)

    def _ok(self, result: Any, req_id: Any) -> Dict:
        return {"jsonrpc": "2.0", "result": result, "id": req_id}

    def _err(self, code: int, msg: str, req_id: Any) -> Dict:
        return {"jsonrpc": "2.0", "error": {"code": code, "message": msg}, "id": req_id}

    def dispatch(self, method: str, params: Dict, req_id: Any) -> Dict:
        self._req_count += 1

        if method == "initialize":
            return self._ok({
                "protocolVersion": PMCP_VERSION,
                "serverInfo": {
                    "name": self.robot_id,
                    "version": "0.5.0",
                    "vendor": "Universal Robots",
                    "model": "UR5",
                    "mock": self._use_mock,
                },
                "capabilities": {"actuations": True, "sensors": True, "leases": True},
            }, req_id)

        elif method == "actuations/list":
            return self._ok({
                "actuations": [
                    {"name": "moveJ", "description": "Move to joint configuration",
                     "parameters": {"joints": "list[float]", "speed": "float", "accel": "float"}},
                    {"name": "moveL", "description": "Linear move in cartesian space",
                     "parameters": {"pose": "list[float]", "speed": "float", "accel": "float"}},
                    {"name": "home", "description": "Move to home position"},
                    {"name": "stop", "description": "Stop all movement"},
                    {"name": "open_gripper", "description": "Open end-effector gripper"},
                    {"name": "close_gripper", "description": "Close end-effector gripper"},
                ]
            }, req_id)

        elif method == "actuations/execute":
            name = (params or {}).get("name", "")
            p = (params or {}).get("parameters", {})
            start = time.time()

            if name == "moveJ":
                joints = p.get("joints", [0.0] * 6)
                self._ctrl.moveJ(joints, p.get("speed", 1.05), p.get("accel", 1.4))
            elif name == "moveL":
                pose = p.get("pose", [0.4, 0.0, 0.5, 0.0, 3.14, 0.0])
                self._ctrl.moveL(pose, p.get("speed", 0.25), p.get("accel", 1.2))
            elif name == "home":
                self._ctrl.moveJ([0.0, -1.57, 1.57, -1.57, -1.57, 0.0])
            elif name == "stop":
                self._ctrl.stopJ(0.5)
            elif name in ("open_gripper", "close_gripper"):
                # Gripper control via digital I/O (stub)
                pass
            else:
                return self._err(-32601, f"Unknown actuation: {name}", req_id)

            elapsed_ms = int((time.time() - start) * 1000)
            return self._ok({"success": True, "energy_wh": 0.05, "duration_ms": elapsed_ms}, req_id)

        elif method == "sensors/list":
            return self._ok({
                "sensors": [
                    {"name": "joints", "description": "Joint angles [rad]"},
                    {"name": "tcp_pose", "description": "TCP pose [x,y,z,rx,ry,rz] m/rad"},
                    {"name": "joint_temps", "description": "Joint temperatures [°C]"},
                    {"name": "voltage", "description": "Robot voltage [V]"},
                    {"name": "uptime", "description": "Uptime [s]"},
                ]
            }, req_id)

        elif method == "sensors/read":
            name = (params or {}).get("name", "")
            now = int(time.time() * 1000)
            if name == "joints":
                val = self._recv.getActualQ()
            elif name == "tcp_pose":
                val = self._recv.getActualTCPPose()
            elif name == "joint_temps":
                val = self._recv.getJointTemperatures()
            elif name == "voltage":
                val = self._recv.getRobotVoltage()
            elif name == "uptime":
                val = time.time() - self._start_time
            else:
                return self._err(-32601, f"Unknown sensor: {name}", req_id)
            return self._ok({
                "sensor_name": name,
                "value": val,
                "unit": "rad" if name in ("joints",) else "",
                "timestamp_ms": now,
                "quality": 1.0,
            }, req_id)

        elif method == "leases/acquire":
            return self._ok({
                "granted": True,
                "lease_id": f"ur5-lease-{int(time.time())}",
                "expires_ms": int(time.time() * 1000) + 30_000,
                "robot_id": self.robot_id,
                "zone_id": "ur5-workspace",
            }, req_id)

        elif method == "leases/release":
            return self._ok({"released": True}, req_id)

        elif method == "pmcp/ping":
            return self._ok({"pong": True, "timestamp_ms": int(time.time() * 1000)}, req_id)

        elif method == "pmcp/metrics":
            return self._ok({
                "uptime_s": time.time() - self._start_time,
                "requests_total": self._req_count,
                "errors_total": 0,
                "active_leases": 0,
                "actuations_executed": self._req_count,
                "battery_pct": 100.0,
                "state": "running",
                "cpu_pct": 0.0,
                "memory_mb": 0.0,
            }, req_id)

        elif method in ("safety/estop/engage", "safety/estop/disengage"):
            self._estop = method.endswith("engage")
            if self._estop:
                self._ctrl.stopJ(0.5)
            return self._ok({"engaged" if self._estop else "disengaged": True}, req_id)

        else:
            return self._err(-32601, f"Method not found: {method}", req_id)

    async def handle_mcp(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response(self._err(-32700, "Parse error", None))
        return web.json_response(
            self.dispatch(body.get("method", ""), body.get("params", {}), body.get("id"))
        )

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({
            "status": "ok",
            "robot_id": self.robot_id,
            "mock": self._use_mock,
            "connected": self._ctrl.isConnected() if self._ctrl else False,
        })


async def main() -> None:
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="192.168.1.100")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--robot-id", default="ur5-0")
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()

    driver = UR5Driver(args.robot_id, args.host, mock=args.mock)
    await driver.connect()

    app = web.Application()
    app.router.add_post("/mcp", driver.handle_mcp)
    app.router.add_get("/health", driver.handle_health)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", args.port)
    await site.start()
    log.info("UR5 driver running on port %d", args.port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
