"""
P-MCP Community Driver — Boston Dynamics Spot
==============================================
Wraps the Boston Dynamics Spot SDK to expose Spot via P-MCP.

Requirements (optional):
    pip install bosdyn-client bosdyn-mission bosdyn-choreography-client

Usage:
    python -m community.drivers.spot_driver --hostname 192.168.80.3 --username user --password hunter2
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, Optional

from aiohttp import web

log = logging.getLogger("pmcp.driver.spot")
PMCP_VERSION = "0.5"

try:
    import bosdyn.client
    import bosdyn.client.util
    from bosdyn.client.robot_command import RobotCommandClient, blocking_stand
    from bosdyn.client.robot_state import RobotStateClient
    SPOT_SDK_AVAILABLE = True
except ImportError:
    SPOT_SDK_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
#  Mock Spot
# ─────────────────────────────────────────────────────────────────────────────

class MockSpot:
    def __init__(self) -> None:
        self.standing = False
        self.battery_pct = 80.0
        self.estop_active = False

    def power_on(self) -> None: pass
    def stand(self) -> None: self.standing = True
    def sit(self) -> None: self.standing = False
    def power_off(self) -> None: pass


# ─────────────────────────────────────────────────────────────────────────────
#  Spot Driver
# ─────────────────────────────────────────────────────────────────────────────

class SpotDriver:
    def __init__(self, robot_id: str, hostname: str = "192.168.80.3",
                 username: str = "user", password: str = "",
                 mock: bool = False) -> None:
        self.robot_id = robot_id
        self.hostname = hostname
        self._use_mock = mock or not SPOT_SDK_AVAILABLE
        self._spot: Any = None
        self._cmd_client: Any = None
        self._state_client: Any = None
        self._start_time = time.time()
        self._req_count = 0
        self._estop = False
        self._username = username
        self._password = password

    async def connect(self) -> None:
        if self._use_mock:
            self._spot = MockSpot()
            log.info("Spot driver using mock")
            return
        loop = asyncio.get_event_loop()
        sdk = bosdyn.client.create_standard_sdk("pmcp-spot")
        self._robot = sdk.create_robot(self.hostname)
        await loop.run_in_executor(None, self._robot.authenticate, self._username, self._password)
        self._cmd_client = self._robot.ensure_client(RobotCommandClient.default_service_name)
        self._state_client = self._robot.ensure_client(RobotStateClient.default_service_name)
        self._spot = self._robot
        log.info("Connected to Spot at %s", self.hostname)

    def _ok(self, result, req_id):
        return {"jsonrpc": "2.0", "result": result, "id": req_id}

    def _err(self, code, msg, req_id):
        return {"jsonrpc": "2.0", "error": {"code": code, "message": msg}, "id": req_id}

    def dispatch(self, method: str, params: Dict, req_id: Any) -> Dict:
        self._req_count += 1

        if method == "initialize":
            return self._ok({
                "protocolVersion": PMCP_VERSION,
                "serverInfo": {"name": self.robot_id, "version": "0.5.0",
                               "vendor": "Boston Dynamics", "model": "Spot",
                               "mock": self._use_mock},
                "capabilities": {"actuations": True, "sensors": True, "leases": True},
            }, req_id)

        elif method == "actuations/list":
            return self._ok({"actuations": [
                {"name": "stand", "description": "Stand up"},
                {"name": "sit", "description": "Sit down"},
                {"name": "walk_to", "description": "Walk to (x,y,heading)",
                 "parameters": {"x": "float", "y": "float", "heading": "float"}},
                {"name": "power_on", "description": "Enable motors"},
                {"name": "power_off", "description": "Disable motors"},
                {"name": "self_right", "description": "Self-right from fallen position"},
            ]}, req_id)

        elif method == "actuations/execute":
            name = (params or {}).get("name", "")
            p = (params or {}).get("parameters", {})
            if name == "stand":
                self._spot.stand()
            elif name == "sit":
                self._spot.sit()
            elif name == "power_on":
                self._spot.power_on()
            elif name == "power_off":
                self._spot.power_off()
            elif name in ("walk_to", "self_right"):
                pass  # stub — full implementation requires SDK
            else:
                return self._err(-32601, f"Unknown actuation: {name}", req_id)
            return self._ok({"success": True, "energy_wh": 0.1, "duration_ms": 500}, req_id)

        elif method == "sensors/list":
            return self._ok({"sensors": [
                {"name": "battery", "description": "Battery [%]"},
                {"name": "estop_state", "description": "E-stop state"},
                {"name": "standing", "description": "Standing state (bool)"},
                {"name": "uptime", "description": "Uptime [s]"},
            ]}, req_id)

        elif method == "sensors/read":
            name = (params or {}).get("name", "")
            now = int(time.time() * 1000)
            sensor_map = {
                "battery": (self._spot.battery_pct if hasattr(self._spot, "battery_pct") else 80.0, "%"),
                "estop_state": (self._estop, "bool"),
                "standing": (self._spot.standing if hasattr(self._spot, "standing") else False, "bool"),
                "uptime": (time.time() - self._start_time, "s"),
            }
            if name not in sensor_map:
                return self._err(-32601, f"Unknown sensor: {name}", req_id)
            val, unit = sensor_map[name]
            return self._ok({"sensor_name": name, "value": val, "unit": unit,
                             "timestamp_ms": now, "quality": 1.0}, req_id)

        elif method == "leases/acquire":
            return self._ok({"granted": True, "lease_id": f"spot-{int(time.time())}",
                             "expires_ms": int(time.time()*1000)+30_000,
                             "robot_id": self.robot_id, "zone_id": "spot-workspace"}, req_id)
        elif method == "leases/release":
            return self._ok({"released": True}, req_id)
        elif method == "pmcp/ping":
            return self._ok({"pong": True, "timestamp_ms": int(time.time()*1000)}, req_id)
        elif method == "pmcp/metrics":
            return self._ok({"uptime_s": time.time()-self._start_time,
                             "requests_total": self._req_count, "errors_total": 0,
                             "active_leases": 0, "actuations_executed": self._req_count,
                             "battery_pct": 80.0, "state": "running",
                             "cpu_pct": 0.0, "memory_mb": 0.0}, req_id)
        elif method == "safety/estop/engage":
            self._estop = True
            return self._ok({"engaged": True}, req_id)
        elif method == "safety/estop/disengage":
            self._estop = False
            return self._ok({"disengaged": True}, req_id)
        else:
            return self._err(-32601, f"Method not found: {method}", req_id)

    async def handle_mcp(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response(self._err(-32700, "Parse error", None))
        return web.json_response(
            self.dispatch(body.get("method",""), body.get("params",{}), body.get("id"))
        )

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({"status": "ok", "robot_id": self.robot_id})


async def main() -> None:
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--hostname", default="192.168.80.3")
    parser.add_argument("--username", default="user")
    parser.add_argument("--password", default="")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--robot-id", default="spot-0")
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()

    driver = SpotDriver(args.robot_id, args.hostname, args.username, args.password, args.mock)
    await driver.connect()

    app = web.Application()
    app.router.add_post("/mcp", driver.handle_mcp)
    app.router.add_get("/health", driver.handle_health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", args.port).start()
    log.info("Spot driver running on port %d", args.port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
