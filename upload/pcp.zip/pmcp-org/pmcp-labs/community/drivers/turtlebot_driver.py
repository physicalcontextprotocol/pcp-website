"""
P-MCP Community Driver — TurtleBot3 / TurtleBot4
==================================================
Wraps the ROS2 action and topic interface (or a direct serial interface
without ROS) to expose the TurtleBot via P-MCP.

Requirements (optional):
    ROS2 (foxy/humble) with turtlebot3 packages for full functionality.
    Falls back to mock mode when ROS2 is unavailable.

Usage:
    python -m community.drivers.turtlebot_driver --port 8080
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from aiohttp import web

log = logging.getLogger("pmcp.driver.turtlebot")
PMCP_VERSION = "0.5"

try:
    import rclpy  # type: ignore
    from geometry_msgs.msg import Twist  # type: ignore
    from nav_msgs.msg import Odometry  # type: ignore
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
#  Mock TurtleBot
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MockTurtleBot:
    x: float = 0.0
    y: float = 0.0
    theta: float = 0.0  # radians
    linear_vel: float = 0.0
    angular_vel: float = 0.0
    battery_pct: float = 85.0

    def cmd_vel(self, linear: float, angular: float) -> None:
        self.linear_vel = linear
        self.angular_vel = angular

    def stop(self) -> None:
        self.linear_vel = 0.0
        self.angular_vel = 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  TurtleBot Driver
# ─────────────────────────────────────────────────────────────────────────────

class TurtleBotDriver:
    def __init__(self, robot_id: str, model: str = "burger", mock: bool = False) -> None:
        self.robot_id = robot_id
        self.model = model
        self._use_mock = mock or not ROS2_AVAILABLE
        self._bot: Any = None
        self._start_time = time.time()
        self._req_count = 0
        self._estop = False

    async def connect(self) -> None:
        if self._use_mock:
            self._bot = MockTurtleBot()
            log.info("TurtleBot driver using mock")
            return
        rclpy.init()
        # ROS2 node setup would go here — stub for now
        self._bot = MockTurtleBot()
        log.info("TurtleBot connected via ROS2")

    def _ok(self, result, req_id):
        return {"jsonrpc": "2.0", "result": result, "id": req_id}

    def _err(self, code, msg, req_id):
        return {"jsonrpc": "2.0", "error": {"code": code, "message": msg}, "id": req_id}

    async def _move_duration(self, linear: float, angular: float, duration_s: float) -> None:
        """Drive at given velocity for duration_s seconds."""
        self._bot.cmd_vel(linear, angular)
        await asyncio.sleep(duration_s)
        self._bot.stop()

    def dispatch(self, method: str, params: Dict, req_id: Any) -> Dict:
        self._req_count += 1

        if method == "initialize":
            return self._ok({
                "protocolVersion": PMCP_VERSION,
                "serverInfo": {"name": self.robot_id, "version": "0.5.0",
                               "vendor": "ROBOTIS", "model": f"TurtleBot3 {self.model}",
                               "mock": self._use_mock},
                "capabilities": {"actuations": True, "sensors": True, "leases": True},
            }, req_id)

        elif method == "actuations/list":
            return self._ok({"actuations": [
                {"name": "cmd_vel", "description": "Set velocity",
                 "parameters": {"linear": "float", "angular": "float"}},
                {"name": "forward", "description": "Drive forward N meters",
                 "parameters": {"distance_m": "float", "speed": "float"}},
                {"name": "rotate", "description": "Rotate by N degrees",
                 "parameters": {"degrees": "float", "speed": "float"}},
                {"name": "stop", "description": "Stop all motion"},
                {"name": "navigate_to", "description": "Navigate to (x,y) goal",
                 "parameters": {"x": "float", "y": "float"}},
            ]}, req_id)

        elif method == "actuations/execute":
            name = (params or {}).get("name", "")
            p = (params or {}).get("parameters", {})

            # Queue the async work and return immediately for fire-and-forget
            if name == "cmd_vel":
                self._bot.cmd_vel(float(p.get("linear", 0)), float(p.get("angular", 0)))
            elif name == "forward":
                dist = float(p.get("distance_m", 0.5))
                speed = float(p.get("speed", 0.2))
                duration = abs(dist) / max(speed, 0.01)
                asyncio.ensure_future(self._move_duration(math.copysign(speed, dist), 0.0, duration))
            elif name == "rotate":
                deg = float(p.get("degrees", 90))
                speed = float(p.get("speed", 0.5))
                duration = abs(math.radians(deg)) / max(speed, 0.01)
                asyncio.ensure_future(self._move_duration(0.0, math.copysign(speed, deg), duration))
            elif name == "stop":
                self._bot.stop()
            elif name == "navigate_to":
                # Simple P-controller stub
                tx, ty = float(p.get("x", 0)), float(p.get("y", 0))
                asyncio.ensure_future(self._navigate_to(tx, ty))
            else:
                return self._err(-32601, f"Unknown actuation: {name}", req_id)
            return self._ok({"success": True, "energy_wh": 0.005, "duration_ms": 100}, req_id)

        elif method == "sensors/list":
            return self._ok({"sensors": [
                {"name": "odom", "description": "Odometry [x,y,theta]"},
                {"name": "linear_vel", "description": "Linear velocity [m/s]"},
                {"name": "angular_vel", "description": "Angular velocity [rad/s]"},
                {"name": "battery", "description": "Battery [%]"},
                {"name": "uptime", "description": "Uptime [s]"},
            ]}, req_id)

        elif method == "sensors/read":
            name = (params or {}).get("name", "")
            now = int(time.time() * 1000)
            sensor_map = {
                "odom": ([self._bot.x, self._bot.y, self._bot.theta], "m/rad"),
                "linear_vel": (self._bot.linear_vel, "m/s"),
                "angular_vel": (self._bot.angular_vel, "rad/s"),
                "battery": (self._bot.battery_pct, "%"),
                "uptime": (time.time() - self._start_time, "s"),
            }
            if name not in sensor_map:
                return self._err(-32601, f"Unknown sensor: {name}", req_id)
            val, unit = sensor_map[name]
            return self._ok({"sensor_name": name, "value": val, "unit": unit,
                             "timestamp_ms": now, "quality": 1.0}, req_id)

        elif method == "leases/acquire":
            return self._ok({"granted": True, "lease_id": f"tb-{int(time.time())}",
                             "expires_ms": int(time.time()*1000)+30_000,
                             "robot_id": self.robot_id, "zone_id": "tb3-zone"}, req_id)
        elif method == "leases/release":
            return self._ok({"released": True}, req_id)
        elif method == "pmcp/ping":
            return self._ok({"pong": True, "timestamp_ms": int(time.time()*1000)}, req_id)
        elif method == "pmcp/metrics":
            return self._ok({"uptime_s": time.time()-self._start_time,
                             "requests_total": self._req_count, "errors_total": 0,
                             "active_leases": 0, "actuations_executed": self._req_count,
                             "battery_pct": self._bot.battery_pct, "state": "running",
                             "cpu_pct": 0.0, "memory_mb": 0.0}, req_id)
        elif method == "safety/estop/engage":
            self._estop = True
            self._bot.stop()
            return self._ok({"engaged": True}, req_id)
        elif method == "safety/estop/disengage":
            self._estop = False
            return self._ok({"disengaged": True}, req_id)
        else:
            return self._err(-32601, f"Method not found: {method}", req_id)

    async def _navigate_to(self, tx: float, ty: float) -> None:
        """Very simple proportional controller."""
        for _ in range(200):  # max 20 s
            if self._estop:
                self._bot.stop()
                return
            dx = tx - self._bot.x
            dy = ty - self._bot.y
            dist = math.hypot(dx, dy)
            if dist < 0.05:
                self._bot.stop()
                return
            heading_err = math.atan2(dy, dx) - self._bot.theta
            self._bot.cmd_vel(min(0.2, dist), 0.5 * heading_err)
            await asyncio.sleep(0.1)
        self._bot.stop()

    async def handle_mcp(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response(self._err(-32700, "Parse error", None))
        return web.json_response(
            self.dispatch(body.get("method",""), body.get("params",{}), body.get("id"))
        )

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({"status": "ok", "robot_id": self.robot_id})


async def main() -> None:
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--robot-id", default="tb3-0")
    parser.add_argument("--model", default="burger", choices=["burger", "waffle"])
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()

    driver = TurtleBotDriver(args.robot_id, args.model, args.mock)
    await driver.connect()

    app = web.Application()
    app.router.add_post("/mcp", driver.handle_mcp)
    app.router.add_get("/health", driver.handle_health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", args.port).start()
    log.info("TurtleBot3 driver on port %d", args.port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
