"""
P-MCP Community Driver — Generic Serial / USB Robot
=====================================================
Wraps pyserial to expose any serial-protocol robot via P-MCP.
Uses a simple line-based command protocol:
    → CMD_NAME param1=val1 param2=val2\\n
    ← OK result_json\\n  |  ERR code message\\n

Requirements (optional):
    pip install pyserial

Usage:
    python -m community.drivers.generic_serial_driver --port /dev/ttyUSB0 --baud 115200
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from aiohttp import web

log = logging.getLogger("pmcp.driver.serial")
PMCP_VERSION = "0.5"

try:
    import serial
    import serial.tools.list_ports
    PYSERIAL_AVAILABLE = True
except ImportError:
    PYSERIAL_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
#  Serial Transport
# ─────────────────────────────────────────────────────────────────────────────

class SerialTransport:
    def __init__(self, port: str, baud: int = 115200, timeout: float = 2.0) -> None:
        self.port = port
        self.baud = baud
        self.timeout = timeout
        self._ser: Any = None

    def connect(self) -> None:
        if not PYSERIAL_AVAILABLE:
            raise RuntimeError("pyserial not installed")
        self._ser = serial.Serial(self.port, self.baud, timeout=self.timeout)
        log.info("Serial connected: %s @ %d baud", self.port, self.baud)

    def disconnect(self) -> None:
        if self._ser and self._ser.is_open:
            self._ser.close()

    def send(self, line: str) -> str:
        """Send a text command and read the response line."""
        self._ser.write((line.strip() + "\n").encode())
        response = self._ser.readline().decode(errors="replace").strip()
        return response

    def is_open(self) -> bool:
        return bool(self._ser and self._ser.is_open)


class MockSerialTransport:
    """Mock serial transport for testing."""

    def connect(self) -> None:
        log.info("Mock serial transport connected")

    def disconnect(self) -> None:
        pass

    def send(self, line: str) -> str:
        parts = line.strip().split()
        cmd = parts[0] if parts else ""
        if cmd == "PING":
            return f"OK {{\"pong\":true,\"timestamp_ms\":{int(time.time()*1000)}}}"
        elif cmd == "SENSOR":
            return "OK {\"value\":42.0,\"unit\":\"unit\"}"
        elif cmd == "ACTUATE":
            return "OK {\"success\":true,\"duration_ms\":100}"
        elif cmd == "STATUS":
            return "OK {\"state\":\"idle\",\"battery_pct\":75.0}"
        return "ERR -32601 Unknown command"

    def is_open(self) -> bool:
        return True


# ─────────────────────────────────────────────────────────────────────────────
#  Generic Serial Driver
# ─────────────────────────────────────────────────────────────────────────────

class GenericSerialDriver:
    def __init__(self, robot_id: str, serial_port: str = "/dev/ttyUSB0",
                 baud: int = 115200, mock: bool = False,
                 actuations: List[str] = None,
                 sensors: List[str] = None) -> None:
        self.robot_id = robot_id
        self._use_mock = mock or not PYSERIAL_AVAILABLE
        self._transport: Any = None
        self._serial_port = serial_port
        self._baud = baud
        self._start_time = time.time()
        self._req_count = 0
        self._estop = False
        self._custom_actuations = actuations or ["move", "stop", "home"]
        self._custom_sensors = sensors or ["state", "battery", "position"]

    async def connect(self) -> None:
        if self._use_mock:
            self._transport = MockSerialTransport()
        else:
            self._transport = SerialTransport(self._serial_port, self._baud)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._transport.connect)
        log.info("Serial driver connected (mock=%s)", self._use_mock)

    async def _send(self, cmd: str) -> str:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._transport.send, cmd)

    def _ok(self, result, req_id):
        return {"jsonrpc": "2.0", "result": result, "id": req_id}

    def _err(self, code, msg, req_id):
        return {"jsonrpc": "2.0", "error": {"code": code, "message": msg}, "id": req_id}

    async def dispatch(self, method: str, params: Dict, req_id: Any) -> Dict:
        self._req_count += 1

        if method == "initialize":
            return self._ok({
                "protocolVersion": PMCP_VERSION,
                "serverInfo": {"name": self.robot_id, "version": "0.5.0",
                               "vendor": "Generic", "model": "Serial Robot",
                               "port": self._serial_port, "mock": self._use_mock},
                "capabilities": {"actuations": True, "sensors": True, "leases": True},
            }, req_id)

        elif method == "actuations/list":
            return self._ok({"actuations": [
                {"name": name, "description": f"Serial actuation: {name}"}
                for name in self._custom_actuations
            ]}, req_id)

        elif method == "actuations/execute":
            if self._estop:
                return self._err(-32003, "E-stop active", req_id)
            name = (params or {}).get("name", "")
            if name not in self._custom_actuations:
                return self._err(-32601, f"Unknown actuation: {name}", req_id)
            p = (params or {}).get("parameters", {})
            param_str = " ".join(f"{k}={v}" for k, v in p.items())
            response = await self._send(f"ACTUATE {name} {param_str}")
            if response.startswith("ERR"):
                parts = response.split(" ", 2)
                code = int(parts[1]) if len(parts) > 1 else -32000
                msg = parts[2] if len(parts) > 2 else "Unknown error"
                return self._err(code, msg, req_id)
            data = json.loads(response[3:].strip()) if response.startswith("OK ") else {}
            return self._ok({"success": True, "energy_wh": 0.001, "duration_ms": 50, **data}, req_id)

        elif method == "sensors/list":
            return self._ok({"sensors": [
                {"name": name, "description": f"Serial sensor: {name}"}
                for name in self._custom_sensors
            ]}, req_id)

        elif method == "sensors/read":
            name = (params or {}).get("name", "")
            if name not in self._custom_sensors:
                return self._err(-32601, f"Unknown sensor: {name}", req_id)
            response = await self._send(f"SENSOR {name}")
            now = int(time.time() * 1000)
            if response.startswith("OK "):
                data = json.loads(response[3:].strip())
                return self._ok({"sensor_name": name, "timestamp_ms": now, "quality": 1.0, **data}, req_id)
            return self._err(-32000, f"Sensor read failed: {response}", req_id)

        elif method == "leases/acquire":
            return self._ok({"granted": True, "lease_id": f"serial-{int(time.time())}",
                             "expires_ms": int(time.time()*1000)+30_000,
                             "robot_id": self.robot_id, "zone_id": "serial-zone"}, req_id)
        elif method == "leases/release":
            return self._ok({"released": True}, req_id)

        elif method == "pmcp/ping":
            response = await self._send("PING")
            now = int(time.time() * 1000)
            return self._ok({"pong": True, "timestamp_ms": now}, req_id)

        elif method == "pmcp/metrics":
            response = await self._send("STATUS")
            status = json.loads(response[3:].strip()) if response.startswith("OK ") else {}
            return self._ok({"uptime_s": time.time()-self._start_time,
                             "requests_total": self._req_count, "errors_total": 0,
                             "active_leases": 0, "actuations_executed": self._req_count,
                             "battery_pct": status.get("battery_pct", 0.0),
                             "state": status.get("state", "unknown"),
                             "cpu_pct": 0.0, "memory_mb": 0.0}, req_id)

        elif method == "safety/estop/engage":
            self._estop = True
            await self._send("ACTUATE stop")
            return self._ok({"engaged": True}, req_id)
        elif method == "safety/estop/disengage":
            self._estop = False
            return self._ok({"disengaged": True}, req_id)
        else:
            return self._err(-32601, f"Method not found: {method}", req_id)

    async def handle_mcp(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response(self._err(-32700, "Parse error", None))
        result = await self.dispatch(body.get("method",""), body.get("params",{}), body.get("id"))
        return web.json_response(result)

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({
            "status": "ok",
            "robot_id": self.robot_id,
            "serial_open": self._transport.is_open() if self._transport else False,
        })


async def main() -> None:
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--http-port", type=int, default=8080)
    parser.add_argument("--robot-id", default="serial-0")
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()

    driver = GenericSerialDriver(args.robot_id, args.port, args.baud, args.mock)
    await driver.connect()

    app = web.Application()
    app.router.add_post("/mcp", driver.handle_mcp)
    app.router.add_get("/health", driver.handle_health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", args.http_port).start()
    log.info("Generic serial driver on port %d", args.http_port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
