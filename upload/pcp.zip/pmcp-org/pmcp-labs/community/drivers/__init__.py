"""
Community Drivers for P-MCP
=============================
Hardware-specific adapters that translate between physical robot APIs
and the P-MCP protocol. Each driver is a self-contained P-MCP server
that wraps the vendor SDK or hardware interface.
"""
