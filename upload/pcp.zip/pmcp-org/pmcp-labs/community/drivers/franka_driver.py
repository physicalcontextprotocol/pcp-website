"""
P-MCP Community Driver — Franka Emika Panda
=============================================
Wraps the Franka RDK (franka-python or libfranka) to expose the Panda
arm via the P-MCP protocol.

Requirements (optional):
    pip install frankx     # Python Franka RDK wrapper
    pip install panda_robot

Usage:
    python -m community.drivers.franka_driver --robot-ip 172.16.0.2
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from typing import Any, Dict, List, Optional

from aiohttp import web

log = logging.getLogger("pmcp.driver.franka")
PMCP_VERSION = "0.5"

try:
    import frankx
    FRANKX_AVAILABLE = True
except ImportError:
    FRANKX_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
#  Mock Panda
# ─────────────────────────────────────────────────────────────────────────────

class MockPanda:
    def __init__(self) -> None:
        self._q = [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785]
        self._T_EE = [0.307, 0.0, 0.590]  # position
        self._gripper_width = 0.08

    def move(self, motion) -> None:
        pass

    def get_state(self):
        class State:
            q = [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785]
            O_T_EE = [1,0,0,0, 0,1,0,0, 0,0,1,0, 0.307,0,0.590,1]
            tau_ext_hat_filtered = [0.0] * 7
        return State()

    def gripper_move(self, width: float, speed: float = 0.1) -> None:
        self._gripper_width = width

    def gripper_grasp(self, width: float, speed: float = 0.1, force: float = 10.0) -> bool:
        return True


# ─────────────────────────────────────────────────────────────────────────────
#  Franka Panda Driver
# ─────────────────────────────────────────────────────────────────────────────

class FrankaDriver:
    def __init__(self, robot_id: str, robot_ip: str = "172.16.0.2", mock: bool = False) -> None:
        self.robot_id = robot_id
        self.robot_ip = robot_ip
        self._use_mock = mock or not FRANKX_AVAILABLE
        self._robot: Any = None
        self._start_time = time.time()
        self._req_count = 0

    async def connect(self) -> None:
        if self._use_mock:
            self._robot = MockPanda()
            log.info("Franka driver using mock")
            return
        loop = asyncio.get_event_loop()
        self._robot = await loop.run_in_executor(None, frankx.Robot, self.robot_ip)
        log.info("Connected to Franka Panda at %s", self.robot_ip)

    def _ok(self, result, req_id):
        return {"jsonrpc": "2.0", "result": result, "id": req_id}

    def _err(self, code, msg, req_id):
        return {"jsonrpc": "2.0", "error": {"code": code, "message": msg}, "id": req_id}

    def dispatch(self, method: str, params: Dict, req_id: Any) -> Dict:
        self._req_count += 1

        if method == "initialize":
            return self._ok({
                "protocolVersion": PMCP_VERSION,
                "serverInfo": {"name": self.robot_id, "version": "0.5.0",
                               "vendor": "Franka Emika", "model": "Panda", "mock": self._use_mock},
                "capabilities": {"actuations": True, "sensors": True, "leases": True},
            }, req_id)

        elif method == "actuations/list":
            return self._ok({"actuations": [
                {"name": "moveJ", "description": "Joint-space motion",
                 "parameters": {"joints": "list[float,7]", "speed": "float"}},
                {"name": "moveL", "description": "Cartesian linear motion",
                 "parameters": {"position": "list[float,3]", "speed": "float"}},
                {"name": "home", "description": "Return to ready pose"},
                {"name": "open_gripper", "description": "Open gripper to max"},
                {"name": "close_gripper", "description": "Close gripper (grasp)"},
                {"name": "set_gripper_width", "description": "Set gripper width",
                 "parameters": {"width_m": "float"}},
            ]}, req_id)

        elif method == "actuations/execute":
            name = (params or {}).get("name", "")
            p = (params or {}).get("parameters", {})
            start = time.time()

            if name == "moveJ":
                if FRANKX_AVAILABLE and not self._use_mock:
                    motion = frankx.JointMotion(p.get("joints", [0.0]*7))
                    self._robot.move(motion)
                else:
                    self._robot.move(None)
            elif name == "moveL":
                if FRANKX_AVAILABLE and not self._use_mock:
                    pos = p.get("position", [0.3, 0.0, 0.5])
                    motion = frankx.LinearMotion(frankx.Affine(pos[0], pos[1], pos[2]))
                    self._robot.move(motion)
                else:
                    self._robot.move(None)
            elif name == "home":
                home_q = [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785]
                if FRANKX_AVAILABLE and not self._use_mock:
                    self._robot.move(frankx.JointMotion(home_q))
                else:
                    self._robot.move(None)
            elif name == "open_gripper":
                self._robot.gripper_move(0.08)
            elif name == "close_gripper":
                self._robot.gripper_grasp(0.0)
            elif name == "set_gripper_width":
                self._robot.gripper_move(float(p.get("width_m", 0.04)))
            else:
                return self._err(-32601, f"Unknown actuation: {name}", req_id)

            return self._ok({"success": True, "energy_wh": 0.02,
                             "duration_ms": int((time.time() - start) * 1000)}, req_id)

        elif method == "sensors/list":
            return self._ok({"sensors": [
                {"name": "joints", "description": "Joint angles [rad]"},
                {"name": "ee_position", "description": "End-effector position [x,y,z] m"},
                {"name": "joint_torques", "description": "External joint torques [Nm]"},
                {"name": "gripper_width", "description": "Gripper width [m]"},
                {"name": "uptime", "description": "Driver uptime [s]"},
            ]}, req_id)

        elif method == "sensors/read":
            name = (params or {}).get("name", "")
            now = int(time.time() * 1000)
            state = self._robot.get_state()

            sensor_map = {
                "joints": (state.q, "rad"),
                "ee_position": (state.O_T_EE[12:15], "m"),
                "joint_torques": (state.tau_ext_hat_filtered, "Nm"),
                "gripper_width": (self._robot._gripper_width if hasattr(self._robot, "_gripper_width") else 0.04, "m"),
                "uptime": (time.time() - self._start_time, "s"),
            }
            if name not in sensor_map:
                return self._err(-32601, f"Unknown sensor: {name}", req_id)
            val, unit = sensor_map[name]
            return self._ok({"sensor_name": name, "value": val, "unit": unit,
                             "timestamp_ms": now, "quality": 1.0}, req_id)

        elif method in ("leases/acquire", "leases/release", "pmcp/ping", "pmcp/metrics",
                        "safety/estop/engage", "safety/estop/disengage"):
            # Delegate to common handler
            return self._common_handler(method, params, req_id)

        else:
            return self._err(-32601, f"Method not found: {method}", req_id)

    def _common_handler(self, method: str, params: Dict, req_id: Any) -> Dict:
        if method == "leases/acquire":
            return self._ok({"granted": True,
                             "lease_id": f"panda-{int(time.time())}",
                             "expires_ms": int(time.time()*1000)+30_000,
                             "robot_id": self.robot_id, "zone_id": "panda-workspace"}, req_id)
        elif method == "leases/release":
            return self._ok({"released": True}, req_id)
        elif method == "pmcp/ping":
            return self._ok({"pong": True, "timestamp_ms": int(time.time()*1000)}, req_id)
        elif method == "pmcp/metrics":
            return self._ok({"uptime_s": time.time()-self._start_time,
                             "requests_total": self._req_count, "errors_total": 0,
                             "active_leases": 0, "actuations_executed": self._req_count,
                             "battery_pct": 100.0, "state": "running",
                             "cpu_pct": 0.0, "memory_mb": 0.0}, req_id)
        elif method == "safety/estop/engage":
            return self._ok({"engaged": True}, req_id)
        elif method == "safety/estop/disengage":
            return self._ok({"disengaged": True}, req_id)
        return self._err(-32601, "Unknown method", req_id)

    async def handle_mcp(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response(self._err(-32700, "Parse error", None))
        return web.json_response(
            self.dispatch(body.get("method",""), body.get("params",{}), body.get("id"))
        )

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({"status": "ok", "robot_id": self.robot_id, "mock": self._use_mock})


async def main() -> None:
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--robot-ip", default="172.16.0.2")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--robot-id", default="panda-0")
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()

    driver = FrankaDriver(args.robot_id, args.robot_ip, args.mock)
    await driver.connect()

    app = web.Application()
    app.router.add_post("/mcp", driver.handle_mcp)
    app.router.add_get("/health", driver.handle_health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", args.port).start()
    log.info("Franka Panda driver running on port %d", args.port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
