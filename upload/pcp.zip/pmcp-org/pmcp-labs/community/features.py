#!/usr/bin/env python3
"""
P-MCP Community Features
=========================

Community platform for P-MCP including:
- Hackathon bounties system
- Contribution tracking
- Leaderboards
- Badges and achievements
- Community events

Usage:
    python community/features.py --port 8081
"""

import argparse
import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set
import threading

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s [%(name)s] %(message)s'
)
logger = logging.getLogger("pmcp-community")


class BountyStatus(Enum):
    """Bounty status."""
    DRAFT = "draft"
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class BountyDifficulty(Enum):
    """Bounty difficulty levels."""
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class BadgeType(Enum):
    """Badge types for achievements."""
    FIRST_CONTRIBUTION = "first_contribution"
    BUG_HUNTER = "bug_hunter"
    DOCUMENTATION = "documentation"
    TESTING = "testing"
    SECURITY = "security"
    TRANSLATION = "translation"
    MENTOR = "mentor"
    HACKATHON_WINNER = "hackathon_winner"
    TOP_CONTRIBUTOR = "top_contributor"
    ROBOT_DRIVER = "robot_driver"


@dataclass
class Bounty:
    """A hackathon bounty."""
    id: str
    title: str
    description: str
    difficulty: BountyDifficulty
    status: BountyStatus
    reward: str
    category: str
    tags: List[str] = field(default_factory=list)
    repository: str = ""
    issues: List[str] = field(default_factory=list)
    created_by: str = ""
    created_at: float = field(default_factory=time.time)
    deadline: Optional[float] = None
    assigned_to: Optional[str] = None
    submitted_pr_url: Optional[str] = None
    reviewers: List[str] = field(default_factory=list)
    comments: int = 0
    accepted_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "difficulty": self.difficulty.value,
            "status": self.status.value,
            "reward": self.reward,
            "category": self.category,
            "tags": self.tags,
            "repository": self.repository,
            "issues": self.issues,
            "createdBy": self.created_by,
            "createdAt": self.created_at,
            "deadline": self.deadline,
            "assignedTo": self.assigned_to,
            "submittedPrUrl": self.submitted_pr_url,
            "reviewers": self.reviewers,
            "comments": self.comments,
            "acceptedAt": self.accepted_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Bounty':
        return cls(
            id=data["id"],
            title=data["title"],
            description=data["description"],
            difficulty=BountyDifficulty(data["difficulty"]),
            status=BountyStatus(data["status"]),
            reward=data["reward"],
            category=data["category"],
            tags=data.get("tags", []),
            repository=data.get("repository", ""),
            issues=data.get("issues", []),
            created_by=data.get("createdBy", ""),
            created_at=data.get("createdAt", time.time()),
            deadline=data.get("deadline"),
            assigned_to=data.get("assignedTo"),
            submitted_pr_url=data.get("submittedPrUrl"),
            reviewers=data.get("reviewers", []),
            comments=data.get("comments", 0),
            accepted_at=data.get("acceptedAt"),
        )


@dataclass
class Contributor:
    """A community contributor."""
    username: str
    display_name: str
    email: str = ""
    avatar_url: str = ""
    joined_at: float = field(default_factory=time.time)
    points: int = 0
    rank: str = "bronze"
    badges: List[str] = field(default_factory=list)
    contributions: Dict[str, int] = field(default_factory=dict)
    bounties_completed: int = 0
    pull_requests: int = 0
    issues_reported: int = 0
    code_reviews: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "username": self.username,
            "displayName": self.display_name,
            "email": self.email,
            "avatarUrl": self.avatar_url,
            "joinedAt": self.joined_at,
            "points": self.points,
            "rank": self.rank,
            "badges": self.badges,
            "contributions": self.contributions,
            "bountiesCompleted": self.bounties_completed,
            "pullRequests": self.pull_requests,
            "issuesReported": self.issues_reported,
            "codeReviews": self.code_reviews,
        }


@dataclass
class Hackathon:
    """A community hackathon event."""
    id: str
    name: str
    description: str
    start_date: float
    end_date: float
    status: str
    prizes: Dict[str, str] = field(default_factory=dict)
    tracks: List[str] = field(default_factory=list)
    participant_count: int = 0
    bounty_ids: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "startDate": self.start_date,
            "endDate": self.end_date,
            "status": self.status,
            "prizes": self.prizes,
            "tracks": self.tracks,
            "participantCount": self.participant_count,
            "bountyIds": self.bounty_ids,
            "createdAt": self.created_at,
        }


@dataclass
class LeaderboardEntry:
    """Leaderboard entry."""
    rank: int
    username: str
    display_name: str
    points: int
    bounties_completed: int
    pull_requests: int


class CommunityStore:
    """In-memory community data store."""

    def __init__(self):
        self._bounties: Dict[str, Bounty] = {}
        self._contributors: Dict[str, Contributor] = {}
        self._hackathons: Dict[str, Hackathon] = {}
        self._lock = threading.RLock()

    def create_bounty(self, bounty: Bounty) -> Bounty:
        with self._lock:
            self._bounties[bounty.id] = bounty
            logger.info(f"Created bounty: {bounty.title}")
            return bounty

    def get_bounty(self, bounty_id: str) -> Optional[Bounty]:
        with self._lock:
            return self._bounties.get(bounty_id)

    def list_bounties(
        self,
        status: Optional[BountyStatus] = None,
        difficulty: Optional[BountyDifficulty] = None,
        category: Optional[str] = None,
    ) -> List[Bounty]:
        with self._lock:
            bounties = list(self._bounties.values())
            if status:
                bounties = [b for b in bounties if b.status == status]
            if difficulty:
                bounties = [b for b in bounties if b.difficulty == difficulty]
            if category:
                bounties = [b for b in bounties if b.category == category]
            return sorted(bounties, key=lambda b: b.created_at, reverse=True)

    def update_bounty(self, bounty: Bounty) -> Bounty:
        with self._lock:
            self._bounties[bounty.id] = bounty
            return bounty

    def register_contributor(self, contributor: Contributor) -> Contributor:
        with self._lock:
            self._contributors[contributor.username] = contributor
            logger.info(f"Registered contributor: {contributor.username}")
            return contributor

    def get_contributor(self, username: str) -> Optional[Contributor]:
        with self._lock:
            return self._contributors.get(username)

    def update_contributor(self, contributor: Contributor) -> Contributor:
        with self._lock:
            self._contributors[contributor.username] = contributor
            self._update_rank(contributor)
            return contributor

    def _update_rank(self, contributor: Contributor):
        if contributor.points >= 5000:
            contributor.rank = "platinum"
        elif contributor.points >= 2000:
            contributor.rank = "gold"
        elif contributor.points >= 500:
            contributor.rank = "silver"
        else:
            contributor.rank = "bronze"

    def get_leaderboard(self, limit: int = 10) -> List[LeaderboardEntry]:
        with self._lock:
            contributors = sorted(
                self._contributors.values(),
                key=lambda c: c.points,
                reverse=True
            )
            entries = []
            for i, c in enumerate(contributors[:limit]):
                entries.append(LeaderboardEntry(
                    rank=i + 1,
                    username=c.username,
                    display_name=c.display_name,
                    points=c.points,
                    bounties_completed=c.bounties_completed,
                    pull_requests=c.pull_requests,
                ))
            return entries

    def create_hackathon(self, hackathon: Hackathon) -> Hackathon:
        with self._lock:
            self._hackathons[hackathon.id] = hackathon
            logger.info(f"Created hackathon: {hackathon.name}")
            return hackathon

    def get_hackathon(self, hackathon_id: str) -> Optional[Hackathon]:
        with self._lock:
            return self._hackathons.get(hackathon_id)

    def list_hackathons(self, status: Optional[str] = None) -> List[Hackathon]:
        with self._lock:
            hackathons = list(self._hackathons.values())
            if status:
                hackathons = [h for h in hackathons if h.status == status]
            return sorted(hackathons, key=lambda h: h.start_date, reverse=True)


class CommunityAPI:
    """P-MCP Community REST API."""

    def __init__(self, store: CommunityStore):
        self.store = store
        self._running = False

    async def start(self, host: str = "0.0.0.0", port: int = 8081):
        try:
            from aiohttp import web
        except ImportError:
            logger.error("aiohttp not installed. Run: pip install aiohttp")
            return

        app = web.Application()

        app.router.add_get("/health", self.handle_health)
        app.router.add_get("/metrics", self.handle_metrics)

        app.router.add_get("/bounties", self.handle_list_bounties)
        app.router.add_post("/bounties", self.handle_create_bounty)
        app.router.add_get("/bounties/{id}", self.handle_get_bounty)
        app.router.add_put("/bounties/{id}", self.handle_update_bounty)
        app.router.add_post("/bounties/{id}/claim", self.handle_claim_bounty)
        app.router.add_post("/bounties/{id}/submit", self.handle_submit_bounty)
        app.router.add_post("/bounties/{id}/accept", self.handle_accept_bounty)

        app.router.add_get("/contributors", self.handle_list_contributors)
        app.router.add_post("/contributors", self.handle_register_contributor)
        app.router.add_get("/contributors/{username}", self.handle_get_contributor)
        app.router.add_post("/contributors/{username}/points", self.handle_add_points)
        app.router.add_post("/contributors/{username}/badges", self.handle_add_badge)

        app.router.add_get("/leaderboard", self.handle_leaderboard)

        app.router.add_get("/hackathons", self.handle_list_hackathons)
        app.router.add_post("/hackathons", self.handle_create_hackathon)
        app.router.add_get("/hackathons/{id}", self.handle_get_hackathon)
        app.router.add_post("/hackathons/{id}/register", self.handle_register_hackathon)

        self._running = True
        self._populate_initial_data()

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host, port)
        await site.start()

        logger.info(f"P-MCP Community API starting on http://{host}:{port}")

        try:
            await asyncio.Event().wait()
        finally:
            await runner.cleanup()

    def _populate_initial_data(self):
        bounties = [
            Bounty(
                id="bounty-001",
                title="Add support for Boston Dynamics Spot",
                description="Implement P-MCP server for Boston Dynamics Spot robot with full motion control and sensor streaming.",
                difficulty=BountyDifficulty.EXPERT,
                status=BountyStatus.OPEN,
                reward="$2,000",
                category="robot_driver",
                tags=["robot", "boston-dynamics", "spot", " quadruped"],
                repository="https://github.com/Sandeeprdy1729/P-MCP",
                created_by="pmcp-team",
                deadline=time.time() + 30 * 24 * 60 * 60,
            ),
            Bounty(
                id="bounty-002",
                title="ROS2 Integration Package",
                description="Create a P-MCP to ROS2 bridge that allows seamless communication between P-MCP clients and ROS2 nodes.",
                difficulty=BountyDifficulty.ADVANCED,
                status=BountyStatus.OPEN,
                reward="$1,500",
                category="integration",
                tags=["ros2", "bridge", "integration"],
                repository="https://github.com/Sandeeprdy1729/P-MCP",
                created_by="pmcp-team",
                deadline=time.time() + 45 * 24 * 60 * 60,
            ),
            Bounty(
                id="bounty-003",
                title="Improve Documentation for v0.5",
                description="Enhance the P-MCP v0.5 documentation with better examples, API reference, and tutorials.",
                difficulty=BountyDifficulty.BEGINNER,
                status=BountyStatus.OPEN,
                reward="$300",
                category="documentation",
                tags=["docs", "tutorial", "examples"],
                repository="https://github.com/Sandeeprdy1729/P-MCP",
                created_by="pmcp-team",
            ),
            Bounty(
                id="bounty-004",
                title="Add Pytest Test Suite for Types",
                description="Write comprehensive pytest tests for all P-MCP type definitions to improve code coverage.",
                difficulty=BountyDifficulty.INTERMEDIATE,
                status=BountyStatus.OPEN,
                reward="$500",
                category="testing",
                tags=["pytest", "testing", "types"],
                repository="https://github.com/Sandeeprdy1729/P-MCP",
                created_by="pmcp-team",
            ),
            Bounty(
                id="bounty-005",
                title="Implement mTLS Gateway for Production",
                description="Build production-ready mTLS gateway with certificate rotation and CRL checking.",
                difficulty=BountyDifficulty.ADVANCED,
                status=BountyStatus.OPEN,
                reward="$1,200",
                category="security",
                tags=["mtls", "security", "gateway"],
                repository="https://github.com/Sandeeprdy1729/P-MCP",
                created_by="pmcp-team",
            ),
        ]

        for bounty in bounties:
            self.store.create_bounty(bounty)

        hackathons = [
            Hackathon(
                id="hackathon-001",
                name="P-MCP Robot Challenge 2025",
                description="Build a complete warehouse automation solution using P-MCP. Create a fleet of robots that can navigate, pick, and deliver items autonomously.",
                start_date=time.time() + 7 * 24 * 60 * 60,
                end_date=time.time() + 14 * 24 * 60 * 60,
                status="upcoming",
                prizes={
                    "1st": "$5,000",
                    "2nd": "$2,500",
                    "3rd": "$1,000",
                },
                tracks=["warehouse", "navigation", "fleet"],
                bounty_ids=["bounty-001", "bounty-002"],
            ),
            Hackathon(
                id="hackathon-002",
                name="P-MCP Safety First Hackathon",
                description="Focus on safety-critical features for P-MCP: emergency stop protocols, collision avoidance, and fail-safe operations.",
                start_date=time.time() + 30 * 24 * 60 * 60,
                end_date=time.time() + 37 * 24 * 60 * 60,
                status="upcoming",
                prizes={
                    "1st": "$3,000",
                    "2nd": "$1,500",
                    "3rd": "$750",
                },
                tracks=["safety", "emergency", "collision"],
                bounty_ids=["bounty-005"],
            ),
        ]

        for hackathon in hackathons:
            self.store.create_hackathon(hackathon)

        logger.info("Populated initial bounties and hackathons")

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({
            "status": "healthy",
            "timestamp": time.time(),
            "version": "0.5.0",
        })

    async def handle_metrics(self, request: web.Request) -> web.Response:
        return web.json_response({
            "totalBounties": len(self.store._bounties),
            "openBounties": len([b for b in self.store._bounties.values() if b.status == BountyStatus.OPEN]),
            "totalContributors": len(self.store._contributors),
            "totalHackathons": len(self.store._hackathons),
        })

    async def handle_list_bounties(self, request: web.Request) -> web.Response:
        status = request.query.get("status")
        difficulty = request.query.get("difficulty")
        category = request.query.get("category")

        status_enum = BountyStatus(status) if status else None
        difficulty_enum = BountyDifficulty(difficulty) if difficulty else None

        bounties = self.store.list_bounties(status_enum, difficulty_enum, category)

        return web.json_response({
            "bounties": [b.to_dict() for b in bounties],
            "count": len(bounties),
        })

    async def handle_create_bounty(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        required = ["title", "description", "difficulty", "reward", "category"]
        for field in required:
            if field not in data:
                return web.json_response({"error": f"Missing required field: {field}"}, status=400)

        bounty = Bounty(
            id=f"bounty-{uuid.uuid4().hex[:8]}",
            title=data["title"],
            description=data["description"],
            difficulty=BountyDifficulty(data["difficulty"]),
            status=BountyStatus.OPEN,
            reward=data["reward"],
            category=data["category"],
            tags=data.get("tags", []),
            repository=data.get("repository", ""),
            created_by=data.get("createdBy", "anonymous"),
            deadline=data.get("deadline"),
        )

        bounty = self.store.create_bounty(bounty)
        return web.json_response(bounty.to_dict(), status=201)

    async def handle_get_bounty(self, request: web.Request) -> web.Response:
        bounty_id = request.match_info["id"]
        bounty = self.store.get_bounty(bounty_id)

        if not bounty:
            return web.json_response({"error": f"Bounty not found: {bounty_id}"}, status=404)

        return web.json_response(bounty.to_dict())

    async def handle_update_bounty(self, request: web.Request) -> web.Response:
        bounty_id = request.match_info["id"]
        bounty = self.store.get_bounty(bounty_id)

        if not bounty:
            return web.json_response({"error": f"Bounty not found: {bounty_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        for key, value in data.items():
            if hasattr(bounty, key):
                setattr(bounty, key, value)

        bounty = self.store.update_bounty(bounty)
        return web.json_response(bounty.to_dict())

    async def handle_claim_bounty(self, request: web.Request) -> web.Response:
        bounty_id = request.match_info["id"]
        bounty = self.store.get_bounty(bounty_id)

        if not bounty:
            return web.json_response({"error": f"Bounty not found: {bounty_id}"}, status=404)

        if bounty.status != BountyStatus.OPEN:
            return web.json_response({"error": "Bounty is not open"}, status=400)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        username = data.get("username")
        if not username:
            return web.json_response({"error": "Missing username"}, status=400)

        bounty.status = BountyStatus.IN_PROGRESS
        bounty.assigned_to = username
        bounty = self.store.update_bounty(bounty)

        return web.json_response(bounty.to_dict())

    async def handle_submit_bounty(self, request: web.Request) -> web.Response:
        bounty_id = request.match_info["id"]
        bounty = self.store.get_bounty(bounty_id)

        if not bounty:
            return web.json_response({"error": f"Bounty not found: {bounty_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        bounty.submitted_pr_url = data.get("prUrl")
        bounty.comments += 1
        bounty = self.store.update_bounty(bounty)

        return web.json_response(bounty.to_dict())

    async def handle_accept_bounty(self, request: web.Request) -> web.Response:
        bounty_id = request.match_info["id"]
        bounty = self.store.get_bounty(bounty_id)

        if not bounty:
            return web.json_response({"error": f"Bounty not found: {bounty_id}"}, status=404)

        bounty.status = BountyStatus.COMPLETED
        bounty.accepted_at = time.time()
        bounty = self.store.update_bounty(bounty)

        if bounty.assigned_to:
            contributor = self.store.get_contributor(bounty.assigned_to)
            if contributor:
                contributor.bounties_completed += 1
                contributor.points += self._calculate_bounty_points(bounty.difficulty)
                self.store.update_contributor(contributor)

        return web.json_response(bounty.to_dict())

    def _calculate_bounty_points(self, difficulty: BountyDifficulty) -> int:
        points_map = {
            BountyDifficulty.BEGINNER: 50,
            BountyDifficulty.INTERMEDIATE: 100,
            BountyDifficulty.ADVANCED: 250,
            BountyDifficulty.EXPERT: 500,
        }
        return points_map.get(difficulty, 50)

    async def handle_list_contributors(self, request: web.Request) -> web.Response:
        contributors = list(self.store._contributors.values())
        return web.json_response({
            "contributors": [c.to_dict() for c in contributors],
            "count": len(contributors),
        })

    async def handle_register_contributor(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        username = data.get("username")
        if not username:
            return web.json_response({"error": "Missing username"}, status=400)

        contributor = Contributor(
            username=username,
            display_name=data.get("displayName", username),
            email=data.get("email", ""),
            avatar_url=data.get("avatarUrl", ""),
        )

        contributor = self.store.register_contributor(contributor)
        return web.json_response(contributor.to_dict(), status=201)

    async def handle_get_contributor(self, request: web.Request) -> web.Response:
        username = request.match_info["username"]
        contributor = self.store.get_contributor(username)

        if not contributor:
            return web.json_response({"error": f"Contributor not found: {username}"}, status=404)

        return web.json_response(contributor.to_dict())

    async def handle_add_points(self, request: web.Request) -> web.Response:
        username = request.match_info["username"]
        contributor = self.store.get_contributor(username)

        if not contributor:
            return web.json_response({"error": f"Contributor not found: {username}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        points = data.get("points", 0)
        contributor.points += points

        contributor = self.store.update_contributor(contributor)
        return web.json_response(contributor.to_dict())

    async def handle_add_badge(self, request: web.Request) -> web.Response:
        username = request.match_info["username"]
        contributor = self.store.get_contributor(username)

        if not contributor:
            return web.json_response({"error": f"Contributor not found: {username}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        badge = data.get("badge")
        if not badge:
            return web.json_response({"error": "Missing badge"}, status=400)

        if badge not in contributor.badges:
            contributor.badges.append(badge)

        contributor = self.store.update_contributor(contributor)
        return web.json_response(contributor.to_dict())

    async def handle_leaderboard(self, request: web.Request) -> web.Response:
        limit = int(request.query.get("limit", "10"))
        entries = self.store.get_leaderboard(limit)

        return web.json_response({
            "leaderboard": [e.__dict__ for e in entries],
            "count": len(entries),
        })

    async def handle_list_hackathons(self, request: web.Request) -> web.Response:
        status = request.query.get("status")
        hackathons = self.store.list_hackathons(status)

        return web.json_response({
            "hackathons": [h.to_dict() for h in hackathons],
            "count": len(hackathons),
        })

    async def handle_create_hackathon(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        required = ["name", "description", "startDate", "endDate"]
        for field in required:
            if field not in data:
                return web.json_response({"error": f"Missing required field: {field}"}, status=400)

        hackathon = Hackathon(
            id=f"hackathon-{uuid.uuid4().hex[:8]}",
            name=data["name"],
            description=data["description"],
            start_date=data["startDate"],
            end_date=data["endDate"],
            status="upcoming",
            prizes=data.get("prizes", {}),
            tracks=data.get("tracks", []),
            bounty_ids=data.get("bountyIds", []),
        )

        hackathon = self.store.create_hackathon(hackathon)
        return web.json_response(hackathon.to_dict(), status=201)

    async def handle_get_hackathon(self, request: web.Request) -> web.Response:
        hackathon_id = request.match_info["id"]
        hackathon = self.store.get_hackathon(hackathon_id)

        if not hackathon:
            return web.json_response({"error": f"Hackathon not found: {hackathon_id}"}, status=404)

        return web.json_response(hackathon.to_dict())

    async def handle_register_hackathon(self, request: web.Request) -> web.Response:
        hackathon_id = request.match_info["id"]
        hackathon = self.store.get_hackathon(hackathon_id)

        if not hackathon:
            return web.json_response({"error": f"Hackathon not found: {hackathon_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        username = data.get("username")
        if not username:
            return web.json_response({"error": "Missing username"}, status=400)

        hackathon.participant_count += 1
        self.store._hackathons[hackathon_id] = hackathon

        return web.json_response(hackathon.to_dict())


async def main():
    parser = argparse.ArgumentParser(description="P-MCP Community Features")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8081, help="Port to bind to")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Logging level")

    args = parser.parse_args()
    logging.getLogger().setLevel(getattr(logging, args.log_level))

    store = CommunityStore()
    api = CommunityAPI(store)
    await api.start(args.host, args.port)


if __name__ == "__main__":
    asyncio.run(main())