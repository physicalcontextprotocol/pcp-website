#!/usr/bin/env python3
"""
P-MCP Monitoring Service
========================

Real-time monitoring and alerting service.

Usage:
    python -m cloud.backend.monitoring
"""

import asyncio
import logging
import time
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable
from enum import Enum

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger("pmcp-monitoring")


class MetricType(Enum):
    """Types of metrics."""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"


@dataclass
class Metric:
    """A monitoring metric."""
    name: str
    value: float
    metric_type: MetricType
    labels: Dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    unit: str = ""


@dataclass
class AlertRule:
    """Alert rule definition."""
    rule_id: str
    name: str
    condition: str
    threshold: float
    severity: str
    enabled: bool = True
    cooldown_seconds: int = 300


@dataclass
class Alert:
    """Generated alert."""
    alert_id: str
    rule_name: str
    message: str
    severity: str
    fired_at: float
    resolved_at: Optional[float] = None


class MetricsCollector:
    """Collect and store metrics."""

    def __init__(self):
        self._metrics: Dict[str, List[Metric]] = {}
        self._lock = threading.Lock()

    def record(self, metric: Metric):
        """Record a metric."""
        with self._lock:
            if metric.name not in self._metrics:
                self._metrics[metric.name] = []
            self._metrics[metric.name].append(metric)

            if len(self._metrics[metric.name]) > 10000:
                self._metrics[metric.name] = self._metrics[metric.name][-5000:]

    def get_metrics(self, name: str, since: Optional[float] = None) -> List[Metric]:
        """Get metrics by name."""
        with self._lock:
            metrics = self._metrics.get(name, [])
            if since:
                metrics = [m for m in metrics if m.timestamp > since]
            return metrics


class AlertManager:
    """Manage alert rules and alerts."""

    def __init__(self, collector: MetricsCollector):
        self.collector = collector
        self._rules: Dict[str, AlertRule] = {}
        self._active_alerts: Dict[str, Alert] = {}
        self._alert_history: List[Alert] = []
        self._lock = threading.Lock()
        self._callbacks: List[Callable] = []

    def add_rule(self, rule: AlertRule):
        """Add an alert rule."""
        with self._lock:
            self._rules[rule.rule_id] = rule

    def remove_rule(self, rule_id: str) -> bool:
        """Remove an alert rule."""
        with self._lock:
            if rule_id in self._rules:
                del self._rules[rule_id]
                return True
            return False

    def enable_rule(self, rule_id: str) -> bool:
        """Enable an alert rule."""
        with self._lock:
            if rule_id in self._rules:
                self._rules[rule_id].enabled = True
                return True
            return False

    def disable_rule(self, rule_id: str) -> bool:
        """Disable an alert rule."""
        with self._lock:
            if rule_id in self._rules:
                self._rules[rule_id].enabled = False
                return True
            return False

    def check_rules(self):
        """Check all enabled rules."""
        with self._lock:
            for rule in self._rules.values():
                if not rule.enabled:
                    continue

                metrics = self.collector.get_metrics(rule.name)
                if not metrics:
                    continue

                latest = metrics[-1]
                should_fire = self._evaluate_condition(rule.condition, latest.value, rule.threshold)

                if should_fire and rule.rule_id not in self._active_alerts:
                    self._fire_alert(rule, latest.value)
                elif not should_fire and rule.rule_id in self._active_alerts:
                    self._resolve_alert(rule.rule_id)

    def _evaluate_condition(self, condition: str, value: float, threshold: float) -> bool:
        """Evaluate alert condition."""
        if condition == "gt":
            return value > threshold
        elif condition == "lt":
            return value < threshold
        elif condition == "eq":
            return value == threshold
        elif condition == "gte":
            return value >= threshold
        elif condition == "lte":
            return value <= threshold
        return False

    def _fire_alert(self, rule: AlertRule, value: float):
        """Fire an alert."""
        alert = Alert(
            alert_id=f"alert-{rule.rule_id}-{int(time.time())}",
            rule_name=rule.name,
            message=f"{rule.name} is {value:.2f} (threshold: {rule.threshold})",
            severity=rule.severity,
            fired_at=time.time(),
        )
        self._active_alerts[rule.rule_id] = alert
        self._alert_history.append(alert)

        for callback in self._callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"Alert callback error: {e}")

        logger.warning(f"Alert fired: {alert.message}")

    def _resolve_alert(self, rule_id: str):
        """Resolve an alert."""
        if rule_id in self._active_alerts:
            alert = self._active_alerts[rule_id]
            alert.resolved_at = time.time()
            del self._active_alerts[rule_id]
            logger.info(f"Alert resolved: {alert.rule_name}")

    def get_active_alerts(self) -> List[Alert]:
        """Get all active alerts."""
        with self._lock:
            return list(self._active_alerts.values())

    def get_alert_history(self, limit: int = 100) -> List[Alert]:
        """Get alert history."""
        with self._lock:
            return self._alert_history[-limit:]

    def subscribe(self, callback: Callable):
        """Subscribe to alerts."""
        self._callbacks.append(callback)


class MonitoringService:
    """Main monitoring service."""

    def __init__(self):
        self.collector = MetricsCollector()
        self.alert_manager = AlertManager(self.collector)
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None

    async def start(self):
        """Start the monitoring service."""
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("Monitoring service started")

    async def stop(self):
        """Stop the monitoring service."""
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()
        logger.info("Monitoring service stopped")

    async def _monitor_loop(self):
        """Main monitoring loop."""
        while self._running:
            self.alert_manager.check_rules()
            await asyncio.sleep(1)

    def record_metric(self, name: str, value: float, metric_type: MetricType = MetricType.GAUGE,
                      labels: Optional[Dict[str, str]] = None, unit: str = ""):
        """Record a metric."""
        metric = Metric(
            name=name,
            value=value,
            metric_type=metric_type,
            labels=labels or {},
            unit=unit,
        )
        self.collector.record(metric)

    def add_alert_rule(self, rule_id: str, name: str, condition: str, threshold: float, severity: str):
        """Add an alert rule."""
        rule = AlertRule(
            rule_id=rule_id,
            name=name,
            condition=condition,
            threshold=threshold,
            severity=severity,
        )
        self.alert_manager.add_rule(rule)

    def get_status(self) -> Dict[str, Any]:
        """Get monitoring status."""
        active_alerts = self.alert_manager.get_active_alerts()
        return {
            "running": self._running,
            "active_alerts": len(active_alerts),
            "alert_rules": len(self.alert_manager._rules),
            "enabled_rules": sum(1 for r in self.alert_manager._rules.values() if r.enabled),
            "alerts_by_severity": {
                "critical": sum(1 for a in active_alerts if a.severity == "critical"),
                "warning": sum(1 for a in active_alerts if a.severity == "warning"),
                "info": sum(1 for a in active_alerts if a.severity == "info"),
            },
        }


async def main():
    """Run monitoring service."""
    service = MonitoringService()

    service.add_alert_rule("high_cpu", "cpu_usage", "gt", 80, "warning")
    service.add_alert_rule("low_memory", "memory_free", "lt", 100, "critical")
    service.add_alert_rule("high_latency", "request_latency", "gt", 1000, "warning")

    service.record_metric("cpu_usage", 45.5, MetricType.GAUGE, {"host": "server1"}, "%")
    service.record_metric("memory_free", 2048, MetricType.GAUGE, {"host": "server1"}, "MB")
    service.record_metric("request_latency", 125.3, MetricType.HISTOGRAM, {"endpoint": "/api"}, "ms")

    await service.start()

    for i in range(10):
        service.record_metric("cpu_usage", 50 + i * 2, MetricType.GAUGE)
        await asyncio.sleep(1)

    status = service.get_status()
    logger.info(f"Status: {status}")

    await service.stop()


if __name__ == "__main__":
    asyncio.run(main())