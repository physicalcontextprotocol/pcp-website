"""P-MCP Metrics Collector - Fleet metrics and monitoring."""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from collections import defaultdict
import time


@dataclass
class FleetMetrics:
    """Fleet-wide metrics."""
    timestamp: float
    total_robots: int = 0
    online_robots: int = 0
    offline_robots: int = 0
    error_robots: int = 0
    avg_health_score: float = 100.0
    total_telemetry_messages: int = 0
    avg_latency_ms: float = 0.0
    active_alerts: int = 0
    zone_stats: Dict[str, Dict[str, int]] = field(default_factory=dict)


@dataclass
class MetricsCollector:
    """Service for collecting and aggregating fleet metrics."""

    _telemetry_count: int = 0
    _latencies: List[float] = field(default_factory=list)
    _zone_counts: Dict[str, Dict[str, int]] = field(default_factory=lambda: defaultdict(lambda: {"online": 0, "offline": 0, "error": 0}))
    _last_collection: float = field(default_factory=time.time)

    def record_telemetry(self, latency_ms: float):
        """Record telemetry message."""
        self._telemetry_count += 1
        self._latencies.append(latency_ms)
        if len(self._latencies) > 1000:
            self._latencies = self._latencies[-500:]

    def update_zone_stats(self, zone_id: str, status: str):
        """Update zone robot counts."""
        self._zone_counts[zone_id][status] = self._zone_counts[zone_id].get(status, 0) + 1

    def collect(self, robots: List[Any]) -> FleetMetrics:
        """Collect current fleet metrics."""
        now = time.time()
        total = len(robots)
        online = sum(1 for r in robots if r.status.value == "online")
        offline = sum(1 for r in robots if r.status.value == "offline")
        error = sum(1 for r in robots if r.status.value == "error")
        avg_health = sum(r.health_score for r in robots) / max(total, 1)

        return FleetMetrics(
            timestamp=now,
            total_robots=total,
            online_robots=online,
            offline_robots=offline,
            error_robots=error,
            avg_health_score=avg_health,
            total_telemetry_messages=self._telemetry_count,
            avg_latency_ms=sum(self._latencies) / max(len(self._latencies), 1),
            zone_stats=dict(self._zone_counts),
        )

    def get_rate(self, metric: str) -> float:
        """Calculate rate for a metric."""
        now = time.time()
        elapsed = now - self._last_collection
        if elapsed == 0:
            return 0.0

        if metric == "telemetry_rate":
            return self._telemetry_count / elapsed
        return 0.0