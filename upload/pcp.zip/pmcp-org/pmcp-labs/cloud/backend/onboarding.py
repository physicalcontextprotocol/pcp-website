"""P-MCP Onboarding Service - Robot onboarding wizard."""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum
import time


class RobotOnboardingStep(Enum):
    """Steps in the robot onboarding wizard."""
    VERIFY_CONNECTION = "verify_connection"
    DETECT_CAPABILITIES = "detect_capabilities"
    CONFIGURE_ZONE = "configure_zone"
    CALIBRATE_SENSORS = "calibrate_sensors"
    VERIFY_OPERATION = "verify_operation"


@dataclass
class OnboardingService:
    """Service for managing robot onboarding."""

    def create_session(self, robot_id: str) -> Dict[str, Any]:
        """Create a new onboarding session."""
        return {
            "sessionId": f"session-{robot_id}",
            "robotId": robot_id,
            "steps": [step.value for step in RobotOnboardingStep],
            "currentStep": 0,
            "createdAt": time.time(),
        }

    def get_step_instructions(self, step: RobotOnboardingStep) -> Dict[str, Any]:
        """Get instructions for a specific onboarding step."""
        instructions = {
            RobotOnboardingStep.VERIFY_CONNECTION: {
                "title": "Verify Connection",
                "description": "Ensure the robot can communicate with the P-MCP server",
                "checklist": [
                    "Check network connectivity",
                    "Verify P-MCP server is reachable",
                    "Confirm robot IP address",
                ],
            },
            RobotOnboardingStep.DETECT_CAPABILITIES: {
                "title": "Detect Capabilities",
                "description": "Automatically detect robot sensors and actuators",
                "checklist": [
                    "Scan for available sensors",
                    "Detect motion capabilities",
                    "Identify communication interfaces",
                ],
            },
            RobotOnboardingStep.CONFIGURE_ZONE: {
                "title": "Configure Zone",
                "description": "Assign the robot to a fleet management zone",
                "checklist": [
                    "Select zone from dropdown",
                    "Set zone boundaries",
                    "Configure zone-specific parameters",
                ],
            },
            RobotOnboardingStep.CALIBRATE_SENSORS: {
                "title": "Calibrate Sensors",
                "description": "Run sensor calibration routines",
                "checklist": [
                    "Calibrate LiDAR if present",
                    "Calibrate cameras",
                    "Verify IMU orientation",
                ],
            },
            RobotOnboardingStep.VERIFY_OPERATION: {
                "title": "Verify Operation",
                "description": "Run basic operation tests",
                "checklist": [
                    "Test basic movement",
                    "Verify telemetry reporting",
                    "Confirm emergency stop works",
                ],
            },
        }
        return instructions.get(step, {})

    def validate_step(self, step: RobotOnboardingStep, data: Dict[str, Any]) -> bool:
        """Validate data for a specific step."""
        if step == RobotOnboardingStep.VERIFY_CONNECTION:
            return "connected" in data and data["connected"]
        elif step == RobotOnboardingStep.DETECT_CAPABILITIES:
            return "capabilities" in data and len(data["capabilities"]) > 0
        elif step == RobotOnboardingStep.CONFIGURE_ZONE:
            return "zoneId" in data
        elif step == RobotOnboardingStep.CALIBRATE_SENSORS:
            return "calibrated" in data and data["calibrated"]
        elif step == RobotOnboardingStep.VERIFY_OPERATION:
            return "verified" in data and data["verified"]
        return False