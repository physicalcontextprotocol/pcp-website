#!/usr/bin/env python3
"""
P-MCP Cloud Control Plane
=========================

Production-grade fleet management backend with:
- Robot onboarding wizard
- Live 3D twin visualization
- Alerting & monitoring
- Audit logging
- Multi-zone fleet management

Usage:
    python -m cloud.backend.server --port 8083
"""

import asyncio
import argparse
import hashlib
import json
import logging
import os
import time
import uuid
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Callable
from collections import defaultdict
import traceback

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s [%(name)s] %(message)s'
)
logger = logging.getLogger("pmcp-cloud")


class RobotStatus(Enum):
    """Robot operational status."""
    PENDING = "pending"
    REGISTERED = "registered"
    ONLINE = "online"
    OFFLINE = "offline"
    ERROR = "error"
    MAINTENANCE = "maintenance"


class OnboardingState(Enum):
    """Onboarding wizard states."""
    START = "start"
    CONNECT = "connect"
    CONFIGURE = "configure"
    VERIFY = "verify"
    COMPLETE = "complete"


@dataclass
class Robot:
    """A registered robot in the fleet."""
    robot_id: str
    name: str
    robot_type: str
    serial_number: str = ""
    firmware_version: str = ""
    status: RobotStatus = RobotStatus.PENDING
    zone: str = "default"
    capabilities: List[str] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    position: Dict[str, float] = field(default_factory=lambda: {"x": 0, "y": 0, "z": 0})
    orientation: Dict[str, float] = field(default_factory=lambda: {"qx": 0, "qy": 0, "qz": 0, "qw": 1})
    velocity: Dict[str, float] = field(default_factory=lambda: {"vx": 0, "vy": 0, "vz": 0, "omega": 0})
    last_seen: float = field(default_factory=time.time)
    registered_at: float = field(default_factory=time.time)
    onboarded_at: Optional[float] = None
    health_score: float = 100.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "robotId": self.robot_id,
            "name": self.name,
            "robotType": self.robot_type,
            "serialNumber": self.serial_number,
            "firmwareVersion": self.firmware_version,
            "status": self.status.value,
            "zone": self.zone,
            "capabilities": self.capabilities,
            "metadata": self.metadata,
            "position": self.position,
            "orientation": self.orientation,
            "velocity": self.velocity,
            "lastSeen": self.last_seen,
            "registeredAt": self.registered_at,
            "onboardedAt": self.onboarded_at,
            "healthScore": self.health_score,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Robot':
        return cls(
            robot_id=data["robotId"],
            name=data["name"],
            robot_type=data["robotType"],
            serial_number=data.get("serialNumber", ""),
            firmware_version=data.get("firmwareVersion", ""),
            status=RobotStatus(data.get("status", "pending")),
            zone=data.get("zone", "default"),
            capabilities=data.get("capabilities", []),
            metadata=data.get("metadata", {}),
            position=data.get("position", {"x": 0, "y": 0, "z": 0}),
            orientation=data.get("orientation", {"qx": 0, "qy": 0, "qz": 0, "qw": 1}),
            velocity=data.get("velocity", {"vx": 0, "vy": 0, "vz": 0, "omega": 0}),
            last_seen=data.get("lastSeen", time.time()),
            registered_at=data.get("registeredAt", time.time()),
            onboarded_at=data.get("onboardedAt"),
            health_score=data.get("healthScore", 100.0),
        )


@dataclass
class Zone:
    """A fleet management zone."""
    zone_id: str
    name: str
    description: str = ""
    bounds: Dict[str, float] = field(default_factory=lambda: {
        "minX": 0, "maxX": 100, "minY": 0, "maxY": 100, "minZ": 0, "maxZ": 10
    })
    robots: List[str] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "zoneId": self.zone_id,
            "name": self.name,
            "description": self.description,
            "bounds": self.bounds,
            "robots": self.robots,
            "metadata": self.metadata,
            "createdAt": self.created_at,
            "robotCount": len(self.robots),
        }


@dataclass
class Alert:
    """A fleet alert."""
    alert_id: str
    robot_id: Optional[str]
    zone_id: Optional[str]
    severity: str
    title: str
    message: str
    source: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[float] = None
    resolved: bool = False
    resolved_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alertId": self.alert_id,
            "robotId": self.robot_id,
            "zoneId": self.zone_id,
            "severity": self.severity,
            "title": self.title,
            "message": self.message,
            "source": self.source,
            "metadata": self.metadata,
            "createdAt": self.created_at,
            "acknowledged": self.acknowledged,
            "acknowledgedBy": self.acknowledged_by,
            "acknowledgedAt": self.acknowledged_at,
            "resolved": self.resolved,
            "resolvedAt": self.resolved_at,
        }


@dataclass
class AuditEvent:
    """An audit log event."""
    event_id: str
    timestamp: float
    action: str
    actor: str
    target_type: str
    target_id: str
    details: Dict[str, Any] = field(default_factory=dict)
    ip_address: str = ""
    user_agent: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "eventId": self.event_id,
            "timestamp": self.timestamp,
            "action": self.action,
            "actor": self.actor,
            "targetType": self.target_type,
            "targetId": self.target_id,
            "details": self.details,
            "ipAddress": self.ip_address,
            "userAgent": self.user_agent,
        }


@dataclass
class OnboardingSession:
    """Robot onboarding session."""
    session_id: str
    robot_id: str
    state: OnboardingState
    current_step: int
    total_steps: int
    step_data: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sessionId": self.session_id,
            "robotId": self.robot_id,
            "state": self.state.value,
            "currentStep": self.current_step,
            "totalSteps": self.total_steps,
            "stepData": self.step_data,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at,
            "completedAt": self.completed_at,
            "progress": f"{self.current_step}/{self.total_steps}",
        }


class CloudStore:
    """In-memory cloud data store."""

    def __init__(self):
        self._robots: Dict[str, Robot] = {}
        self._zones: Dict[str, Zone] = {}
        self._alerts: Dict[str, Alert] = {}
        self._audit: List[AuditEvent] = []
        self._onboarding: Dict[str, OnboardingSession] = {}
        self._lock = threading.RLock()
        self._subscribers: Dict[str, List[Callable]] = defaultdict(list)

        self._initialize_default_zones()

    def _initialize_default_zones(self):
        default_zones = [
            Zone("zone-default", "Default Zone", "Default fleet zone"),
            Zone("zone-warehouse-a", "Warehouse A", "Primary warehouse area"),
            Zone("zone-warehouse-b", "Warehouse B", "Secondary warehouse area"),
            Zone("zone-loading", "Loading Dock", "Loading and unloading area"),
        ]
        for zone in default_zones:
            self._zones[zone.zone_id] = zone

    def register_robot(self, robot: Robot) -> Robot:
        with self._lock:
            self._robots[robot.robot_id] = robot
            self._emit_event("robot_registered", robot.to_dict())
            return robot

    def get_robot(self, robot_id: str) -> Optional[Robot]:
        with self._lock:
            return self._robots.get(robot_id)

    def update_robot(self, robot: Robot) -> Robot:
        with self._lock:
            self._robots[robot.robot_id] = robot
            self._emit_event("robot_updated", robot.to_dict())
            return robot

    def delete_robot(self, robot_id: str) -> bool:
        with self._lock:
            if robot_id in self._robots:
                del self._robots[robot_id]
                self._emit_event("robot_deleted", {"robotId": robot_id})
                return True
            return False

    def list_robots(self, status: Optional[RobotStatus] = None, zone: Optional[str] = None) -> List[Robot]:
        with self._lock:
            robots = list(self._robots.values())
            if status:
                robots = [r for r in robots if r.status == status]
            if zone:
                robots = [r for r in robots if r.zone == zone]
            return robots

    def create_zone(self, zone: Zone) -> Zone:
        with self._lock:
            self._zones[zone.zone_id] = zone
            return zone

    def get_zone(self, zone_id: str) -> Optional[Zone]:
        with self._lock:
            return self._zones.get(zone_id)

    def list_zones(self) -> List[Zone]:
        with self._lock:
            return list(self._zones.values())

    def add_alert(self, alert: Alert) -> Alert:
        with self._lock:
            self._alerts[alert.alert_id] = alert
            return alert

    def get_alert(self, alert_id: str) -> Optional[Alert]:
        with self._lock:
            return self._alerts.get(alert_id)

    def list_alerts(
        self,
        robot_id: Optional[str] = None,
        severity: Optional[str] = None,
        acknowledged: Optional[bool] = None,
        resolved: Optional[bool] = None,
    ) -> List[Alert]:
        with self._lock:
            alerts = list(self._alerts.values())
            if robot_id:
                alerts = [a for a in alerts if a.robot_id == robot_id]
            if severity:
                alerts = [a for a in alerts if a.severity == severity]
            if acknowledged is not None:
                alerts = [a for a in alerts if a.acknowledged == acknowledged]
            if resolved is not None:
                alerts = [a for a in alerts if a.resolved == resolved]
            return sorted(alerts, key=lambda a: a.created_at, reverse=True)

    def add_audit_event(self, event: AuditEvent):
        with self._lock:
            self._audit.append(event)
            if len(self._audit) > 10000:
                self._audit[:] = self._audit[-5000:]

    def list_audit_events(
        self,
        action: Optional[str] = None,
        actor: Optional[str] = None,
        target_type: Optional[str] = None,
        limit: int = 100,
    ) -> List[AuditEvent]:
        with self._lock:
            events = list(self._audit)
            if action:
                events = [e for e in events if e.action == action]
            if actor:
                events = [e for e in events if e.actor == actor]
            if target_type:
                events = [e for e in events if e.target_type == target_type]
            return events[-limit:]

    def create_onboarding_session(self, session: OnboardingSession) -> OnboardingSession:
        with self._lock:
            self._onboarding[session.session_id] = session
            return session

    def get_onboarding_session(self, session_id: str) -> Optional[OnboardingSession]:
        with self._lock:
            return self._onboarding.get(session_id)

    def update_onboarding_session(self, session: OnboardingSession) -> OnboardingSession:
        with self._lock:
            session.updated_at = time.time()
            self._onboarding[session.session_id] = session
            return session

    def get_fleet_stats(self) -> Dict[str, Any]:
        with self._lock:
            robots = list(self._robots.values())
            return {
                "totalRobots": len(robots),
                "onlineRobots": len([r for r in robots if r.status == RobotStatus.ONLINE]),
                "offlineRobots": len([r for r in robots if r.status == RobotStatus.OFFLINE]),
                "errorRobots": len([r for r in robots if r.status == RobotStatus.ERROR]),
                "pendingRobots": len([r for r in robots if r.status == RobotStatus.PENDING]),
                "totalZones": len(self._zones),
                "activeAlerts": len([a for a in self._alerts.values() if not a.resolved]),
                "criticalAlerts": len([a for a in self._alerts.values() if a.severity == "critical" and not a.resolved]),
                "avgHealthScore": sum(r.health_score for r in robots) / max(len(robots), 1),
            }

    def _emit_event(self, event_type: str, data: Any):
        for callback in self._subscribers.get(event_type, []):
            try:
                callback(data)
            except Exception as e:
                logger.error(f"Subscriber error: {e}")


class CloudAPI:
    """P-MCP Cloud Control Plane REST API."""

    def __init__(self, store: CloudStore):
        self.store = store
        self._running = False
        self._cleanup_task: Optional[asyncio.Task] = None

    async def start(self, host: str = "0.0.0.0", port: int = 8083):
        try:
            from aiohttp import web
        except ImportError:
            logger.error("aiohttp not installed. Run: pip install aiohttp")
            return

        app = web.Application()

        app.router.add_get("/health", self.handle_health)
        app.router.add_get("/metrics", self.handle_metrics)

        app.router.add_get("/api/v1/robots", self.handle_list_robots)
        app.router.add_post("/api/v1/robots", self.handle_register_robot)
        app.router.add_get("/api/v1/robots/{id}", self.handle_get_robot)
        app.router.add_put("/api/v1/robots/{id}", self.handle_update_robot)
        app.router.add_delete("/api/v1/robots/{id}", self.handle_delete_robot)
        app.router.add_post("/api/v1/robots/{id}/telemetry", self.handle_robot_telemetry)
        app.router.add_post("/api/v1/robots/{id}/command", self.handle_robot_command)

        app.router.add_get("/api/v1/zones", self.handle_list_zones)
        app.router.add_post("/api/v1/zones", self.handle_create_zone)
        app.router.add_get("/api/v1/zones/{id}", self.handle_get_zone)
        app.router.add_put("/api/v1/zones/{id}", self.handle_update_zone)
        app.router.add_delete("/api/v1/zones/{id}", self.handle_delete_zone)

        app.router.add_get("/api/v1/alerts", self.handle_list_alerts)
        app.router.add_post("/api/v1/alerts", self.handle_create_alert)
        app.router.add_post("/api/v1/alerts/{id}/acknowledge", self.handle_acknowledge_alert)
        app.router.add_post("/api/v1/alerts/{id}/resolve", self.handle_resolve_alert)

        app.router.add_get("/api/v1/audit", self.handle_list_audit)
        app.router.add_post("/api/v1/audit/query", self.handle_query_audit)

        app.router.add_get("/api/v1/onboarding", self.handle_list_onboarding)
        app.router.add_post("/api/v1/onboarding/start", self.handle_start_onboarding)
        app.router.add_post("/api/v1/onboarding/{id}/next", self.handle_onboarding_next)
        app.router.add_post("/api/v1/onboarding/{id}/complete", self.handle_onboarding_complete)

        app.router.add_get("/api/v1/twin", self.handle_get_twin_state)
        app.router.add_get("/api/v1/twin/stream", self.handle_twin_stream)

        app.router.add_get("/api/v1/fleet/stats", self.handle_fleet_stats)

        self._running = True
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host, port)
        await site.start()

        logger.info(f"P-MCP Cloud starting on http://{host}:{port}")

        try:
            await asyncio.Event().wait()
        finally:
            self._running = False
            await runner.cleanup()

    async def _cleanup_loop(self):
        while self._running:
            await asyncio.sleep(10)
            try:
                await self._cleanup_stale_robots()
            except Exception as e:
                logger.error(f"Cleanup error: {e}")

    async def _cleanup_stale_robots(self):
        now = time.time()
        timeout = 60
        for robot in self.store.list_robots():
            if robot.status == RobotStatus.ONLINE and (now - robot.last_seen) > timeout:
                robot.status = RobotStatus.OFFLINE
                self.store.update_robot(robot)
                alert = Alert(
                    alert_id=f"alert-{uuid.uuid4().hex[:8]}",
                    robot_id=robot.robot_id,
                    zone_id=robot.zone,
                    severity="warning",
                    title="Robot went offline",
                    message=f"Robot {robot.name} has not reported in {timeout} seconds",
                    source="system",
                )
                self.store.add_alert(alert)

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({
            "status": "healthy",
            "timestamp": time.time(),
            "version": "0.5.0",
            "service": "pmcp-cloud",
        })

    async def handle_metrics(self, request: web.Request) -> web.Response:
        return web.json_response(self.store.get_fleet_stats())

    async def handle_list_robots(self, request: web.Request) -> web.Response:
        status = request.query.get("status")
        zone = request.query.get("zone")

        status_enum = RobotStatus(status) if status else None

        robots = self.store.list_robots(status_enum, zone)

        return web.json_response({
            "robots": [r.to_dict() for r in robots],
            "count": len(robots),
        })

    async def handle_register_robot(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        robot_id = data.get("robotId", f"robot-{uuid.uuid4().hex[:8]}")
        robot = Robot(
            robot_id=robot_id,
            name=data.get("name", robot_id),
            robot_type=data.get("robotType", "unknown"),
            serial_number=data.get("serialNumber", ""),
            firmware_version=data.get("firmwareVersion", ""),
            status=RobotStatus.PENDING,
            zone=data.get("zone", "default"),
            capabilities=data.get("capabilities", []),
            metadata=data.get("metadata", {}),
        )

        robot = self.store.register_robot(robot)

        event = AuditEvent(
            event_id=f"audit-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            action="robot.register",
            actor=request.headers.get("X-User", "anonymous"),
            target_type="robot",
            target_id=robot_id,
            details=robot.to_dict(),
            ip_address=request.remote,
        )
        self.store.add_audit_event(event)

        return web.json_response(robot.to_dict(), status=201)

    async def handle_get_robot(self, request: web.Request) -> web.Response:
        robot_id = request.match_info["id"]
        robot = self.store.get_robot(robot_id)

        if not robot:
            return web.json_response({"error": f"Robot not found: {robot_id}"}, status=404)

        return web.json_response(robot.to_dict())

    async def handle_update_robot(self, request: web.Request) -> web.Response:
        robot_id = request.match_info["id"]
        robot = self.store.get_robot(robot_id)

        if not robot:
            return web.json_response({"error": f"Robot not found: {robot_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        for key, value in data.items():
            if hasattr(robot, key):
                setattr(robot, key, value)

        robot = self.store.update_robot(robot)

        event = AuditEvent(
            event_id=f"audit-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            action="robot.update",
            actor=request.headers.get("X-User", "anonymous"),
            target_type="robot",
            target_id=robot_id,
            details=data,
            ip_address=request.remote,
        )
        self.store.add_audit_event(event)

        return web.json_response(robot.to_dict())

    async def handle_delete_robot(self, request: web.Request) -> web.Response:
        robot_id = request.match_info["id"]
        success = self.store.delete_robot(robot_id)

        if not success:
            return web.json_response({"error": f"Robot not found: {robot_id}"}, status=404)

        event = AuditEvent(
            event_id=f"audit-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            action="robot.delete",
            actor=request.headers.get("X-User", "anonymous"),
            target_type="robot",
            target_id=robot_id,
            details={},
            ip_address=request.remote,
        )
        self.store.add_audit_event(event)

        return web.json_response({"deleted": True})

    async def handle_robot_telemetry(self, request: web.Request) -> web.Response:
        robot_id = request.match_info["id"]
        robot = self.store.get_robot(robot_id)

        if not robot:
            return web.json_response({"error": f"Robot not found: {robot_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        if "position" in data:
            robot.position = data["position"]
        if "orientation" in data:
            robot.orientation = data["orientation"]
        if "velocity" in data:
            robot.velocity = data["velocity"]
        if "healthScore" in data:
            robot.health_score = data["healthScore"]

        robot.last_seen = time.time()
        if robot.status == RobotStatus.PENDING or robot.status == RobotStatus.OFFLINE:
            robot.status = RobotStatus.ONLINE

        self.store.update_robot(robot)

        if robot.health_score < 50:
            alert = Alert(
                alert_id=f"alert-{uuid.uuid4().hex[:8]}",
                robot_id=robot_id,
                zone_id=robot.zone,
                severity="warning",
                title="Low health score",
                message=f"Robot {robot.name} health score is {robot.health_score:.1f}",
                source="telemetry",
            )
            self.store.add_alert(alert)

        return web.json_response({"received": True})

    async def handle_robot_command(self, request: web.Request) -> web.Response:
        robot_id = request.match_info["id"]
        robot = self.store.get_robot(robot_id)

        if not robot:
            return web.json_response({"error": f"Robot not found: {robot_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        command = data.get("command")
        if not command:
            return web.json_response({"error": "Missing command"}, status=400)

        event = AuditEvent(
            event_id=f"audit-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            action="robot.command",
            actor=request.headers.get("X-User", "anonymous"),
            target_type="robot",
            target_id=robot_id,
            details={"command": command, "params": data.get("params", {})},
            ip_address=request.remote,
        )
        self.store.add_audit_event(event)

        return web.json_response({
            "commandId": f"cmd-{uuid.uuid4().hex[:8]}",
            "status": "queued",
            "command": command,
        })

    async def handle_list_zones(self, request: web.Request) -> web.Response:
        zones = self.store.list_zones()
        return web.json_response({
            "zones": [z.to_dict() for z in zones],
            "count": len(zones),
        })

    async def handle_create_zone(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        zone_id = data.get("zoneId", f"zone-{uuid.uuid4().hex[:8]}")
        zone = Zone(
            zone_id=zone_id,
            name=data.get("name", zone_id),
            description=data.get("description", ""),
            bounds=data.get("bounds", {}),
            metadata=data.get("metadata", {}),
        )

        zone = self.store.create_zone(zone)
        return web.json_response(zone.to_dict(), status=201)

    async def handle_get_zone(self, request: web.Request) -> web.Response:
        zone_id = request.match_info["id"]
        zone = self.store.get_zone(zone_id)

        if not zone:
            return web.json_response({"error": f"Zone not found: {zone_id}"}, status=404)

        robots = self.store.list_robots(zone=zone_id)
        zone.robots = [r.robot_id for r in robots]

        return web.json_response(zone.to_dict())

    async def handle_update_zone(self, request: web.Request) -> web.Response:
        return web.json_response({"updated": True})

    async def handle_delete_zone(self, request: web.Request) -> web.Response:
        return web.json_response({"deleted": True})

    async def handle_list_alerts(self, request: web.Response) -> web.Response:
        severity = request.query.get("severity")
        acknowledged = request.query.get("acknowledged")
        resolved = request.query.get("resolved")

        ack = None if acknowledged is None else (acknowledged.lower() == "true")
        res = None if resolved is None else (resolved.lower() == "true")

        alerts = self.store.list_alerts(None, severity, ack, res)

        return web.json_response({
            "alerts": [a.to_dict() for a in alerts],
            "count": len(alerts),
        })

    async def handle_create_alert(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        alert = Alert(
            alert_id=data.get("alertId", f"alert-{uuid.uuid4().hex[:8]}"),
            robot_id=data.get("robotId"),
            zone_id=data.get("zoneId"),
            severity=data.get("severity", "info"),
            title=data.get("title", ""),
            message=data.get("message", ""),
            source=data.get("source", "api"),
            metadata=data.get("metadata", {}),
        )

        alert = self.store.add_alert(alert)
        return web.json_response(alert.to_dict(), status=201)

    async def handle_acknowledge_alert(self, request: web.Request) -> web.Response:
        alert_id = request.match_info["id"]
        alert = self.store.get_alert(alert_id)

        if not alert:
            return web.json_response({"error": f"Alert not found: {alert_id}"}, status=404)

        alert.acknowledged = True
        alert.acknowledged_by = request.headers.get("X-User", "anonymous")
        alert.acknowledged_at = time.time()

        return web.json_response(alert.to_dict())

    async def handle_resolve_alert(self, request: web.Request) -> web.Response:
        alert_id = request.match_info["id"]
        alert = self.store.get_alert(alert_id)

        if not alert:
            return web.json_response({"error": f"Alert not found: {alert_id}"}, status=404)

        alert.resolved = True
        alert.resolved_at = time.time()

        return web.json_response(alert.to_dict())

    async def handle_list_audit(self, request: web.Request) -> web.Response:
        limit = int(request.query.get("limit", "100"))
        events = self.store.list_audit_events(limit=limit)

        return web.json_response({
            "events": [e.to_dict() for e in events],
            "count": len(events),
        })

    async def handle_query_audit(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        action = data.get("action")
        actor = data.get("actor")
        target_type = data.get("targetType")
        limit = data.get("limit", 100)

        events = self.store.list_audit_events(action, actor, target_type, limit)

        return web.json_response({
            "events": [e.to_dict() for e in events],
            "count": len(events),
        })

    async def handle_list_onboarding(self, request: web.Request) -> web.Response:
        sessions = []
        return web.json_response({
            "sessions": sessions,
            "count": len(sessions),
        })

    async def handle_start_onboarding(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "Invalid JSON"}, status=400)

        robot_id = data.get("robotId")
        if not robot_id:
            return web.json_response({"error": "Missing robotId"}, status=400)

        session_id = f"onboarding-{uuid.uuid4().hex[:8]}"
        session = OnboardingSession(
            session_id=session_id,
            robot_id=robot_id,
            state=OnboardingState.START,
            current_step=1,
            total_steps=5,
        )

        session = self.store.create_onboarding_session(session)

        event = AuditEvent(
            event_id=f"audit-{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            action="onboarding.start",
            actor=request.headers.get("X-User", "anonymous"),
            target_type="robot",
            target_id=robot_id,
            details={"sessionId": session_id},
            ip_address=request.remote,
        )
        self.store.add_audit_event(event)

        return web.json_response(session.to_dict(), status=201)

    async def handle_onboarding_next(self, request: web.Request) -> web.Response:
        session_id = request.match_info["id"]
        session = self.store.get_onboarding_session(session_id)

        if not session:
            return web.json_response({"error": f"Session not found: {session_id}"}, status=404)

        try:
            data = await request.json()
        except Exception:
            data = {}

        session.step_data.update(data)
        session.current_step += 1

        if session.current_step >= session.total_steps:
            session.state = OnboardingState.COMPLETE
            session.completed_at = time.time()
        else:
            session.state = OnboardingState(
                ["start", "connect", "configure", "verify", "complete"][session.current_step - 1]
            )

        session = self.store.update_onboarding_session(session)
        return web.json_response(session.to_dict())

    async def handle_onboarding_complete(self, request: web.Request) -> web.Response:
        session_id = request.match_info["id"]
        session = self.store.get_onboarding_session(session_id)

        if not session:
            return web.json_response({"error": f"Session not found: {session_id}"}, status=404)

        session.state = OnboardingState.COMPLETE
        session.completed_at = time.time()
        session = self.store.update_onboarding_session(session)

        robot = self.store.get_robot(session.robot_id)
        if robot:
            robot.status = RobotStatus.REGISTERED
            robot.onboarded_at = time.time()
            self.store.update_robot(robot)

        return web.json_response(session.to_dict())

    async def handle_get_twin_state(self, request: web.Request) -> web.Response:
        robots = self.store.list_robots()
        zones = self.store.list_zones()

        return web.json_response({
            "robots": [r.to_dict() for r in robots],
            "zones": [z.to_dict() for z in zones],
            "timestamp": time.time(),
        })

    async def handle_twin_stream(self, request: web.Request) -> web.Response:
        return web.json_response({
            "streamUrl": "ws://localhost:8083/api/v1/twin/ws",
            "format": "json",
        })

    async def handle_fleet_stats(self, request: web.Request) -> web.Response:
        return web.json_response(self.store.get_fleet_stats())


async def main():
    parser = argparse.ArgumentParser(description="P-MCP Cloud Control Plane")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8083, help="Port to bind to")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Logging level")

    args = parser.parse_args()
    logging.getLogger().setLevel(getattr(logging, args.log_level))

    store = CloudStore()
    api = CloudAPI(store)
    await api.start(args.host, args.port)


if __name__ == "__main__":
    asyncio.run(main())