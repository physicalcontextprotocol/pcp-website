"""
P-MCP Cloud Control Plane Backend
===================================

A production-grade cloud backend for robot fleet management with:
- Robot onboarding wizard
- Live 3D twin visualization
- Alerting & monitoring
- Audit logging

This implements patterns from:
- Transitive Robotics transAct
- Roboticks.io
- TensorFleet
"""

from .server import CloudServer, CloudConfig
from .onboarding import OnboardingService, RobotOnboardingStep
from .alerts import AlertService, Alert, AlertSeverity, AlertRule
from .audit import AuditService, AuditEvent, AuditAction
from .twin import TwinService, TwinView, RobotPose
from .metrics import MetricsCollector, FleetMetrics

__all__ = [
    "CloudServer",
    "CloudConfig",
    "OnboardingService",
    "RobotOnboardingStep",
    "AlertService",
    "Alert",
    "AlertSeverity",
    "AlertRule",
    "AuditService",
    "AuditEvent",
    "AuditAction",
    "TwinService",
    "TwinView",
    "RobotPose",
    "MetricsCollector",
    "FleetMetrics",
]