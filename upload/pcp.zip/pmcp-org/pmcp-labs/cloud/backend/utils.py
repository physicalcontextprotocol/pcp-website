#!/usr/bin/env python3
"""
P-MCP Utilities
===============

Common utility functions for P-MCP.

Usage:
    python -m cloud.backend.utils
"""

import hashlib
import hmac
import json
import logging
import os
import random
import re
import secrets
import string
import time
import uuid
from base64 import b64decode, b64encode
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple, Union
from urllib.parse import parse_qs, quote, urlencode, urlparse, urlunparse

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s [%(name)s] %(message)s')
logger = logging.getLogger("pmcp-utils")


def generate_id(prefix: str = "") -> str:
    """Generate a unique ID."""
    return f"{prefix}{uuid.uuid4().hex[:16]}" if prefix else uuid.uuid4().hex[:16]


def generate_token(length: int = 32) -> str:
    """Generate a secure random token."""
    return secrets.token_urlsafe(length)


def hash_string(data: str, algorithm: str = "sha256") -> str:
    """Hash a string."""
    if algorithm == "sha256":
        return hashlib.sha256(data.encode()).hexdigest()
    elif algorithm == "sha512":
        return hashlib.sha512(data.encode()).hexdigest()
    elif algorithm == "md5":
        return hashlib.md5(data.encode()).hexdigest()
    raise ValueError(f"Unsupported algorithm: {algorithm}")


def hmac_sign(data: str, key: str, algorithm: str = "sha256") -> str:
    """Create HMAC signature."""
    if algorithm == "sha256":
        return hmac.new(key.encode(), data.encode(), hashlib.sha256).hexdigest()
    elif algorithm == "sha512":
        return hmac.new(key.encode(), data.encode(), hashlib.sha512).hexdigest()
    raise ValueError(f"Unsupported algorithm: {algorithm}")


def verify_hmac(data: str, signature: str, key: str, algorithm: str = "sha256") -> bool:
    """Verify HMAC signature."""
    expected = hmac_sign(data, key, algorithm)
    return hmac.compare_digest(signature, expected)


def encode_base64(data: Union[str, bytes]) -> str:
    """Encode to base64."""
    if isinstance(data, str):
        data = data.encode()
    return b64encode(data).decode()


def decode_base64(data: str) -> bytes:
    """Decode from base64."""
    return b64decode(data)


def sanitize_string(s: str, max_length: int = 1000) -> str:
    """Sanitize a string."""
    s = re.sub(r'[<>]', '', s)
    if len(s) > max_length:
        s = s[:max_length]
    return s.strip()


def validate_email(email: str) -> bool:
    """Validate email address."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_hostname(hostname: str) -> bool:
    """Validate hostname."""
    if len(hostname) > 255:
        return False
    pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$'
    return bool(re.match(pattern, hostname))


def validate_ip(ip: str) -> bool:
    """Validate IP address (IPv4 or IPv6)."""
    ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if re.match(ipv4_pattern, ip):
        parts = ip.split('.')
        return all(0 <= int(p) <= 255 for p in parts)
    return False


def parse_duration(duration_str: str) -> float:
    """Parse duration string to seconds."""
    units = {
        's': 1,
        'm': 60,
        'h': 3600,
        'd': 86400,
        'w': 604800,
    }

    match = re.match(r'^(\d+(?:\.\d+)?)([smhdw])$', duration_str)
    if not match:
        raise ValueError(f"Invalid duration: {duration_str}")

    value, unit = match.groups()
    return float(value) * units[unit]


def format_duration(seconds: float) -> str:
    """Format seconds to human readable duration."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    elif seconds < 3600:
        return f"{seconds / 60:.1f}m"
    elif seconds < 86400:
        return f"{seconds / 3600:.1f}h"
    else:
        return f"{seconds / 86400:.1f}d"


def format_bytes(bytes_count: int) -> str:
    """Format bytes to human readable size."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_count < 1024.0:
            return f"{bytes_count:.1f} {unit}"
        bytes_count /= 1024.0
    return f"{bytes_count:.1f} PB"


def truncate_string(s: str, max_length: int, suffix: str = "...") -> str:
    """Truncate string to max length."""
    if len(s) <= max_length:
        return s
    return s[:max_length - len(suffix)] + suffix


def slugify(text: str) -> str:
    """Convert text to slug format."""
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text.strip('-')


def parse_json_safe(json_str: str, default: Any = None) -> Any:
    """Parse JSON with error handling."""
    try:
        return json.loads(json_str)
    except (json.JSONDecodeError, TypeError):
        return default


def deep_merge(dict1: Dict, dict2: Dict) -> Dict:
    """Deep merge two dictionaries."""
    result = dict1.copy()
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def flatten_dict(d: Dict, parent_key: str = '', sep: str = '.') -> Dict:
    """Flatten nested dictionary."""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def chunk_list(lst: List, chunk_size: int) -> List[List]:
    """Split list into chunks."""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def deduplicate_list(lst: List) -> List:
    """Remove duplicates while preserving order."""
    seen = set()
    result = []
    for item in lst:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Safe division."""
    if denominator == 0:
        return default
    return numerator / denominator


def clamp(value: float, min_value: float, max_value: float) -> float:
    """Clamp value between min and max."""
    return max(min_value, min(value, max_value))


def interpolate(start: float, end: float, factor: float) -> float:
    """Linear interpolation."""
    return start + (end - start) * clamp(factor, 0, 1)


def moving_average(values: List[float], window: int) -> List[float]:
    """Calculate moving average."""
    if window <= 0 or len(values) < window:
        return values

    result = []
    for i in range(len(values) - window + 1):
        window_values = values[i:i + window]
        result.append(sum(window_values) / window)

    return result


def calculate_percentile(values: List[float], percentile: float) -> float:
    """Calculate percentile of values."""
    if not values:
        return 0.0

    sorted_values = sorted(values)
    index = int(len(sorted_values) * percentile / 100)
    index = min(index, len(sorted_values) - 1)
    return sorted_values[index]


class RateLimiter:
    """Rate limiter for API calls."""

    def __init__(self, max_calls: int, period: float):
        self.max_calls = max_calls
        self.period = period
        self._calls: List[float] = []

    def is_allowed(self) -> bool:
        """Check if call is allowed."""
        now = time.time()
        self._calls = [t for t in self._calls if now - t < self.period]

        if len(self._calls) < self.max_calls:
            self._calls.append(now)
            return True
        return False

    def wait_time(self) -> float:
        """Get time to wait before next call."""
        if not self._calls:
            return 0.0
        now = time.time()
        oldest = min(self._calls)
        return max(0.0, self.period - (now - oldest))


class Cache:
    """Simple in-memory cache."""

    def __init__(self, ttl: float = 300):
        self.ttl = ttl
        self._cache: Dict[str, Tuple[Any, float]] = {}

    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if key in self._cache:
            value, expires = self._cache[key]
            if time.time() < expires:
                return value
            del self._cache[key]
        return None

    def set(self, key: str, value: Any):
        """Set value in cache."""
        self._cache[key] = (value, time.time() + self.ttl)

    def delete(self, key: str):
        """Delete value from cache."""
        if key in self._cache:
            del self._cache[key]

    def clear(self):
        """Clear all cache."""
        self._cache.clear()


class RetryHandler:
    """Handle retry logic."""

    def __init__(self, max_retries: int = 3, backoff_factor: float = 2.0):
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

    async def execute(self, func, *args, **kwargs):
        """Execute function with retries."""
        last_error = None

        for attempt in range(self.max_retries):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < self.max_retries - 1:
                    wait_time = self.backoff_factor ** attempt
                    logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {wait_time}s...")
                    await asyncio.sleep(wait_time)

        raise last_error


def main():
    """Run utility tests."""
    logger.info("Testing utilities...")

    assert generate_id("test-").startswith("test-")
    assert len(generate_token()) >= 32

    assert hash_string("test") == hash_string("test")
    assert hash_string("test") != hash_string("test2")

    assert validate_email("test@example.com")
    assert not validate_email("invalid")

    assert parse_duration("30s") == 30
    assert parse_duration("5m") == 300

    assert format_bytes(1024) == "1.0 KB"
    assert format_bytes(1048576) == "1.0 MB"

    logger.info("All tests passed!")


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())