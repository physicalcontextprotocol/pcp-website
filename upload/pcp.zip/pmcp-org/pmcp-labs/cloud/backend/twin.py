"""P-MCP Digital Twin Service - 3D visualization and state management."""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import time
import math


@dataclass
class RobotPose:
    """Robot pose in 3D space."""
    robot_id: str
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    qx: float = 0.0
    qy: float = 0.0
    qz: float = 0.0
    qw: float = 1.0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "robotId": self.robot_id,
            "position": {"x": self.x, "y": self.y, "z": self.z},
            "orientation": {"qx": self.qx, "qy": self.qy, "qz": self.qz, "qw": self.qw},
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RobotPose':
        pos = data.get("position", {})
        orient = data.get("orientation", {})
        return cls(
            robot_id=data["robotId"],
            x=pos.get("x", 0),
            y=pos.get("y", 0),
            z=pos.get("z", 0),
            qx=orient.get("qx", 0),
            qy=orient.get("qy", 0),
            qz=orient.get("qz", 0),
            qw=orient.get("qw", 1),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class TwinView:
    """A 3D twin view configuration."""
    view_id: str
    name: str
    camera_position: Dict[str, float] = field(default_factory=lambda: {"x": 0, "y": 0, "z": 10})
    camera_target: Dict[str, float] = field(default_factory=lambda: {"x": 0, "y": 0, "z": 0})
    zoom: float = 1.0
    show_grid: bool = True
    show_labels: bool = True


@dataclass
class TwinService:
    """Service for digital twin management."""

    _poses: Dict[str, RobotPose] = field(default_factory=dict)
    _views: Dict[str, TwinView] = field(default_factory=dict)
    _history_size: int = 1000
    _history: Dict[str, List[RobotPose]] = field(default_factory=dict)

    def update_pose(self, pose: RobotPose):
        """Update robot pose."""
        self._poses[pose.robot_id] = pose
        if pose.robot_id not in self._history:
            self._history[pose.robot_id] = []
        self._history[pose.robot_id].append(pose)
        if len(self._history[pose.robot_id]) > self._history_size:
            self._history[pose.robot_id] = self._history[pose.robot_id][-self._history_size:]

    def get_pose(self, robot_id: str) -> Optional[RobotPose]:
        """Get current pose of a robot."""
        return self._poses.get(robot_id)

    def get_all_poses(self) -> List[RobotPose]:
        """Get all current poses."""
        return list(self._poses.values())

    def get_history(self, robot_id: str, limit: int = 100) -> List[RobotPose]:
        """Get pose history for a robot."""
        return self._history.get(robot_id, [])[-limit:]

    def add_view(self, view: TwinView):
        """Add a twin view configuration."""
        self._views[view.view_id] = view

    def get_view(self, view_id: str) -> Optional[TwinView]:
        """Get a twin view configuration."""
        return self._views.get(view_id)

    def list_views(self) -> List[TwinView]:
        """List all twin views."""
        return list(self._views.values())

    def compute_distance(self, robot_id1: str, robot_id2: str) -> Optional[float]:
        """Compute distance between two robots."""
        pose1 = self._poses.get(robot_id1)
        pose2 = self._poses.get(robot_id2)
        if not pose1 or not pose2:
            return None
        dx = pose1.x - pose2.x
        dy = pose1.y - pose2.y
        dz = pose1.z - pose2.z
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def detect_collisions(self, threshold: float = 0.5) -> List[Dict[str, Any]]:
        """Detect potential collisions between robots."""
        collisions = []
        robots = list(self._poses.keys())
        for i, r1 in enumerate(robots):
            for r2 in robots[i + 1:]:
                dist = self.compute_distance(r1, r2)
                if dist is not None and dist < threshold:
                    collisions.append({
                        "robot1": r1,
                        "robot2": r2,
                        "distance": dist,
                        "threshold": threshold,
                    })
        return collisions