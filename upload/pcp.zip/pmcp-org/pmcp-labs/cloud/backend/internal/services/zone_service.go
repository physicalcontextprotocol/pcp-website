package services

import (
	"context"
	"sync"
	"time"

	"pmcp-cloud/internal/config"
	"pmcp-cloud/internal/models"

	"gopkg.in/mgo.v2/bson"
)

type ZoneService struct {
	cfg   *config.Config
	mu    sync.RWMutex
	zones map[string]*models.Zone
}

func NewZoneService(cfg *config.Config) *ZoneService {
	svc := &ZoneService{
		cfg:   cfg,
		zones: make(map[string]*models.Zone),
	}
	svc.initializeDefaultZones()
	return svc
}

func (s *ZoneService) initializeDefaultZones() {
	defaultZones := []models.Zone{
		{
			ZoneID:      "zone-default",
			Name:       "Default Zone",
			Description: "Default fleet zone",
			Bounds: models.ZoneBounds{
				MinX: 0, MaxX: 100,
				MinY: 0, MaxY: 100,
				MinZ: 0, MaxZ: 10,
			},
			Robots:    []string{"robot-001"},
			CreatedAt: time.Now().Add(-168 * time.Hour),
		},
		{
			ZoneID:      "zone-warehouse-a",
			Name:       "Warehouse A",
			Description: "Primary warehouse area",
			Bounds: models.ZoneBounds{
				MinX: 0, MaxX: 50,
				MinY: 0, MaxY: 50,
				MinZ: 0, MaxZ: 15,
			},
			Robots:    []string{"robot-002"},
			CreatedAt: time.Now().Add(-168 * time.Hour),
		},
		{
			ZoneID:      "zone-warehouse-b",
			Name:       "Warehouse B",
			Description: "Secondary warehouse area",
			Bounds: models.ZoneBounds{
				MinX: 50, MaxX: 100,
				MinY: 0, MaxY: 50,
				MinZ: 0, MaxZ: 15,
			},
			Robots:    []string{"robot-003"},
			CreatedAt: time.Now().Add(-168 * time.Hour),
		},
		{
			ZoneID:      "zone-loading",
			Name:       "Loading Dock",
			Description: "Loading and unloading area",
			Bounds: models.ZoneBounds{
				MinX: 0, MaxX: 30,
				MinY: 50, MaxY: 80,
				MinZ: 0, MaxZ: 10,
			},
			Robots:    []string{},
			CreatedAt: time.Now().Add(-72 * time.Hour),
		},
	}
	for i := range defaultZones {
		s.zones[defaultZones[i].ZoneID] = &defaultZones[i]
	}
}

func (s *ZoneService) Create(ctx context.Context, zone *models.Zone) (*models.Zone, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if zone.ZoneID == "" {
		zone.ZoneID = fmt.Sprintf("zone-%s", bson.NewObjectId().Hex()[:8])
	}
	if zone.CreatedAt.IsZero() {
		zone.CreatedAt = time.Now()
	}
	if zone.Metadata == nil {
		zone.Metadata = make(map[string]string)
	}
	if zone.Bounds.MaxX == 0 {
		zone.Bounds = models.ZoneBounds{
			MinX: 0, MaxX: 100,
			MinY: 0, MaxY: 100,
			MinZ: 0, MaxZ: 10,
		}
	}

	s.zones[zone.ZoneID] = zone
	return zone, nil
}

func (s *ZoneService) Get(ctx context.Context, zoneID string) (*models.Zone, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	zone, ok := s.zones[zoneID]
	if !ok {
		return nil, fmt.Errorf("zone not found: %s", zoneID)
	}
	return zone, nil
}

func (s *ZoneService) Update(ctx context.Context, zone *models.Zone) (*models.Zone, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.zones[zone.ZoneID]; !ok {
		return nil, fmt.Errorf("zone not found: %s", zone.ZoneID)
	}

	s.zones[zone.ZoneID] = zone
	return zone, nil
}

func (s *ZoneService) Delete(ctx context.Context, zoneID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if zoneID == "zone-default" {
		return fmt.Errorf("cannot delete default zone")
	}

	if _, ok := s.zones[zoneID]; !ok {
		return fmt.Errorf("zone not found: %s", zoneID)
	}

	delete(s.zones, zoneID)
	return nil
}

func (s *ZoneService) List(ctx context.Context) ([]*models.Zone, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	result := make([]*models.Zone, 0, len(s.zones))
	for _, zone := range s.zones {
		result = append(result, zone)
	}
	return result, nil
}

func (s *ZoneService) AddRobot(ctx context.Context, zoneID, robotID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	zone, ok := s.zones[zoneID]
	if !ok {
		return fmt.Errorf("zone not found: %s", zoneID)
	}

	for _, r := range zone.Robots {
		if r == robotID {
			return nil
		}
	}

	zone.Robots = append(zone.Robots, robotID)
	s.zones[zoneID] = zone
	return nil
}

func (s *ZoneService) RemoveRobot(ctx context.Context, zoneID, robotID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	zone, ok := s.zones[zoneID]
	if !ok {
		return fmt.Errorf("zone not found: %s", zoneID)
	}

	newRobots := []string{}
	found := false
	for _, r := range zone.Robots {
		if r != robotID {
			newRobots = append(newRobots, r)
		} else {
			found = true
		}
	}

	if !found {
		return fmt.Errorf("robot not in zone: %s", robotID)
	}

	zone.Robots = newRobots
	s.zones[zoneID] = zone
	return nil
}

func (s *ZoneService) GetRobotsInZone(ctx context.Context, zoneID string) ([]string, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	zone, ok := s.zones[zoneID]
	if !ok {
		return nil, fmt.Errorf("zone not found: %s", zoneID)
	}

	return zone.Robots, nil
}

func (s *ZoneService) ContainsPoint(ctx context.Context, zoneID string, x, y, z float64) (bool, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	zone, ok := s.zones[zoneID]
	if !ok {
		return false, fmt.Errorf("zone not found: %s", zoneID)
	}

	return x >= zone.Bounds.MinX && x <= zone.Bounds.MaxX &&
		y >= zone.Bounds.MinY && y <= zone.Bounds.MaxY &&
		z >= zone.Bounds.MinZ && z <= zone.Bounds.MaxZ, nil
}