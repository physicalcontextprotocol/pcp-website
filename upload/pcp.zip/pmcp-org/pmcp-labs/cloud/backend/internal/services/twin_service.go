package services

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"sync"
	"time"

	"pmcp-cloud/internal/config"
	"pmcp-cloud/internal/models"
	"pmcp-cloud/internal/websocket"

	"gopkg.in/mgo.v2/bson"
)

type TwinService struct {
	cfg       *config.Config
	mu        sync.RWMutex
	positions map[string]TwinPosition
	history   map[string][]TwinPosition
	views     map[string]*TwinView
	hub       *websocket.Hub
}

type TwinPosition struct {
	RobotID     string    `json:"robotId"`
	X           float64   `json:"x"`
	Y           float64   `json:"y"`
	Z           float64   `json:"z"`
	Qx          float64   `json:"qx"`
	Qy          float64   `json:"qy"`
	Qz          float64   `json:"qz"`
	Qw          float64   `json:"qw"`
	Timestamp   time.Time `json:"timestamp"`
	VelocityX   float64   `json:"velocityX"`
	VelocityY   float64   `json:"velocityY"`
	VelocityZ   float64   `json:"velocityZ"`
}

type TwinView struct {
	ViewID          string             `json:"viewId"`
	Name            string             `json:"name"`
	CameraPosition TwinCameraPosition `json:"cameraPosition"`
	CameraTarget   TwinCameraPosition `json:"cameraTarget"`
	Zoom            float64            `json:"zoom"`
	ShowGrid        bool               `json:"showGrid"`
	ShowLabels      bool               `json:"showLabels"`
	FloorPlanURL    string             `json:"floorPlanUrl"`
	Obstacles       []TwinObstacle     `json:"obstacles"`
}

type TwinCameraPosition struct {
	X float64 `json:"x"`
	Y float64 `json:"y"`
	Z float64 `json:"z"`
}

type TwinObstacle struct {
	ID        string      `json:"id"`
	Type      string      `json:"type"`
	Position  TwinPosition `json:"position"`
	Bounds    ObstacleBounds `json:"bounds"`
	Color     string      `json:"color"`
	Label     string      `json:"label"`
}

type ObstacleBounds struct {
	Width  float64 `json:"width"`
	Height float64 `json:"height"`
	Depth  float64 `json:"depth"`
}

func NewTwinService(cfg *config.Config) *TwinService {
	svc := &TwinService{
		cfg:       cfg,
		positions: make(map[string]TwinPosition),
		history:   make(map[string][]TwinPosition),
		views:     make(map[string]*TwinView),
	}
	svc.initializeDefaultViews()
	return svc
}

func (s *TwinService) initializeDefaultViews() {
	s.views = map[string]*TwinView{
		"overview": {
			ViewID:   "overview",
			Name:     "Fleet Overview",
			ShowGrid: true,
			ShowLabels: true,
			CameraPosition: TwinCameraPosition{X: 0, Y: 0, Z: 50},
			CameraTarget: TwinCameraPosition{X: 0, Y: 0, Z: 0},
			Zoom: 1.0,
			Obstacles: []TwinObstacle{
				{
					ID:    "wall-north",
					Type:  "wall",
					Label: "North Wall",
					Position: TwinPosition{RobotID: "", X: 0, Y: 50, Z: 0},
					Bounds: ObstacleBounds{Width: 100, Height: 2, Depth: 1},
					Color: "#666666",
				},
				{
					ID:    "wall-south",
					Type:  "wall",
					Label: "South Wall",
					Position: TwinPosition{RobotID: "", X: 0, Y: -50, Z: 0},
					Bounds: ObstacleBounds{Width: 100, Height: 2, Depth: 1},
					Color: "#666666",
				},
			},
		},
		"warehouse-a": {
			ViewID:   "warehouse-a",
			Name:     "Warehouse A",
			ShowGrid: true,
			ShowLabels: true,
			CameraPosition: TwinCameraPosition{X: 25, Y: 25, Z: 30},
			CameraTarget: TwinCameraPosition{X: 25, Y: 25, Z: 0},
			Zoom: 1.5,
		},
		"loading-dock": {
			ViewID:   "loading-dock",
			Name:     "Loading Dock",
			ShowGrid: true,
			ShowLabels: true,
			CameraPosition: TwinCameraPosition{X: 15, Y: 65, Z: 20},
			CameraTarget: TwinCameraPosition{X: 15, Y: 65, Z: 0},
			Zoom: 2.0,
		},
	}
}

func (s *TwinService) UpdatePosition(ctx context.Context, robotID string, pos TwinPosition) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	pos.RobotID = robotID
	pos.Timestamp = time.Now()

	prevPos, exists := s.positions[robotID]
	if exists {
		dt := pos.Timestamp.Sub(prevPos.Timestamp).Seconds()
		if dt > 0 {
			pos.VelocityX = (pos.X - prevPos.X) / dt
			pos.VelocityY = (pos.Y - prevPos.Y) / dt
			pos.VelocityZ = (pos.Z - prevPos.Z) / dt
		}
	}

	s.positions[robotID] = pos

	historyLen := 1000
	if s.cfg.Twin.HistoryLength > 0 {
		historyLen = s.cfg.Twin.HistoryLength
	}

	s.history[robotID] = append(s.history[robotID], pos)
	if len(s.history[robotID]) > historyLen {
		s.history[robotID] = s.history[robotID][-historyLen:]
	}

	if s.hub != nil {
		s.hub.Broadcast(websocket.Message{
			Type: "position_update",
			Data: pos,
		})
	}

	return nil
}

func (s *TwinService) GetPosition(ctx context.Context, robotID string) (*TwinPosition, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	pos, ok := s.positions[robotID]
	if !ok {
		return nil, fmt.Errorf("robot position not found: %s", robotID)
	}

	return &pos, nil
}

func (s *TwinService) GetAllPositions(ctx context.Context) ([]TwinPosition, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	positions := make([]TwinPosition, 0, len(s.positions))
	for _, pos := range s.positions {
		positions = append(positions, pos)
	}

	return positions, nil
}

func (s *TwinService) GetHistory(ctx context.Context, robotID string, limit int) ([]TwinPosition, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	history, ok := s.history[robotID]
	if !ok {
		return nil, fmt.Errorf("robot history not found: %s", robotID)
	}

	if limit > 0 && limit < len(history) {
		return history[-limit:], nil
	}

	return history, nil
}

func (s *TwinService) ComputeDistance(ctx context.Context, robotID1, robotID2 string) (float64, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	pos1, ok1 := s.positions[robotID1]
	pos2, ok2 := s.positions[robotID2]

	if !ok1 {
		return 0, fmt.Errorf("robot position not found: %s", robotID1)
	}
	if !ok2 {
		return 0, fmt.Errorf("robot position not found: %s", robotID2)
	}

	dx := pos1.X - pos2.X
	dy := pos1.Y - pos2.Y
	dz := pos1.Z - pos2.Z

	return math.Sqrt(dx*dx + dy*dy + dz*dz), nil
}

func (s *TwinService) DetectCollisions(ctx context.Context, threshold float64) ([]CollisionEvent, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	var collisions []CollisionEvent

	robotIDs := make([]string, 0, len(s.positions))
	for id := range s.positions {
		robotIDs = append(robotIDs, id)
	}

	for i := 0; i < len(robotIDs); i++ {
		for j := i + 1; j < len(robotIDs); j++ {
			pos1 := s.positions[robotIDs[i]]
			pos2 := s.positions[robotIDs[j]]

			dx := pos1.X - pos2.X
			dy := pos1.Y - pos2.Y
			dz := pos1.Z - pos2.Z
			dist := math.Sqrt(dx*dx + dy*dy + dz*dz)

			if dist < threshold {
				collisions = append(collisions, CollisionEvent{
					EventID:     fmt.Sprintf("collision-%s-%s", robotIDs[i], robotIDs[j]),
					RobotID1:    robotIDs[i],
					RobotID2:    robotIDs[j],
					Distance:    dist,
					Threshold:  threshold,
					Timestamp:  time.Now(),
					Severity:   "warning",
				})
			}
		}
	}

	return collisions, nil
}

func (s *TwinService) DetectProximity(ctx context.Context, robotID string, radius float64) ([]ProximityEvent, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	pos1, ok := s.positions[robotID]
	if !ok {
		return nil, fmt.Errorf("robot position not found: %s", robotID)
	}

	var events []ProximityEvent

	for id, pos2 := range s.positions {
		if id == robotID {
			continue
		}

		dx := pos1.X - pos2.X
		dy := pos1.Y - pos2.Y
		dz := pos1.Z - pos2.Z
		dist := math.Sqrt(dx*dx + dy*dy + dz*dz)

		if dist < radius {
			events = append(events, ProximityEvent{
				EventID:     fmt.Sprintf("proximity-%s-%s", robotID, id),
				RobotID:      robotID,
				NearbyRobot: id,
				Distance:    dist,
				Radius:      radius,
				Timestamp:   time.Now(),
			})
		}
	}

	return events, nil
}

func (s *TwinService) CreateView(ctx context.Context, view *TwinView) (*TwinView, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if view.ViewID == "" {
		view.ViewID = fmt.Sprintf("view-%s", bson.NewObjectId().Hex()[:8])
	}

	s.views[view.ViewID] = view
	return view, nil
}

func (s *TwinService) GetView(ctx context.Context, viewID string) (*TwinView, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	view, ok := s.views[viewID]
	if !ok {
		return nil, fmt.Errorf("view not found: %s", viewID)
	}

	return view, nil
}

func (s *TwinService) ListViews(ctx context.Context) ([]*TwinView, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	views := make([]*TwinView, 0, len(s.views))
	for _, view := range s.views {
		v := view
		views = append(views, v)
	}

	return views, nil
}

func (s *TwinService) UpdateView(ctx context.Context, view *TwinView) (*TwinView, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.views[view.ViewID]; !ok {
		return nil, fmt.Errorf("view not found: %s", view.ViewID)
	}

	s.views[view.ViewID] = view
	return view, nil
}

func (s *TwinService) DeleteView(ctx context.Context, viewID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if viewID == "overview" {
		return fmt.Errorf("cannot delete default view")
	}

	delete(s.views, viewID)
	return nil
}

func (s *TwinService) GetState(ctx context.Context) (models.TwinState, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	positions := make([]TwinPosition, 0, len(s.positions))
	for _, pos := range s.positions {
		positions = append(positions, pos)
	}

	views := make([]*TwinView, 0, len(s.views))
	for _, view := range s.views {
		v := view
		views = append(views, v)
	}

	return models.TwinState{
		Timestamp: time.Now(),
		Robots:    []models.Robot{},
		Zones:     []models.Zone{},
	}, nil
}

func (s *TwinService) SetHub(hub *websocket.Hub) {
	s.hub = hub
}

func (s *TwinService) GetHeatmap(ctx context.Context, zoneID string, timeRange time.Duration) (map[string]int, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	heatmap := make(map[string]int)
	cutoff := time.Now().Add(-timeRange)

	for robotID, history := range s.history {
		gridX := ""
		gridY := ""

		for _, pos := range history {
			if pos.Timestamp.Before(cutoff) {
				continue
			}

			gx := int(pos.X / 5)
			gy := int(pos.Y / 5)
			cell := fmt.Sprintf("%s_%d_%d", zoneID, gx, gy)
			heatmap[cell]++
		}

		_ = robotID
	}

	return heatmap, nil
}

func (s *TwinService) GetTrajectory(ctx context.Context, robotID string, timeRange time.Duration) ([]TwinPosition, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	history, ok := s.history[robotID]
	if !ok {
		return nil, fmt.Errorf("robot history not found: %s", robotID)
	}

	cutoff := time.Now().Add(-timeRange)
	var trajectory []TwinPosition

	for _, pos := range history {
		if pos.Timestamp.After(cutoff) {
			trajectory = append(trajectory, pos)
		}
	}

	return trajectory, nil
}

func (s *TwinService) SimulateTrajectory(ctx context.Context, robotID string, targetX, targetY, targetZ float64) ([]TwinPosition, error) {
	s.mu.RLock()
	pos, ok := s.positions[robotID]
	s.mu.RUnlock()

	if !ok {
		return nil, fmt.Errorf("robot position not found: %s", robotID)
	}

	var trajectory []TwinPosition
	steps := 20

	for i := 0; i <= steps; i++ {
		t := float64(i) / float64(steps)
		simPos := TwinPosition{
			RobotID:   robotID,
			X:         pos.X + (targetX - pos.X)*t,
			Y:         pos.Y + (targetY - pos.Y)*t,
			Z:         pos.Z + (targetZ - pos.Z)*t,
			Qx:        pos.Qx,
			Qy:        pos.Qy,
			Qz:        pos.Qz,
			Qw:        pos.Qw,
			Timestamp: time.Now(),
		}
		trajectory = append(trajectory, simPos)
	}

	return trajectory, nil
}

type CollisionEvent struct {
	EventID    string    `json:"eventId"`
	RobotID1   string    `json:"robotId1"`
	RobotID2   string    `json:"robotId2"`
	Distance   float64   `json:"distance"`
	Threshold  float64   `json:"threshold"`
	Timestamp  time.Time `json:"timestamp"`
	Severity   string    `json:"severity"`
}

type ProximityEvent struct {
	EventID      string    `json:"eventId"`
	RobotID      string    `json:"robotId"`
	NearbyRobot string    `json:"nearbyRobot"`
	Distance     float64   `json:"distance"`
	Radius       float64   `json:"radius"`
	Timestamp    time.Time `json:"timestamp"`
}

func (s *TwinService) ExportTrajectory(ctx context.Context, robotID string, format string) ([]byte, error) {
	s.mu.RLock()
	history, ok := s.history[robotID]
	s.mu.RUnlock()

	if !ok {
		return nil, fmt.Errorf("robot history not found: %s", robotID)
	}

	switch format {
	case "json":
		return json.MarshalIndent(history, "", "  ")
	case "csv":
		var csv string
		csv = "timestamp,x,y,z,qx,qy,qz,qw\n"
		for _, pos := range history {
			csv += fmt.Sprintf("%s,%.2f,%.2f,%.2f,%.4f,%.4f,%.4f,%.4f\n",
				pos.Timestamp.Format(time.RFC3339),
				pos.X, pos.Y, pos.Z,
				pos.Qx, pos.Qy, pos.Qz, pos.Qw)
		}
		return []byte(csv), nil
	default:
		return nil, fmt.Errorf("unsupported format: %s", format)
	}
}

func (s *TwinService) GetAnalytics(ctx context.Context, robotID string) (map[string]interface{}, error) {
	s.mu.RLock()
	history, ok := s.history[robotID]
	s.mu.RUnlock()

	if !ok {
		return nil, fmt.Errorf("robot history not found: %s", robotID)
	}

	if len(history) < 2 {
		return map[string]interface{}{
			"totalDistance": 0,
			"avgSpeed":      0,
			"maxSpeed":      0,
			"totalTime":     0,
		}, nil
	}

	var totalDistance float64
	var maxSpeed float64
	var totalSpeed float64

	for i := 1; i < len(history); i++ {
		dx := history[i].X - history[i-1].X
		dy := history[i].Y - history[i-1].Y
		dz := history[i].Z - history[i-1].Z
		dist := math.Sqrt(dx*dx + dy*dy + dz*dz)
		totalDistance += dist

		dt := history[i].Timestamp.Sub(history[i-1].Timestamp).Seconds()
		if dt > 0 {
			speed := dist / dt
			if speed > maxSpeed {
				maxSpeed = speed
			}
			totalSpeed += speed
		}
	}

	totalTime := history[len(history)-1].Timestamp.Sub(history[0]).Timestamp
	avgSpeed := totalSpeed / float64(len(history)-1)

	return map[string]interface{}{
		"totalDistance": totalDistance,
		"avgSpeed":      avgSpeed,
		"maxSpeed":      maxSpeed,
		"totalTime":     totalTime.Seconds(),
		"sampleCount":   len(history),
	}, nil
}