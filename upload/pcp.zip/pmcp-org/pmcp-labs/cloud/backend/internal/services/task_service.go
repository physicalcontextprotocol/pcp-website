package services

import (
	"context"
	"fmt"
	"sync"
	"time"

	"pmcp-cloud/internal/config"
	"pmcp-cloud/internal/models"
)

type TaskService struct {
	cfg     *config.Config
	mu      sync.RWMutex
	tasks   map[string]*models.Task
	queue   []string
	history map[string][]*models.TaskHistory
}

type TaskType string
type TaskStatus string

const (
	TaskTypeNavigation    TaskType = "navigation"
	TaskTypeInspection   TaskType = "inspection"
	TaskTypeManipulation TaskType = "manipulation"
	TaskTypeTransport    TaskType = "transport"
	TaskTypeMaintenance  TaskType = "maintenance"
	TaskTypeMonitoring   TaskType = "monitoring"

	TaskStatusPending   TaskStatus = "pending"
	TaskStatusQueued    TaskStatus = "queued"
	TaskStatusRunning   TaskStatus = "running"
	TaskStatusPaused    TaskStatus = "paused"
	TaskStatusCompleted TaskStatus = "completed"
	TaskStatusFailed    TaskStatus = "failed"
	TaskStatusCancelled TaskStatus = "cancelled"
)

func NewTaskService(cfg *config.Config) *TaskService {
	svc := &TaskService{
		cfg:     cfg,
		tasks:   make(map[string]*models.Task),
		queue:   []string{},
		history: make(map[string][]*models.TaskHistory),
	}
	return svc
}

func (s *TaskService) Create(ctx context.Context, task *models.Task) (*models.Task, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if task.TaskID == "" {
		task.TaskID = fmt.Sprintf("task-%d", time.Now().UnixNano())
	}
	if task.Status == "" {
		task.Status = models.TaskStatusPending
	}
	if task.CreatedAt.IsZero() {
		task.CreatedAt = time.Now()
	}
	if task.Progress == 0 {
		task.Progress = 0
	}
	if task.Checkpoints == nil {
		task.Checkpoints = []*models.TaskCheckpoint{}
	}

	s.tasks[task.TaskID] = task
	s.queue = append(s.queue, task.TaskID)

	s.addHistory(task.TaskID, models.TaskHistoryActionCreated, "Task created")

	return task, nil
}

func (s *TaskService) Get(ctx context.Context, taskID string) (*models.Task, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return nil, fmt.Errorf("task not found: %s", taskID)
	}
	return task, nil
}

func (s *TaskService) Update(ctx context.Context, task *models.Task) (*models.Task, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.tasks[task.TaskID]; !ok {
		return nil, fmt.Errorf("task not found: %s", task.TaskID)
	}

	oldTask := s.tasks[task.TaskID]
	if oldTask.Status != task.Status {
		s.addHistory(task.TaskID, models.TaskHistoryActionStatusChanged, 
			fmt.Sprintf("Status changed from %s to %s", oldTask.Status, task.Status))
	}

	s.tasks[task.TaskID] = task
	return task, nil
}

func (s *TaskService) Delete(ctx context.Context, taskID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.tasks[taskID]; !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	delete(s.tasks, taskID)

	for i, id := range s.queue {
		if id == taskID {
			s.queue = append(s.queue[:i], s.queue[i+1:]...)
			break
		}
	}

	return nil
}

func (s *TaskService) List(ctx context.Context, filter *models.TaskFilter) ([]*models.Task, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	var result []*models.Task
	for _, task := range s.tasks {
		if filter != nil {
			if filter.Status != "" && string(task.Status) != filter.Status {
				continue
			}
			if filter.RobotID != "" {
				found := false
				for _, rid := range task.AssignedRobots {
					if rid == filter.RobotID {
						found = true
						break
					}
				}
				if !found {
					continue
				}
			}
			if filter.Priority != "" && string(task.Priority) != filter.Priority {
				continue
			}
			if filter.TaskType != "" && string(task.Type) != filter.TaskType {
				continue
			}
		}
		result = append(result, task)
	}
	return result, nil
}

func (s *TaskService) Start(ctx context.Context, taskID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	if task.Status != models.TaskStatusPending && task.Status != models.TaskStatusPaused {
		return fmt.Errorf("task cannot be started in status: %s", task.Status)
	}

	now := time.Now()
	task.Status = models.TaskStatusRunning
	task.ActualStart = &now
	task.StartedAt = &now

	s.addHistory(taskID, models.TaskHistoryActionStarted, "Task started")

	return nil
}

func (s *TaskService) Pause(ctx context.Context, taskID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	if task.Status != models.TaskStatusRunning {
		return fmt.Errorf("task is not running")
	}

	task.Status = models.TaskStatusPaused
	s.addHistory(taskID, models.TaskHistoryActionPaused, "Task paused")

	return nil
}

func (s *TaskService) Resume(ctx context.Context, taskID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	if task.Status != models.TaskStatusPaused {
		return fmt.Errorf("task is not paused")
	}

	task.Status = models.TaskStatusRunning
	s.addHistory(taskID, models.TaskHistoryActionResumed, "Task resumed")

	return nil
}

func (s *TaskService) Complete(ctx context.Context, taskID string, result *models.TaskResult) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	if task.Status != models.TaskStatusRunning {
		return fmt.Errorf("task is not running")
	}

	now := time.Now()
	task.Status = models.TaskStatusCompleted
	task.ActualEnd = &now
	task.CompletedAt = &now
	task.Progress = 100
	task.Result = result

	s.addHistory(taskID, models.TaskHistoryActionCompleted, "Task completed")

	return nil
}

func (s *TaskService) Fail(ctx context.Context, taskID string, errMsg string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	now := time.Now()
	task.Status = models.TaskStatusFailed
	task.ActualEnd = &now
	task.FailedAt = &now
	task.ErrorMessage = errMsg

	s.addHistory(taskID, models.TaskHistoryActionFailed, fmt.Sprintf("Task failed: %s", errMsg))

	return nil
}

func (s *TaskService) Cancel(ctx context.Context, taskID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	if task.Status == models.TaskStatusCompleted || task.Status == models.TaskStatusFailed {
		return fmt.Errorf("cannot cancel completed or failed task")
	}

	task.Status = models.TaskStatusCancelled
	task.CancelledAt = new(time.Time)
	*task.CancelledAt = time.Now()

	s.addHistory(taskID, models.TaskHistoryActionCancelled, "Task cancelled")

	return nil
}

func (s *TaskService) UpdateProgress(ctx context.Context, taskID string, progress int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	if progress < 0 || progress > 100 {
		return fmt.Errorf("progress must be between 0 and 100")
	}

	task.Progress = progress
	return nil
}

func (s *TaskService) GetNextTask(ctx context.Context) (*models.Task, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	for i, taskID := range s.queue {
		task := s.tasks[taskID]
		if task.Status == models.TaskStatusPending {
			s.queue = append(s.queue[:i], s.queue[i+1:]...)
			return task, nil
		}
	}
	return nil, fmt.Errorf("no pending tasks in queue")
}

func (s *TaskService) GetHistory(ctx context.Context, taskID string) ([]*models.TaskHistory, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	history, ok := s.history[taskID]
	if !ok {
		return []*models.TaskHistory{}, nil
	}
	return history, nil
}

func (s *TaskService) addHistory(taskID string, action string, message string) {
	entry := &models.TaskHistory{
		HistoryID:  fmt.Sprintf("hist-%d", time.Now().UnixNano()),
		TaskID:     taskID,
		Action:     action,
		Message:    message,
		Timestamp:  time.Now(),
	}
	s.history[taskID] = append(s.history[taskID], entry)
}

func (s *TaskService) GetStats(ctx context.Context) (*models.TaskStats, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	stats := &models.TaskStats{
		Total:     len(s.tasks),
		Pending:   0,
		Queued:    0,
		Running:   0,
		Paused:    0,
		Completed: 0,
		Failed:    0,
		Cancelled: 0,
	}

	for _, task := range s.tasks {
		switch task.Status {
		case models.TaskStatusPending:
			stats.Pending++
		case models.TaskStatusQueued:
			stats.Queued++
		case models.TaskStatusRunning:
			stats.Running++
		case models.TaskStatusPaused:
			stats.Paused++
		case models.TaskStatusCompleted:
			stats.Completed++
		case models.TaskStatusFailed:
			stats.Failed++
		case models.TaskStatusCancelled:
			stats.Cancelled++
		}
	}

	return stats, nil
}

func (s *TaskService) AssignRobot(ctx context.Context, taskID, robotID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %s", taskID)
	}

	for _, rid := range task.AssignedRobots {
		if rid == robotID {
			return fmt.Errorf("robot already assigned")
		}
	}

	task.AssignedRobots = append(task.AssignedRobots, robotID)
	return nil
}

func (s *TaskService) UnassignRobot(ctx context.Context, taskID, robotID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, ok := s.tasks[taskID]
	if !ok {
		return fmt.Errorf("task not found: %taskID")
	}

	found := false
	newRobots := []string{}
	for _, rid := range task.AssignedRobots {
		if rid == robotID {
			found = true
		} else {
			newRobots = append(newRobots, rid)
		}
	}

	if !found {
		return fmt.Errorf("robot not assigned to task")
	}

	task.AssignedRobots = newRobots
	return nil
}