export interface Robot {
  robotId: string;
  name: string;
  robotType: string;
  status: RobotStatus;
  zone: string;
  healthScore: number;
  batteryLevel: number;
  position: Position3D;
  orientation: Orientation3D;
  velocity: Velocity3D;
  lastUpdate: number;
  capabilities: string[];
  firmware: FirmwareInfo;
  network: NetworkInfo;
  metadata: Record<string, string>;
}

export type RobotStatus = 'online' | 'offline' | 'error' | 'maintenance' | 'degraded' | 'emergency_stop';

export interface Position3D {
  x: number;
  y: number;
  z: number;
}

export interface Orientation3D {
  roll: number;
  pitch: number;
  yaw: number;
}

export interface Velocity3D {
  linear: number;
  angular: number;
}

export interface FirmwareInfo {
  version: string;
  commit: string;
  buildTime: string;
}

export interface NetworkInfo {
  ipAddress: string;
  macAddress: string;
  signalStrength: number;
  latency: number;
  connected: boolean;
}

export interface Alert {
  alertId: string;
  severity: AlertSeverity;
  category: AlertCategory;
  title: string;
  message: string;
  robotId?: string;
  createdAt: number;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: number;
  resolved: boolean;
  resolvedAt?: number;
  resolvedBy?: string;
  resolution?: string;
  actions: AlertAction[];
}

export type AlertSeverity = 'critical' | 'high' | 'medium' | 'low' | 'info';
export type AlertCategory = 'hardware' | 'software' | 'network' | 'safety' | 'battery' | 'performance' | 'security';

export interface AlertAction {
  actionId: string;
  type: 'command' | 'notification' | 'escalation' | 'auto_remediation';
  status: 'pending' | 'executed' | 'failed';
  executedAt?: number;
  result?: string;
}

export interface FleetStats {
  totalRobots: number;
  onlineRobots: number;
  offlineRobots: number;
  errorRobots: number;
  maintenanceRobots: number;
  degradedRobots: number;
  activeAlerts: number;
  criticalAlerts: number;
  averageHealth: number;
  totalBattery: number;
  fleetUptime: number;
}

export interface Zone {
  zoneId: string;
  name: string;
  description: string;
  boundaries: ZoneBoundary[];
  robots: string[];
  capacity: number;
  status: 'active' | 'inactive' | 'restricted';
  rules: ZoneRule[];
}

export interface ZoneBoundary {
  type: 'polygon' | 'circle' | 'rectangle';
  points: Position3D[];
  center?: Position3D;
  radius?: number;
}

export interface ZoneRule {
  ruleId: string;
  type: 'speed_limit' | 'access_control' | 'scheduled_maintenance' | 'environmental';
  parameters: Record<string, unknown>;
  enabled: boolean;
}

export interface Task {
  taskId: string;
  name: string;
  description: string;
  type: TaskType;
  status: TaskStatus;
  priority: 'critical' | 'high' | 'medium' | 'low';
  assignedRobots: string[];
  createdBy: string;
  createdAt: number;
  scheduledStart?: number;
  scheduledEnd?: number;
  actualStart?: number;
  actualEnd?: number;
  progress: number;
  checkpoints: TaskCheckpoint[];
  dependencies: string[];
  result?: TaskResult;
}

export type TaskType = 'navigation' | 'inspection' | 'manipulation' | 'transport' | 'maintenance' | 'monitoring';
export type TaskStatus = 'pending' | 'queued' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';

export interface TaskCheckpoint {
  checkpointId: string;
  name: string;
  status: 'pending' | 'reached' | 'skipped' | 'failed';
  reachedAt?: number;
  position?: Position3D;
}

export interface TaskResult {
  success: boolean;
  message: string;
  metrics?: Record<string, number>;
}

export interface MetricData {
  metricId: string;
  robotId: string;
  metricType: string;
  value: number;
  unit: string;
  timestamp: number;
  tags: Record<string, string>;
}

export interface TimeSeriesData {
  timestamps: number[];
  values: number[];
  labels?: string[];
}

export interface DashboardLayout {
  id: string;
  name: string;
  panels: DashboardPanel[];
  refreshInterval: number;
}

export interface DashboardPanel {
  id: string;
  type: 'chart' | 'table' | 'stat' | 'map' | 'alert_list';
  title: string;
  config: Record<string, unknown>;
  position: { x: number; y: number };
  size: { width: number; height: number };
}

export interface User {
  userId: string;
  username: string;
  email: string;
  role: UserRole;
  permissions: string[];
  lastLogin?: number;
  preferences: UserPreferences;
}

export type UserRole = 'admin' | 'operator' | 'viewer' | 'maintenance';

export interface UserPreferences {
  theme: 'light' | 'dark' | 'auto';
  dashboardLayout?: string;
  notifications: NotificationPreferences;
  timezone: string;
  language: string;
}

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  criticalOnly: boolean;
  digestFrequency: 'realtime' | 'hourly' | 'daily';
}

export interface WebSocketMessage {
  type: string;
  payload: unknown;
  timestamp: number;
}

export interface CommandRequest {
  commandId: string;
  robotId: string;
  command: string;
  parameters: Record<string, unknown>;
  timeout?: number;
  priority?: number;
}

export interface CommandResponse {
  commandId: string;
  status: 'queued' | 'sent' | 'executed' | 'failed';
  result?: unknown;
  error?: string;
  executedAt?: number;
}

export interface ApiResponse<T> {
  data?: T;
  error?: ApiError;
  meta?: ResponseMeta;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface ResponseMeta {
  total?: number;
  page?: number;
  pageSize?: number;
  hasMore?: boolean;
}