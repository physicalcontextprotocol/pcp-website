import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { Robot, Alert, FleetStats, Task, User, Zone } from '../types';
import { getWebSocketService } from '../services/websocket';
import { robotApi, alertApi, fleetApi, taskApi } from '../services/api';

interface AppState {
  robots: Robot[];
  alerts: Alert[];
  stats: FleetStats | null;
  tasks: Task[];
  zones: Zone[];
  user: User | null;
  isConnected: boolean;
  theme: 'light' | 'dark';
}

interface AppContextType extends AppState {
  refreshRobots: () => Promise<void>;
  refreshAlerts: () => Promise<void>;
  refreshStats: () => Promise<void>;
  refreshTasks: () => Promise<void>;
  refreshZones: () => Promise<void>;
  acknowledgeAlert: (alertId: string) => Promise<void>;
  resolveAlert: (alertId: string, resolution: string) => Promise<void>;
  sendRobotCommand: (robotId: string, command: string, params?: Record<string, unknown>) => Promise<void>;
  createTask: (task: Partial<Task>) => Promise<void>;
  cancelTask: (taskId: string) => Promise<void>;
  setTheme: (theme: 'light' | 'dark') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [robots, setRobots] = useState<Robot[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [stats, setStats] = useState<FleetStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const stored = localStorage.getItem('theme');
    return (stored as 'light' | 'dark') || 'dark';
  });

  const refreshRobots = useCallback(async () => {
    const response = await robotApi.list();
    if (response.data) setRobots(response.data.robots);
  }, []);

  const refreshAlerts = useCallback(async () => {
    const response = await alertApi.list({ resolved: false });
    if (response.data) setAlerts(response.data.alerts);
  }, []);

  const refreshStats = useCallback(async () => {
    const response = await fleetApi.getStats();
    if (response.data) setStats(response.data);
  }, []);

  const refreshTasks = useCallback(async () => {
    const response = await taskApi.list();
    if (response.data) setTasks(response.data.tasks);
  }, []);

  const refreshZones = useCallback(async () => {
    const response = await fleetApi.getZones();
    if (response.data) setZones(response.data.zones);
  }, []);

  const acknowledgeAlert = useCallback(async (alertId: string) => {
    await alertApi.acknowledge(alertId);
    refreshAlerts();
  }, [refreshAlerts]);

  const resolveAlert = useCallback(async (alertId: string, resolution: string) => {
    await alertApi.resolve(alertId, resolution);
    refreshAlerts();
  }, [refreshAlerts]);

  const sendRobotCommand = useCallback(async (
    robotId: string,
    command: string,
    params?: Record<string, unknown>
  ) => {
    await robotApi.sendCommand({
      commandId: `cmd_${Date.now()}`,
      robotId,
      command,
      parameters: params || {},
    });
  }, []);

  const createTask = useCallback(async (task: Partial<Task>) => {
    await taskApi.create(task);
    refreshTasks();
  }, [refreshTasks]);

  const cancelTask = useCallback(async (taskId: string) => {
    await taskApi.cancel(taskId);
    refreshTasks();
  }, [refreshTasks]);

  useEffect(() => {
    refreshRobots();
    refreshAlerts();
    refreshStats();
    refreshTasks();
    refreshZones();
  }, [refreshRobots, refreshAlerts, refreshStats, refreshTasks, refreshZones]);

  useEffect(() => {
    const ws = getWebSocketService();
    const unsubConnect = ws.onConnect(() => setIsConnected(true));
    const unsubDisconnect = ws.onDisconnect(() => setIsConnected(false));
    const unsubRobotUpdate = ws.subscribe('robot.update', (msg) => {
      if (msg.payload && typeof msg.payload === 'object') {
        const updatedRobot = msg.payload as Robot;
        setRobots(prev => prev.map(r =>
          r.robotId === updatedRobot.robotId ? updatedRobot : r
        ));
      }
    });
    const unsubAlert = ws.subscribe('alert.new', (msg) => {
      if (msg.payload && typeof msg.payload === 'object') {
        const newAlert = msg.payload as Alert;
        setAlerts(prev => [newAlert, ...prev]);
      }
    });

    ws.connect().catch(console.error);

    return () => {
      unsubConnect();
      unsubDisconnect();
      unsubRobotUpdate();
      unsubAlert();
    };
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const value: AppContextType = {
    robots,
    alerts,
    stats,
    tasks,
    zones,
    user,
    isConnected,
    theme,
    refreshRobots,
    refreshAlerts,
    refreshStats,
    refreshTasks,
    refreshZones,
    acknowledgeAlert,
    resolveAlert,
    sendRobotCommand,
    createTask,
    cancelTask,
    setTheme,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

export default AppContext;