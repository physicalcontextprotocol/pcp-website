import { useState, useEffect, useCallback } from 'react';
import { robotApi, alertApi, fleetApi, taskApi } from '../services/api';
import { Robot, Alert, FleetStats, Task, Zone } from '../types';

export function useRobots(params?: {
  status?: string;
  zone?: string;
  refreshInterval?: number;
}) {
  const [robots, setRobots] = useState<Robot[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchRobots = useCallback(async () => {
    try {
      setError(null);
      const response = await robotApi.list(params);
      if (response.data) {
        setRobots(response.data.robots);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch robots'));
    } finally {
      setLoading(false);
    }
  }, [params?.status, params?.zone]);

  useEffect(() => {
    fetchRobots();
    const interval = setInterval(
      fetchRobots,
      params?.refreshInterval || 5000
    );
    return () => clearInterval(interval);
  }, [fetchRobots, params?.refreshInterval]);

  return { robots, loading, error, refetch: fetchRobots };
}

export function useRobot(robotId: string) {
  const [robot, setRobot] = useState<Robot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchRobot = useCallback(async () => {
    try {
      setError(null);
      const response = await robotApi.get(robotId);
      if (response.data) {
        setRobot(response.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch robot'));
    } finally {
      setLoading(false);
    }
  }, [robotId]);

  useEffect(() => {
    fetchRobot();
    const interval = setInterval(fetchRobot, 2000);
    return () => clearInterval(interval);
  }, [fetchRobot]);

  return { robot, loading, error, refetch: fetchRobot };
}

export function useAlerts(params?: {
  severity?: string;
  resolved?: boolean;
  robotId?: string;
  refreshInterval?: number;
}) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchAlerts = useCallback(async () => {
    try {
      setError(null);
      const response = await alertApi.list(params);
      if (response.data) {
        setAlerts(response.data.alerts);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch alerts'));
    } finally {
      setLoading(false);
    }
  }, [params?.severity, params?.resolved, params?.robotId]);

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(
      fetchAlerts,
      params?.refreshInterval || 5000
    );
    return () => clearInterval(interval);
  }, [fetchAlerts, params?.refreshInterval]);

  const acknowledgeAlert = useCallback(async (alertId: string) => {
    await alertApi.acknowledge(alertId);
    fetchAlerts();
  }, [fetchAlerts]);

  const resolveAlert = useCallback(async (alertId: string, resolution: string) => {
    await alertApi.resolve(alertId, resolution);
    fetchAlerts();
  }, [fetchAlerts]);

  return { alerts, loading, error, refetch: fetchAlerts, acknowledgeAlert, resolveAlert };
}

export function useFleetStats(refreshInterval = 5000) {
  const [stats, setStats] = useState<FleetStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchStats = useCallback(async () => {
    try {
      setError(null);
      const response = await fleetApi.getStats();
      if (response.data) {
        setStats(response.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch fleet stats'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, refreshInterval);
    return () => clearInterval(interval);
  }, [fetchStats, refreshInterval]);

  return { stats, loading, error, refetch: fetchStats };
}

export function useZones() {
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchZones = useCallback(async () => {
    try {
      setError(null);
      const response = await fleetApi.getZones();
      if (response.data) {
        setZones(response.data.zones);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch zones'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchZones();
  }, [fetchZones]);

  return { zones, loading, error, refetch: fetchZones };
}

export function useTasks(params?: {
  status?: string;
  robotId?: string;
  refreshInterval?: number;
}) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchTasks = useCallback(async () => {
    try {
      setError(null);
      const response = await taskApi.list(params);
      if (response.data) {
        setTasks(response.data.tasks);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to fetch tasks'));
    } finally {
      setLoading(false);
    }
  }, [params?.status, params?.robotId]);

  useEffect(() => {
    fetchTasks();
    const interval = setInterval(
      fetchTasks,
      params?.refreshInterval || 5000
    );
    return () => clearInterval(interval);
  }, [fetchTasks, params?.refreshInterval]);

  const createTask = useCallback(async (task: Partial<Task>) => {
    const response = await taskApi.create(task);
    if (response.data) {
      fetchTasks();
    }
    return response;
  }, [fetchTasks]);

  const cancelTask = useCallback(async (taskId: string) => {
    await taskApi.cancel(taskId);
    fetchTasks();
  }, [fetchTasks]);

  return { tasks, loading, error, refetch: fetchTasks, createTask, cancelTask };
}

export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((prev: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback((value: T | ((prev: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  }, [key, storedValue]);

  return [storedValue, setValue];
}

export function useInterval(callback: () => void, delay: number | null) {
  useEffect(() => {
    if (delay === null) return;
    const id = setInterval(callback, delay);
    return () => clearInterval(id);
  }, [callback, delay]);
}

export function usePrevious<T>(value: T): T | undefined {
  const ref = useRef<T>();
  useEffect(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}

import { useRef } from 'react';

export default {
  useRobots,
  useRobot,
  useAlerts,
  useFleetStats,
  useZones,
  useTasks,
  useDebounce,
  useLocalStorage,
  useInterval,
  usePrevious,
};