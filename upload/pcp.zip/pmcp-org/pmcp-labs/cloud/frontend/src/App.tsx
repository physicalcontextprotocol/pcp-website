import React, { useState, useEffect } from 'react';

interface Robot {
  robotId: string;
  name: string;
  robotType: string;
  status: string;
  zone: string;
  healthScore: number;
  position: { x: number; y: number; z: number };
}

interface Alert {
  alertId: string;
  severity: string;
  title: string;
  message: string;
  createdAt: number;
  acknowledged: boolean;
  resolved: boolean;
}

interface FleetStats {
  totalRobots: number;
  onlineRobots: number;
  offlineRobots: number;
  errorRobots: number;
  activeAlerts: number;
}

const API_BASE = 'http://localhost:8083/api/v1';

function App() {
  const [robots, setRobots] = useState<Robot[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [stats, setStats] = useState<FleetStats | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'robots' | 'alerts' | 'twin'>('dashboard');
  const [selectedRobot, setSelectedRobot] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      const [robotsRes, alertsRes, statsRes] = await Promise.all([
        fetch(`${API_BASE}/robots`),
        fetch(`${API_BASE}/alerts?resolved=false`),
        fetch(`${API_BASE}/fleet/stats`),
      ]);
      const robotsData = await robotsRes.json();
      const alertsData = await alertsRes.json();
      const statsData = await statsRes.json();
      setRobots(robotsData.robots || []);
      setAlerts(alertsData.alerts || []);
      setStats(statsData);
    } catch (err) {
      console.error('Failed to fetch data:', err);
    }
  };

  const renderDashboard = () => (
    <div className="dashboard">
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{stats?.totalRobots || 0}</div>
          <div className="stat-label">Total Robots</div>
        </div>
        <div className="stat-card online">
          <div className="stat-value">{stats?.onlineRobots || 0}</div>
          <div className="stat-label">Online</div>
        </div>
        <div className="stat-card offline">
          <div className="stat-value">{stats?.offlineRobots || 0}</div>
          <div className="stat-label">Offline</div>
        </div>
        <div className="stat-card error">
          <div className="stat-value">{stats?.errorRobots || 0}</div>
          <div className="stat-label">Errors</div>
        </div>
      </div>
      <div className="recent-alerts">
        <h3>Recent Alerts</h3>
        {alerts.slice(0, 5).map(alert => (
          <div key={alert.alertId} className={`alert-item ${alert.severity}`}>
            <span className="alert-title">{alert.title}</span>
            <span className="alert-time">{new Date(alert.createdAt * 1000).toLocaleTimeString()}</span>
          </div>
        ))}
      </div>
    </div>
  );

  const renderRobots = () => (
    <div className="robots-list">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Status</th>
            <th>Zone</th>
            <th>Health</th>
            <th>Position</th>
          </tr>
        </thead>
        <tbody>
          {robots.map(robot => (
            <tr key={robot.robotId} onClick={() => setSelectedRobot(robot.robotId)}>
              <td>{robot.name}</td>
              <td>{robot.robotType}</td>
              <td className={`status ${robot.status}`}>{robot.status}</td>
              <td>{robot.zone}</td>
              <td>{robot.healthScore.toFixed(1)}%</td>
              <td>({robot.position.x.toFixed(1)}, {robot.position.y.toFixed(1)})</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderAlerts = () => (
    <div className="alerts-list">
      {alerts.map(alert => (
        <div key={alert.alertId} className={`alert-card ${alert.severity}`}>
          <div className="alert-header">
            <span className={`severity-badge ${alert.severity}`}>{alert.severity}</span>
            <span className="alert-time">{new Date(alert.createdAt * 1000).toLocaleString()}</span>
          </div>
          <h4>{alert.title}</h4>
          <p>{alert.message}</p>
          {!alert.acknowledged && (
            <button onClick={() => acknowledgeAlert(alert.alertId)}>Acknowledge</button>
          )}
        </div>
      ))}
    </div>
  );

  const renderTwin = () => (
    <div className="twin-view">
      <div className="canvas-3d">
        <div className="placeholder-3d">
          <p>3D Digital Twin View</p>
          <p className="hint">Robot positions displayed here</p>
          {robots.map(robot => (
            <div
              key={robot.robotId}
              className={`robot-marker ${robot.status}`}
              style={{
                left: `${(robot.position.x / 100) * 100}%`,
                top: `${(robot.position.y / 100) * 100}%`,
              }}
              title={`${robot.name} (${robot.status})`}
            />
          ))}
        </div>
      </div>
      <div className="twin-controls">
        <button>Zoom In</button>
        <button>Zoom Out</button>
        <button>Reset View</button>
        <button>Toggle Grid</button>
      </div>
    </div>
  );

  const acknowledgeAlert = async (alertId: string) => {
    await fetch(`${API_BASE}/alerts/${alertId}/acknowledge`, { method: 'POST' });
    fetchData();
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>P-MCP Fleet Control</h1>
        <nav>
          <button className={activeTab === 'dashboard' ? 'active' : ''} onClick={() => setActiveTab('dashboard')}>Dashboard</button>
          <button className={activeTab === 'robots' ? 'active' : ''} onClick={() => setActiveTab('robots')}>Robots</button>
          <button className={activeTab === 'alerts' ? 'active' : ''} onClick={() => setActiveTab('alerts')}>Alerts ({alerts.length})</button>
          <button className={activeTab === 'twin' ? 'active' : ''} onClick={() => setActiveTab('twin')}>Digital Twin</button>
        </nav>
      </header>
      <main className="app-content">
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'robots' && renderRobots()}
        {activeTab === 'alerts' && renderAlerts()}
        {activeTab === 'twin' && renderTwin()}
      </main>
    </div>
  );
}

export default App;