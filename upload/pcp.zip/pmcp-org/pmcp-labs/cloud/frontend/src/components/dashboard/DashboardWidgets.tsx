import React, { useState, useEffect, useCallback } from 'react';
import { FleetStats, Robot, Alert, Task, Zone } from '../../types';

interface ChartData {
  labels: string[];
  values: number[];
  colors?: string[];
}

interface TimeSeriesPoint {
  timestamp: number;
  value: number;
}

interface DashboardWidgetsProps {
  stats: FleetStats | null;
  robots: Robot[];
  alerts: Alert[];
  tasks: Task[];
  zones: Zone[];
  timeRange: '1h' | '24h' | '7d' | '30d';
  onTimeRangeChange: (range: '1h' | '24h' | '7d' | '30d') => void;
}

export function DashboardWidgets({
  stats,
  robots,
  alerts,
  tasks,
  zones,
  timeRange,
  onTimeRangeChange,
}: DashboardWidgetsProps) {
  return (
    <div className="dashboard-widgets">
      <div className="widgets-grid">
        <FleetOverviewWidget stats={stats} />
        <RobotsByStatusWidget robots={robots} />
        <RecentAlertsWidget alerts={alerts} />
        <ActiveTasksWidget tasks={tasks} />
        <ZoneUtilizationWidget zones={zones} robots={robots} />
        <HealthTrendWidget timeRange={timeRange} />
      </div>
    </div>
  );
}

interface FleetOverviewWidgetProps {
  stats: FleetStats | null;
}

function FleetOverviewWidget({ stats }: FleetOverviewWidgetProps) {
  if (!stats) {
    return <div className="widget loading">Loading...</div>;
  }

  const onlinePercentage = stats.totalRobots > 0
    ? (stats.onlineRobots / stats.totalRobots * 100).toFixed(1)
    : '0';

  return (
    <div className="widget fleet-overview">
      <div className="widget-header">
        <h3>Fleet Overview</h3>
      </div>
      <div className="widget-content">
        <div className="overview-stats">
          <div className="stat-item">
            <span className="stat-value">{stats.totalRobots}</span>
            <span className="stat-label">Total Robots</span>
          </div>
          <div className="stat-item online">
            <span className="stat-value">{stats.onlineRobots}</span>
            <span className="stat-label">Online ({onlinePercentage}%)</span>
          </div>
          <div className="stat-item offline">
            <span className="stat-value">{stats.offlineRobots}</span>
            <span className="stat-label">Offline</span>
          </div>
          <div className="stat-item error">
            <span className="stat-value">{stats.errorRobots}</span>
            <span className="stat-label">Errors</span>
          </div>
        </div>
      </div>
    </div>
  );
}

interface RobotsByStatusWidgetProps {
  robots: Robot[];
}

function RobotsByStatusWidget({ robots }: RobotsByStatusWidgetProps) {
  const statusCounts = robots.reduce((acc, robot) => {
    acc[robot.status] = (acc[robot.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const statusColors: Record<string, string> = {
    online: '#22c55e',
    offline: '#6b7280',
    error: '#ef4444',
    maintenance: '#f59e0b',
    degraded: '#f59e0b',
    emergency_stop: '#ef4444',
  };

  const data: ChartData = {
    labels: Object.keys(statusCounts),
    values: Object.values(statusCounts),
    colors: Object.keys(statusCounts).map(s => statusColors[s] || '#6b7280'),
  };

  return (
    <div className="widget robots-by-status">
      <div className="widget-header">
        <h3>Robots by Status</h3>
      </div>
      <div className="widget-content">
        <div className="status-bars">
          {data.labels.map((status, i) => (
            <div key={status} className="status-bar-item">
              <div className="status-label">
                <span className="status-dot" style={{ backgroundColor: data.colors![i] }} />
                <span className="status-name">{status}</span>
              </div>
              <div className="status-bar-container">
                <div
                  className="status-bar"
                  style={{
                    width: `${(data.values[i] / robots.length) * 100}%`,
                    backgroundColor: data.colors![i],
                  }}
                />
              </div>
              <span className="status-count">{data.values[i]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface RecentAlertsWidgetProps {
  alerts: Alert[];
}

function RecentAlertsWidget({ alerts }: RecentAlertsWidgetProps) {
  const recentAlerts = alerts.slice(0, 5);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return '#ef4444';
      case 'high': return '#f97316';
      case 'medium': return '#f59e0b';
      case 'low': return '#3b82f6';
      default: return '#6b7280';
    }
  };

  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp * 1000;
    const minutes = Math.floor(diff / 60000);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <div className="widget recent-alerts">
      <div className="widget-header">
        <h3>Recent Alerts</h3>
        <span className="alert-count">{alerts.length}</span>
      </div>
      <div className="widget-content">
        {recentAlerts.length === 0 ? (
          <div className="empty-state">No recent alerts</div>
        ) : (
          <div className="alerts-list">
            {recentAlerts.map(alert => (
              <div key={alert.alertId} className="alert-item">
                <div
                  className="alert-severity-indicator"
                  style={{ backgroundColor: getSeverityColor(alert.severity) }}
                />
                <div className="alert-content">
                  <div className="alert-title">{alert.title}</div>
                  <div className="alert-meta">
                    <span className="alert-time">{formatTime(alert.createdAt)}</span>
                    {alert.robotId && <span className="alert-robot">{alert.robotId}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

interface ActiveTasksWidgetProps {
  tasks: Task[];
}

function ActiveTasksWidget({ tasks }: ActiveTasksWidgetProps) {
  const activeTasks = tasks.filter(t => t.status === 'running' || t.status === 'pending');
  const runningTasks = activeTasks.filter(t => t.status === 'running');
  const pendingTasks = activeTasks.filter(t => t.status === 'pending');

  return (
    <div className="widget active-tasks">
      <div className="widget-header">
        <h3>Active Tasks</h3>
      </div>
      <div className="widget-content">
        <div className="tasks-summary">
          <div className="task-stat running">
            <span className="task-count">{runningTasks.length}</span>
            <span className="task-label">Running</span>
          </div>
          <div className="task-stat pending">
            <span className="task-count">{pendingTasks.length}</span>
            <span className="task-label">Pending</span>
          </div>
        </div>
        {runningTasks.length > 0 && (
          <div className="running-tasks">
            {runningTasks.slice(0, 3).map(task => (
              <div key={task.taskId} className="task-item">
                <span className="task-name">{task.name}</span>
                <div className="task-progress">
                  <div
                    className="progress-fill"
                    style={{ width: `${task.progress}%` }}
                  />
                </div>
                <span className="task-progress-label">{task.progress}%</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

interface ZoneUtilizationWidgetProps {
  zones: Zone[];
  robots: Robot[];
}

function ZoneUtilizationWidget({ zones, robots }: ZoneUtilizationWidgetProps) {
  const zoneStats = zones.map(zone => {
    const zoneRobots = robots.filter(r => r.zone === zone.zone_id);
    const utilization = zone.capacity > 0 ? (zoneRobots.length / zone.capacity) * 100 : 0;
    return {
      name: zone.name,
      robotCount: zoneRobots.length,
      capacity: zone.capacity,
      utilization: utilization,
    };
  });

  return (
    <div className="widget zone-utilization">
      <div className="widget-header">
        <h3>Zone Utilization</h3>
      </div>
      <div className="widget-content">
        <div className="zone-list">
          {zoneStats.map(zone => (
            <div key={zone.name} className="zone-item">
              <div className="zone-info">
                <span className="zone-name">{zone.name}</span>
                <span className="zone-count">
                  {zone.robotCount}/{zone.capacity} robots
                </span>
              </div>
              <div className="zone-progress">
                <div
                  className={`progress-fill ${zone.utilization > 80 ? 'high' : ''}`}
                  style={{ width: `${Math.min(zone.utilization, 100)}%` }}
                />
              </div>
              <span className="zone-utilization">{zone.utilization.toFixed(0)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface HealthTrendWidgetProps {
  timeRange: '1h' | '24h' | '7d' | '30d';
}

function HealthTrendWidget({ timeRange }: HealthTrendWidgetProps) {
  const [trendData, setTrendData] = useState<TimeSeriesPoint[]>([]);

  useEffect(() => {
    const now = Date.now();
    let points = 0;
    let interval = 0;

    switch (timeRange) {
      case '1h':
        points = 60;
        interval = 60000;
        break;
      case '24h':
        points = 24;
        interval = 3600000;
        break;
      case '7d':
        points = 7 * 24;
        interval = 3600000;
        break;
      case '30d':
        points = 30;
        interval = 86400000;
        break;
    }

    const data: TimeSeriesPoint[] = [];
    for (let i = points - 1; i >= 0; i--) {
      data.push({
        timestamp: now - i * interval,
        value: 70 + Math.random() * 25,
      });
    }
    setTrendData(data);
  }, [timeRange]);

  if (trendData.length === 0) {
    return <div className="widget loading">Loading...</div>;
  }

  const minValue = Math.min(...trendData.map(d => d.value));
  const maxValue = Math.max(...trendData.map(d => d.value));
  const avgValue = trendData.reduce((sum, d) => sum + d.value, 0) / trendData.length;

  const points = trendData.map((d, i) => {
    const x = (i / (trendData.length - 1)) * 100;
    const y = 100 - ((d.value - minValue) / (maxValue - minValue)) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="widget health-trend">
      <div className="widget-header">
        <h3>Health Trend</h3>
        <div className="trend-stats">
          <span className="trend-stat avg">Avg: {avgValue.toFixed(1)}%</span>
          <span className="trend-stat min">Min: {minValue.toFixed(1)}%</span>
          <span className="trend-stat max">Max: {maxValue.toFixed(1)}%</span>
        </div>
      </div>
      <div className="widget-content">
        <svg className="trend-chart" viewBox="0 0 100 50" preserveAspectRatio="none">
          <polyline
            fill="none"
            stroke="#22c55e"
            strokeWidth="2"
            points={points}
          />
        </svg>
      </div>
    </div>
  );
}

export default DashboardWidgets;