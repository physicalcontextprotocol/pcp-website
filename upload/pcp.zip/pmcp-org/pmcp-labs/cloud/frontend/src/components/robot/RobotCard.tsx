import React, { useState } from 'react';
import { Robot } from '../../types';
import { Badge, ProgressBar, Tooltip } from '../common/StatCard';

interface RobotCardProps {
  robot: Robot;
  onSelect?: (robot: Robot) => void;
  onCommand?: (robotId: string, command: string) => void;
  isSelected?: boolean;
}

export function RobotCard({ robot, onSelect, onCommand, isSelected }: RobotCardProps) {
  const [showMenu, setShowMenu] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'success';
      case 'offline':
        return 'default';
      case 'error':
        return 'error';
      case 'maintenance':
        return 'warning';
      case 'degraded':
        return 'warning';
      case 'emergency_stop':
        return 'error';
      default:
        return 'default';
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 80) return 'success';
    if (score >= 50) return 'warning';
    return 'error';
  };

  const getBatteryIcon = (level: number) => {
    if (level >= 80) return '🔋';
    if (level >= 50) return '🔌';
    if (level >= 20) return '⚠️';
    return '🪫';
  };

  return (
    <div
      className={`robot-card ${isSelected ? 'selected' : ''}`}
      onClick={() => onSelect?.(robot)}
    >
      <div className="robot-card-header">
        <div className="robot-info">
          <h3 className="robot-name">{robot.name}</h3>
          <span className="robot-id">{robot.robotId}</span>
        </div>
        <Badge text={robot.status} variant={getStatusColor(robot.status)} />
      </div>

      <div className="robot-card-body">
        <div className="robot-details">
          <div className="detail-row">
            <span className="detail-label">Type:</span>
            <span className="detail-value">{robot.robotType}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Zone:</span>
            <span className="detail-value">{robot.zone}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Firmware:</span>
            <Tooltip content={`Build: ${robot.firmware.buildTime}`}>
              <span className="detail-value">{robot.firmware.version}</span>
            </Tooltip>
          </div>
        </div>

        <div className="robot-metrics">
          <div className="metric">
            <span className="metric-label">Health</span>
            <ProgressBar
              value={robot.healthScore}
              color={getHealthColor(robot.healthScore)}
              size="small"
            />
            <span className="metric-value">{robot.healthScore.toFixed(0)}%</span>
          </div>
          <div className="metric">
            <span className="metric-label">Battery</span>
            <ProgressBar
              value={robot.batteryLevel}
              color={getHealthColor(robot.batteryLevel)}
              size="small"
            />
            <span className="metric-value">
              {getBatteryIcon(robot.batteryLevel)} {robot.batteryLevel.toFixed(0)}%
            </span>
          </div>
        </div>

        <div className="robot-position">
          <span className="position-label">Position</span>
          <span className="position-value">
            X: {robot.position.x.toFixed(1)} |
            Y: {robot.position.y.toFixed(1)} |
            Z: {robot.position.z.toFixed(1)}
          </span>
        </div>

        {robot.network && (
          <div className="robot-network">
            <span className={`network-status ${robot.network.connected ? 'connected' : 'disconnected'}`}>
              {robot.network.connected ? '●' : '○'}
            </span>
            <span className="network-latency">{robot.network.latency}ms</span>
            <span className="network-signal">{robot.network.signalStrength}%</span>
          </div>
        )}
      </div>

      <div className="robot-card-footer">
        <span className="last-update">
          Updated: {new Date(robot.lastUpdate * 1000).toLocaleTimeString()}
        </span>
        <div className="robot-actions">
          <button
            className="btn-icon"
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
          >
            ⋮
          </button>
          {showMenu && (
            <div className="action-menu">
              <button onClick={() => onCommand?.(robot.robotId, 'stop')}>Stop</button>
              <button onClick={() => onCommand?.(robot.robotId, 'restart')}>Restart</button>
              <button onClick={() => onCommand?.(robot.robotId, 'maintenance')}>
                Set Maintenance
              </button>
              <button onClick={() => onCommand?.(robot.robotId, 'diagnostics')}>
                Run Diagnostics
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

interface RobotListProps {
  robots: Robot[];
  onSelect?: (robot: Robot) => void;
  onCommand?: (robotId: string, command: string) => void;
  selectedId?: string;
}

export function RobotList({ robots, onSelect, onCommand, selectedId }: RobotListProps) {
  return (
    <div className="robot-list">
      {robots.map(robot => (
        <RobotCard
          key={robot.robotId}
          robot={robot}
          onSelect={onSelect}
          onCommand={onCommand}
          isSelected={robot.robotId === selectedId}
        />
      ))}
    </div>
  );
}

interface RobotTableProps {
  robots: Robot[];
  onSelect?: (robot: Robot) => void;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export function RobotTable({ robots, onSelect, sortBy = 'name', sortOrder = 'asc' }: RobotTableProps) {
  const sortedRobots = [...robots].sort((a, b) => {
    const aVal = (a as Record<string, unknown>)[sortBy];
    const bVal = (b as Record<string, unknown>)[sortBy];
    if (typeof aVal === 'string' && typeof bVal === 'string') {
      return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
    }
    return 0;
  });

  const getStatusClass = (status: string) => {
    return `status-badge status-${status}`;
  };

  return (
    <div className="robot-table-container">
      <table className="robot-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Status</th>
            <th>Zone</th>
            <th>Health</th>
            <th>Battery</th>
            <th>Position</th>
            <th>Last Update</th>
          </tr>
        </thead>
        <tbody>
          {sortedRobots.map(robot => (
            <tr key={robot.robotId} onClick={() => onSelect?.(robot)}>
              <td>
                <div className="robot-name-cell">
                  <span className="name">{robot.name}</span>
                  <span className="id">{robot.robotId}</span>
                </div>
              </td>
              <td>{robot.robotType}</td>
              <td>
                <span className={getStatusClass(robot.status)}>{robot.status}</span>
              </td>
              <td>{robot.zone}</td>
              <td>
                <ProgressBar
                  value={robot.healthScore}
                  showLabel
                  size="small"
                />
              </td>
              <td>
                <ProgressBar
                  value={robot.batteryLevel}
                  showLabel
                  size="small"
                />
              </td>
              <td className="position-cell">
                ({robot.position.x.toFixed(1)}, {robot.position.y.toFixed(1)})
              </td>
              <td className="time-cell">
                {new Date(robot.lastUpdate * 1000).toLocaleTimeString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default { RobotCard, RobotList, RobotTable };