import React from 'react';
import { Alert, AlertSeverity, AlertCategory } from '../../types';
import { Badge } from '../common/StatCard';

interface AlertItemProps {
  alert: Alert;
  onAcknowledge?: (alertId: string) => void;
  onResolve?: (alertId: string) => void;
  onSelect?: (alert: Alert) => void;
}

export function AlertItem({ alert, onAcknowledge, onResolve, onSelect }: AlertItemProps) {
  const getSeverityVariant = (severity: AlertSeverity) => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'high':
        return 'error';
      case 'medium':
        return 'warning';
      case 'low':
        return 'info';
      default:
        return 'default';
    }
  };

  const getCategoryIcon = (category: AlertCategory) => {
    switch (category) {
      case 'hardware':
        return '🔧';
      case 'software':
        return '💿';
      case 'network':
        return '📡';
      case 'safety':
        return '⚠️';
      case 'battery':
        return '🔋';
      case 'performance':
        return '📊';
      case 'security':
        return '🔒';
      default:
        return '📋';
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <div
      className={`alert-item alert-severity-${alert.severity} ${
        alert.acknowledged ? 'acknowledged' : ''
      } ${alert.resolved ? 'resolved' : ''}`}
      onClick={() => onSelect?.(alert)}
    >
      <div className="alert-icon">
        <span className="category-icon">{getCategoryIcon(alert.category)}</span>
      </div>

      <div className="alert-content">
        <div className="alert-header-row">
          <h4 className="alert-title">{alert.title}</h4>
          <div className="alert-badges">
            <Badge
              text={alert.severity}
              variant={getSeverityVariant(alert.severity)}
              size="small"
            />
            <Badge
              text={alert.category}
              variant="default"
              size="small"
            />
          </div>
        </div>

        <p className="alert-message">{alert.message}</p>

        <div className="alert-meta">
          <span className="alert-timestamp">{formatTimestamp(alert.createdAt)}</span>
          {alert.robotId && (
            <span className="alert-robot-id">Robot: {alert.robotId}</span>
          )}
        </div>

        {alert.acknowledged && (
          <div className="alert-acknowledged-info">
            <span className="acknowledged-by">
              Acknowledged by {alert.acknowledgedBy}
            </span>
            <span className="acknowledged-at">
              {alert.acknowledgedAt && new Date(alert.acknowledgedAt * 1000).toLocaleString()}
            </span>
          </div>
        )}

        {alert.resolved && (
          <div className="alert-resolved-info">
            <span className="resolved-by">Resolved by {alert.resolvedBy}</span>
            <span className="resolution">{alert.resolution}</span>
          </div>
        )}
      </div>

      <div className="alert-actions">
        {!alert.acknowledged && onAcknowledge && (
          <button
            className="btn btn-secondary btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              onAcknowledge(alert.alertId);
            }}
          >
            Acknowledge
          </button>
        )}
        {alert.acknowledged && !alert.resolved && onResolve && (
          <button
            className="btn btn-primary btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              onResolve(alert.alertId);
            }}
          >
            Resolve
          </button>
        )}
      </div>
    </div>
  );
}

interface AlertListProps {
  alerts: Alert[];
  onAcknowledge?: (alertId: string) => void;
  onResolve?: (alertId: string) => void;
  onSelect?: (alert: Alert) => void;
  filter?: {
    severity?: AlertSeverity[];
    category?: AlertCategory[];
    resolved?: boolean;
  };
}

export function AlertList({
  alerts,
  onAcknowledge,
  onResolve,
  onSelect,
  filter,
}: AlertListProps) {
  const filteredAlerts = alerts.filter(alert => {
    if (filter?.severity?.length && !filter.severity.includes(alert.severity)) {
      return false;
    }
    if (filter?.category?.length && !filter.category.includes(alert.category)) {
      return false;
    }
    if (filter?.resolved !== undefined) {
      if (filter.resolved && !alert.resolved) return false;
      if (!filter.resolved && alert.resolved) return false;
    }
    return true;
  });

  const sortedAlerts = [...filteredAlerts].sort((a, b) => {
    const severityOrder: Record<AlertSeverity, number> = {
      critical: 0,
      high: 1,
      medium: 2,
      low: 3,
      info: 4,
    };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });

  if (sortedAlerts.length === 0) {
    return (
      <div className="alert-empty">
        <span className="empty-icon">✓</span>
        <p>No alerts to display</p>
      </div>
    );
  }

  return (
    <div className="alert-list">
      {sortedAlerts.map(alert => (
        <AlertItem
          key={alert.alertId}
          alert={alert}
          onAcknowledge={onAcknowledge}
          onResolve={onResolve}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
}

interface AlertStatsProps {
  alerts: Alert[];
}

export function AlertStats({ alerts }: AlertStatsProps) {
  const stats = {
    total: alerts.length,
    critical: alerts.filter(a => a.severity === 'critical').length,
    high: alerts.filter(a => a.severity === 'high').length,
    medium: alerts.filter(a => a.severity === 'medium').length,
    low: alerts.filter(a => a.severity === 'low').length,
    unacknowledged: alerts.filter(a => !a.acknowledged).length,
    unresolved: alerts.filter(a => !a.resolved).length,
  };

  return (
    <div className="alert-stats">
      <div className="stat-item">
        <span className="stat-label">Total</span>
        <span className="stat-value">{stats.total}</span>
      </div>
      <div className="stat-item critical">
        <span className="stat-label">Critical</span>
        <span className="stat-value">{stats.critical}</span>
      </div>
      <div className="stat-item high">
        <span className="stat-label">High</span>
        <span className="stat-value">{stats.high}</span>
      </div>
      <div className="stat-item medium">
        <span className="stat-label">Medium</span>
        <span className="stat-value">{stats.medium}</span>
      </div>
      <div className="stat-item low">
        <span className="stat-label">Low</span>
        <span className="stat-value">{stats.low}</span>
      </div>
      <div className="stat-item unack">
        <span className="stat-label">Unacknowledged</span>
        <span className="stat-value">{stats.unacknowledged}</span>
      </div>
    </div>
  );
}

export default { AlertItem, AlertList, AlertStats };