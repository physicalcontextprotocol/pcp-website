import {
  Robot,
  Alert,
  FleetStats,
  Zone,
  Task,
  MetricData,
  TimeSeriesData,
  User,
  CommandRequest,
  CommandResponse,
  ApiResponse,
} from '../types';

const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:8083/api/v1';

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const url = `${API_BASE}${endpoint}`;
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  const token = localStorage.getItem('auth_token');
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(url, { ...options, headers });
    const data = await response.json();

    if (!response.ok) {
      return {
        error: {
          code: response.status.toString(),
          message: data.message || 'Request failed',
          details: data.details,
        },
      };
    }

    return { data, meta: data.meta };
  } catch (error) {
    return {
      error: {
        code: 'NETWORK_ERROR',
        message: error instanceof Error ? error.message : 'Network error',
      },
    };
  }
}

export const robotApi = {
  async list(params?: {
    status?: string;
    zone?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<{ robots: Robot[] }>> {
    const query = new URLSearchParams();
    if (params?.status) query.set('status', params.status);
    if (params?.zone) query.set('zone', params.zone);
    if (params?.page) query.set('page', params.page.toString());
    if (params?.pageSize) query.set('pageSize', params.pageSize.toString());
    return request(`/robots?${query}`);
  },

  async get(robotId: string): Promise<ApiResponse<Robot>> {
    return request(`/robots/${robotId}`);
  },

  async create(robot: Partial<Robot>): Promise<ApiResponse<Robot>> {
    return request('/robots', { method: 'POST', body: JSON.stringify(robot) });
  },

  async update(robotId: string, updates: Partial<Robot>): Promise<ApiResponse<Robot>> {
    return request(`/robots/${robotId}`, { method: 'PATCH', body: JSON.stringify(updates) });
  },

  async delete(robotId: string): Promise<ApiResponse<void>> {
    return request(`/robots/${robotId}`, { method: 'DELETE' });
  },

  async sendCommand(command: CommandRequest): Promise<ApiResponse<CommandResponse>> {
    return request(`/robots/${command.robotId}/commands`, {
      method: 'POST',
      body: JSON.stringify(command),
    });
  },

  async getMetrics(
    robotId: string,
    metricType: string,
    startTime: number,
    endTime: number
  ): Promise<ApiResponse<TimeSeriesData>> {
    const query = new URLSearchParams({
      metricType,
      startTime: startTime.toString(),
      endTime: endTime.toString(),
    });
    return request(`/robots/${robotId}/metrics?${query}`);
  },
};

export const alertApi = {
  async list(params?: {
    severity?: string;
    resolved?: boolean;
    robotId?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<{ alerts: Alert[] }>> {
    const query = new URLSearchParams();
    if (params?.severity) query.set('severity', params.severity);
    if (params?.resolved !== undefined) query.set('resolved', params.resolved.toString());
    if (params?.robotId) query.set('robotId', params.robotId);
    if (params?.page) query.set('page', params.page.toString());
    if (params?.pageSize) query.set('pageSize', params.pageSize.toString());
    return request(`/alerts?${query}`);
  },

  async get(alertId: string): Promise<ApiResponse<Alert>> {
    return request(`/alerts/${alertId}`);
  },

  async acknowledge(alertId: string): Promise<ApiResponse<Alert>> {
    return request(`/alerts/${alertId}/acknowledge`, { method: 'POST' });
  },

  async resolve(
    alertId: string,
    resolution: string
  ): Promise<ApiResponse<Alert>> {
    return request(`/alerts/${alertId}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ resolution }),
    });
  },

  async create(alert: Partial<Alert>): Promise<ApiResponse<Alert>> {
    return request('/alerts', { method: 'POST', body: JSON.stringify(alert) });
  },
};

export const fleetApi = {
  async getStats(): Promise<ApiResponse<FleetStats>> {
    return request('/fleet/stats');
  },

  async getZones(): Promise<ApiResponse<{ zones: Zone[] }>> {
    return request('/fleet/zones');
  },

  async createZone(zone: Partial<Zone>): Promise<ApiResponse<Zone>> {
    return request('/fleet/zones', { method: 'POST', body: JSON.stringify(zone) });
  },

  async updateZone(zoneId: string, updates: Partial<Zone>): Promise<ApiResponse<Zone>> {
    return request(`/fleet/zones/${zoneId}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  },

  async deleteZone(zoneId: string): Promise<ApiResponse<void>> {
    return request(`/fleet/zones/${zoneId}`, { method: 'DELETE' });
  },

  async getHealth(): Promise<ApiResponse<{ health: number; components: Record<string, number> }>> {
    return request('/fleet/health');
  },
};

export const taskApi = {
  async list(params?: {
    status?: string;
    robotId?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<{ tasks: Task[] }>> {
    const query = new URLSearchParams();
    if (params?.status) query.set('status', params.status);
    if (params?.robotId) query.set('robotId', params.robotId);
    if (params?.page) query.set('page', params.page.toString());
    if (params?.pageSize) query.set('pageSize', params.pageSize.toString());
    return request('/tasks?${query}');
  },

  async get(taskId: string): Promise<ApiResponse<Task>> {
    return request(`/tasks/${taskId}`);
  },

  async create(task: Partial<Task>): Promise<ApiResponse<Task>> {
    return request('/tasks', { method: 'POST', body: JSON.stringify(task) });
  },

  async update(taskId: string, updates: Partial<Task>): Promise<ApiResponse<Task>> {
    return request(`/tasks/${taskId}`, { method: 'PATCH', body: JSON.stringify(updates) });
  },

  async cancel(taskId: string): Promise<ApiResponse<Task>> {
    return request(`/tasks/${taskId}/cancel`, { method: 'POST' });
  },

  async pause(taskId: string): Promise<ApiResponse<Task>> {
    return request(`/tasks/${taskId}/pause`, { method: 'POST' });
  },

  async resume(taskId: string): Promise<ApiResponse<Task>> {
    return request(`/tasks/${taskId}/resume`, { method: 'POST' });
  },
};

export const userApi = {
  async me(): Promise<ApiResponse<User>> {
    return request('/auth/me');
  },

  async login(username: string, password: string): Promise<ApiResponse<{ token: string; user: User }>> {
    return request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  },

  async logout(): Promise<ApiResponse<void>> {
    return request('/auth/logout', { method: 'POST' });
  },

  async list(): Promise<ApiResponse<{ users: User[] }>> {
    return request('/users');
  },

  async updatePreferences(preferences: Partial<User['preferences']>): Promise<ApiResponse<User>> {
    return request('/users/me/preferences', {
      method: 'PATCH',
      body: JSON.stringify(preferences),
    });
  },
};

export const metricsApi = {
  async query(params: {
    metric: string;
    robotIds?: string[];
    startTime: number;
    endTime: number;
    aggregation?: 'avg' | 'min' | 'max' | 'sum' | 'count';
    interval?: number;
  }): Promise<ApiResponse<{ series: TimeSeriesData[] }>> {
    const query = new URLSearchParams({
      metric: params.metric,
      startTime: params.startTime.toString(),
      endTime: params.endTime.toString(),
    });
    if (params.robotIds?.length) query.set('robotIds', params.robotIds.join(','));
    if (params.aggregation) query.set('aggregation', params.aggregation);
    if (params.interval) query.set('interval', params.interval.toString());
    return request(`/metrics/query?${query}`);
  },

  async getAggregated(
    metric: string,
    startTime: number,
    endTime: number
  ): Promise<ApiResponse<{ value: number; change: number }>> {
    const query = new URLSearchParams({
      metric,
      startTime: startTime.toString(),
      endTime: endTime.toString(),
    });
    return request(`/metrics/aggregated?${query}`);
  },
};

export { ApiError };
export default {
  robot: robotApi,
  alert: alertApi,
  fleet: fleetApi,
  task: taskApi,
  user: userApi,
  metrics: metricsApi,
};