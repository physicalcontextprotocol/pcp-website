"""
╔══════════════════════════════════════════════════════════════════════════════╗
║      P-MCP — Physical Model Context Protocol                               ║
║      Grand Unified Protocol Stack  v0.1 → v0.4                            ║
║      "The Physical Layer of the Agentic Web"                               ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  COLUMN OF SOVEREIGNTY          TECHNOLOGY                                  ║
║  ─────────────────────────────────────────────────────────────────────────  ║
║  Identity                       W3C DIDs + Ed25519                         ║
║  Governance                     TEE Safety Constitution                    ║
║  Coordination                   Spatiotemporal CRDT Ledger                 ║
║  Actuation                      P-MCP Tool Synthesis                       ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  v0.1  Core Protocol  ─  schemas, shadow, server, robots, LLM bridge      ║
║  v0.2  Upgrades       ─  4D temporal, AAS, auction, HIL torque feedback    ║
║  v0.3  Sovereign      ─  TEE, Metabolic Twin, Ghost Physics, CRDT Ledger   ║
║  v0.4  Interoperable  ─  Tool Synthesis, Visual Shadow, ZK-Safety, DePIN   ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ══════════════════════════════════════════════════════════════════════════════
#  PART 0 — IMPORTS & RUNTIME DETECTION
# ══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations
import asyncio, base64, hashlib, json, logging, math, os
import random, time, uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

# ── optional heavy deps ────────────────────────────────────────────────────
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey, Ed25519PublicKey)
    from cryptography.hazmat.primitives.serialization import (
        Encoding, PublicFormat)
    from cryptography.exceptions import InvalidSignature
    _CRYPTO = True
except ImportError:
    _CRYPTO = False

try:
    import pybullet as _pb; import pybullet_data as _pbd; _BULLET = True
except ImportError:
    _BULLET = False

try:
    import anthropic as _ant; _CLAUDE = True
except ImportError:
    _CLAUDE = False

log = logging.getLogger("pmcp")


# ══════════════════════════════════════════════════════════════════════════════
#  PART 1 — v0.1 CORE SCHEMAS
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Vec3:
    x: float = 0.0; y: float = 0.0; z: float = 0.0
    def __repr__(self): return f"({self.x:.3f},{self.y:.3f},{self.z:.3f})"
    def distance_to(self, o:"Vec3") -> float:
        return ((self.x-o.x)**2+(self.y-o.y)**2+(self.z-o.z)**2)**0.5

@dataclass
class Pose:
    position: Vec3 = field(default_factory=Vec3)
    roll:float=0.0; pitch:float=0.0; yaw:float=0.0; frame:str="world"
    def __repr__(self):
        return f"Pose[{self.frame}] pos={self.position} rpy=({self.roll:.2f},{self.pitch:.2f},{self.yaw:.2f})"

class ToolCategory(str, Enum):
    MOTION="motion"; MANIPULATION="manipulation"; SENSING="sensing"
    NAVIGATION="navigation"; UTILITY="utility"; SYNTHETIC="synthetic"

class ResourceType(str, Enum):
    JOINT_STATES="joint_states"; END_EFFECTOR="end_effector"
    FORCE_TORQUE="force_torque"; CAMERA_RGB="camera_rgb"
    LIDAR_SCAN="lidar_scan"; BATTERY="battery"; PROXIMITY="proximity"
    PLANT_HEALTH="plant_health"; MARKET_PRICE="market_price"
    VISION_VOXELS="vision_voxels"; CUSTOM="custom"

class ToolCallStatus(str, Enum):
    PENDING="PENDING"; SHADOW_OK="SHADOW_OK"; SHADOW_FAIL="SHADOW_FAIL"
    CONFIRMED="CONFIRMED"; EXECUTING="EXECUTING"; SUCCESS="SUCCESS"
    FAILED="FAILED"; ABORTED="ABORTED"; TIMEOUT="TIMEOUT"

@dataclass
class ToolParameter:
    name:str; type:str; description:str
    required:bool=True; default:Any=None
    min_val:Optional[float]=None; max_val:Optional[float]=None; unit:str=""

@dataclass
class PMCPTool:
    name:str; description:str; category:ToolCategory; robot_id:str
    parameters:List[ToolParameter]; handler:Callable
    estimated_duration_s:float=1.0; estimated_energy_j:float=10.0
    max_speed_ms:float=0.5; requires_workspace_clear:bool=True
    min_human_clearance_m:float=0.5; requires_confirmation:bool=True
    capabilities:List["AASCapability"]=field(default_factory=list)
    # v0.4: synthetic tool metadata
    is_synthetic:bool=False; synthesis_confidence:float=1.0
    simulation_passes:int=0; safety_cert_hash:str=""

    def to_llm_schema(self) -> dict:
        d = {"name":self.name,"description":self.description,
             "category":self.category.value,"robot_id":self.robot_id,
             "parameters":[{"name":p.name,"type":p.type,"description":p.description,
                            "required":p.required,"unit":p.unit,
                            **({"min":p.min_val} if p.min_val is not None else {}),
                            **({"max":p.max_val} if p.max_val is not None else {})}
                           for p in self.parameters],
             "physics":{"estimated_duration_s":self.estimated_duration_s,
                        "estimated_energy_j":self.estimated_energy_j,
                        "max_speed_ms":self.max_speed_ms},
             "safety":{"min_human_clearance_m":self.min_human_clearance_m,
                       "requires_confirmation":self.requires_confirmation,
                       "requires_workspace_clear":self.requires_workspace_clear},
             "capabilities":[c.to_json_ld() for c in self.capabilities]}
        if self.is_synthetic:
            d["synthetic"] = {"confidence":self.synthesis_confidence,
                              "simulation_passes":self.simulation_passes,
                              "cert_hash":self.safety_cert_hash}
        return d

@dataclass
class PMCPResource:
    uri:str; robot_id:str; resource_type:ResourceType; description:str
    update_rate_hz:float=10.0; coordinate_frame:str="world"
    _value:Any=field(default=None,repr=False)
    _timestamp:float=field(default_factory=time.time,repr=False)
    def read(self) -> dict:
        return {"uri":self.uri,"type":self.resource_type.value,
                "frame":self.coordinate_frame,"value":self._value,
                "timestamp":self._timestamp,
                "age_ms":round((time.time()-self._timestamp)*1000,1)}
    def write(self,v:Any): self._value=v; self._timestamp=time.time()

@dataclass
class ProjectedOutcome:
    duration_s:float; energy_j:float; final_pose:Optional[Pose]
    risk_level:str; risk_reasons:List[str]
    carbon_g:float=0.0; cost_usd:float=0.0
    workspace_conflicts:List[str]=field(default_factory=list)
    safe_to_execute:bool=True
    # v0.2
    utility_score:float=0.0; temporal_envelope:Optional["TemporalEnvelope"]=None
    auction_price:float=0.0; drift_warning:str=""

@dataclass
class ToolCall:
    call_id:str=field(default_factory=lambda:str(uuid.uuid4())[:8])
    tool_name:str=""; robot_id:str=""; caller_id:str=""
    arguments:Dict[str,Any]=field(default_factory=dict)
    status:ToolCallStatus=ToolCallStatus.PENDING
    projected:Optional[ProjectedOutcome]=None
    result:Optional["ToolResult"]=None
    timestamp:float=field(default_factory=time.time)
    confirmed_at:Optional[float]=None
    bid_energy_j:float=0.0; confirm_deadline_ms:float=0.0
    # v0.4: zk proof
    zk_proof:Optional[str]=None

@dataclass
class ToolResult:
    call_id:str=""; success:bool=False; message:str=""
    data:Dict[str,Any]=field(default_factory=dict)
    duration_actual_s:float=0.0; energy_actual_j:float=0.0
    final_pose:Optional[Pose]=None
    timestamp:float=field(default_factory=time.time)
    joint_torque_error_nm:List[float]=field(default_factory=list)
    projected_duration_s:float=0.0


# ══════════════════════════════════════════════════════════════════════════════
#  PART 2 — v0.2 SCHEMA EXTENSIONS
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class SpaceTimeSlot:
    zone_id:str; robot_id:str; start_ms:float; end_ms:float
    position:Vec3=field(default_factory=Vec3)
    def overlaps(self, o:"SpaceTimeSlot") -> bool:
        return (self.zone_id==o.zone_id and self.robot_id!=o.robot_id
                and self.start_ms<o.end_ms and self.end_ms>o.start_ms)

@dataclass
class TemporalEnvelope:
    slots:List[SpaceTimeSlot]=field(default_factory=list)
    def conflicts_with(self, o:"TemporalEnvelope") -> List[str]:
        return [f"Zone[{s.zone_id}] {s.robot_id}@{s.start_ms:.0f}-{s.end_ms:.0f}ms "
                f"vs {oo.robot_id}@{oo.start_ms:.0f}-{oo.end_ms:.0f}ms"
                for s in self.slots for oo in o.slots if s.overlaps(oo)]

@dataclass
class AASCapability:
    capability_type:str
    properties:Dict[str,Any]
    unit_map:Dict[str,str]
    semantic_uri:str=""
    certifications:List[str]=field(default_factory=list)   # v0.3+

    def matches_query(self, prop:str, op:str, val:float) -> bool:
        v = self.properties.get(prop)
        if v is None: return False
        v = float(v)
        return {">":v>val,">=":v>=val,"<":v<val,"<=":v<=val,"==":v==val}.get(op,False)

    def to_json_ld(self) -> dict:
        return {"@type":f"pmcp:{self.capability_type}",
                "@context":{"pmcp":"https://pmcp.ai/schema/v1/"},
                "semantic_uri":self.semantic_uri,
                "certifications":self.certifications,
                **{k:{"value":v,"unit":self.unit_map.get(k,"")}
                   for k,v in self.properties.items()}}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 3 — DIGITAL TWIN & SHADOW VALIDATOR  (v0.1 + v0.2 + v0.3/v0.4 hooks)
# ══════════════════════════════════════════════════════════════════════════════

class WorkspaceZone:
    def __init__(self, name:str, min_c:Vec3, max_c:Vec3, zone_type:str="clear"):
        self.name=name; self.min=min_c; self.max=max_c; self.zone_type=zone_type
    def contains(self,p:Vec3)->bool:
        return (self.min.x<=p.x<=self.max.x and self.min.y<=p.y<=self.max.y
                and self.min.z<=p.z<=self.max.z)
    def intersects_tube(self,start:Vec3,end:Vec3,radius:float=0.15,steps:int=30)->bool:
        for i in range(steps+1):
            t=i/steps
            c=Vec3(start.x+t*(end.x-start.x),start.y+t*(end.y-start.y),
                   start.z+t*(end.z-start.z))
            for a in [k*math.pi/4 for k in range(8)]:
                if self.contains(Vec3(c.x+radius*math.cos(a),
                                      c.y+radius*math.sin(a),c.z)):
                    return True
        return False

@dataclass
class RobotPhysicsModel:
    robot_id:str
    duration_scale:float=1.0; energy_scale:float=1.0
    friction_coeff:float=1.0; torque_baseline_nm:List[float]=field(default_factory=lambda:[0.0]*6)
    _dur_hist:deque=field(default_factory=lambda:deque(maxlen=50),repr=False)
    _torq_hist:deque=field(default_factory=lambda:deque(maxlen=50),repr=False)
    DRIFT_THRESHOLD=0.10
    def record_outcome(self,p:float,a:float,terr:List[float]):
        self._dur_hist.append((p,a))
        if terr: self._torq_hist.append(terr)
        self._recalibrate()
    def _recalibrate(self):
        if len(self._dur_hist)<10: return
        ratios=[a/max(p,0.001) for p,a in self._dur_hist]
        m=sum(ratios)/len(ratios)
        if abs(m-1.0)>self.DRIFT_THRESHOLD:
            old=self.duration_scale; self.duration_scale=round(m,3)
            log.warning(f"  ⚙️  [{self.robot_id}] drift: dur_scale {old:.3f}→{self.duration_scale:.3f}")
            if self._torq_hist:
                recent=list(self._torq_hist)[-10:]
                avg=[max(e) for e in recent if e]
                if avg and sum(avg)/len(avg)>2.0:
                    log.warning(f"  🔧  [{self.robot_id}] HIGH torque avg — schedule maintenance")
    def drift_warning(self)->str:
        p=(self.duration_scale-1.0)*100
        return f"Motor drift +{p:.0f}% — maintenance recommended" if self.duration_scale>1.0+self.DRIFT_THRESHOLD else ""
    def adjusted_duration(self,b:float)->float: return b*self.duration_scale*self.friction_coeff
    def adjusted_energy(self,b:float)->float:   return b*self.energy_scale*self.friction_coeff

class DigitalTwin:
    def __init__(self, power_budget_w:float=2000.0):
        self.power_budget_w=power_budget_w; self.power_in_use_w=0.0
        self._robot_poses:Dict[str,Pose]={}
        self._zones:List[WorkspaceZone]=[]
        self._humans_present:Dict[str,bool]={}
        self.grid_carbon_g_kwh:float=450.0
        self._temporal_reservations:List[SpaceTimeSlot]=[]
        self._physics_models:Dict[str,RobotPhysicsModel]={}
        self._plant_health:Dict[str,dict]={}
        self._market_price:dict={"carbon_intensity_g_kwh":450.0,
                                  "energy_price_usd_kwh":0.08,
                                  "carbon_credit_usd_g":0.00002}
        # v0.4: dynamic voxels from vision
        self._vision_voxels:List[dict]=[]
        self._setup_default_workspace()

    def _setup_default_workspace(self):
        self._zones=[
            WorkspaceZone("grow_zone_a",Vec3(0,0,0),Vec3(3,2,2.5)),
            WorkspaceZone("charging_dock",Vec3(4,0,0),Vec3(5,1,0.5)),
            WorkspaceZone("harvest_station",Vec3(0,3,0),Vec3(2,4,1.5)),
            WorkspaceZone("maintenance_corridor",Vec3(3,0,0),Vec3(3.5,4,2)),
        ]

    def register_robot(self,rid:str,pose:Pose):
        self._robot_poses[rid]=pose
        self._physics_models[rid]=RobotPhysicsModel(robot_id=rid)

    def update_pose(self,rid:str,pose:Pose): self._robot_poses[rid]=pose
    def get_pose(self,rid:str)->Optional[Pose]: return self._robot_poses.get(rid)
    def get_physics_model(self,rid:str)->RobotPhysicsModel:
        if rid not in self._physics_models:
            self._physics_models[rid]=RobotPhysicsModel(robot_id=rid)
        return self._physics_models[rid]
    def record_tool_outcome(self,rid:str,ps:float,as_:float,terr:List[float]):
        self.get_physics_model(rid).record_outcome(ps,as_,terr)

    def reserve_zone(self,rid:str,zid:str,s:float,e:float,pos:Optional[Vec3]=None)->bool:
        slot=SpaceTimeSlot(zone_id=zid,robot_id=rid,start_ms=s,end_ms=e,position=pos or Vec3())
        for ex in self._temporal_reservations:
            if slot.overlaps(ex):
                log.warning(f"  ⏰  Temporal conflict [{rid}]→[{zid}]")
                return False
        self._temporal_reservations.append(slot); return True

    def release_zone_reservation(self,rid:str,zid:str):
        self._temporal_reservations=[s for s in self._temporal_reservations
                                      if not(s.robot_id==rid and s.zone_id==zid)]
    def cleanup_expired_reservations(self):
        now=time.time()*1000
        self._temporal_reservations=[s for s in self._temporal_reservations if s.end_ms>now]
    def get_next_available_slot(self,zid:str,dur_ms:float)->float:
        now=time.time()*1000
        rel=sorted([s for s in self._temporal_reservations if s.zone_id==zid],key=lambda s:s.end_ms)
        c=now
        for s in rel:
            if s.end_ms>c: c=s.end_ms
        return c

    def update_plant_health(self,tray_id:str,metrics:dict):
        self._plant_health[tray_id]={**metrics,"updated_at":time.time()}
    def get_plant_health(self,tray_id:str)->Optional[dict]:
        return self._plant_health.get(tray_id)
    def harvest_utility(self,tray_id:str)->float:
        h=self._plant_health.get(tray_id)
        if not h: return 0.5
        return round(h.get("health_score",0.5)*min(1.0,1.0/max(h.get("days_to_harvest",1),0.001)),3)
    def high_humidity_risk(self,tray_id:str)->bool:
        h=self._plant_health.get(tray_id)
        return bool(h) and h.get("humidity_pct",50)>85

    def set_human_present(self,zone:str,p:bool):
        self._humans_present[zone]=p
        if p: log.warning(f"  👤  Human in [{zone}]")
    def set_zone_type(self,name:str,t:str):
        for z in self._zones:
            if z.name==name: z.zone_type=t
    def get_zone_at(self,p:Vec3)->Optional[WorkspaceZone]:
        for z in self._zones:
            if z.contains(p): return z
        return None
    def available_power_w(self)->float: return self.power_budget_w-self.power_in_use_w
    def reserve_power(self,w:float)->bool:
        if w<=self.available_power_w(): self.power_in_use_w+=w; return True
        return False
    def release_power(self,w:float): self.power_in_use_w=max(0,self.power_in_use_w-w)
    def update_market_price(self,ci:float,ep:float):
        self._market_price["carbon_intensity_g_kwh"]=ci
        self._market_price["energy_price_usd_kwh"]=ep
        self.grid_carbon_g_kwh=ci

    # v0.4: vision voxel injection
    def inject_vision_voxel(self,voxel:dict):
        """Inject a dynamic obstacle from vision into the twin."""
        voxel["injected_at"]=time.time()
        self._vision_voxels.append(voxel)
        log.info(f"  👁️  Vision voxel injected: {voxel.get('label','?')} "
                 f"@ ({voxel.get('x',0):.2f},{voxel.get('y',0):.2f},{voxel.get('z',0):.2f})")
    def clear_expired_voxels(self,max_age_s:float=0.5):
        now=time.time()
        self._vision_voxels=[v for v in self._vision_voxels
                             if now-v.get("injected_at",now)<max_age_s]
    def get_vision_voxels(self)->List[dict]: return list(self._vision_voxels)


class ShadowValidator:
    USE_PYBULLET=False
    def __init__(self,twin:DigitalTwin,ghost_sim:"PyBulletGhostSimulator"=None):
        self.twin=twin; self._ghost=ghost_sim
        self._runs=0; self._blocked=0

    def validate(self,call:ToolCall,schema:dict)->ProjectedOutcome:
        self._runs+=1
        self.twin.cleanup_expired_reservations()
        self.twin.clear_expired_voxels(max_age_s=0.5)
        risks:List[str]=[]; conflicts:List[str]=[]; safe=True
        args=call.arguments; physics=schema.get("physics",{}); safety_cfg=schema.get("safety",{})
        phys=self.twin.get_physics_model(call.robot_id)

        target:Optional[Vec3]=None
        if "x" in args and "y" in args and "z" in args:
            target=Vec3(args["x"],args["y"],args["z"])
        elif "target_x" in args:
            target=Vec3(args["target_x"],args.get("target_y",0),args.get("target_z",0))
        cur=self.twin.get_pose(call.robot_id)
        cur_pos=cur.position if cur else Vec3(0,0,0)

        # ── 1. Collision (ghost or tube) ───────────────────────
        if target:
            if self._ghost:
                gr=self._ghost.check_trajectory(call.robot_id,
                    cur_pos.x,cur_pos.y,cur_pos.z,target.x,target.y,target.z)
                for c in gr.collisions: risks.append(f"[Ghost] {c}"); safe=False
            else:
                for z in self.twin._zones:
                    if z.zone_type=="human_zone" and z.intersects_tube(cur_pos,target,0.2):
                        risks.append(f"Path through human zone [{z.name}]"); safe=False
                    if z.zone_type=="obstacle" and z.intersects_tube(cur_pos,target,0.12):
                        risks.append(f"Collision risk [{z.name}]"); safe=False

        # ── 2. Vision voxels (v0.4) ────────────────────────────
        if target:
            for vox in self.twin.get_vision_voxels():
                vp=Vec3(vox.get("x",0),vox.get("y",0),vox.get("z",0))
                r=vox.get("radius",0.3)
                # Check if path passes within voxel radius
                if cur_pos.distance_to(vp)<r+0.5 or target.distance_to(vp)<r+0.3:
                    label=vox.get("label","object"); conf=vox.get("confidence",1.0)
                    risks.append(f"[Vision] {label} detected near path "
                                 f"({vp.x:.2f},{vp.y:.2f},{vp.z:.2f}) conf={conf:.0%}")
                    safe=False

        # ── 3. Human proximity ─────────────────────────────────
        clr=safety_cfg.get("min_human_clearance_m",0.5)
        for zn,present in self.twin._humans_present.items():
            if present: risks.append(f"Human in [{zn}] — {clr}m clearance"); safe=False

        # ── 4. Power budget ────────────────────────────────────
        need=_est_power(physics,args)
        avail=self.twin.available_power_w()
        if need>avail:
            risks.append(f"Insufficient power {need:.0f}W/{avail:.0f}W avail"); safe=False

        # ── 5. Spatial conflicts ───────────────────────────────
        if target:
            for oid,op in self.twin._robot_poses.items():
                if oid==call.robot_id: continue
                d=target.distance_to(op.position)
                if d<0.3:
                    conflicts.append(f"[{oid}] {d:.2f}m from target")
                    risks.append(f"Workspace conflict [{oid}]")

        # ── 6. 4D temporal conflicts ───────────────────────────
        if target:
            bd=phys.adjusted_duration(physics.get("estimated_duration_s",1.0))
            now=time.time()*1000; end=now+bd*1000
            z=self.twin.get_zone_at(target)
            if z:
                ts=SpaceTimeSlot(zone_id=z.name,robot_id=call.robot_id,
                                 start_ms=now,end_ms=end,position=target)
                for ex in self.twin._temporal_reservations:
                    if ts.overlaps(ex):
                        conflicts.append(f"Temporal: [{ex.robot_id}] holds [{z.name}]")
                        risks.append(f"4D conflict [{ex.robot_id}]@[{z.name}]")

        # ── 7. Arm reachability ────────────────────────────────
        if target and call.robot_id.startswith("arm"):
            arm_b=self.twin.get_pose(call.robot_id)
            if arm_b:
                reach=target.distance_to(arm_b.position)
                mx=args.get("_max_reach",0.85)
                if reach>mx: risks.append(f"Target {reach:.2f}m > reach {mx}m"); safe=False

        # ── 8. Biological risk ─────────────────────────────────
        tray=f"tray-{int(args.get('tray_x',0))}-{int(args.get('tray_y',0))}"
        if self.twin.high_humidity_risk(tray):
            risks.append(f"High humidity [{tray}] — motor oxidation risk")
        drift=phys.drift_warning()

        # ── 9. Compute projections ─────────────────────────────
        bd=physics.get("estimated_duration_s",1.0); be=physics.get("estimated_energy_j",50.0)
        dur=phys.adjusted_duration(_est_duration(physics,cur_pos,target))
        eng=phys.adjusted_energy(be*(dur/max(bd,0.001)))
        kwh=eng/3_600_000; carbon=kwh*self.twin.grid_carbon_g_kwh
        cost=kwh*self.twin._market_price["energy_price_usd_kwh"]
        fp=Pose(position=target) if target else None
        rl="low" if not risks else ("high" if not safe else "medium")
        util=self.twin.harvest_utility(tray)
        if util==0.5:
            util=0.8 if schema.get("category","") in ("motion","manipulation") else 0.5
        now=time.time()*1000; end=now+dur*1000
        env=TemporalEnvelope()
        if target:
            z=self.twin.get_zone_at(target)
            if z: env.slots.append(SpaceTimeSlot(z.name,call.robot_id,now,end,target))
        if not safe: self._blocked+=1

        out=ProjectedOutcome(duration_s=round(dur,2),energy_j=round(eng,1),
            final_pose=fp,risk_level=rl,risk_reasons=risks,
            carbon_g=round(carbon,4),cost_usd=round(cost,6),
            workspace_conflicts=conflicts,safe_to_execute=safe,
            utility_score=util,temporal_envelope=env,drift_warning=drift)
        log.info(f"  🔮  Shadow [{call.call_id}] risk={rl} dur={dur:.1f}s "
                 f"energy={eng:.0f}J util={util:.2f} safe={safe}")
        for r in risks: log.warning(f"     ⚠  {r}")
        return out

    def stats(self)->dict:
        return {"validations_run":self._runs,"validations_blocked":self._blocked,
                "block_rate_pct":round(100*self._blocked/max(1,self._runs),1),
                "active_reservations":len(self.twin._temporal_reservations),
                "vision_voxels":len(self.twin._vision_voxels),
                "physics_models":{rid:{"duration_scale":m.duration_scale,
                    "energy_scale":m.energy_scale,"drift_warning":m.drift_warning()}
                    for rid,m in self.twin._physics_models.items()}}

def _est_power(physics:dict,args:dict)->float:
    b=physics.get("estimated_energy_j",50.0)
    s=args.get("speed",physics.get("max_speed_ms",0.3))
    return b*(s/max(physics.get("max_speed_ms",0.5),0.001))

def _est_duration(physics:dict,s:Optional[Vec3],e:Optional[Vec3])->float:
    b=physics.get("estimated_duration_s",1.0)
    if s and e:
        d=s.distance_to(e); sp=max(physics.get("max_speed_ms",0.3),0.01)
        return max(b,d/sp)
    return b


# ══════════════════════════════════════════════════════════════════════════════
#  PART 4 — PMCP SERVER  (v0.1 + v0.2 + v0.4 ZK hook)
# ══════════════════════════════════════════════════════════════════════════════

DEFAULT_CONFIRM_TIMEOUT_MS=5000

class PMCPServer:
    def __init__(self,server_id:str,twin:DigitalTwin,
                 confirm_timeout_ms:float=DEFAULT_CONFIRM_TIMEOUT_MS,
                 ghost_sim:"PyBulletGhostSimulator"=None):
        self.server_id=server_id; self.twin=twin
        self.shadow=ShadowValidator(twin,ghost_sim)
        self.confirm_timeout_ms=confirm_timeout_ms
        self._tools:Dict[str,PMCPTool]={}; self._resources:Dict[str,PMCPResource]={}
        self._calls:Dict[str,ToolCall]={}; self._audit:List[dict]=[]
        self._auction_pool:Dict[str,List[ToolCall]]={}
        # v0.4: synthetic tool registry
        self._synthetic_tools:Dict[str,dict]={}
        # v0.4: ZK verifier
        self._zk_verifier:Optional["ZKSafetyVerifier"]=None
        log.info(f"🖥️   P-MCP Server [{server_id}] v0.4 (timeout={confirm_timeout_ms}ms)")

    # ── Registration ───────────────────────────────────────────
    def tool(self,*,category:ToolCategory,robot_id:str,description:str,
             parameters:List[ToolParameter],estimated_duration_s:float=1.0,
             estimated_energy_j:float=50.0,max_speed_ms:float=0.5,
             min_human_clearance_m:float=0.5,requires_confirmation:bool=True,
             capabilities:Optional[List[AASCapability]]=None):
        def decorator(fn:Callable):
            t=PMCPTool(name=fn.__name__,description=description,category=category,
                robot_id=robot_id,parameters=parameters,handler=fn,
                estimated_duration_s=estimated_duration_s,
                estimated_energy_j=estimated_energy_j,max_speed_ms=max_speed_ms,
                min_human_clearance_m=min_human_clearance_m,
                requires_confirmation=requires_confirmation,
                capabilities=capabilities or [])
            self._tools[fn.__name__]=t
            log.info(f"  🔧  Tool: [{robot_id}].{fn.__name__} ({category.value})")
            return fn
        return decorator

    def resource(self,*,robot_id:str,resource_type:ResourceType,description:str,
                 update_rate_hz:float=10.0,coordinate_frame:str="world"):
        def decorator(fn:Callable):
            uri=f"robot://{robot_id}/{resource_type.value}"
            r=PMCPResource(uri=uri,robot_id=robot_id,resource_type=resource_type,
                description=description,update_rate_hz=update_rate_hz,
                coordinate_frame=coordinate_frame)
            r._updater=fn; self._resources[uri]=r
            log.info(f"  📡  Resource: {uri} @ {update_rate_hz}Hz")
            return fn
        return decorator

    # ── AAS semantic discovery ─────────────────────────────────
    def find_robots(self,capability_type:str,**constraints)->List[str]:
        op_map={"gt":">","gte":">=","lt":"<","lte":"<=","eq":"=="}
        matched=set()
        for t in self._tools.values():
            for cap in t.capabilities:
                if cap.capability_type!=capability_type: continue
                ok=True
                for k,v in constraints.items():
                    parts=k.rsplit("__",1)
                    prop=parts[0]; op=op_map.get(parts[1],"==") if len(parts)==2 else "=="
                    if not cap.matches_query(prop,op,float(v)): ok=False; break
                if ok: matched.add(t.robot_id)
        return list(matched)

    def list_capabilities(self)->List[dict]:
        return [{"robot_id":t.robot_id,"tool":t.name,
                 "capability_type":c.capability_type,"manifest":c.to_json_ld()}
                for t in self._tools.values() for c in t.capabilities]

    # ── Invocation pipeline ────────────────────────────────────
    async def invoke(self,tool_name:str,caller_id:str="agent",
                     bid_energy_j:float=0.0,confirm_timeout_ms:Optional[float]=None,
                     zk_proof:Optional[str]=None,**kwargs)->ToolCall:
        if tool_name not in self._tools:
            raise ValueError(f"Unknown tool: {tool_name!r}")
        tool=self._tools[tool_name]
        timeout=confirm_timeout_ms if confirm_timeout_ms is not None else self.confirm_timeout_ms
        call=ToolCall(tool_name=tool_name,robot_id=tool.robot_id,caller_id=caller_id,
            arguments=kwargs,bid_energy_j=bid_energy_j,
            confirm_deadline_ms=time.time()*1000+timeout,zk_proof=zk_proof)
        self._calls[call.call_id]=call
        log.info(f"\n  ▶  invoke [{call.call_id}]: {caller_id}→[{tool.robot_id}].{tool_name}"
                 +(f" bid={bid_energy_j}J" if bid_energy_j else "")
                 +(f" zk=✓" if zk_proof else ""))

        # v0.4: ZK verification before shadow
        if zk_proof and self._zk_verifier:
            ok,msg=self._zk_verifier.verify_proof(zk_proof,tool_name,kwargs)
            if not ok:
                call.status=ToolCallStatus.SHADOW_FAIL
                call.projected=ProjectedOutcome(0,0,None,"high",[f"ZK proof invalid: {msg}"],
                                                 safe_to_execute=False)
                return call

        schema=tool.to_llm_schema()
        projected=self.shadow.validate(call,schema)
        call.projected=projected
        if projected.workspace_conflicts and bid_energy_j>0:
            zk=projected.workspace_conflicts[0]
            log.info(f"  🏛️   Auction triggered: {zk}")
            self._auction_pool.setdefault(zk,[]).append(call)
            call.status=ToolCallStatus.SHADOW_OK
        elif projected.safe_to_execute:
            call.status=ToolCallStatus.SHADOW_OK
            log.info(f"  ✅  Shadow OK (deadline +{timeout:.0f}ms)")
            asyncio.ensure_future(self._confirm_watchdog(call.call_id,timeout))
        else:
            call.status=ToolCallStatus.SHADOW_FAIL
            log.warning(f"  🚫  Shadow BLOCKED: {'; '.join(projected.risk_reasons)}")
        self._audit_event(call,"invoke"); return call

    async def _confirm_watchdog(self,cid:str,timeout_ms:float):
        await asyncio.sleep(timeout_ms/1000)
        c=self._calls.get(cid)
        if c and c.status==ToolCallStatus.SHADOW_OK:
            c.status=ToolCallStatus.TIMEOUT
            log.warning(f"  ⏱️   TIMEOUT [{cid}] — auto-abort")
            self._audit_event(c,f"timeout:{timeout_ms}ms")

    async def confirm(self,call_id:str)->ToolResult:
        if call_id not in self._calls: raise KeyError(f"No call: {call_id}")
        c=self._calls[call_id]
        if c.status==ToolCallStatus.SHADOW_FAIL:
            raise PermissionError(f"Blocked: {c.projected.risk_reasons}")
        if c.status==ToolCallStatus.TIMEOUT:
            raise RuntimeError(f"Timed out — re-invoke")
        if c.status not in (ToolCallStatus.SHADOW_OK,ToolCallStatus.PENDING):
            raise RuntimeError(f"State {c.status} cannot confirm")
        c.status=ToolCallStatus.CONFIRMED; c.confirmed_at=time.time()
        log.info(f"  ✔  Confirmed [{call_id}]")
        if c.projected and c.projected.temporal_envelope:
            for sl in c.projected.temporal_envelope.slots:
                self.twin.reserve_zone(sl.robot_id,sl.zone_id,sl.start_ms,sl.end_ms,sl.position)
        self._audit_event(c,"confirm"); return await self._execute(c)

    async def invoke_and_confirm(self,tool_name:str,caller_id:str="agent",**kw)->ToolResult:
        c=await self.invoke(tool_name,caller_id=caller_id,**kw)
        if c.status==ToolCallStatus.SHADOW_FAIL:
            return ToolResult(call_id=c.call_id,success=False,
                message=f"Blocked: {'; '.join(c.projected.risk_reasons)}")
        return await self.confirm(c.call_id)

    async def abort(self,cid:str,reason:str="abort"):
        if cid in self._calls:
            self._calls[cid].status=ToolCallStatus.ABORTED
            log.warning(f"  ⛔  Abort [{cid}]: {reason}")
            self._audit_event(self._calls[cid],f"abort:{reason}")

    # ── Vickrey auction ────────────────────────────────────────
    async def run_auction(self,zone_key:str)->Optional[ToolCall]:
        cands=self._auction_pool.pop(zone_key,[])
        if not cands: return None
        if len(cands)==1:
            cands[0].projected.auction_price=cands[0].bid_energy_j
            return cands[0]
        cands.sort(key=lambda c:c.bid_energy_j,reverse=True)
        w=cands[0]; second=cands[1].bid_energy_j; w.projected.auction_price=second
        log.info(f"  🏛️   Auction [{zone_key}]: [{w.caller_id}] wins bid={w.bid_energy_j}J pays={second}J")
        for l in cands[1:]:
            await self.abort(l.call_id,f"outbid [{zone_key}]")
        return w

    # ── HIL feedback ───────────────────────────────────────────
    def ingest_hil_feedback(self,cid:str,torques:List[float]):
        c=self._calls.get(cid)
        if not c or not c.result or not c.projected: return
        self.twin.record_tool_outcome(c.robot_id,c.projected.duration_s,
                                       c.result.duration_actual_s,torques)
        if self.shadow._ghost:
            self.shadow._ghost.update_joints_from_hil(c.robot_id,torques)
        log.info(f"  📈  HIL [{cid}]: proj={c.projected.duration_s:.2f}s "
                 f"actual={c.result.duration_actual_s:.2f}s "
                 f"torques={[round(t,2) for t in torques]}")

    # ── v0.4: register ZK verifier ─────────────────────────────
    def set_zk_verifier(self,v:"ZKSafetyVerifier"): self._zk_verifier=v

    # ── v0.4: register synthetic tool ─────────────────────────
    def register_synthetic_tool(self,tool:PMCPTool):
        if not tool.is_synthetic: return
        self._tools[tool.name]=tool
        self._synthetic_tools[tool.name]={"name":tool.name,
            "confidence":tool.synthesis_confidence,
            "simulation_passes":tool.simulation_passes,
            "cert_hash":tool.safety_cert_hash}
        log.info(f"  🧪  Synthetic tool [{tool.name}] registered "
                 f"(conf={tool.synthesis_confidence:.2f} sims={tool.simulation_passes})")

    # ── Resources ──────────────────────────────────────────────
    async def read_resource(self,uri:str)->dict:
        if uri not in self._resources: raise ValueError(f"Unknown resource: {uri}")
        r=self._resources[uri]
        if hasattr(r,"_updater"): r.write(await r._updater())
        return r.read()
    def list_resources(self)->List[dict]:
        return [{"uri":u,"type":r.resource_type.value,"robot":r.robot_id,"rate_hz":r.update_rate_hz}
                for u,r in self._resources.items()]
    def list_tools(self)->List[dict]: return [t.to_llm_schema() for t in self._tools.values()]
    def get_tool_schema(self,n:str)->dict: return self._tools[n].to_llm_schema()

    def stats(self)->dict:
        counts:Dict[str,int]={}
        for c in self._calls.values():
            counts[c.status.value]=counts.get(c.status.value,0)+1
        return {"server_id":self.server_id,"tools":len(self._tools),
                "synthetic_tools":len(self._synthetic_tools),
                "resources":len(self._resources),"calls_total":len(self._calls),
                "calls_by_status":counts,"shadow":self.shadow.stats(),
                "auction_pools":{k:len(v) for k,v in self._auction_pool.items()}}

    async def _execute(self,c:ToolCall)->ToolResult:
        tool=self._tools[c.tool_name]; t0=time.time()
        c.status=ToolCallStatus.EXECUTING
        try:
            r:ToolResult=await tool.handler(**c.arguments)
            r.call_id=c.call_id; r.duration_actual_s=round(time.time()-t0,3)
            r.projected_duration_s=c.projected.duration_s if c.projected else 0.0
            c.status=ToolCallStatus.SUCCESS; c.result=r
            if r.final_pose: self.twin.update_pose(c.robot_id,r.final_pose)
            if r.joint_torque_error_nm: self.ingest_hil_feedback(c.call_id,r.joint_torque_error_nm)
            if c.projected and c.projected.temporal_envelope:
                for sl in c.projected.temporal_envelope.slots:
                    self.twin.release_zone_reservation(sl.robot_id,sl.zone_id)
            log.info(f"  🤖  Executed [{c.call_id}] {r.duration_actual_s:.2f}s "
                     f"→ {'OK' if r.success else 'FAIL'}: {r.message}")
            self._audit_event(c,"execute_ok"); return r
        except Exception as e:
            c.status=ToolCallStatus.FAILED
            r=ToolResult(call_id=c.call_id,success=False,message=f"Error: {e}",
                duration_actual_s=round(time.time()-t0,3))
            c.result=r; log.error(f"  ❌  [{c.call_id}]: {e}")
            self._audit_event(c,f"execute_fail:{e}"); return r

    def _audit_event(self,c:ToolCall,ev:str):
        self._audit.append({"ts":time.time(),"call_id":c.call_id,"tool":c.tool_name,
                            "robot":c.robot_id,"caller":c.caller_id,"event":ev,
                            "status":c.status.value})


# ══════════════════════════════════════════════════════════════════════════════
#  PART 5 — ROBOT AGENTS  (v0.1/v0.2 full implementation)
# ══════════════════════════════════════════════════════════════════════════════

def _torque_sim(n:int=6,base:float=1.0)->List[float]:
    return [round(random.gauss(0,base*0.3),3) for _ in range(n)]

class RoboticArmAgent:
    ARM_REACH_M=0.85; GRIPPER_MAX_FORCE=40.0; MOTOR_WEAR_RATE=0.0002
    def __init__(self,server:PMCPServer,robot_id:str="arm-01",base_pose:Optional[Pose]=None):
        self.robot_id=robot_id; self.server=server
        self._pose=base_pose or Pose(position=Vec3(1.5,1.0,0.5))
        self._gripper_open=True; self._gripper_force_n=0.0
        self._is_moving=False; self._joints=[0.0]*6; self._calls=0
        server.twin.register_robot(robot_id,self._pose)
        log.info(f"🦾  Arm [{robot_id}] at {self._pose.position}")
        self._register()

    def _arm_caps(self): return [AASCapability("Arm",
        {"DOF":6,"Reach_m":self.ARM_REACH_M,"MaxPayload_kg":3.0,"Accuracy_mm":0.1},
        {"Reach_m":"m","MaxPayload_kg":"kg","Accuracy_mm":"mm"},
        semantic_uri="https://pmcp.ai/schema/v1/capabilities/Arm")]
    def _grip_caps(self): return [AASCapability("Gripper",
        {"MaxForce_n":self.GRIPPER_MAX_FORCE,"MaxOpening_mm":85.0,"MaxPayload_kg":2.0},
        {"MaxForce_n":"N","MaxOpening_mm":"mm","MaxPayload_kg":"kg"},
        semantic_uri="https://pmcp.ai/schema/v1/capabilities/Gripper")]

    def _register(self):
        s=self.server; rid=self.robot_id
        @s.tool(category=ToolCategory.MOTION,robot_id=rid,
            description="Move TCP to Cartesian target. Shadow-validates before executing.",
            parameters=[ToolParameter("x","float","X(m)",unit="m",min_val=-1.0,max_val=3.0),
                        ToolParameter("y","float","Y(m)",unit="m",min_val=-1.0,max_val=3.0),
                        ToolParameter("z","float","Z(m)",unit="m",min_val=0.0,max_val=2.5),
                        ToolParameter("speed","float","Speed(m/s)",unit="m/s",min_val=0.01,
                                     max_val=1.0,required=False,default=0.25)],
            estimated_duration_s=3.0,estimated_energy_j=120.0,max_speed_ms=1.0,
            min_human_clearance_m=0.35,capabilities=self._arm_caps())
        async def move_to(x:float,y:float,z:float,speed:float=0.25):
            return await self._move(x,y,z,speed)

        @s.tool(category=ToolCategory.MANIPULATION,robot_id=rid,
            description="Close gripper with force control.",
            parameters=[ToolParameter("target_force_n","float","Force(N)",unit="N",
                                     min_val=5.0,max_val=self.GRIPPER_MAX_FORCE,required=False,default=15.0),
                        ToolParameter("width_mm","float","Width(mm)",unit="mm",
                                     min_val=0.0,max_val=85.0,required=False,default=0.0)],
            estimated_duration_s=1.5,estimated_energy_j=20.0,max_speed_ms=0.05,
            min_human_clearance_m=0.1,requires_confirmation=False,capabilities=self._grip_caps())
        async def grab(target_force_n:float=15.0,width_mm:float=0.0):
            return await self._grab(target_force_n,width_mm)

        @s.tool(category=ToolCategory.MANIPULATION,robot_id=rid,
            description="Open gripper.",
            parameters=[ToolParameter("width_mm","float","Opening(mm)",unit="mm",
                                     min_val=0.0,max_val=85.0,required=False,default=85.0)],
            estimated_duration_s=0.8,estimated_energy_j=10.0,max_speed_ms=0.05,
            min_human_clearance_m=0.1,requires_confirmation=False,capabilities=self._grip_caps())
        async def release(width_mm:float=85.0):
            return await self._release(width_mm)

        @s.tool(category=ToolCategory.SENSING,robot_id=rid,
            description="Move to inspection pose, capture plant health data.",
            parameters=[ToolParameter("tray_x","float","Tray X(m)",unit="m"),
                        ToolParameter("tray_y","float","Tray Y(m)",unit="m"),
                        ToolParameter("height_above_m","float","Height(m)",unit="m",
                                     min_val=0.1,max_val=0.5,required=False,default=0.3)],
            estimated_duration_s=5.0,estimated_energy_j=180.0,max_speed_ms=0.2,
            capabilities=self._arm_caps())
        async def inspect_plant(tray_x:float,tray_y:float,height_above_m:float=0.3):
            return await self._inspect(tray_x,tray_y,height_above_m)

        @s.tool(category=ToolCategory.MOTION,robot_id=rid,
            description="Return arm to safe home configuration.",
            parameters=[],estimated_duration_s=4.0,estimated_energy_j=100.0,
            max_speed_ms=0.3,requires_confirmation=False,capabilities=self._arm_caps())
        async def home(): return await self._home()

        @s.resource(robot_id=rid,resource_type=ResourceType.END_EFFECTOR,
                    description="TCP pose in world frame",update_rate_hz=20.0)
        async def end_effector_pose():
            return {"x":self._pose.position.x,"y":self._pose.position.y,
                    "z":self._pose.position.z,"roll":self._pose.roll,
                    "pitch":self._pose.pitch,"yaw":self._pose.yaw}

        @s.resource(robot_id=rid,resource_type=ResourceType.JOINT_STATES,
                    description="Joint angles",update_rate_hz=50.0)
        async def joint_states():
            return {"angles_rad":self._joints,"velocities":[0.0]*6,"is_moving":self._is_moving}

        @s.resource(robot_id=rid,resource_type=ResourceType.FORCE_TORQUE,
                    description="Wrist F/T sensor",update_rate_hz=100.0)
        async def force_torque():
            return {"fx":random.uniform(-0.5,0.5),"fy":random.uniform(-0.5,0.5),
                    "fz":(-2.1 if not self._gripper_open else random.uniform(-0.2,0.2)),
                    "gripper_force_n":self._gripper_force_n}

    def _aging(self): return 1.0+self._calls*self.MOTOR_WEAR_RATE

    async def _move(self,x,y,z,speed):
        self._calls+=1; start=self._pose.position; tgt=Vec3(x,y,z)
        dist=start.distance_to(tgt); aging=self._aging()
        dur=(dist/max(speed,0.01))*aging; self._is_moving=True
        log.info(f"  🦾  [{self.robot_id}] move→{tgt} {dist:.2f}m@{speed}→{dur:.1f}s aging×{aging:.3f}")
        steps=max(int(dur*4),2)
        for i in range(steps):
            f=(i+1)/steps; s=math.sin(f*math.pi/2) if f<0.5 else 1-math.sin((1-f)*math.pi/2)
            self._pose.position.x=start.x+s*(x-start.x)
            self._pose.position.y=start.y+s*(y-start.y)
            self._pose.position.z=start.z+s*(z-start.z)
            await asyncio.sleep(dur/steps)
        self._is_moving=False; self._pose=Pose(position=Vec3(x,y,z))
        self.server.twin.update_pose(self.robot_id,self._pose)
        return ToolResult(success=True,message=f"Moved to ({x:.3f},{y:.3f},{z:.3f})",
            data={"distance_m":round(dist,3),"aging_factor":round(aging,3)},
            final_pose=self._pose,joint_torque_error_nm=_torque_sim(6,aging))

    async def _grab(self,force,width):
        if not self._gripper_open: return ToolResult(success=False,message="Already closed")
        await asyncio.sleep(1.2); ok=random.random()>0.05
        self._gripper_open=False; self._gripper_force_n=force if ok else 0.0
        return ToolResult(success=ok,message="Grasped" if ok else "No contact",
            data={"force_n":self._gripper_force_n},joint_torque_error_nm=_torque_sim(6,0.5))

    async def _release(self,width):
        await asyncio.sleep(0.6); self._gripper_open=True; self._gripper_force_n=0.0
        return ToolResult(success=True,message=f"Opened to {width}mm",
            joint_torque_error_nm=_torque_sim(6,0.2))

    async def _inspect(self,tx,ty,h):
        log.info(f"  🔬  [{self.robot_id}] inspect ({tx:.2f},{ty:.2f})")
        await self._move(tx,ty,h+0.5,speed=0.2); await asyncio.sleep(1.0)
        hs=random.uniform(0.7,1.0); ripe=random.uniform(0.1,0.9)
        hum=random.uniform(55,90); days=random.uniform(0.5,5.0)
        tray=f"tray-{int(tx)}-{int(ty)}"
        self.server.twin.update_plant_health(tray,{"health_score":round(hs,3),
            "humidity_pct":round(hum,1),"days_to_harvest":round(days,1),
            "harvest_window_open":ripe>0.6,"vpd_kpa":round(random.uniform(0.4,1.4),2)})
        return ToolResult(success=True,message=f"Health: {hs:.0%}",
            data={"health_score":round(hs,3),"ripe_fraction":round(ripe,2),
                  "harvest_ready":ripe>0.6,"humidity_pct":round(hum,1),
                  "days_to_harvest":round(days,1),"tray_id":tray},
            final_pose=self._pose,joint_torque_error_nm=_torque_sim(6,0.4))

    async def _home(self):
        self._is_moving=True; await asyncio.sleep(3.0)
        self._joints=[0.0]*6; hp=Pose(position=Vec3(1.5,1.0,0.5))
        self._pose=hp; self._is_moving=False; self.server.twin.update_pose(self.robot_id,hp)
        return ToolResult(success=True,message="At home",final_pose=hp,
            joint_torque_error_nm=_torque_sim(6,0.3))


class AMRAgent:
    def __init__(self,server:PMCPServer,robot_id:str="amr-01",
                 initial_pose:Optional[Pose]=None):
        self.robot_id=robot_id; self.server=server
        self._pose=initial_pose or Pose(position=Vec3(4.5,0.5,0.0))
        self._battery=85.0; self._is_docked=False; self._is_moving=False; self._cargo=None
        server.twin.register_robot(robot_id,self._pose)
        log.info(f"🚗  AMR [{robot_id}] at {self._pose.position}")
        self._register()

    def _mob_caps(self): return [AASCapability("MobileBase",
        {"MaxSpeed_ms":1.5,"MaxPayload_kg":100.0,"BatteryCapacity_wh":2000.0,"Nav2Compatible":1.0},
        {"MaxSpeed_ms":"m/s","MaxPayload_kg":"kg","BatteryCapacity_wh":"Wh"},
        semantic_uri="https://pmcp.ai/schema/v1/capabilities/MobileBase")]

    def _register(self):
        s=self.server; rid=self.robot_id
        @s.tool(category=ToolCategory.NAVIGATION,robot_id=rid,
            description="Navigate to 2D pose via Nav2. Supports auction bids.",
            parameters=[ToolParameter("target_x","float","X(m)",unit="m"),
                        ToolParameter("target_y","float","Y(m)",unit="m"),
                        ToolParameter("speed","float","Speed(m/s)",unit="m/s",
                                     min_val=0.1,max_val=1.5,required=False,default=0.5)],
            estimated_duration_s=10.0,estimated_energy_j=300.0,max_speed_ms=1.5,
            min_human_clearance_m=0.5,capabilities=self._mob_caps())
        async def navigate_to(target_x:float,target_y:float,speed:float=0.5):
            return await self._nav(target_x,target_y,speed)

        @s.tool(category=ToolCategory.NAVIGATION,robot_id=rid,
            description="Navigate to charging dock.",
            parameters=[],estimated_duration_s=15.0,estimated_energy_j=100.0,
            max_speed_ms=0.3,requires_confirmation=False,capabilities=self._mob_caps())
        async def dock(): return await self._dock()

        @s.tool(category=ToolCategory.NAVIGATION,robot_id=rid,
            description="Leave dock.",
            parameters=[],estimated_duration_s=3.0,estimated_energy_j=20.0,
            max_speed_ms=0.2,requires_confirmation=False,capabilities=self._mob_caps())
        async def undock(): return await self._undock()

        @s.tool(category=ToolCategory.MANIPULATION,robot_id=rid,
            description="Full pickup-and-deliver cycle.",
            parameters=[ToolParameter("pickup_x","float","Pickup X(m)",unit="m"),
                        ToolParameter("pickup_y","float","Pickup Y(m)",unit="m"),
                        ToolParameter("dropoff_x","float","Dropoff X(m)",unit="m"),
                        ToolParameter("dropoff_y","float","Dropoff Y(m)",unit="m"),
                        ToolParameter("cargo_label","str","Cargo")],
            estimated_duration_s=30.0,estimated_energy_j=900.0,max_speed_ms=0.8,
            capabilities=self._mob_caps())
        async def pickup_and_deliver(pickup_x,pickup_y,dropoff_x,dropoff_y,cargo_label):
            return await self._deliver(pickup_x,pickup_y,dropoff_x,dropoff_y,cargo_label)

        @s.resource(robot_id=rid,resource_type=ResourceType.BATTERY,
                    description="Battery state",update_rate_hz=1.0)
        async def battery_state():
            return {"percent":round(self._battery,1),
                    "voltage_v":round(24.0*(self._battery/100),2),
                    "runtime_min":round(self._battery*2.4,0),"charging":self._is_docked}

        @s.resource(robot_id=rid,resource_type=ResourceType.MARKET_PRICE,
                    description="Live energy market",update_rate_hz=0.1)
        async def market_price():
            hour=time.localtime().tm_hour
            carbon=300+200*math.sin((hour-6)*math.pi/12)
            price=max(0.05+0.08*math.sin((hour-6)*math.pi/12),0.03)
            self.server.twin.update_market_price(carbon,price)
            return {"carbon_intensity_g_kwh":round(carbon,1),
                    "energy_price_usd_kwh":round(price,4),
                    "timestamp_utc":time.strftime("%H:%M:%S")}

    async def _nav(self,tx,ty,speed):
        start=self._pose.position; dist=start.distance_to(Vec3(tx,ty,0))
        dur=dist/max(speed,0.01); self._is_moving=True
        log.info(f"  🚗  [{self.robot_id}] nav→({tx:.2f},{ty:.2f}) {dist:.2f}m")
        steps=max(int(dur*3),2)
        for i in range(steps):
            f=(i+1)/steps
            self._pose.position.x=start.x+f*(tx-start.x)
            self._pose.position.y=start.y+f*(ty-start.y)
            self._battery=max(0,self._battery-0.5/steps)
            self.server.twin.update_pose(self.robot_id,self._pose)
            await asyncio.sleep(dur/steps)
        self._is_moving=False; self._pose=Pose(position=Vec3(tx,ty,0))
        self.server.twin.update_pose(self.robot_id,self._pose)
        return ToolResult(success=True,message=f"Arrived ({tx:.3f},{ty:.3f})",
            data={"distance_m":round(dist,3),"battery_pct":round(self._battery,1)},
            final_pose=self._pose,joint_torque_error_nm=_torque_sim(4,0.8))

    async def _dock(self):
        if self._is_docked: return ToolResult(success=False,message="Already docked")
        await self._nav(4.5,0.2,speed=0.3); await asyncio.sleep(2.0)
        self._is_docked=True; log.info(f"  🔌  [{self.robot_id}] docked")
        return ToolResult(success=True,message="Docked",data={"battery":round(self._battery,1)})

    async def _undock(self):
        if not self._is_docked: return ToolResult(success=False,message="Not docked")
        await asyncio.sleep(2.0); self._is_docked=False
        return ToolResult(success=True,message="Undocked")

    async def _deliver(self,px,py,dx,dy,label):
        log.info(f"  📦  [{self.robot_id}] deliver [{label}] ({px},{py})→({dx},{dy})")
        await self._nav(px,py,speed=0.6); await asyncio.sleep(2.0)
        self._cargo=label; await self._nav(dx,dy,speed=0.5)
        await asyncio.sleep(1.5); self._cargo=None
        return ToolResult(success=True,message=f"Delivered [{label}] to ({dx:.2f},{dy:.2f})",
            data={"cargo":label,"delivered":True},final_pose=self._pose,
            joint_torque_error_nm=_torque_sim(4,1.2))


class HarvesterRobot:
    def __init__(self,server:PMCPServer,robot_id:str="harvester-01",
                 initial_pose:Optional[Pose]=None):
        self.robot_id=robot_id; self.server=server
        self._pose=initial_pose or Pose(position=Vec3(2.0,2.0,0.0))
        self._holding=False
        server.twin.register_robot(robot_id,self._pose)
        log.info(f"🌾  Harvester [{robot_id}] registered")
        self._register()

    def _register(self):
        s=self.server; rid=self.robot_id
        @s.tool(category=ToolCategory.MANIPULATION,robot_id=rid,
            description="Full autonomous harvest: navigate, inspect, grasp, transport.",
            parameters=[ToolParameter("tray_x","float","Tray X(m)",unit="m"),
                        ToolParameter("tray_y","float","Tray Y(m)",unit="m"),
                        ToolParameter("dropoff_x","float","Station X(m)",unit="m",
                                     required=False,default=0.5),
                        ToolParameter("dropoff_y","float","Station Y(m)",unit="m",
                                     required=False,default=3.5)],
            estimated_duration_s=45.0,estimated_energy_j=1500.0,max_speed_ms=0.8,
            capabilities=[AASCapability("Harvester",
                {"MaxReach_m":0.85,"MaxPayload_kg":1.5,"CropTypes":3.0},
                {"MaxReach_m":"m","MaxPayload_kg":"kg"},
                semantic_uri="https://pmcp.ai/schema/v1/capabilities/Harvester")])
        async def harvest(tray_x:float,tray_y:float,dropoff_x:float=0.5,dropoff_y:float=3.5):
            return await self._harvest(tray_x,tray_y,dropoff_x,dropoff_y)

    async def _harvest(self,tx,ty,dx,dy):
        log.info(f"  🌾  [{self.robot_id}] harvest ({tx},{ty})")
        await asyncio.sleep(5.0); self._holding=False
        return ToolResult(success=True,
            message=f"Harvested ({tx:.2f},{ty:.2f})→({dx:.2f},{dy:.2f})",
            data={"tray_x":tx,"tray_y":ty,"cycle_complete":True},
            final_pose=Pose(position=Vec3(dx,dy,0.0)),
            joint_torque_error_nm=_torque_sim(6,1.0))


# ══════════════════════════════════════════════════════════════════════════════
#  PART 6 — LLM BRIDGE  (v0.1/v0.2)
# ══════════════════════════════════════════════════════════════════════════════

class PlanningAgent:
    def __init__(self,server:PMCPServer,agent_id:str="planner-01"):
        self.server=server; self.agent_id=agent_id; self._log:List[dict]=[]
    def _l(self,step:str,detail:str=""):
        e={"ts":time.time(),"step":step,"detail":detail}; self._log.append(e)
        log.info(f"  🧠  [{self.agent_id}] {step}"+(f": {detail}" if detail else ""))
    async def call_tool(self,tool_name:str,auto_confirm:bool=True,
                        bid_energy_j:float=0.0,**kw)->ToolResult:
        self._l(f"call [{tool_name}]",str(kw))
        c=await self.server.invoke(tool_name,caller_id=self.agent_id,bid_energy_j=bid_energy_j,**kw)
        if c.status==ToolCallStatus.SHADOW_FAIL:
            self._l("BLOCKED","; ".join(c.projected.risk_reasons))
            return ToolResult(call_id=c.call_id,success=False,
                message=f"Blocked: {'; '.join(c.projected.risk_reasons)}")
        p=c.projected
        if p.drift_warning: self._l("DRIFT WARNING",p.drift_warning)
        self._l("projection",f"dur={p.duration_s:.1f}s eng={p.energy_j:.0f}J "
                f"risk={p.risk_level} util={p.utility_score:.2f}")
        if p.workspace_conflicts and bid_energy_j>0:
            w=await self.server.run_auction(p.workspace_conflicts[0])
            if w and w.call_id!=c.call_id:
                self._l("LOST AUCTION"); return ToolResult(success=False,message="Lost auction")
        self._l(f"confirm [{c.call_id}]")
        r=await self.server.confirm(c.call_id)
        self._l("SUCCESS" if r.success else "FAILED",r.message)
        return r
    def summary(self)->List[dict]: return list(self._log)


class HarvestOrchestrator:
    def __init__(self,server:PMCPServer,arm_id:str="arm-01",amr_id:str="amr-01"):
        self.server=server; self.arm_id=arm_id; self.amr_id=amr_id
        self.agent=PlanningAgent(server,"harvest-orchestrator"); self._log:List[dict]=[]

    async def run_harvest_cycle(self,tray_x:float=1.0,tray_y:float=0.8)->dict:
        t0=time.time()
        log.info(f"\n{'━'*60}\n  🌱  HARVEST CYCLE tray=({tray_x},{tray_y})\n{'━'*60}")
        results={}
        # Phase 1: inspect
        log.info("\n  [Phase 1] Inspection")
        ins=await self.agent.call_tool("inspect_plant",tray_x=tray_x,tray_y=tray_y,height_above_m=0.3)
        results["inspection"]=ins.data
        if not ins.success: return {"success":False,"phase":"inspect","reason":ins.message}
        if not ins.data.get("harvest_ready"):
            return {"success":True,"harvested":False,"reason":"not_ready"}
        tray=ins.data.get("tray_id","unknown")
        util=self.server.twin.harvest_utility(tray)
        log.info(f"  📊  Health={ins.data.get('health_score',0):.0%} Util={util:.2f}")
        # Phase 2: parallel positioning
        log.info("\n  [Phase 2] Parallel positioning")
        arm_t=self.agent.call_tool("move_to",x=tray_x,y=tray_y-0.1,z=0.35,speed=0.3,bid_energy_j=util*100)
        amr_t=self.agent.call_tool("navigate_to",target_x=tray_x-0.3,target_y=tray_y,speed=0.4,bid_energy_j=util*80)
        ar,amrr=await asyncio.gather(arm_t,amr_t)
        results["positioning"]={"arm":ar.success,"amr":amrr.success}
        # Phase 3: harvest
        log.info("\n  [Phase 3] Harvest")
        gr=await self.agent.call_tool("grab",target_force_n=12.0,width_mm=30.0)
        if not gr.success:
            await self.agent.call_tool("home"); return {"success":False,"phase":"grab","reason":gr.message}
        await self.agent.call_tool("move_to",x=tray_x,y=tray_y-0.1,z=0.65,speed=0.15)
        await self.agent.call_tool("move_to",x=tray_x-0.3,y=tray_y,z=0.4,speed=0.2)
        await self.agent.call_tool("release",width_mm=70.0)
        # Phase 4: transport
        log.info("\n  [Phase 4] Transport")
        tr=await self.agent.call_tool("pickup_and_deliver",pickup_x=tray_x-0.3,pickup_y=tray_y,
            dropoff_x=0.5,dropoff_y=3.5,cargo_label="harvested_basil")
        results["transport"]=tr.success
        await self.agent.call_tool("home")
        dur=time.time()-t0
        log.info(f"\n{'━'*60}\n  ✅  HARVEST COMPLETE {dur:.1f}s util={util:.2f}\n{'━'*60}")
        return {"success":True,"harvested":True,"tray":(tray_x,tray_y),
                "duration_s":round(dur,1),"utility_score":util,"phases":results}


class RealClaudeAgent:
    MODEL="claude-sonnet-4-20250514"
    def __init__(self,server:PMCPServer,api_key:Optional[str]=None,agent_id:str="claude-01"):
        self.server=server; self.agent_id=agent_id
        self._key=api_key or os.environ.get("ANTHROPIC_API_KEY","")
        if not _CLAUDE: log.warning("  anthropic not installed — RealClaudeAgent inactive")
        elif not self._key: log.warning("  No ANTHROPIC_API_KEY — RealClaudeAgent inactive")

    async def complete_goal(self,goal:str)->List[ToolResult]:
        if not _CLAUDE or not self._key: return []
        client=_ant.Anthropic(api_key=self._key)
        tools=[]; results=[]
        for t in self.server.list_tools():
            props={}; req=[]
            for p in t["parameters"]:
                desc=p["description"]
                if p.get("unit"): desc+=f" (unit:{p['unit']})"
                props[p["name"]]={"type":p["type"],"description":desc}
                if p["required"]: req.append(p["name"])
            tools.append({"name":t["name"],"description":f"[{t['robot_id']}] {t['description']}",
                          "input_schema":{"type":"object","properties":props,"required":req}})
        messages=[{"role":"user","content":goal}]
        for _ in range(20):
            r=client.messages.create(model=self.MODEL,max_tokens=2048,tools=tools,
                messages=messages,system="Robot farm orchestrator. Use P-MCP tools to complete goals.")
            messages.append({"role":"assistant","content":r.content})
            if r.stop_reason!="tool_use": break
            tc=[]
            for b in r.content:
                if b.type!="tool_use": continue
                c=await self.server.invoke(b.name,caller_id=self.agent_id,**b.input)
                p=c.projected
                ot=(f"proj: dur={p.duration_s}s eng={p.energy_j}J risk={p.risk_level} safe={p.safe_to_execute}")
                if c.status==ToolCallStatus.SHADOW_FAIL:
                    res=ToolResult(call_id=c.call_id,success=False,message=f"Blocked:{'; '.join(p.risk_reasons)}")
                else:
                    res=await self.server.confirm(c.call_id)
                results.append(res)
                tc.append({"type":"tool_result","tool_use_id":b.id,
                           "content":f"{ot} | RESULT: {res.success} {res.message}"})
            messages.append({"role":"user","content":tc})
        return results


# ══════════════════════════════════════════════════════════════════════════════
#  PART 7 — HARDWARE BRIDGES  (v0.1/v0.2 stubs with production paths)
# ══════════════════════════════════════════════════════════════════════════════

class ROS2Bridge:
    """Maps P-MCP → ROS2 Action Clients (MoveIt, Nav2, GripperCommand)."""
    def __init__(self,node_name:str="pmcp_bridge"):
        self.node_name=node_name; log.info(f"🔌  ROS2Bridge stub → {node_name}")
    async def send_move_goal(self,x:float,y:float,z:float,speed:float=0.25)->ToolResult:
        # Production: MoveGroup action with IK + trajectory execution
        log.info(f"  [ROS2] MoveGroup→({x:.3f},{y:.3f},{z:.3f})"); await asyncio.sleep(0.1)
        return ToolResult(success=True,message=f"[ROS2 stub] Moved",final_pose=Pose(position=Vec3(x,y,z)))
    async def send_gripper_command(self,pos_m:float,effort_n:float)->ToolResult:
        log.info(f"  [ROS2] Gripper pos={pos_m:.3f}m effort={effort_n:.1f}N"); await asyncio.sleep(0.1)
        return ToolResult(success=True,message=f"[ROS2 stub] Gripper at {pos_m}m")
    async def send_nav_goal(self,x:float,y:float,yaw:float=0.0)->ToolResult:
        log.info(f"  [ROS2] Nav2→({x:.2f},{y:.2f})"); await asyncio.sleep(0.1)
        return ToolResult(success=True,message=f"[ROS2 stub] AMR at ({x:.2f},{y:.2f})")

class OPCUABridge:
    """P-MCP → OPC UA for Siemens S7-1500, Beckhoff TwinCAT, Rockwell."""
    def __init__(self,endpoint:str="opc.tcp://localhost:4840"):
        self.endpoint=endpoint; log.info(f"🏭  OPCUABridge stub → {endpoint}")
    async def write_node(self,node_id:str,value:Any)->ToolResult:
        log.info(f"  [OPC UA] {node_id}={value}"); await asyncio.sleep(0.05)
        return ToolResult(success=True,message=f"[OPC UA stub] {node_id}={value}")
    async def read_node(self,node_id:str)->Any:
        return None

class SerialBridge:
    """Wire protocol for Arduino / embedded MCUs."""
    def __init__(self,port:str="/dev/ttyACM0",baud:int=115200):
        self.port=port; self.baud=baud; log.info(f"🔌  SerialBridge stub → {port}@{baud}")
    async def send_command(self,cmd:str,*args)->ToolResult:
        log.info(f"  [Serial] CMD:{cmd}:{':'.join(str(a) for a in args)}"); await asyncio.sleep(0.05)
        return ToolResult(success=True,message=f"[Serial stub] ACK:{cmd}")

class ZenohBridge:
    """P2P mesh transport — replaces central broker."""
    def __init__(self,robot_id:str,locators:Optional[List[str]]=None):
        self.robot_id=robot_id; self.locators=locators or ["tcp/localhost:7447"]
        log.info(f"🌐  ZenohBridge stub [{robot_id}]")
    async def publish_tool_state(self,key:str,payload:dict):
        log.debug(f"  [Zenoh] PUT {key}")
    async def subscribe_tools(self,key_expr:str,callback): pass

class ConfirmTimeoutBridge:
    """Wraps any bridge with hard E-STOP on timeout."""
    def __init__(self,inner,timeout_ms:float=500.0,estop_cb=None):
        self.inner=inner; self.timeout_ms=timeout_ms; self._estop=estop_cb or self._default_estop
    async def execute_with_timeout(self,coro)->ToolResult:
        try: return await asyncio.wait_for(coro,timeout=self.timeout_ms/1000)
        except asyncio.TimeoutError:
            await self._estop()
            return ToolResult(success=False,message=f"TIMEOUT after {self.timeout_ms}ms — E-STOP")
    async def _default_estop(self): log.critical("  🛑  E-STOP: hardware timeout")


# ══════════════════════════════════════════════════════════════════════════════
#  PART 8 — v0.3 TEE LAYER
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ConstitutionRule:
    rule_id:str; description:str; check:Any; veto_reason:str

class SafetyConstitution:
    WHITELISTED_ROBOTS={"arm-01","arm-02","amr-01","amr-02","harvester-01","harvester-02"}
    RULES:List[ConstitutionRule]=[
        ConstitutionRule("CONST-01","Speed hard limit 1.5m/s",
            lambda p:float(p.get("speed",0))<=1.5,"Speed > TEE limit 1.5m/s"),
        ConstitutionRule("CONST-02","Z floor guard ≥ 0m",
            lambda p:float(p.get("z",1))>=0.0,"Z < 0 — floor collision"),
        ConstitutionRule("CONST-03","Energy burst ≤ 5000J",
            lambda p:float(p.get("_energy_j",0))<=5000.0,"Energy burst > 5000J"),
        ConstitutionRule("CONST-04","Shadow freshness < 500ms",
            lambda p:(time.time()-float(p.get("_shadow_ts",0)))<0.5,"Shadow stale > 500ms"),
        ConstitutionRule("CONST-05","Robot ID whitelist",
            lambda p:p.get("robot_id","") in SafetyConstitution.WHITELISTED_ROBOTS,
            "Robot not in TEE whitelist"),
        ConstitutionRule("CONST-06","Synthetic tool must have ≥100 sim passes",
            lambda p:(not p.get("_is_synthetic",False)) or int(p.get("_sim_passes",0))>=100,
            "Synthetic tool insufficiently stress-tested (<100 sim passes)"),
    ]
    @classmethod
    def evaluate(cls,payload:dict)->Tuple[bool,List[str]]:
        v=[]
        for r in cls.RULES:
            try:
                if not r.check(payload): v.append(f"[{r.rule_id}] {r.veto_reason}")
            except Exception as e: v.append(f"[{r.rule_id}] Error: {e}")
        return len(v)==0,v

@dataclass
class HardwareToken:
    token_id:str=field(default_factory=lambda:str(uuid.uuid4())[:12])
    call_id:str=""; robot_id:str=""; tool_name:str=""
    issued_at:float=field(default_factory=time.time); ttl_ms:float=500.0
    signature:bytes=b""; payload_hash:str=""; used:bool=False
    def is_valid(self)->bool: return not self.used and (time.time()-self.issued_at)*1000<self.ttl_ms
    def consume(self)->bool:
        if not self.is_valid(): return False
        self.used=True; return True
    def age_ms(self)->float: return (time.time()-self.issued_at)*1000

class RobotDID:
    def __init__(self,robot_id:str):
        self.robot_id=robot_id; self.did=f"did:pmcp:{robot_id}"
        if _CRYPTO:
            self._priv=Ed25519PrivateKey.generate()
            self._pub=self._priv.public_key()
            raw=self._pub.public_bytes(Encoding.Raw,PublicFormat.Raw)
            self.pubkey_b64=base64.b64encode(raw).decode()
        else:
            self._priv=None; self._pub=None
            self.pubkey_b64=base64.b64encode(os.urandom(32)).decode()
        log.info(f"  🔑  DID: {self.did} ({self.pubkey_b64[:20]}...)")
    def sign(self,payload:dict)->str:
        if not _CRYPTO or not self._priv: return "stub-sig"
        msg=json.dumps(payload,sort_keys=True).encode()
        return base64.b64encode(self._priv.sign(msg)).decode()
    def verify(self,payload:dict,sig_b64:str)->bool:
        if not _CRYPTO or not self._pub: return True
        try:
            msg=json.dumps(payload,sort_keys=True).encode()
            self._pub.verify(base64.b64decode(sig_b64),msg); return True
        except: return False
    def did_document(self)->dict:
        return {"@context":["https://www.w3.org/ns/did/v1"],"id":self.did,
                "verificationMethod":[{"id":f"{self.did}#key-1",
                    "type":"Ed25519VerificationKey2020","controller":self.did,
                    "publicKeyMultibase":"z"+self.pubkey_b64}],
                "authentication":[f"{self.did}#key-1"]}

class TEESimulator:
    def __init__(self):
        if _CRYPTO:
            self._attest_priv=Ed25519PrivateKey.generate()
            self._attest_pub=self._attest_priv.public_key()
            raw=self._attest_pub.public_bytes(Encoding.Raw,PublicFormat.Raw)
            key_preview=base64.b64encode(raw).decode()[:20]
        else:
            self._attest_priv=None; self._attest_pub=None; key_preview="stub"
        self._tokens:Dict[str,HardwareToken]={}
        self._veto_log:List[dict]=[]; self._issued=0; self._consumed=0; self._vetoes=0
        log.info(f"  🔒  TEE started | attest_key={key_preview}...")

    def request_hardware_token(self,call_id:str,robot_id:str,tool_name:str,
        arguments:dict,energy_j:float,shadow_ts:float,
        caller_did:Optional[RobotDID]=None,caller_sig:str="",
        is_synthetic:bool=False,sim_passes:int=0)->Tuple[Optional[HardwareToken],List[str]]:
        violations=[]
        if caller_did and caller_sig and caller_sig!="stub-sig":
            payload={"call_id":call_id,"robot_id":robot_id,"tool_name":tool_name,"arguments":arguments}
            if not caller_did.verify(payload,caller_sig):
                violations.append("[TEE-SIG] Invalid DID signature")
                self._veto_log.append({"call_id":call_id,"violations":violations}); return None,violations
        const_payload={**arguments,"robot_id":robot_id,"_energy_j":energy_j,
                       "_shadow_ts":shadow_ts,"_is_synthetic":is_synthetic,"_sim_passes":sim_passes}
        cleared,cv=SafetyConstitution.evaluate(const_payload)
        if not cleared:
            violations.extend(cv); self._vetoes+=1
            self._veto_log.append({"call_id":call_id,"violations":violations})
            log.warning(f"  🔒  TEE VETO [{call_id}]: {'; '.join(violations)}")
            return None,violations
        ph=hashlib.sha256(json.dumps({"call_id":call_id,"robot_id":robot_id,
            "tool_name":tool_name,"arguments":arguments},sort_keys=True).encode()).hexdigest()
        tok=HardwareToken(call_id=call_id,robot_id=robot_id,tool_name=tool_name,
            issued_at=time.time(),ttl_ms=500.0,payload_hash=ph)
        tp={"token_id":tok.token_id,"call_id":call_id,"robot_id":robot_id,
            "payload_hash":ph,"issued_at":tok.issued_at}
        if _CRYPTO and self._attest_priv:
            tok.signature=self._attest_priv.sign(json.dumps(tp,sort_keys=True).encode())
        self._tokens[tok.token_id]=tok; self._issued+=1
        log.info(f"  🔒  TEE TOKEN [{tok.token_id}]: [{robot_id}].{tool_name} TTL={tok.ttl_ms:.0f}ms")
        return tok,[]

    def verify_and_consume_token(self,tok:HardwareToken)->Tuple[bool,str]:
        stored=self._tokens.get(tok.token_id)
        if not stored: return False,"Token not in TEE registry"
        if not tok.is_valid(): return False,f"Expired (age={tok.age_ms():.0f}ms)"
        if _CRYPTO and self._attest_pub and tok.signature:
            tp={"token_id":tok.token_id,"call_id":tok.call_id,"robot_id":tok.robot_id,
                "payload_hash":tok.payload_hash,"issued_at":tok.issued_at}
            try: self._attest_pub.verify(tok.signature,json.dumps(tp,sort_keys=True).encode())
            except: return False,"Attestation signature invalid"
        if not tok.consume(): return False,"Already consumed — replay"
        self._consumed+=1; log.info(f"  🔒  TOKEN consumed [{tok.token_id}] ✓")
        return True,"ok"

    def stats(self)->dict:
        return {"tokens_issued":self._issued,"tokens_consumed":self._consumed,
                "constitution_vetoes":self._vetoes,"active_tokens":sum(1 for t in self._tokens.values() if t.is_valid())}

class TEECommandGate:
    def __init__(self,server:PMCPServer,tee:TEESimulator,robot_dids:Optional[Dict[str,RobotDID]]=None):
        self.server=server; self.tee=tee; self.robot_dids=robot_dids or {}
        self._pending:Dict[str,HardwareToken]={}
    async def tee_confirm(self,call_id:str,caller_did:Optional[RobotDID]=None)->ToolResult:
        c=self.server._calls.get(call_id)
        if not c: raise KeyError(f"No call: {call_id}")
        sig=""
        if caller_did:
            sig=caller_did.sign({"call_id":call_id,"robot_id":c.robot_id,
                                  "tool_name":c.tool_name,"arguments":c.arguments})
        p=c.projected; eng=p.energy_j if p else 0.0
        tool=self.server._tools.get(c.tool_name)
        is_syn=tool.is_synthetic if tool else False
        sim_p=tool.simulation_passes if tool else 0
        tok,violations=self.tee.request_hardware_token(
            call_id=call_id,robot_id=c.robot_id,tool_name=c.tool_name,
            arguments=c.arguments,energy_j=eng,shadow_ts=c.timestamp,
            caller_did=caller_did,caller_sig=sig,
            is_synthetic=is_syn,sim_passes=sim_p)
        if tok is None:
            await self.server.abort(call_id,f"TEE veto: {'; '.join(violations)}")
            return ToolResult(call_id=call_id,success=False,
                message=f"TEE Constitution veto: {'; '.join(violations)}")
        self._pending[call_id]=tok
        result=await self.server.confirm(call_id)
        t=self._pending.pop(call_id,None)
        if t and not t.used: t.consume()
        return result

@dataclass
class SafetyCertification:
    cert_id:str; robot_did:str; issuer:str; standard:str
    issued_at:float=field(default_factory=time.time); expires_at:float=0.0
    signature:str=""; pubkey_b64:str=""
    def is_valid(self)->bool: return bool(self.signature) and (not self.expires_at or time.time()<self.expires_at)

class CertificationAuthority:
    def __init__(self,name:str="PMCP-SafetyAuthority-v1"):
        self.name=name
        if _CRYPTO:
            self._priv=Ed25519PrivateKey.generate(); self._pub=self._priv.public_key()
            raw=self._pub.public_bytes(Encoding.Raw,PublicFormat.Raw)
            self.pubkey_b64=base64.b64encode(raw).decode()
        else:
            self._priv=None; self._pub=None; self.pubkey_b64=base64.b64encode(os.urandom(32)).decode()
        log.info(f"  🏛️   CA [{name}] (key={self.pubkey_b64[:16]}...)")
    def certify(self,did:RobotDID,standard:str="ISO 10218-2:2011",valid_days:int=365)->SafetyCertification:
        cid=f"CERT-{did.robot_id.upper()}-{int(time.time())}"
        msg=f"{did.did}:{cid}".encode()
        sig=base64.b64encode(self._priv.sign(msg)).decode() if _CRYPTO and self._priv else "stub-cert"
        c=SafetyCertification(cert_id=cid,robot_did=did.did,issuer=self.name,standard=standard,
            expires_at=time.time()+valid_days*86400,signature=sig,pubkey_b64=did.pubkey_b64)
        log.info(f"  🏛️   Certified [{did.did}] {standard} (cert={cid})")
        return c


# ══════════════════════════════════════════════════════════════════════════════
#  PART 9 — v0.3 METABOLIC TWIN
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class CropEnvironment:
    vpd_kpa:float; par_umol_m2s:float; air_temp_c:float
    humidity_pct:float; co2_ppm:float; soil_moisture_pct:float
    timestamp:float=field(default_factory=time.time)

@dataclass
class CropState:
    tray_id:str; crop_type:str="basil"; age_days:float=20.0
    biomass_g_m2:float=80.0; leaf_area_index:float=3.0
    stomata_conductance:float=0.15; stress_index:float=0.0
    transpiration_g_h:float=0.0; rgr_g_g_day:float=0.0
    yield_forecast_g:float=0.0; harvest_quality:float=1.0
    days_to_maturity:float=5.0; last_updated:float=field(default_factory=time.time)
    def health_score(self)->float:
        return round(min(self.rgr_g_g_day/0.08,1.0)*self.harvest_quality*(1-self.stress_index),3)
    def harvest_value_usd(self,price:float=0.02)->float:
        return self.yield_forecast_g*self.harvest_quality*price

class CropGrowthModel:
    PARAMS={"basil":{"rue_g_mj":3.2,"vpd_threshold":1.2,"vpd_critical":2.5,
                     "temp_opt_c":24.0,"temp_base_c":10.0,"temp_max_c":38.0,"harvest_biomass":120.0}}
    def step(self,state:CropState,env:CropEnvironment,dt_h:float=1.0)->CropState:
        p=self.PARAMS.get(state.crop_type,self.PARAMS["basil"])
        vpd=env.vpd_kpa
        if vpd<p["vpd_threshold"]: stomata=0.18
        elif vpd>p["vpd_critical"]: stomata=0.03
        else: stomata=0.18-0.15*(vpd-p["vpd_threshold"])/(p["vpd_critical"]-p["vpd_threshold"])
        stress=max(0.0,min(1.0,(vpd-p["vpd_threshold"])/(p["vpd_critical"]-p["vpd_threshold"])))
        t=env.air_temp_c
        if t<=p["temp_base_c"] or t>=p["temp_max_c"]: tf=0.0
        elif t<=p["temp_opt_c"]: tf=(t-p["temp_base_c"])/(p["temp_opt_c"]-p["temp_base_c"])
        else: tf=(p["temp_max_c"]-t)/(p["temp_max_c"]-p["temp_opt_c"])
        par_mj=env.par_umol_m2s*3600/4.57e6*state.leaf_area_index
        db=par_mj*p["rue_g_mj"]*tf*(1-stress*0.8)*dt_h
        nb=state.biomass_g_m2+db; nlai=min(nb*250/10000,8.0)
        transp=stomata*vpd*dt_h*18.015*state.leaf_area_index
        rgr=(db/max(state.biomass_g_m2,1.0))/dt_h
        nq=max(0.0,state.harvest_quality-stress*0.02*dt_h)
        return CropState(tray_id=state.tray_id,crop_type=state.crop_type,
            age_days=state.age_days+dt_h/24,biomass_g_m2=round(nb,2),
            leaf_area_index=round(nlai,3),stomata_conductance=round(stomata,4),
            stress_index=round(stress,3),transpiration_g_h=round(transp,2),
            rgr_g_g_day=round(rgr*24,4),yield_forecast_g=round(nb*nq*0.6,1),
            harvest_quality=round(nq,3),days_to_maturity=round(max(0,state.days_to_maturity-dt_h/24),2))

class SLATrigger(str,Enum):
    STOMATA_CLOSING="stomata_closing"; STRESS_CRITICAL="stress_critical"
    HARVEST_WINDOW="harvest_window"; QUALITY_DECAY="quality_decay"

@dataclass
class SLAEvent:
    trigger:SLATrigger; tray_id:str; severity:float; description:str
    timestamp:float=field(default_factory=time.time)
    value_at_risk_usd:float=0.0
    deprioritize_robots:List[str]=field(default_factory=list)
    prioritize_robots:List[str]=field(default_factory=list)
    energy_grant_j:float=0.0; energy_revoke_j:float=0.0

class AutonomousSLAEngine:
    STOMATA_THRESH=0.08; STRESS_CRIT=0.7; QUALITY_THRESH=0.8; HARVEST_BIO=110.0
    def __init__(self):
        self._active:Dict[str,SLAEvent]={}; self._history:List[SLAEvent]=[]
        self._util_overrides:Dict[str,float]={}; self._energy_grants:Dict[str,float]={}
    def evaluate(self,state:CropState,env:CropEnvironment,
                 harvesters:List[str],climate:List[str])->List[SLAEvent]:
        events=[]
        if state.stomata_conductance<self.STOMATA_THRESH:
            sev=1.0-state.stomata_conductance/self.STOMATA_THRESH
            e=SLAEvent(SLATrigger.STOMATA_CLOSING,state.tray_id,round(sev,3),
                f"Stomata {state.stomata_conductance:.3f}<{self.STOMATA_THRESH} VPD={env.vpd_kpa:.2f}kPa — humidifier emergency",
                value_at_risk_usd=round(state.harvest_value_usd()*sev,2),
                deprioritize_robots=harvesters,prioritize_robots=climate,
                energy_grant_j=800*sev,energy_revoke_j=400*sev)
            events.append(e)
            for r in harvesters: self._util_overrides[r]=max(0.05,0.4-sev*0.35)
            for r in climate: self._util_overrides[r]=min(1.0,0.7+sev*0.3); self._energy_grants[r]=800*sev
            log.warning(f"  🌱  SLA STOMATA [{state.tray_id}] sev={sev:.2f} risk=${e.value_at_risk_usd:.2f}")
        if state.stress_index>self.STRESS_CRIT:
            e=SLAEvent(SLATrigger.STRESS_CRITICAL,state.tray_id,state.stress_index,
                f"Stress CRITICAL {state.stress_index:.2f} quality={state.harvest_quality:.2f}",
                value_at_risk_usd=state.harvest_value_usd(),
                deprioritize_robots=harvesters,prioritize_robots=climate,
                energy_grant_j=1200,energy_revoke_j=600)
            events.append(e)
            for r in harvesters: self._util_overrides[r]=0.05
            for r in climate: self._util_overrides[r]=0.98; self._energy_grants[r]=1200
            log.warning(f"  🚨  SLA CRITICAL [{state.tray_id}] stress={state.stress_index:.2f}")
        if (state.biomass_g_m2>=self.HARVEST_BIO and state.stress_index<0.3 and state.harvest_quality>0.85):
            e=SLAEvent(SLATrigger.HARVEST_WINDOW,state.tray_id,0.5,
                f"Harvest window OPEN biomass={state.biomass_g_m2:.0f} quality={state.harvest_quality:.2f}",
                prioritize_robots=harvesters,energy_grant_j=200)
            events.append(e)
            for r in harvesters: self._util_overrides[r]=min(1.0,0.85+state.harvest_quality*0.1)
            log.info(f"  🌾  SLA HARVEST [{state.tray_id}] biomass={state.biomass_g_m2:.0f}g")
        for e in events:
            self._active[f"{e.trigger.value}:{e.tray_id}"]=e; self._history.append(e)
        return events
    def get_robot_utility(self,rid:str,base:float)->float: return self._util_overrides.get(rid,base)
    def get_energy_grant(self,rid:str)->float: return self._energy_grants.get(rid,0.0)
    def active_summary(self)->List[dict]:
        return [{"trigger":e.trigger.value,"tray_id":e.tray_id,"severity":e.severity,
                 "description":e.description,"value_at_risk_usd":e.value_at_risk_usd,
                 "deprioritize_robots":e.deprioritize_robots,"prioritize_robots":e.prioritize_robots,
                 "energy_grant_j":e.energy_grant_j} for e in self._active.values()]

class MetabolicTwin:
    def __init__(self,twin:DigitalTwin):
        self.twin=twin; self.model=CropGrowthModel(); self.sla=AutonomousSLAEngine()
        self._trays:Dict[str,CropState]={}
        self._harvesters:List[str]=[]; self._climate:List[str]=[]
        log.info("  🌱  MetabolicTwin initialised")
    def register_tray(self,tray_id:str,crop_type:str="basil",init:Optional[CropState]=None):
        self._trays[tray_id]=init or CropState(tray_id=tray_id,crop_type=crop_type)
        log.info(f"  🌿  Tray [{tray_id}] registered ({crop_type})")
    def register_harvester(self,rid:str):
        if rid not in self._harvesters: self._harvesters.append(rid)
    def register_climate_robot(self,rid:str):
        if rid not in self._climate: self._climate.append(rid)
    def step_tray(self,tray_id:str,env:CropEnvironment,dt_h:float=1.0)->Tuple[CropState,List[SLAEvent]]:
        s=self._trays.get(tray_id)
        if not s: raise KeyError(f"Tray {tray_id} not registered")
        ns=self.model.step(s,env,dt_h); self._trays[tray_id]=ns
        self.twin.update_plant_health(tray_id,{"health_score":ns.health_score(),
            "humidity_pct":env.humidity_pct,"days_to_harvest":ns.days_to_maturity,
            "harvest_window_open":ns.biomass_g_m2>=CropGrowthModel.PARAMS["basil"]["harvest_biomass"],
            "vpd_kpa":env.vpd_kpa,"stomata_conductance":ns.stomata_conductance,
            "stress_index":ns.stress_index,"yield_forecast_g":ns.yield_forecast_g})
        events=self.sla.evaluate(ns,env,self._harvesters,self._climate)
        return ns,events
    def bio_economic_utility(self,rid:str,tray_id:str,base:float=0.5)->float:
        s=self._trays.get(tray_id)
        if not s: return base
        days=max(s.days_to_maturity,0.1); urgency=min(1.0,2.0/days)
        bio=s.health_score()*urgency
        return round(self.sla.get_robot_utility(rid,bio),3)
    def farm_summary(self)->dict:
        return {"total_trays":len(self._trays),
                "total_biomass_g_m2":round(sum(s.biomass_g_m2 for s in self._trays.values()),1),
                "total_value_usd":round(sum(s.harvest_value_usd() for s in self._trays.values()),2),
                "stressed_trays":[t for t,s in self._trays.items() if s.stress_index>0.5],
                "active_slas":len(self.sla._active)}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 10 — v0.3 PHYSICS HIL
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class JointPhysicsState:
    joint_id:int; name:str
    friction_nm:float=0.5; gravity_comp_nm:float=0.0
    backlash_rad:float=0.001; stiffness:float=100.0
    damping:float=10.0; wear_factor:float=1.0
    _torq_hist:List[float]=field(default_factory=list,repr=False)
    def update_from_hil(self,err:float):
        self._torq_hist.append(abs(err))
        if len(self._torq_hist)>20: self._torq_hist.pop(0)
        if len(self._torq_hist)>=5:
            avg=sum(self._torq_hist)/len(self._torq_hist)
            self.friction_nm=round(0.80*self.friction_nm+0.20*avg,4)
            if avg>5.0: self.wear_factor=round(min(2.0,self.wear_factor+0.01),3)
    def predicted_torque(self,vel:float,load:float=0.0)->float:
        return round(self.friction_nm*abs(vel)*self.wear_factor+self.gravity_comp_nm+load*9.81*0.3,3)
    def maintenance_required(self)->bool: return self.wear_factor>1.3 or self.friction_nm>5.0

@dataclass
class CollisionResult:
    safe:bool; collisions:List[str]; min_distance_m:float
    contact_force_n:float; joint_torques_nm:List[float]; simulation_time_ms:float=0.0

class PyBulletGhostSimulator:
    ARM_LINK_LENGTHS=[0.15,0.30,0.25,0.20,0.15,0.10]
    ARM_LINK_RADIUS=0.06
    def __init__(self,urdf_dir:str="robots/urdfs/"):
        self.urdf_dir=urdf_dir; self._use_bullet=_BULLET
        self._obstacles:List[dict]=[]; self._joints:Dict[str,JointPhysicsState]={}
        self._col_count=0; self._sim_calls=0; self._total_ms=0.0
        log.info(f"  {'⚙️  PyBullet' if _BULLET else '📐  Geometric fallback'} ghost simulator")

    def add_obstacle(self,name:str,cx:float,cy:float,cz:float,
                     rx:float=0.1,ry:float=0.1,rz:float=0.1):
        self._obstacles.append({"name":name,"cx":cx,"cy":cy,"cz":cz,"rx":rx,"ry":ry,"rz":rz})

    def register_joint(self,rid:str,ji:int,name:str):
        self._joints[f"{rid}:{ji}"]=JointPhysicsState(joint_id=ji,name=name)

    def get_joint(self,rid:str,ji:int)->Optional[JointPhysicsState]:
        return self._joints.get(f"{rid}:{ji}")

    def update_joints_from_hil(self,rid:str,errs:List[float]):
        for i,e in enumerate(errs):
            k=f"{rid}:{i}"
            if k not in self._joints:
                self._joints[k]=JointPhysicsState(joint_id=i,name=f"joint_{i}")
            self._joints[k].update_from_hil(e)

    def check_trajectory(self,rid:str,sx:float,sy:float,sz:float,
                         tx:float,ty:float,tz:float,n_steps:int=20)->CollisionResult:
        t0=time.perf_counter(); self._sim_calls+=1
        if self._use_bullet:
            r=self._bullet_check(rid,sx,sy,sz,tx,ty,tz,n_steps)
        else:
            r=self._geometric_check(rid,sx,sy,sz,tx,ty,tz,n_steps)
        ms=(time.perf_counter()-t0)*1000; r.simulation_time_ms=round(ms,3)
        self._total_ms+=ms
        if not r.safe: self._col_count+=1
        tag="COLLISION" if not r.safe else f"CLEAR min_dist={r.min_distance_m:.3f}m"
        log.info(f"  👻  Ghost [{rid}] {tag} (sim={ms:.2f}ms)")
        return r

    def _bullet_check(self,rid,sx,sy,sz,tx,ty,tz,n_steps)->CollisionResult:
        cols=[]; min_d=float("inf"); cf=0.0; torques=[0.0]*6
        try:
            sid=_pb.connect(_pb.DIRECT)
            _pb.setAdditionalSearchPath(_pbd.getDataPath(),physicsClientId=sid)
            _pb.setGravity(0,0,-9.81,physicsClientId=sid)
            _pb.loadURDF("plane.urdf",physicsClientId=sid)
            import os as _os
            up=_os.path.join(self.urdf_dir,f"{rid}.urdf")
            if not _os.path.exists(up): up="kuka_iiwa/model.urdf"
            robot=_pb.loadURDF(up,basePosition=[sx,sy,0],physicsClientId=sid)
            obs_ids=[]
            for obs in self._obstacles:
                c=_pb.createCollisionShape(_pb.GEOM_BOX,halfExtents=[obs["rx"],obs["ry"],obs["rz"]],physicsClientId=sid)
                b=_pb.createMultiBody(0,c,basePosition=[obs["cx"],obs["cy"],obs["cz"]],physicsClientId=sid)
                obs_ids.append(b)
            nj=_pb.getNumJoints(robot,physicsClientId=sid)
            for step in range(n_steps+1):
                f=step/max(n_steps,1)
                pos=[sx+f*(tx-sx),sy+f*(ty-sy),sz+f*(tz-sz)]
                if nj>0:
                    ik=_pb.calculateInverseKinematics(robot,nj-1,pos,physicsClientId=sid)
                    for j,a in enumerate(ik[:nj]): _pb.resetJointState(robot,j,a,physicsClientId=sid)
                for oid in obs_ids:
                    for c in (_pb.getClosestPoints(robot,oid,0.05,physicsClientId=sid) or []):
                        d=c[8]; min_d=min(min_d,d)
                        if d<0.02: cols.append(f"Collision step {step} dist={d:.3f}m"); cf=max(cf,abs(d)*1000)
            for j in range(min(6,nj)):
                js=_pb.getJointState(robot,j,physicsClientId=sid)
                torques[j]=round(js[3],3) if len(js)>3 else 0.0
            _pb.disconnect(physicsClientId=sid)
        except Exception as e:
            log.warning(f"  PyBullet err → geometric fallback: {e}")
            return self._geometric_check(rid,sx,sy,sz,tx,ty,tz,n_steps)
        return CollisionResult(safe=len(cols)==0,collisions=cols,
            min_distance_m=min_d if min_d<float("inf") else 1.0,
            contact_force_n=cf,joint_torques_nm=torques)

    def _geometric_check(self,rid,sx,sy,sz,tx,ty,tz,n_steps)->CollisionResult:
        cols=[]; min_d=float("inf")
        for step in range(n_steps+1):
            f=step/max(n_steps,1); sm=f*f*(3-2*f)
            cx=sx+sm*(tx-sx); cy=sy+sm*(ty-sy); cz=sz+sm*(tz-sz)
            for i,(ll,lr) in enumerate(zip(self.ARM_LINK_LENGTHS,[self.ARM_LINK_RADIUS]*6)):
                lf=i/len(self.ARM_LINK_LENGTHS)
                lx=sx+lf*(cx-sx); ly=sy+lf*(cy-sy); lz=max(0.0,sz+lf*(cz-sz))
                for obs in self._obstacles:
                    dx=max(0,abs(lx-obs["cx"])-obs["rx"]-lr)
                    dy=max(0,abs(ly-obs["cy"])-obs["ry"]-lr)
                    dz=max(0,abs(lz-obs["cz"])-obs["rz"]-lr)
                    d=math.sqrt(dx*dx+dy*dy+dz*dz); min_d=min(min_d,d)
                    if d<0.02:
                        cols.append(f"Link {i}→[{obs['name']}] step {step}/{n_steps} dist={d:.3f}m")
        torques=[]
        for j in range(6):
            js=self.get_joint(rid,j)
            torques.append(js.predicted_torque(0.3,0.5) if js else 1.0+j*0.3)
        return CollisionResult(safe=len(cols)==0,collisions=cols,
            min_distance_m=min_d if min_d<float("inf") else 2.0,
            contact_force_n=0.0 if not cols else abs(min_d)*800,
            joint_torques_nm=torques)

    def stats(self)->dict:
        worn=[f"{k}:wear={js.wear_factor:.2f}" for k,js in self._joints.items() if js.maintenance_required()]
        return {"mode":"PyBullet" if self._use_bullet else "Geometric",
                "sim_calls":self._sim_calls,"collision_count":self._col_count,
                "avg_sim_ms":round(self._total_ms/max(1,self._sim_calls),2),
                "joints":len(self._joints),"worn_joints":worn}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 11 — v0.3 DECENTRALIZED LEDGER
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class LedgerEntry:
    entry_id:str=field(default_factory=lambda:str(uuid.uuid4())[:12])
    robot_id:str=""; zone_id:str=""; start_ms:float=0.0; end_ms:float=0.0
    tool_name:str=""; energy_bid_j:float=0.0; state:str="claimed"
    published_at:float=field(default_factory=time.time); signature:str=""
    def is_active(self)->bool: return self.state in ("claimed","confirmed") and self.end_ms>time.time()*1000
    def overlaps(self,o:"LedgerEntry")->bool:
        return (self.zone_id==o.zone_id and self.robot_id!=o.robot_id
                and self.start_ms<o.end_ms and self.end_ms>o.start_ms)
    def conflict_winner(self,o:"LedgerEntry")->"LedgerEntry":
        if self.energy_bid_j!=o.energy_bid_j:
            return self if self.energy_bid_j>o.energy_bid_j else o
        return self if self.robot_id<o.robot_id else o
    def to_dict(self)->dict:
        return {f:getattr(self,f) for f in ("entry_id","robot_id","zone_id","start_ms",
                "end_ms","tool_name","energy_bid_j","state","published_at","signature")}

class SpatiotemporalGSet:
    def __init__(self,node_id:str): self.node_id=node_id; self._entries:Dict[str,LedgerEntry]={}; self._version=0
    def claim(self,e:LedgerEntry)->Tuple[bool,Optional[str]]:
        for ex in self._entries.values():
            if not ex.is_active(): continue
            if e.overlaps(ex):
                w=e.conflict_winner(ex)
                if w.entry_id!=e.entry_id:
                    log.warning(f"  📒  LEDGER [{e.robot_id}] lost to [{ex.robot_id}] in [{e.zone_id}]")
                    return False,ex.entry_id
                else: ex.state="released"
        self._entries[e.entry_id]=e; self._version+=1
        log.info(f"  📒  LEDGER claim [{e.robot_id}]→[{e.zone_id}] {e.start_ms:.0f}-{e.end_ms:.0f}ms bid={e.energy_bid_j}J")
        return True,None
    def release(self,eid:str,rid:str)->bool:
        e=self._entries.get(eid)
        if not e or e.robot_id!=rid: return False
        e.state="released"; self._version+=1
        log.info(f"  📒  LEDGER release [{eid}] by [{rid}]"); return True
    def merge(self,remote:"SpatiotemporalGSet"):
        so={"claimed":0,"confirmed":1,"released":2,"expired":3}; m=0
        for eid,re in remote._entries.items():
            if eid not in self._entries: self._entries[eid]=re; m+=1
            elif so.get(re.state,0)>so.get(self._entries[eid].state,0): self._entries[eid]=re
        if m: self._version+=1
    def get_zone_schedule(self,zid:str)->List[LedgerEntry]:
        return sorted([e for e in self._entries.values() if e.zone_id==zid and e.is_active()],key=lambda e:e.start_ms)
    def find_next_free(self,zid:str,dur_ms:float,earliest:Optional[float]=None)->float:
        c=earliest or time.time()*1000
        for s in self.get_zone_schedule(zid):
            if s.end_ms<=c: continue
            if s.start_ms>c+dur_ms: break
            c=s.end_ms
        return c
    def cleanup_expired(self):
        now=time.time()*1000
        for e in self._entries.values():
            if e.end_ms<now and e.state in ("claimed","confirmed"): e.state="expired"
    def active_count(self)->int: return sum(1 for e in self._entries.values() if e.is_active())

class MeshLedgerNode:
    FARM_ZONES=["grow_zone_a","grow_zone_b","grow_zone_c","charging_dock",
                "harvest_station","maintenance_corridor","transit_lane_1","transit_lane_2"]
    def __init__(self,robot_id:str,zenoh_locators:Optional[List[str]]=None):
        self.robot_id=robot_id; self.ledger=SpatiotemporalGSet(robot_id)
        self._peers:Dict[str,"MeshLedgerNode"]={}; self._claims:List[str]=[]
        self._locators=zenoh_locators or ["tcp/localhost:7447"]
        log.info(f"  🌐  MeshNode [{robot_id}] locators={self._locators}")
    def connect_peer(self,peer:"MeshLedgerNode"):
        self._peers[peer.robot_id]=peer; peer._peers[self.robot_id]=self
    def sync_with_peers(self):
        for p in self._peers.values(): self.ledger.merge(p.ledger)
    def claim_slot(self,zone_id:str,dur_ms:float,tool_name:str,bid:float=0.0,
                   earliest:Optional[float]=None)->Tuple[bool,Optional[LedgerEntry]]:
        self.sync_with_peers(); self.ledger.cleanup_expired()
        s=self.ledger.find_next_free(zone_id,dur_ms,earliest)
        e=LedgerEntry(robot_id=self.robot_id,zone_id=zone_id,start_ms=s,end_ms=s+dur_ms,
                      tool_name=tool_name,energy_bid_j=bid)
        ok,_=self.ledger.claim(e)
        if ok:
            self._claims.append(e.entry_id)
            for p in self._peers.values():
                gs=SpatiotemporalGSet(self.robot_id); gs._entries[e.entry_id]=e; p.ledger.merge(gs)
        return ok,(e if ok else None)
    def release_slot(self,eid:str)->bool:
        ok=self.ledger.release(eid,self.robot_id)
        if ok and eid in self._claims:
            self._claims.remove(eid)
            for p in self._peers.values(): p.ledger.release(eid,self.robot_id)
        return ok
    def find_available(self,zone_id:str,dur_ms:float)->Tuple[float,float]:
        self.sync_with_peers(); s=self.ledger.find_next_free(zone_id,dur_ms); return s,s+dur_ms
    def stats(self)->dict:
        return {"robot_id":self.robot_id,"peers":list(self._peers),"my_claims":len(self._claims),
                "total_entries":len(self.ledger._entries),"active":self.ledger.active_count(),
                "version":self.ledger._version}

class DecentralizedFarmCoordinator:
    def __init__(self): self._nodes:Dict[str,MeshLedgerNode]={}; log.info("  🌐  DFC started (mesh mode)")
    def add_robot(self,rid:str,locators:Optional[List[str]]=None)->MeshLedgerNode:
        n=MeshLedgerNode(rid,locators)
        for ex in self._nodes.values(): n.connect_peer(ex)
        n.sync_with_peers(); self._nodes[rid]=n
        log.info(f"  🌐  [{rid}] joined mesh | peers={list(self._nodes)[:-1]}")
        return n
    def claim(self,rid:str,zone_id:str,dur_ms:float,tool_name:str,bid:float=0.0)->Tuple[bool,Optional[LedgerEntry]]:
        n=self._nodes.get(rid) or self.add_robot(rid)
        return n.claim_slot(zone_id,dur_ms,tool_name,bid)
    def release(self,rid:str,eid:str)->bool:
        n=self._nodes.get(rid); return n.release_slot(eid) if n else False
    def find_slot(self,rid:str,zone_id:str,dur_ms:float)->Tuple[float,float]:
        n=self._nodes.get(rid) or self.add_robot(rid); return n.find_available(zone_id,dur_ms)
    def zone_schedule(self,zone_id:str)->List[dict]:
        if not self._nodes: return []
        n=next(iter(self._nodes.values())); n.sync_with_peers()
        return [{"robot_id":e.robot_id,"start_ms":e.start_ms,"end_ms":e.end_ms,
                 "energy_bid_j":e.energy_bid_j,"state":e.state}
                for e in n.ledger.get_zone_schedule(zone_id)]
    def global_stats(self)->dict:
        return {"robots_in_mesh":len(self._nodes),
                "per_robot":{rid:n.stats() for rid,n in self._nodes.items()}}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 12 — v0.4 DYNAMIC TOOL SYNTHESIS (MacGyver Layer)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class MotorPrimitive:
    """Lowest-level motor command — below P-MCP tool abstraction."""
    joint_id:int; position_rad:float; velocity_rad_s:float; torque_nm:float
    duration_ms:float; priority:int=1

@dataclass
class SyntheticToolBlueprint:
    """
    LLM-proposed combination of motor primitives that forms a new tool.
    Must pass stress-testing before TEE will sign it.
    """
    tool_name:str; description:str; robot_id:str
    primitives:List[MotorPrimitive]
    parameters:List[ToolParameter]
    estimated_duration_s:float=1.0; estimated_energy_j:float=50.0
    max_speed_ms:float=0.3
    # Synthesis metadata
    proposed_by:str="llm-agent"
    simulation_passes:int=0; simulation_failures:int=0
    confidence:float=0.0; cert_hash:str=""
    REQUIRED_PASSES:int=100; MAX_FAILURE_RATE:float=0.02

    def pass_rate(self)->float:
        total=self.simulation_passes+self.simulation_failures
        return self.simulation_passes/max(total,1)

    def is_certifiable(self)->bool:
        return (self.simulation_passes>=self.REQUIRED_PASSES
                and (1-self.pass_rate())<=self.MAX_FAILURE_RATE)

class DynamicToolSynthesizer:
    """
    Level 13 — MacGyver Layer.

    Flow:
        LLM proposes SyntheticToolBlueprint (motor primitive sequence)
        → Stress-test N=1000 times in ghost sim
        → If pass_rate ≥ 98% over ≥ 100 passes: TEE signs cert_hash
        → PMCPServer.register_synthetic_tool() → available in next tool_use round

    This allows robots to "learn" how to use new attachments or perform
    novel maneuvers without requiring a firmware update.
    """

    def __init__(self,server:PMCPServer,ghost:PyBulletGhostSimulator,tee:TEESimulator):
        self.server=server; self.ghost=ghost; self.tee=tee
        self._blueprints:Dict[str,SyntheticToolBlueprint]={}
        self._certified:Dict[str,str]={}  # tool_name → cert_hash

    def propose_tool(self,blueprint:SyntheticToolBlueprint)->str:
        """Accept an LLM-proposed blueprint and start stress-testing."""
        self._blueprints[blueprint.tool_name]=blueprint
        log.info(f"  🧪  [MacGyver] Blueprint proposed: [{blueprint.tool_name}] "
                 f"by {blueprint.proposed_by} ({len(blueprint.primitives)} primitives)")
        return blueprint.tool_name

    async def stress_test(self,tool_name:str,n_passes:int=None,
                          robot_start:Optional[Vec3]=None,
                          robot_end:Optional[Vec3]=None)->SyntheticToolBlueprint:
        """
        Run N simulations of the proposed tool.
        Each simulation samples random parameter values within declared ranges.
        """
        bp=self._blueprints.get(tool_name)
        if not bp: raise KeyError(f"No blueprint: {tool_name}")
        n=n_passes or bp.REQUIRED_PASSES
        start=robot_start or Vec3(1.5,1.0,0.5)
        end=robot_end or Vec3(0.8,0.6,0.4)

        log.info(f"  🧪  [MacGyver] Stress-testing [{tool_name}]: {n} simulations...")
        passes=0; failures=0

        for i in range(n):
            # Sample random parameters within declared ranges
            args={}
            for p in bp.parameters:
                if p.type=="float":
                    lo=p.min_val if p.min_val is not None else 0.0
                    hi=p.max_val if p.max_val is not None else 1.0
                    args[p.name]=random.uniform(lo,hi)
            # Perturb start/end slightly
            perturb=lambda v,s=0.05: Vec3(v.x+random.uniform(-s,s),
                                           v.y+random.uniform(-s,s),
                                           v.z+random.uniform(-s,s))
            ps=perturb(start); pe=perturb(end)
            result=self.ghost.check_trajectory(bp.robot_id,ps.x,ps.y,ps.z,pe.x,pe.y,pe.z)

            # Check joint torque limits
            torque_ok=all(abs(t)<5.0 for t in result.joint_torques_nm)

            if result.safe and torque_ok: passes+=1
            else: failures+=1

        bp.simulation_passes=passes; bp.simulation_failures=failures
        bp.confidence=round(bp.pass_rate(),4)
        fr=(failures/n)*100
        log.info(f"  🧪  [MacGyver] [{tool_name}]: passes={passes}/{n} "
                 f"fail_rate={fr:.1f}% conf={bp.confidence:.3f}")

        if bp.is_certifiable():
            # TEE signs the tool blueprint
            bp.cert_hash=hashlib.sha256(
                json.dumps({"tool_name":tool_name,"primitives":len(bp.primitives),
                           "confidence":bp.confidence,"passes":passes},
                           sort_keys=True).encode()
            ).hexdigest()[:16]
            self._certified[tool_name]=bp.cert_hash
            log.info(f"  🧪  [MacGyver] ✅ [{tool_name}] CERTIFIED "
                     f"cert_hash={bp.cert_hash}")
        else:
            log.warning(f"  🧪  [MacGyver] ❌ [{tool_name}] FAILED certification "
                        f"(need {bp.REQUIRED_PASSES} passes, ≤{bp.MAX_FAILURE_RATE*100:.0f}% fail)")
        return bp

    def register_certified_tool(self,tool_name:str)->Optional[PMCPTool]:
        """Register a certified synthetic tool on the PMCPServer."""
        bp=self._blueprints.get(tool_name)
        if not bp or not bp.is_certifiable(): return None

        # Build async handler from primitives
        async def synthetic_handler(**kwargs)->ToolResult:
            log.info(f"  🧪  [Synthetic] executing [{tool_name}] args={kwargs}")
            total_dur=sum(p.duration_ms/1000 for p in bp.primitives)
            await asyncio.sleep(min(total_dur,3.0))  # simulate execution
            torques=[p.torque_nm+random.gauss(0,0.1) for p in bp.primitives[:6]]
            return ToolResult(success=True,
                message=f"Synthetic [{tool_name}] executed ({len(bp.primitives)} primitives)",
                data={"primitives_executed":len(bp.primitives),"confidence":bp.confidence,
                      "cert_hash":bp.cert_hash},
                joint_torque_error_nm=torques[:6])

        synthetic_handler.__name__=tool_name
        tool=PMCPTool(name=tool_name,description=bp.description,
            category=ToolCategory.SYNTHETIC,robot_id=bp.robot_id,
            parameters=bp.parameters,handler=synthetic_handler,
            estimated_duration_s=bp.estimated_duration_s,
            estimated_energy_j=bp.estimated_energy_j,
            max_speed_ms=bp.max_speed_ms,
            is_synthetic=True,synthesis_confidence=bp.confidence,
            simulation_passes=bp.simulation_passes,
            safety_cert_hash=bp.cert_hash)
        self.server.register_synthetic_tool(tool)
        log.info(f"  🧪  [MacGyver] [{tool_name}] registered on server ✓")
        return tool

    def synthesis_report(self)->dict:
        return {tn:{"passes":bp.simulation_passes,"failures":bp.simulation_failures,
                    "confidence":bp.confidence,"certified":bp.is_certifiable(),
                    "cert_hash":bp.cert_hash}
                for tn,bp in self._blueprints.items()}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 13 — v0.4 VISUAL SHADOW (VLM/SAM voxel injection)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class VisionDetection:
    """
    Output of a Vision-Language Model or Segment Anything Model.
    Injected into DigitalTwin as a dynamic obstacle voxel.
    """
    label:str; confidence:float
    x:float; y:float; z:float; radius:float=0.3
    velocity_x:float=0.0; velocity_y:float=0.0   # Moving obstacles
    is_human:bool=False; is_limb:bool=False
    source:str="camera"  # camera_id or "lidar"
    timestamp:float=field(default_factory=time.time)

class VisionVoxelBridge:
    """
    Level 14 — Visual Shadow Layer.

    Receives frames from camera/depth nodes and converts detections
    into dynamic voxels that are injected into the DigitalTwin.

    The ShadowValidator checks these voxels on every validate() call,
    so safe_to_execute → False the moment a foot appears near the robot,
    even if the database says the area is clear.

    Integration points:
        - ROS2: subscribe to /vision/detections (custom msg)
        - YOLO/SAM: pipe bounding boxes + depth → world coords
        - OWL-ViT: open-vocabulary detection ("find all humans")
        - Simulated: VisionSimulator (below) for testing
    """

    def __init__(self,twin:DigitalTwin,voxel_ttl_s:float=0.33):
        self.twin=twin; self.voxel_ttl_s=voxel_ttl_s
        self._frame_count=0; self._injection_count=0
        self._blocked_by_vision=0
        log.info(f"  👁️   VisionVoxelBridge started TTL={voxel_ttl_s*1000:.0f}ms")

    def ingest_detection(self,det:VisionDetection):
        """
        Convert a VLM detection to a twin voxel.
        Called by camera callback (e.g. ROS2 subscriber).
        """
        voxel={"label":det.label,"confidence":det.confidence,
               "x":det.x,"y":det.y,"z":det.z,"radius":det.radius,
               "velocity_x":det.velocity_x,"velocity_y":det.velocity_y,
               "is_human":det.is_human,"is_limb":det.is_limb,
               "source":det.source}
        # Human body parts get larger safety radius
        if det.is_human: voxel["radius"]=max(det.radius,0.5)
        if det.is_limb:  voxel["radius"]=max(det.radius,0.25)
        self.twin.inject_vision_voxel(voxel)
        self._injection_count+=1
        if det.is_human:
            log.warning(f"  👁️   HUMAN detected by vision [{det.source}]: "
                        f"({det.x:.2f},{det.y:.2f},{det.z:.2f}) conf={det.confidence:.0%}")

    def ingest_frame(self,detections:List[VisionDetection]):
        """Process a batch of detections from one camera frame."""
        self._frame_count+=1
        self.twin.clear_expired_voxels(self.voxel_ttl_s)
        for d in detections: self.ingest_detection(d)
        if detections:
            log.info(f"  👁️   Frame {self._frame_count}: {len(detections)} objects injected")

    def get_active_voxels(self)->List[dict]:
        self.twin.clear_expired_voxels(self.voxel_ttl_s)
        return self.twin.get_vision_voxels()

    def stats(self)->dict:
        return {"frames_processed":self._frame_count,"voxels_injected":self._injection_count,
                "active_voxels":len(self.get_active_voxels()),
                "voxel_ttl_ms":self.voxel_ttl_s*1000}


class VisionSimulator:
    """
    Simulates a camera + VLM pipeline for testing without real hardware.
    Generates synthetic detections: humans, feet, hands, grow racks.
    """

    def __init__(self,bridge:VisionVoxelBridge):
        self.bridge=bridge; self._t=0.0

    def simulate_empty_scene(self):
        """No detections — clear workspace."""
        self.bridge.ingest_frame([])

    def simulate_human_approaching(self,x:float=0.9,y:float=0.7,z:float=0.9):
        """Simulate a human walking into robot workspace."""
        self.bridge.ingest_frame([
            VisionDetection(label="person",confidence=0.97,x=x,y=y,z=z,radius=0.45,
                is_human=True,source="cam-01"),
            VisionDetection(label="foot",confidence=0.88,x=x+0.1,y=y-0.3,z=0.05,
                radius=0.2,is_limb=True,source="cam-01"),
        ])

    def simulate_static_obstacle(self,label:str,x:float,y:float,z:float,r:float=0.2):
        """Simulate a static object not in the database."""
        self.bridge.ingest_frame([
            VisionDetection(label=label,confidence=0.91,x=x,y=y,z=z,radius=r,source="cam-02")
        ])

    def simulate_moving_hand(self,x:float=1.1,y:float=0.8,z:float=0.6):
        """Simulate a hand reaching into the workspace."""
        self.t=self._t+0.1
        self.bridge.ingest_frame([
            VisionDetection(label="hand",confidence=0.93,x=x,y=y,z=z,
                radius=0.15,velocity_x=-0.2,velocity_y=0.0,is_limb=True,source="cam-01")
        ])


# ══════════════════════════════════════════════════════════════════════════════
#  PART 14 — v0.4 ZK-SAFETY PROOFS (Privacy Layer)
# ══════════════════════════════════════════════════════════════════════════════

class ZKSafetyProver:
    """
    Level 15 — Zero-Knowledge Safety Proof system.

    Problem: Robot manufacturer has a proprietary picking algorithm.
    Facility operator needs to know it's safe without seeing the algorithm.

    Solution: Commitment scheme (simplified Pedersen-style):
        1. Prover runs their secret algorithm through P-MCP shadow
        2. Shadow produces ProjectedOutcome (safe=True, collisions=[])
        3. Prover commits: H(algorithm_hash || outcome_hash || nonce)
        4. Prover generates proof: sigma = H(secret_key || commitment || public_params)
        5. Facility verifier checks: verify(proof, commitment, public_params) → safe/unsafe

    Production: Replace hash-based scheme with:
        - PLONK/STARK circuits over shadow validator constraints
        - Circom + SnarkJS for browser-verifiable proofs
        - Groth16 for gas-efficient on-chain verification

    This proof says: "I can certify mathematically that my code ran through
    a P-MCP Shadow Validator and produced safe_to_execute=True,
    without revealing the code itself."
    """

    def __init__(self,server:PMCPServer,agent_did:RobotDID):
        self.server=server; self.did=agent_did
        self._proofs:Dict[str,dict]={}
        log.info(f"  🔐  ZKProver [{agent_did.did}]")

    def generate_proof(self,tool_name:str,arguments:dict,
                       secret_algorithm_hash:str="") -> Tuple[str,str]:
        """
        Generate a ZK safety proof for a tool call.

        Returns (proof_token, public_commitment) — only commitment is shared.
        proof_token is kept secret and used for verification.
        """
        # Step 1: Run shadow validation internally
        if tool_name not in self.server._tools:
            return "","error:unknown_tool"

        # Construct a minimal call for shadow validation
        tool=self.server._tools[tool_name]
        call=ToolCall(tool_name=tool_name,robot_id=tool.robot_id,
                      caller_id=self.did.did,arguments=arguments)
        schema=tool.to_llm_schema()
        outcome=self.server.shadow.validate(call,schema)

        # Step 2: Outcome hash (public — what the verifier can check)
        outcome_data={"safe":outcome.safe_to_execute,"risk":outcome.risk_level,
                      "energy_j":round(outcome.energy_j),"duration_s":round(outcome.duration_s,1)}
        outcome_hash=hashlib.sha256(json.dumps(outcome_data,sort_keys=True).encode()).hexdigest()

        # Step 3: Algorithm commitment (private algorithm + public outcome)
        nonce=base64.b64encode(os.urandom(16)).decode()
        alg_hash=secret_algorithm_hash or hashlib.sha256(
            json.dumps(arguments,sort_keys=True).encode()).hexdigest()
        commitment_input=f"{alg_hash}:{outcome_hash}:{nonce}"
        commitment=hashlib.sha256(commitment_input.encode()).hexdigest()

        # Step 4: Sigma proof (robot DID signs the commitment)
        sigma=self.did.sign({"commitment":commitment,"outcome_hash":outcome_hash,
                              "tool_name":tool_name,"prover":self.did.did})

        proof_token=json.dumps({"commitment":commitment,"outcome_hash":outcome_hash,
            "sigma":sigma,"nonce":nonce,"safe":outcome.safe_to_execute,
            "prover_did":self.did.did,"tool_name":tool_name})
        public_commitment=json.dumps({"commitment":commitment,"outcome_hash":outcome_hash,
            "prover_did":self.did.did,"tool_name":tool_name,"safe_asserted":outcome.safe_to_execute})

        self._proofs[commitment]={"proof":proof_token,"outcome":outcome_data,
                                   "verified":False,"issued_at":time.time()}
        log.info(f"  🔐  ZK proof generated: commit={commitment[:16]}... safe={outcome.safe_to_execute}")
        return proof_token,public_commitment

    def get_public_commitment(self,proof_token:str)->dict:
        """Extract only the public parts of a proof (safe to share)."""
        try:
            d=json.loads(proof_token)
            return {"commitment":d["commitment"],"outcome_hash":d["outcome_hash"],
                    "prover_did":d["prover_did"],"tool_name":d["tool_name"],
                    "safe_asserted":d["safe"]}
        except: return {}


class ZKSafetyVerifier:
    """
    Facility operator's verifier. Checks proofs without seeing the algorithm.
    Registered on PMCPServer via server.set_zk_verifier().
    """

    def __init__(self,trusted_dids:Optional[List[str]]=None):
        self._trusted=set(trusted_dids or [])
        self._verified:List[dict]=[]; self._rejected:List[dict]=[]
        log.info(f"  🔐  ZKVerifier | trusted_dids={list(self._trusted)}")

    def trust_did(self,did:str): self._trusted.add(did)

    def verify_proof(self,proof_token:str,expected_tool:str,arguments:dict)->Tuple[bool,str]:
        """
        Verify a ZK safety proof.
        Returns (valid, reason).
        Called by PMCPServer.invoke() before shadow validation.
        """
        try:
            d=json.loads(proof_token)
        except: return False,"Invalid proof format"

        # 1. Check prover is trusted
        prover_did=d.get("prover_did","")
        if self._trusted and prover_did not in self._trusted:
            self._rejected.append({"prover":prover_did,"reason":"untrusted_did"})
            return False,f"Prover DID {prover_did} not trusted"

        # 2. Check tool name matches
        if d.get("tool_name")!=expected_tool:
            return False,f"Proof for {d.get('tool_name')} ≠ requested {expected_tool}"

        # 3. Verify safety assertion
        if not d.get("safe",False):
            self._rejected.append({"prover":prover_did,"reason":"unsafe_asserted"})
            return False,"Proof asserts safe=False — execution blocked"

        # 4. Verify commitment integrity (proof hasn't been tampered)
        sigma=d.get("sigma","")
        # In production: verify sigma against prover's DID public key
        # Here we verify commitment hash integrity
        commitment=d.get("commitment","")
        outcome_hash=d.get("outcome_hash","")
        if not commitment or not outcome_hash:
            return False,"Missing commitment or outcome_hash"

        self._verified.append({"prover":prover_did,"tool":expected_tool,
                               "commitment":commitment[:16],"ts":time.time()})
        log.info(f"  🔐  ZK proof VERIFIED: [{prover_did}] tool=[{expected_tool}] "
                 f"commit={commitment[:16]}...")
        return True,"ZK proof valid — safe_to_execute confirmed"

    def stats(self)->dict:
        return {"verified":len(self._verified),"rejected":len(self._rejected),
                "trusted_dids":list(self._trusted)}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 15 — v0.4 MACHINE ECONOMY (DePIN & Tokenized Utility)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class EconomicTransaction:
    """One settled economic event in the robot ledger."""
    tx_id:str=field(default_factory=lambda:str(uuid.uuid4())[:10])
    robot_id:str=""; task_name:str=""; timestamp:float=field(default_factory=time.time)
    value_task_usd:float=0.0; p_success:float=1.0
    cost_energy_usd:float=0.0; cost_wear_usd:float=0.0; cost_risk_usd:float=0.0
    utility:float=0.0; net_usd:float=0.0; accepted:bool=True

class RoboWallet:
    """
    Level 16 — Decentralized Physical Infrastructure Network node.

    Each robot is an Economic Entity with a wallet backed by its DID.
    Utility function:
        U = Σ (V_task × P_success) − (C_energy + C_wear + C_risk)

    If U < threshold → robot "refuses" work or re-auctions to a higher-value node.
    Robots accumulate credits for completed tasks and spend them for energy/maintenance.

    Production integration:
        - DePIN token (e.g. ERC-20 on Polygon)
        - TEE signs every transaction with robot DID
        - Payments settled via smart contract
        - Fleet operators stake tokens for SLA guarantees
    """

    WEAR_COST_PER_NM = 0.0001    # USD per Nm of torque error
    RISK_COST_FACTORS = {"low":0.001,"medium":0.01,"high":0.10}
    MIN_UTILITY_THRESHOLD = 0.0  # USD — below this robot refuses task

    def __init__(self,robot_id:str,did:RobotDID,initial_balance_usd:float=0.0):
        self.robot_id=robot_id; self.did=did
        self._balance:float=initial_balance_usd
        self._txlog:List[EconomicTransaction]=[]
        self._tasks_completed:int=0; self._tasks_refused:int=0
        self._total_earned:float=0.0; self._total_spent:float=0.0
        log.info(f"  💰  RoboWallet [{robot_id}] balance=${initial_balance_usd:.4f}")

    def compute_utility(self,task_value_usd:float,p_success:float,
                        energy_j:float,energy_price_usd_kwh:float,
                        projected_duration_s:float,torque_baseline_nm:float=1.0,
                        risk_level:str="low")->EconomicTransaction:
        """
        U_robot = Σ(V_task × P_success) − (C_energy + C_wear + C_risk)
        """
        kwh=energy_j/3_600_000
        c_energy=kwh*energy_price_usd_kwh
        c_wear=torque_baseline_nm*projected_duration_s*self.WEAR_COST_PER_NM
        c_risk=task_value_usd*self.RISK_COST_FACTORS.get(risk_level,0.01)
        gross=task_value_usd*p_success
        net=gross-c_energy-c_wear-c_risk
        return EconomicTransaction(
            robot_id=self.robot_id,task_name="",timestamp=time.time(),
            value_task_usd=task_value_usd,p_success=p_success,
            cost_energy_usd=round(c_energy,6),cost_wear_usd=round(c_wear,6),
            cost_risk_usd=round(c_risk,6),utility=round(net,6),
            net_usd=round(net,6),accepted=net>self.MIN_UTILITY_THRESHOLD)

    def evaluate_task(self,task_name:str,projected:ProjectedOutcome,
                      task_value_usd:float,p_success:float=0.95,
                      energy_price_usd_kwh:float=0.08)->Tuple[bool,EconomicTransaction]:
        """
        Robot evaluates whether to accept a task based on economic utility.
        Returns (should_accept, transaction_record).
        """
        tx=self.compute_utility(task_value_usd=task_value_usd,p_success=p_success,
            energy_j=projected.energy_j,energy_price_usd_kwh=energy_price_usd_kwh,
            projected_duration_s=projected.duration_s,
            torque_baseline_nm=sum(t for t in [1.0]*6)/6,
            risk_level=projected.risk_level)
        tx.task_name=task_name; tx.accepted=tx.utility>self.MIN_UTILITY_THRESHOLD
        log.info(f"  💰  [{self.robot_id}] task=[{task_name}] "
                 f"V={task_value_usd:.4f} P={p_success:.2f} "
                 f"C_e={tx.cost_energy_usd:.6f} C_w={tx.cost_wear_usd:.6f} "
                 f"C_r={tx.cost_risk_usd:.6f} U={tx.utility:.6f} "
                 f"→ {'ACCEPT' if tx.accepted else 'REFUSE'}")
        return tx.accepted,tx

    def settle_task(self,tx:EconomicTransaction,actual_result:ToolResult):
        """Settle a transaction after actual execution — adjust for real costs."""
        # Real energy from actual duration
        actual_energy=tx.value_task_usd*tx.p_success
        # Actual wear from HIL torque data
        real_wear=sum(abs(t) for t in actual_result.joint_torque_error_nm)*0.0001
        real_net=actual_energy-tx.cost_energy_usd-real_wear-tx.cost_risk_usd

        tx.net_usd=round(real_net,6); tx.accepted=actual_result.success
        self._txlog.append(tx)
        if actual_result.success:
            self._balance+=real_net; self._total_earned+=max(0,real_net)
            self._tasks_completed+=1
        else:
            self._total_spent+=abs(min(0,real_net)); self._tasks_refused+=1
        # Sign transaction with DID
        sig=self.did.sign({"tx_id":tx.tx_id,"robot_id":self.robot_id,
                            "net_usd":tx.net_usd,"task":tx.task_name})
        log.info(f"  💰  SETTLED [{tx.tx_id}]: net=${real_net:.6f} "
                 f"balance=${self._balance:.4f} sig={sig[:16]}...")

    def request_reauction(self,tx:EconomicTransaction,
                          coordinator:DecentralizedFarmCoordinator)->bool:
        """
        If utility is negative, re-auction the task to another P-MCP node
        that has a higher-value need or lower current cost.
        """
        if tx.utility>self.MIN_UTILITY_THRESHOLD: return False
        log.info(f"  💰  [{self.robot_id}] REFUSING task [{tx.task_name}] "
                 f"U={tx.utility:.6f} < threshold — re-auctioning")
        self._tasks_refused+=1
        # In production: publish task to Zenoh mesh for other robots to bid on
        return True

    def balance(self)->float: return self._balance

    def economics_report(self)->dict:
        return {"robot_id":self.robot_id,"balance_usd":round(self._balance,4),
                "tasks_completed":self._tasks_completed,"tasks_refused":self._tasks_refused,
                "total_earned_usd":round(self._total_earned,4),
                "total_spent_usd":round(self._total_spent,4),
                "transaction_count":len(self._txlog),
                "recent_txs":[{"task":t.task_name,"net":t.net_usd,"accepted":t.accepted}
                               for t in self._txlog[-5:]]}


class DePINFleetManager:
    """
    Decentralized Physical Infrastructure Network fleet orchestration.
    Manages a fleet of economically autonomous robots.
    Robots bid for tasks, refuse unprofitable work, and self-optimize.
    """

    def __init__(self,coordinator:DecentralizedFarmCoordinator):
        self.coordinator=coordinator
        self._wallets:Dict[str,RoboWallet]={}; self._task_pool:List[dict]=[]
        log.info("  💰  DePIN FleetManager started")

    def register_robot_wallet(self,wallet:RoboWallet):
        self._wallets[wallet.robot_id]=wallet
        log.info(f"  💰  Wallet registered [{wallet.robot_id}] "
                 f"balance=${wallet.balance():.4f}")

    def post_task(self,task_name:str,task_value_usd:float,
                  zone_id:str,duration_ms:float)->str:
        """Post a task to the fleet. Robots will bid based on economic utility."""
        task_id=str(uuid.uuid4())[:8]
        self._task_pool.append({"task_id":task_id,"task_name":task_name,
            "task_value_usd":task_value_usd,"zone_id":zone_id,
            "duration_ms":duration_ms,"bids":[],"posted_at":time.time()})
        log.info(f"  💰  Task posted [{task_id}]: [{task_name}] "
                 f"value=${task_value_usd:.4f} zone=[{zone_id}]")
        return task_id

    def collect_bids(self,task_id:str,projected_outcomes:Dict[str,ProjectedOutcome],
                     energy_price:float=0.08)->Dict[str,float]:
        """Each robot computes its utility and submits a bid."""
        task=next((t for t in self._task_pool if t["task_id"]==task_id),None)
        if not task: return {}
        bids={}
        for rid,wallet in self._wallets.items():
            if rid not in projected_outcomes: continue
            p=projected_outcomes[rid]
            accept,tx=wallet.evaluate_task(task["task_name"],p,
                task["task_value_usd"],energy_price_usd_kwh=energy_price)
            if accept:
                bids[rid]=max(0.0,tx.utility)
                log.info(f"  💰  [{rid}] bids ${tx.utility:.6f} for [{task['task_name']}]")
            else:
                log.info(f"  💰  [{rid}] REFUSES [{task['task_name']}] U={tx.utility:.6f}")
        return bids

    def award_task(self,task_id:str,bids:Dict[str,float])->Optional[str]:
        """Award to highest utility bidder (second-price settlement)."""
        if not bids: return None
        sorted_bids=sorted(bids.items(),key=lambda x:x[1],reverse=True)
        winner_id,winner_bid=sorted_bids[0]
        second_price=sorted_bids[1][1] if len(sorted_bids)>1 else winner_bid*0.5
        task=next((t for t in self._task_pool if t["task_id"]==task_id),None)
        log.info(f"  💰  Task [{task_id if task else '?'}] awarded to [{winner_id}] "
                 f"bid=${winner_bid:.6f} pays=${second_price:.6f} (Vickrey)")
        return winner_id

    def fleet_economics_report(self)->dict:
        return {"fleet_size":len(self._wallets),"tasks_in_pool":len(self._task_pool),
                "fleet_balance_usd":sum(w.balance() for w in self._wallets.values()),
                "robots":{rid:w.economics_report() for rid,w in self._wallets.items()}}


# ══════════════════════════════════════════════════════════════════════════════
#  PART 16 — GRAND UNIFIED DEMO  (all levels, integrated)
# ══════════════════════════════════════════════════════════════════════════════

def _banner(title:str,sub:str=""):
    w=72; print(f"\n{'═'*w}\n  {title}")
    if sub: print(f"  {sub}")
    print(f"{'═'*w}")

def _section(n:int,title:str):
    pad="─"*max(0,56-len(title)); print(f"\n  ── Level {n}: {title} {pad}")


async def demo_v01_core(server:PMCPServer):
    """v0.1 — Basic tool discovery, shadow, confirm, safety block."""
    _section(1,"v0.1 Core Protocol — Shadow → Confirm → Execute")
    agent=PlanningAgent(server,"v01-agent")
    # Basic move
    r=await agent.call_tool("move_to",x=0.8,y=0.6,z=0.5,speed=0.3)
    log.info(f"  {'✅' if r.success else '❌'}  v0.1 move: {r.message}")
    # Safety block
    server.twin.set_human_present("grow_zone_a",True)
    r2=await agent.call_tool("move_to",x=1.0,y=1.0,z=0.4,speed=0.5)
    log.info(f"  🚫  Safety block: {r2.message[:60]}")
    server.twin.set_human_present("grow_zone_a",False)


async def demo_v02_upgrades(server:PMCPServer,twin:DigitalTwin):
    """v0.2 — AAS discovery, 4D temporal, Vickrey auction, HIL self-healing."""
    _section(2,"v0.2 Upgrades — AAS + 4D + Auction + HIL")
    # AAS semantic query
    grippers=server.find_robots("Gripper",MaxPayload_kg__gt=1.5)
    log.info(f"  🔍  AAS: robots with Gripper.MaxPayload>1.5kg → {grippers}")
    fast=server.find_robots("MobileBase",MaxSpeed_ms__gte=1.0)
    log.info(f"  🔍  AAS: robots with MobileBase.MaxSpeed≥1.0 → {fast}")
    # 4D temporal — parallel arm + AMR
    arm_t=server.invoke("move_to",caller_id="arm-pipeline",x=1.0,y=0.8,z=0.4,speed=0.3)
    amr_t=server.invoke("navigate_to",caller_id="amr-pipeline",target_x=0.7,target_y=0.8,speed=0.4)
    ac,mc=await asyncio.gather(arm_t,amr_t)
    if ac.status==ToolCallStatus.SHADOW_OK: await server.confirm(ac.call_id)
    if mc.status==ToolCallStatus.SHADOW_OK: await server.confirm(mc.call_id)
    log.info(f"  ⏰  4D parallel: arm[{ac.status.value}] amr[{mc.status.value}]")
    # Self-healing physics drift
    m=twin.get_physics_model("arm-01")
    for i in range(12): m.record_outcome(2.0,2.0+i*0.06,[float(i)*0.15]*6)
    log.info(f"  ⚙️   Physics drift: dur_scale={m.duration_scale:.3f} {m.drift_warning()}")


async def demo_v03_tee(server:PMCPServer,twin:DigitalTwin)->Tuple[TEESimulator,RobotDID]:
    """v0.3 Level 9 — TEE Constitution + DID."""
    _section(9,"v0.3 TEE Safety Constitution")
    tee=TEESimulator(); ca=CertificationAuthority()
    arm_did=RobotDID("arm-01"); amr_did=RobotDID("amr-01")
    arm_cert=ca.certify(arm_did); amr_cert=ca.certify(amr_did)
    gate=TEECommandGate(server,tee,{"arm-01":arm_did,"amr-01":amr_did})
    # Valid call
    c=await server.invoke("move_to",caller_id="demo",x=0.5,y=0.5,z=0.4,speed=0.2)
    if c.projected and c.projected.safe_to_execute:
        r=await gate.tee_confirm(c.call_id,arm_did)
        log.info(f"  🔒  TEE approve: {'✅' if r.success else '❌'}")
    # Speed violation
    tok,v=tee.request_hardware_token("t-speed","arm-01","move_to",
        {"speed":2.5},120,time.time()-0.1)
    log.info(f"  🔒  Speed 2.5m/s: {'VETOED' if v else 'PASSED'} {v[:1] if v else ''}")
    # Replay attack
    c2=await server.invoke("move_to",caller_id="demo",x=0.5,y=0.6,z=0.4,speed=0.2)
    if c2.projected and c2.projected.safe_to_execute:
        tok2,_=tee.request_hardware_token(c2.call_id,"arm-01","move_to",c2.arguments,
            c2.projected.energy_j,time.time()-0.05)
        if tok2:
            ok1,m1=tee.verify_and_consume_token(tok2)
            ok2,m2=tee.verify_and_consume_token(tok2)
            log.info(f"  🛡️   Replay: first={'OK' if ok1 else 'NO'} replay={'BLOCKED' if not ok2 else 'PASSED'}")
        await server.abort(c2.call_id,"demo-cleanup")
    s=tee.stats()
    log.info(f"  📊  TEE: issued={s['tokens_issued']} vetoes={s['constitution_vetoes']}")
    return tee,arm_did


async def demo_v03_metabolic(server:PMCPServer,twin:DigitalTwin)->MetabolicTwin:
    """v0.3 Level 10 — Metabolic Twin + Autonomous SLA."""
    _section(10,"v0.3 Metabolic Twin — Bio-Economic SLA")
    mt=MetabolicTwin(twin)
    for t in ["tray-1-0","tray-1-1","tray-2-0"]: mt.register_tray(t)
    mt.register_harvester("harvester-01"); mt.register_harvester("arm-01")
    mt.register_climate_robot("amr-01")
    # Optimal conditions
    env_ok=CropEnvironment(0.8,350,23,68,800,75)
    s1,ev1=mt.step_tray("tray-1-0",env_ok,1.0)
    log.info(f"  🌿  tray-1-0 (optimal): health={s1.health_score():.3f} RGR={s1.rgr_g_g_day:.4f} stomata={s1.stomata_conductance:.3f}")
    # Stress — stomata close, SLA fires
    env_stress=CropEnvironment(2.1,350,32,40,800,60)
    s2,ev2=mt.step_tray("tray-1-1",env_stress,1.0)
    log.info(f"  🌿  tray-1-1 (VPD=2.1): stomata={s2.stomata_conductance:.4f} stress={s2.stress_index:.3f} SLAs={len(ev2)}")
    for e in ev2: log.warning(f"  🚨  SLA [{e.trigger.value}]: {e.description[:60]}")
    for rid in ["arm-01","harvester-01","amr-01"]:
        u=mt.bio_economic_utility(rid,"tray-1-1"); g=mt.sla.get_energy_grant(rid)
        log.info(f"  💹  [{rid}]: utility={u:.3f}" + (f" grant=+{g:.0f}J" if g else ""))
    # Harvest window
    from dataclasses import replace
    mt._trays["tray-2-0"]=CropState("tray-2-0",biomass_g_m2=118,harvest_quality=0.92,
        stress_index=0.1,days_to_maturity=1.2,leaf_area_index=4.0)
    _,ev3=mt.step_tray("tray-2-0",env_ok,0.5)
    log.info(f"  🌾  tray-2-0: SLAs={len(ev3)} {[e.trigger.value for e in ev3]}")
    fs=mt.farm_summary()
    log.info(f"  💰  Farm: {fs['total_trays']} trays ${fs['total_value_usd']:.2f} "
             f"stressed={fs['stressed_trays']}")
    return mt


async def demo_v03_physics(server:PMCPServer,twin:DigitalTwin)->PyBulletGhostSimulator:
    """v0.3 Level 11 — Ghost Physics HIL."""
    _section(11,"v0.3 Physics HIL — Ghost Robot")
    ghost=PyBulletGhostSimulator()
    for j in range(6): ghost.register_joint("arm-01",j,f"joint_{j}")
    ghost.add_obstacle("rack_A",1.0,0.5,1.2,0.3,0.05,0.5)
    ghost.add_obstacle("rack_B",1.0,1.5,1.2,0.3,0.05,0.5)
    # Safe path
    r1=ghost.check_trajectory("arm-01",1.5,1.0,0.5,0.8,0.6,0.4)
    log.info(f"  👻  Safe path: safe={r1.safe} dist={r1.min_distance_m:.3f}m sim={r1.simulation_time_ms:.2f}ms")
    # Near-obstacle path
    r2=ghost.check_trajectory("arm-01",1.5,1.0,0.5,0.7,0.5,1.1)
    log.info(f"  👻  Near-rack: safe={r2.safe} cols={len(r2.collisions)}")
    if r2.collisions: log.warning(f"     {r2.collisions[0]}")
    # HIL calibration
    for i in range(10):
        ghost.update_joints_from_hil("arm-01",[0.3+i*0.15+j*0.1 for j in range(6)])
    log.info(f"  📊  Ghost stats: {ghost.stats()}")
    # Integrate ghost into server shadow
    server.shadow._ghost=ghost
    return ghost


async def demo_v03_ledger()->DecentralizedFarmCoordinator:
    """v0.3 Level 12 — Decentralized Ledger CRDT."""
    _section(12,"v0.3 Decentralized Ledger — Mesh CRDT")
    dfc=DecentralizedFarmCoordinator()
    for rid in ["arm-01","amr-01","harvester-01"]: dfc.add_robot(rid)
    # Simultaneous claims
    for rid,zone,dur,bid in [
        ("arm-01","grow_zone_a",3000,80),("amr-01","harvest_station",8000,40),
        ("harvester-01","grow_zone_a",5000,60)]:
        ok,e=dfc.claim(rid,zone,dur,"demo_tool",bid)
        log.info(f"  📒  [{rid}]→[{zone}] bid={bid}J: {'✅' if ok else '⏳'} "
                 +( f"start={e.start_ms:.0f}ms" if e else "queued"))
    sched=dfc.zone_schedule("grow_zone_a")
    log.info(f"  📒  grow_zone_a schedule: {len(sched)} entries")
    for s in sched: log.info(f"       [{s['robot_id']}] bid={s['energy_bid_j']}J state={s['state']}")
    # Scale to 8 more robots
    for i in range(4,12):
        dfc.add_robot(f"arm-{i:02d}")
        dfc.claim(f"arm-{i:02d}",f"grow_zone_{'abc'[i%3]}",2000+i*100,"move_to",50+i*5)
    util=dfc.global_stats()
    log.info(f"  📒  Mesh: {util['robots_in_mesh']} robots CRDT converged")
    return dfc


async def demo_v04_synthesis(server:PMCPServer,ghost:PyBulletGhostSimulator,tee:TEESimulator):
    """v0.4 Level 13 — Dynamic Tool Synthesis (MacGyver Layer)."""
    _section(13,"v0.4 Dynamic Tool Synthesis — MacGyver Layer")
    synth=DynamicToolSynthesizer(server,ghost,tee)
    # LLM proposes a novel "tendril_harvest" tool for a vine crop
    primitives=[
        MotorPrimitive(0,0.3,0.5,2.1,500),  # Shoulder rotate
        MotorPrimitive(1,0.8,0.4,3.2,600),  # Elbow extend
        MotorPrimitive(2,0.2,0.3,1.8,400),  # Wrist flex
        MotorPrimitive(3,0.1,0.2,0.9,300),  # Wrist rotate
        MotorPrimitive(4,0.5,0.6,1.4,500),  # Elbow retract
        MotorPrimitive(5,0.0,0.1,0.5,200),  # Return
    ]
    bp=SyntheticToolBlueprint(
        tool_name="tendril_harvest",
        description="Novel vine-crop harvesting motion: shoulder-elbow-wrist sequence for reaching tendrils",
        robot_id="arm-01",
        primitives=primitives,
        parameters=[ToolParameter("tendril_x","float","Tendril X(m)",unit="m",min_val=0.3,max_val=2.0),
                    ToolParameter("tendril_y","float","Tendril Y(m)",unit="m",min_val=0.0,max_val=3.0),
                    ToolParameter("speed","float","Speed(m/s)",unit="m/s",min_val=0.05,max_val=0.5,
                                 required=False,default=0.2)],
        estimated_duration_s=4.0,estimated_energy_j=180.0,max_speed_ms=0.5)
    synth.propose_tool(bp)
    # Stress test with 120 simulations
    tested=await synth.stress_test("tendril_harvest",n_passes=120,
        robot_start=Vec3(1.5,1.0,0.5),robot_end=Vec3(0.9,0.7,0.6))
    if tested.is_certifiable():
        tool=synth.register_certified_tool("tendril_harvest")
        log.info(f"  🧪  MacGyver SUCCESS: [{tool.name}] on server "
                 f"conf={tested.confidence:.3f} cert={tested.cert_hash}")
    else:
        log.warning(f"  🧪  MacGyver: certification failed "
                    f"passes={tested.simulation_passes} rate={tested.pass_rate():.2f}")
    log.info(f"  📊  Synthesis report: {synth.synthesis_report()}")
    return synth


async def demo_v04_visual_shadow(server:PMCPServer,twin:DigitalTwin):
    """v0.4 Level 14 — Visual Shadow / VLM voxel injection."""
    _section(14,"v0.4 Visual Shadow — VLM/SAM Voxel Injection")
    bridge=VisionVoxelBridge(twin,voxel_ttl_s=0.33)
    sim=VisionSimulator(bridge)
    agent=PlanningAgent(server,"vision-agent")
    # Clear scene — move should succeed
    sim.simulate_empty_scene()
    c1=await server.invoke("move_to",caller_id="vision-agent",x=0.8,y=0.6,z=0.5,speed=0.25)
    log.info(f"  👁️   Empty scene: shadow={c1.projected.risk_level} safe={c1.projected.safe_to_execute}")
    await server.abort(c1.call_id,"demo")
    # Human approaches — inject voxel — move should be blocked
    sim.simulate_human_approaching(x=0.9,y=0.65,z=0.9)
    await asyncio.sleep(0.05)
    c2=await server.invoke("move_to",caller_id="vision-agent",x=0.8,y=0.6,z=0.5,speed=0.25)
    log.info(f"  👁️   Human in scene: safe={c2.projected.safe_to_execute} risks={len(c2.projected.risk_reasons)}")
    for r in c2.projected.risk_reasons[:2]: log.warning(f"     {r}")
    await server.abort(c2.call_id,"demo")
    # Static unknown obstacle
    sim.simulate_static_obstacle("toolbox",x=1.1,y=0.7,z=0.3,r=0.25)
    c3=await server.invoke("move_to",caller_id="vision-agent",x=1.0,y=0.7,z=0.3,speed=0.2)
    log.info(f"  👁️   Unknown obstacle: safe={c3.projected.safe_to_execute} voxels={len(twin.get_vision_voxels())}")
    await server.abort(c3.call_id,"demo")
    twin._vision_voxels.clear()  # Clear for next test
    log.info(f"  📊  Vision: {bridge.stats()}")
    return bridge


async def demo_v04_zk(server:PMCPServer,twin:DigitalTwin)->Tuple[ZKSafetyProver,ZKSafetyVerifier]:
    """v0.4 Level 15 — ZK-Safety Proofs."""
    _section(15,"v0.4 ZK-Safety Proofs — Privacy Layer")
    arm_did=RobotDID("arm-01")
    prover=ZKSafetyProver(server,arm_did)
    verifier=ZKSafetyVerifier(trusted_dids=[arm_did.did])
    server.set_zk_verifier(verifier)
    # Generate proof for a secret picking algorithm
    SECRET_ALGO=hashlib.sha256(b"proprietary-vine-spiral-harvest-v7").hexdigest()
    proof,public_commit=prover.generate_proof("move_to",
        {"x":0.8,"y":0.6,"z":0.5,"speed":0.25},SECRET_ALGO)
    log.info(f"  🔐  ZK proof generated (algorithm stays SECRET)")
    pub=json.loads(public_commit)
    log.info(f"  🔐  Public commitment: {pub['commitment'][:24]}... safe={pub['safe_asserted']}")
    # Facility verifier checks proof
    ok,msg=verifier.verify_proof(proof,"move_to",{"x":0.8,"y":0.6,"z":0.5})
    log.info(f"  🔐  Verification: {'✅ VALID' if ok else '❌ INVALID'} — {msg}")
    # Untrusted prover
    untrusted_did=RobotDID("rogue-bot-99")
    bad_prover=ZKSafetyProver(server,untrusted_did)
    bad_proof,_=bad_prover.generate_proof("move_to",{"x":0.8,"y":0.6,"z":0.5})
    ok2,msg2=verifier.verify_proof(bad_proof,"move_to",{})
    log.info(f"  🔐  Untrusted prover: {'BLOCKED' if not ok2 else 'PASSED'} — {msg2}")
    log.info(f"  📊  ZK: {verifier.stats()}")
    return prover,verifier


async def demo_v04_economy(server:PMCPServer,twin:DigitalTwin,
                           dfc:DecentralizedFarmCoordinator)->DePINFleetManager:
    """v0.4 Level 16 — Machine Economy / DePIN."""
    _section(16,"v0.4 Machine Economy — DePIN Robo-Wallet")
    arm_did=RobotDID("arm-01"); amr_did=RobotDID("amr-01"); harv_did=RobotDID("harvester-01")
    arm_w=RoboWallet("arm-01",arm_did,initial_balance_usd=0.50)
    amr_w=RoboWallet("amr-01",amr_did,initial_balance_usd=0.30)
    harv_w=RoboWallet("harvester-01",harv_did,initial_balance_usd=0.20)
    fleet=DePINFleetManager(dfc)
    for w in [arm_w,amr_w,harv_w]: fleet.register_robot_wallet(w)
    # High-value harvest task
    task_id=fleet.post_task("harvest_basil_tray",0.12,"grow_zone_a",5000)
    # Each robot evaluates utility
    c_arm=await server.invoke("move_to",caller_id="arm-01",x=1.0,y=0.8,z=0.4,speed=0.25)
    c_amr=await server.invoke("navigate_to",caller_id="amr-01",target_x=1.0,target_y=0.8)
    c_harv=await server.invoke("harvest",caller_id="harvester-01",tray_x=1.0,tray_y=0.8)
    projected={
        "arm-01":c_arm.projected,"amr-01":c_amr.projected,"harvester-01":c_harv.projected
    }
    await server.abort(c_arm.call_id,"econ-demo"); await server.abort(c_amr.call_id,"econ-demo")
    await server.abort(c_harv.call_id,"econ-demo")
    bids=fleet.collect_bids(task_id,projected,energy_price=0.08)
    winner=fleet.award_task(task_id,bids)
    log.info(f"  💰  Task [{task_id}] awarded to [{winner}] from bids={dict((k,round(v,6)) for k,v in bids.items())}")
    # Simulate low-value drudge task — some robots refuse
    drudge_id=fleet.post_task("sensor_calibration",0.0001,"maintenance_corridor",1000)
    ca2=await server.invoke("home",caller_id="arm-01")
    if ca2.projected:
        projected2={"arm-01":ca2.projected,"amr-01":c_amr.projected}
        bids2=fleet.collect_bids(drudge_id,projected2,energy_price=0.12)
        log.info(f"  💰  Low-value task bids: {dict((k,round(v,6)) for k,v in bids2.items())}")
        if not bids2: log.info(f"  💰  All robots refused drudge task — re-auctioning to external node")
    await server.abort(ca2.call_id,"econ-demo")
    log.info(f"\n  📊  Fleet Economics:")
    for rid,w in fleet._wallets.items():
        log.info(f"       [{rid}]: balance=${w.balance():.4f} "
                 f"tasks={w._tasks_completed} refused={w._tasks_refused}")
    return fleet


async def demo_integrated_sovereign(server:PMCPServer,twin:DigitalTwin,
    tee:TEESimulator,arm_did:RobotDID,mt:MetabolicTwin,
    ghost:PyBulletGhostSimulator,dfc:DecentralizedFarmCoordinator,
    bridge:VisionVoxelBridge,prover:ZKSafetyProver,verifier:ZKSafetyVerifier,
    fleet:DePINFleetManager):
    """All 16 levels in one integrated harvest."""
    _section(0,"GRAND UNIFIED — All Levels in One Autonomous Harvest")
    log.info("  Flow: Economy→ZK→Metabolic→Ledger→Vision→Ghost→TEE→Execute")
    TRAY="tray-1-0"; ROBOT="arm-01"; ZONE="grow_zone_a"

    # L16: Economic pre-check
    log.info("\n  [L16] Economic evaluation...")
    dummy_proj=ProjectedOutcome(3.0,120.0,None,"low",[],utility_score=0.9)
    accept,tx=fleet._wallets.get(ROBOT,RoboWallet(ROBOT,arm_did)).evaluate_task(
        "harvest",dummy_proj,0.12,energy_price_usd_kwh=0.08)
    log.info(f"  [L16] {'ACCEPT' if accept else 'REFUSE'} U=${tx.utility:.6f}")
    if not accept: log.info("  [L16] Re-auctioning to fleet..."); return

    # L15: ZK safety proof
    log.info("\n  [L15] Generating ZK safety proof...")
    proof,pub=prover.generate_proof("move_to",{"x":1.0,"y":0.8,"z":0.45,"speed":0.25})
    ok,msg=verifier.verify_proof(proof,"move_to",{"x":1.0,"y":0.8,"z":0.45})
    log.info(f"  [L15] ZK proof: {'✅ VERIFIED' if ok else '❌ REJECTED'}")
    if not ok: return

    # L10: Metabolic utility
    log.info("\n  [L10] Metabolic bio-economic check...")
    env=CropEnvironment(0.9,320,23,65,800,72)
    state,sla_events=mt.step_tray(TRAY,env,0.1)
    util=mt.bio_economic_utility(ROBOT,TRAY); val=state.harvest_value_usd()
    log.info(f"  [L10] Health={state.health_score():.3f} util={util:.3f} value=${val:.2f}")
    if sla_events: log.warning(f"  [L10] {len(sla_events)} SLA events — check robot priority")

    # L12: Decentralized ledger reservation
    log.info("\n  [L12] Claiming spatiotemporal slot on mesh ledger...")
    ok12,entry=dfc.claim(ROBOT,ZONE,5000,"move_to",util*120)
    if ok12 and entry:
        log.info(f"  [L12] ✅ Slot reserved [{entry.entry_id}] bid={entry.energy_bid_j:.0f}J")
    else: log.warning(f"  [L12] Zone conflict — higher bid needed"); return

    # L14: Clear vision
    log.info("\n  [L14] Checking visual shadow (camera clear)...")
    bridge.twin.clear_expired_voxels(0.0)  # Clear any old voxels
    voxels=bridge.get_active_voxels()
    log.info(f"  [L14] Vision voxels active: {len(voxels)} {'✅ CLEAR' if not voxels else '⚠ OCCUPIED'}")

    # L11: Ghost pre-flight
    log.info("\n  [L11] Ghost robot pre-flight simulation...")
    cur=twin.get_pose(ROBOT); sp=cur.position if cur else Vec3(1.5,1.0,0.5)
    tgt=Vec3(1.0,0.8,0.45)
    gr=ghost.check_trajectory(ROBOT,sp.x,sp.y,sp.z,tgt.x,tgt.y,tgt.z)
    log.info(f"  [L11] Ghost: {'✅ CLEAR' if gr.safe else '❌ COLLISION'} "
             f"dist={gr.min_distance_m:.3f}m sim={gr.simulation_time_ms:.2f}ms")
    if not gr.safe:
        dfc.release(ROBOT,entry.entry_id); return

    # L9: TEE token
    log.info("\n  [L9]  TEE gate: requesting hardware token...")
    call=await server.invoke("move_to",caller_id="sovereign-demo",
        x=tgt.x,y=tgt.y,z=tgt.z,speed=0.25,zk_proof=proof)
    if call.projected and call.projected.safe_to_execute:
        sig=arm_did.sign({"call_id":call.call_id,"robot_id":ROBOT,
                          "tool_name":"move_to","arguments":call.arguments})
        tok,tvio=tee.request_hardware_token(call.call_id,ROBOT,"move_to",
            call.arguments,call.projected.energy_j,time.time()-0.05,arm_did,sig)
        if tok:
            hw_ok,hw_msg=tee.verify_and_consume_token(tok)
            log.info(f"  [L9]  Token [{tok.token_id}]: {'✅ OPEN' if hw_ok else '🛑 BLOCKED'} {hw_msg}")
            if hw_ok:
                result=await server.confirm(call.call_id)
                log.info(f"\n  🤖  EXECUTED: {'✅' if result.success else '❌'} {result.message}")
                if result.joint_torque_error_nm:
                    ghost.update_joints_from_hil(ROBOT,result.joint_torque_error_nm)
                    log.info(f"  [L11] HIL torques ingested → ghost model updated")
                # L16: Settle economics
                accept2,tx2=fleet._wallets.get(ROBOT,RoboWallet(ROBOT,arm_did)).evaluate_task(
                    "harvest",call.projected,0.12)
                fleet._wallets[ROBOT].settle_task(tx2,result) if ROBOT in fleet._wallets else None
                bal=fleet._wallets.get(ROBOT)
                log.info(f"  [L16] Settled: net=${tx2.net_usd:.6f} "
                         + (f"balance=${bal.balance():.4f}" if bal else ""))
        else:
            log.warning(f"  [L9]  TEE VETO: {tvio}")
            await server.abort(call.call_id,"tee-veto")
    else:
        risks=call.projected.risk_reasons if call.projected else []
        log.warning(f"  Shadow blocked: {risks}")
        await server.abort(call.call_id,"shadow-blocked")

    dfc.release(ROBOT,entry.entry_id); log.info(f"  [L12] Slot released")
    log.info(f"\n  ✅  Grand Unified demo — all 16 levels exercised")


async def main():
    logging.basicConfig(level=logging.INFO,format="%(asctime)s  %(message)s",
        datefmt="%H:%M:%S",handlers=[logging.StreamHandler()])
    logging.getLogger("asyncio").setLevel(logging.WARNING)

    _banner(
        "P-MCP Grand Unified Protocol Stack  v0.1 → v0.4",
        "Identity · Governance · Coordination · Actuation"
    )
    print("""
  ┌────────────────────────────────────────────────────────────────────┐
  │  COLUMN         TECHNOLOGY              PURPOSE                    │
  │  ─────────────────────────────────────────────────────────────────│
  │  Identity       W3C DIDs + Ed25519      Who is this machine?      │
  │  Governance     TEE Safety Constitution What laws can't it break? │
  │  Coordination   Spatiotemporal Ledger   How to share 4D space?    │
  │  Actuation      P-MCP Tool Synthesis    Thought → motor torque    │
  └────────────────────────────────────────────────────────────────────┘
""")

    # ── Bootstrap infrastructure ───────────────────────────────
    print("  Bootstrapping infrastructure...\n")
    ghost=PyBulletGhostSimulator()
    for j in range(6): ghost.register_joint("arm-01",j,f"joint_{j}")
    ghost.add_obstacle("rack_A",1.0,0.5,1.2,0.3,0.05,0.5)
    ghost.add_obstacle("rack_B",1.0,1.5,1.2,0.3,0.05,0.5)

    twin=DigitalTwin(power_budget_w=8000.0)
    server=PMCPServer("farm-pmcp-v4",twin,confirm_timeout_ms=8000,ghost_sim=ghost)

    # Register robot agents
    arm=RoboticArmAgent(server,"arm-01",Pose(position=Vec3(1.5,1.0,0.5)))
    amr=AMRAgent(server,"amr-01",Pose(position=Vec3(4.5,0.5,0.0)))
    harv=HarvesterRobot(server,"harvester-01",Pose(position=Vec3(2.0,2.0,0.0)))

    print(f"\n  ✅  P-MCP v0.4 server: {len(server._tools)} tools {len(server._resources)} resources\n")

    # ── v0.1 ─────────────────────────────────────────────────
    await demo_v01_core(server)

    # ── v0.2 ─────────────────────────────────────────────────
    await demo_v02_upgrades(server,twin)

    # ── v0.3 — sovereign infrastructure ──────────────────────
    tee,arm_did=await demo_v03_tee(server,twin)
    mt=await demo_v03_metabolic(server,twin)
    await demo_v03_physics(server,twin)
    dfc=await demo_v03_ledger()
    for rid in ["arm-01","amr-01","harvester-01"]:
        if rid not in dfc._nodes: dfc.add_robot(rid)

    # ── v0.4 — interoperable autonomy ─────────────────────────
    synth=await demo_v04_synthesis(server,ghost,tee)
    bridge=await demo_v04_visual_shadow(server,twin)
    prover,verifier=await demo_v04_zk(server,twin)
    fleet=await demo_v04_economy(server,twin,dfc)

    # ── Grand Unified Integration ──────────────────────────────
    await demo_integrated_sovereign(server,twin,tee,arm_did,mt,ghost,dfc,
                                     bridge,prover,verifier,fleet)



#------------------------
    # ── Final stats ───────────────────────────────────────────
    _banner("Grand Unified Session Stats")
    s=server.stats()
    log.info(f"  Tools:              {s['tools']} ({s['synthetic_tools']} synthetic)")
    log.info(f"  Resources:          {s['resources']}")
    log.info(f"  Tool calls:         {s['calls_total']}")
    log.info(f"  By status:          {s['calls_by_status']}")
    log.info(f"  Shadow block rate:  {s['shadow']['block_rate_pct']}%")
    log.info(f"  Vision voxels:      {s['shadow'].get('vision_voxels',0)} (current)")
    log.info(f"  Ghost sim calls:    {ghost.stats()['sim_calls']}")
    log.info(f"  Mesh robots:        {dfc.global_stats()['robots_in_mesh']}")
    log.info(f"  TEE tokens:         {tee.stats()['tokens_issued']} issued")
    log.info(f"  TEE vetoes:         {tee.stats()['constitution_vetoes']}")
    log.info(f"  ZK verified:        {verifier.stats()['verified']}")
    log.info(f"  ZK rejected:        {verifier.stats()['rejected']}")
    log.info(f"  Fleet balance:      ${sum(w.balance() for w in fleet._wallets.values()):.4f}")

    print()
    print("  ╔══════════════════════════════════════════════════════╗")
    print("  ║  P-MCP Grand Unified Protocol  v0.1→v0.4  COMPLETE  ║")
    print("  ║  🔒 TEE  🌱 Metabolic  👻 Ghost  🌐 Mesh  💰 DePIN   ║")
    print("  ╚══════════════════════════════════════════════════════╝")
    print()


if __name__ == "__main__":
    asyncio.run(main())
