"""
P-MCP DePIN HTTP Server — wraps DePINNode behind a JSON-RPC 2.0 HTTP endpoint.
"""
import asyncio
import json
import logging
from decimal import Decimal

from aiohttp import web

from .node import DePINNode

log = logging.getLogger("pmcp.depin.server")


def create_depin_app(node: DePINNode) -> web.Application:
    app = web.Application()
    app["node"] = node
    app.router.add_post("/rpc", handle_rpc)
    app.router.add_get("/health", lambda r: web.json_response({"status": "ok"}))
    return app


async def handle_rpc(req: web.Request) -> web.Response:
    node: DePINNode = req.app["node"]
    try:
        body = await req.json()
    except Exception:
        return web.json_response(
            {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}},
            status=400
        )
    result = await node.dispatch(body)
    return web.json_response(result)


async def main(port: int = 9001) -> None:
    logging.basicConfig(level=logging.INFO)
    node = DePINNode()
    app = create_depin_app(node)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    log.info("DePIN server running on port %d", port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
