"""
P-MCP DePIN Token Economy — Off-chain Coordination Layer
==========================================================
Implements the token economy for decentralised robot work coordination:

  RobotToken   — ERC-20-style balance ledger (off-chain stub for dev; connects
                  to an EVM chain via web3.py in production)
  WorkAuction  — PMCP-level resource auction: robots bid compute/sensor slots
  StakeManager — Robots stake tokens to unlock premium capabilities
  RewardEngine — Distributes task-completion rewards proportional to quality score
  DePINNode    — Wraps all the above and exposes JSON-RPC endpoints

Wire Protocol (JSON-RPC 2.0):
  depin/stake          { robot_id, amount }
  depin/unstake        { robot_id, amount }
  depin/bid            { auction_id, robot_id, bid, collateral }
  depin/claim_reward   { task_id, robot_id }
  depin/balance        { robot_id }
  depin/auctions       {}
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, List, Optional

log = logging.getLogger("pmcp.depin")

# ─────────────────────────────────────────────────────────────────────────────
#  Constants
# ─────────────────────────────────────────────────────────────────────────────

GENESIS_SUPPLY = Decimal("1_000_000")   # 1 M tokens at genesis
MIN_STAKE = Decimal("100")              # minimum stake to participate
REWARD_POOL_RATIO = Decimal("0.02")     # 2 % of circulating supply per epoch
AUCTION_TIMEOUT_S = 60                  # auction closes after 60 s


# ─────────────────────────────────────────────────────────────────────────────
#  Token Ledger
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TokenBalance:
    robot_id: str
    liquid: Decimal = Decimal("0")
    staked: Decimal = Decimal("0")
    locked: Decimal = Decimal("0")

    @property
    def total(self) -> Decimal:
        return self.liquid + self.staked + self.locked


class RobotToken:
    """In-process ERC-20-style ledger. Swap `transfer` for web3.py calls in prod."""

    def __init__(self) -> None:
        self._balances: Dict[str, TokenBalance] = {}
        self._tx_log: List[Dict] = []

    def _ensure(self, robot_id: str) -> TokenBalance:
        if robot_id not in self._balances:
            self._balances[robot_id] = TokenBalance(robot_id=robot_id)
        return self._balances[robot_id]

    def mint(self, robot_id: str, amount: Decimal) -> None:
        """Mint tokens to a robot address (faucet / genesis allocation)."""
        self._ensure(robot_id).liquid += amount
        self._log_tx("MINT", "0x0", robot_id, amount)

    def transfer(self, from_id: str, to_id: str, amount: Decimal) -> None:
        bal = self._ensure(from_id)
        if bal.liquid < amount:
            raise ValueError(f"Insufficient liquid balance: {bal.liquid} < {amount}")
        bal.liquid -= amount
        self._ensure(to_id).liquid += amount
        self._log_tx("TRANSFER", from_id, to_id, amount)

    def balance_of(self, robot_id: str) -> TokenBalance:
        return self._ensure(robot_id)

    def _log_tx(self, tx_type: str, sender: str, receiver: str, amount: Decimal) -> None:
        self._tx_log.append({
            "type": tx_type,
            "sender": sender,
            "receiver": receiver,
            "amount": str(amount),
            "ts": int(time.time() * 1000),
            "hash": hashlib.sha256(
                f"{tx_type}{sender}{receiver}{amount}{time.time()}".encode()
            ).hexdigest()[:16],
        })

    def tx_history(self, robot_id: str, limit: int = 20) -> List[Dict]:
        relevant = [t for t in self._tx_log if t["sender"] == robot_id or t["receiver"] == robot_id]
        return relevant[-limit:]


# ─────────────────────────────────────────────────────────────────────────────
#  Stake Manager
# ─────────────────────────────────────────────────────────────────────────────

class StakeManager:
    """Robots must stake tokens to unlock capabilities."""

    def __init__(self, ledger: RobotToken) -> None:
        self._ledger = ledger
        self._stakes: Dict[str, Decimal] = {}

    def stake(self, robot_id: str, amount: Decimal) -> None:
        if amount < MIN_STAKE:
            raise ValueError(f"Minimum stake is {MIN_STAKE}")
        bal = self._ledger.balance_of(robot_id)
        if bal.liquid < amount:
            raise ValueError("Insufficient liquid balance")
        bal.liquid -= amount
        bal.staked += amount
        self._stakes[robot_id] = self._stakes.get(robot_id, Decimal("0")) + amount
        log.info("Robot %s staked %s tokens", robot_id, amount)

    def unstake(self, robot_id: str, amount: Decimal) -> None:
        current = self._stakes.get(robot_id, Decimal("0"))
        if amount > current:
            raise ValueError(f"Cannot unstake {amount} > {current}")
        bal = self._ledger.balance_of(robot_id)
        bal.staked -= amount
        bal.liquid += amount
        self._stakes[robot_id] = current - amount
        log.info("Robot %s unstaked %s tokens", robot_id, amount)

    def stake_of(self, robot_id: str) -> Decimal:
        return self._stakes.get(robot_id, Decimal("0"))

    def is_eligible(self, robot_id: str) -> bool:
        return self.stake_of(robot_id) >= MIN_STAKE


# ─────────────────────────────────────────────────────────────────────────────
#  Work Auction
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Bid:
    robot_id: str
    amount: Decimal
    collateral: Decimal
    ts: float = field(default_factory=time.time)


@dataclass
class Auction:
    auction_id: str
    resource: str         # e.g. "sensor:lidar", "compute:gpu"
    min_bid: Decimal
    expires_at: float
    bids: List[Bid] = field(default_factory=list)
    winner: Optional[str] = None
    winning_bid: Optional[Decimal] = None
    closed: bool = False


class WorkAuction:
    """First-price sealed-bid auction for robot compute/sensor resources."""

    def __init__(self, ledger: RobotToken, stake_mgr: StakeManager) -> None:
        self._ledger = ledger
        self._stakes = stake_mgr
        self._auctions: Dict[str, Auction] = {}

    def create_auction(self, resource: str, min_bid: Decimal) -> str:
        auction_id = str(uuid.uuid4())
        expires = time.time() + AUCTION_TIMEOUT_S
        self._auctions[auction_id] = Auction(
            auction_id=auction_id, resource=resource,
            min_bid=min_bid, expires_at=expires
        )
        log.info("Auction created %s for %s", auction_id, resource)
        return auction_id

    def place_bid(self, auction_id: str, robot_id: str, amount: Decimal, collateral: Decimal) -> None:
        auction = self._auctions.get(auction_id)
        if auction is None:
            raise ValueError("Auction not found")
        if auction.closed or time.time() > auction.expires_at:
            raise ValueError("Auction closed")
        if not self._stakes.is_eligible(robot_id):
            raise ValueError(f"Robot {robot_id} not staked")
        if amount < auction.min_bid:
            raise ValueError(f"Bid {amount} below minimum {auction.min_bid}")
        bal = self._ledger.balance_of(robot_id)
        if bal.liquid < collateral:
            raise ValueError("Insufficient collateral")
        # Lock collateral
        bal.liquid -= collateral
        bal.locked += collateral
        auction.bids.append(Bid(robot_id=robot_id, amount=amount, collateral=collateral))

    def close_auction(self, auction_id: str) -> Optional[str]:
        auction = self._auctions.get(auction_id)
        if auction is None or auction.closed:
            return None
        auction.closed = True
        if not auction.bids:
            return None
        winning = max(auction.bids, key=lambda b: b.amount)
        auction.winner = winning.robot_id
        auction.winning_bid = winning.amount
        # Release collateral for all but winner, charge winner
        for bid in auction.bids:
            bal = self._ledger.balance_of(bid.robot_id)
            bal.locked -= bid.collateral
            if bid.robot_id != winning.robot_id:
                bal.liquid += bid.collateral
        log.info("Auction %s won by %s with %s tokens", auction_id, winning.robot_id, winning.amount)
        return winning.robot_id

    def list_auctions(self) -> List[Dict]:
        return [
            {"auction_id": a.auction_id, "resource": a.resource,
             "min_bid": str(a.min_bid), "expires_at": a.expires_at,
             "bid_count": len(a.bids), "closed": a.closed,
             "winner": a.winner}
            for a in self._auctions.values()
        ]


# ─────────────────────────────────────────────────────────────────────────────
#  Reward Engine
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CompletedTask:
    task_id: str
    robot_id: str
    quality_score: float     # 0.0–1.0
    reward: Decimal
    claimed: bool = False
    completed_at: float = field(default_factory=time.time)


class RewardEngine:
    """Distributes rewards proportional to quality_score."""

    def __init__(self, ledger: RobotToken) -> None:
        self._ledger = ledger
        self._tasks: Dict[str, CompletedTask] = {}

    def record_task(self, task_id: str, robot_id: str, quality_score: float,
                    base_reward: Decimal) -> None:
        reward = base_reward * Decimal(str(max(0.0, min(1.0, quality_score))))
        self._tasks[task_id] = CompletedTask(
            task_id=task_id, robot_id=robot_id,
            quality_score=quality_score, reward=reward
        )

    def claim_reward(self, task_id: str, robot_id: str) -> Decimal:
        task = self._tasks.get(task_id)
        if task is None:
            raise ValueError("Task not found")
        if task.claimed:
            raise ValueError("Reward already claimed")
        if task.robot_id != robot_id:
            raise ValueError("Not the task executor")
        task.claimed = True
        self._ledger.mint(robot_id, task.reward)
        log.info("Reward claimed: task=%s robot=%s amount=%s", task_id, robot_id, task.reward)
        return task.reward

    def pending_rewards(self, robot_id: str) -> List[Dict]:
        return [
            {"task_id": t.task_id, "reward": str(t.reward), "score": t.quality_score}
            for t in self._tasks.values()
            if t.robot_id == robot_id and not t.claimed
        ]


# ─────────────────────────────────────────────────────────────────────────────
#  DePIN Node (JSON-RPC endpoint)
# ─────────────────────────────────────────────────────────────────────────────

class DePINNode:
    """Single entry-point for all DePIN operations, dispatches JSON-RPC calls."""

    def __init__(self) -> None:
        self.ledger = RobotToken()
        self.stakes = StakeManager(self.ledger)
        self.auctions = WorkAuction(self.ledger, self.stakes)
        self.rewards = RewardEngine(self.ledger)
        # Seed faucet
        self.ledger.mint("faucet", GENESIS_SUPPLY)

    def faucet(self, robot_id: str, amount: Decimal = Decimal("1000")) -> None:
        """Grant initial tokens from the genesis faucet (dev/test)."""
        self.ledger.transfer("faucet", robot_id, amount)

    async def dispatch(self, request: Dict) -> Dict:
        method = request.get("method", "")
        params = request.get("params", {})
        rpc_id = request.get("id", None)

        try:
            result = await self._route(method, params)
            return {"jsonrpc": "2.0", "id": rpc_id, "result": result}
        except ValueError as exc:
            return {"jsonrpc": "2.0", "id": rpc_id,
                    "error": {"code": -32602, "message": str(exc)}}
        except Exception as exc:
            log.exception("DePIN dispatch error: %s", exc)
            return {"jsonrpc": "2.0", "id": rpc_id,
                    "error": {"code": -32603, "message": "Internal error"}}

    async def _route(self, method: str, params: Dict) -> Any:
        if method == "depin/balance":
            bal = self.ledger.balance_of(params["robot_id"])
            return {"liquid": str(bal.liquid), "staked": str(bal.staked),
                    "locked": str(bal.locked), "total": str(bal.total)}

        if method == "depin/faucet":
            amount = Decimal(str(params.get("amount", "1000")))
            self.faucet(params["robot_id"], amount)
            return {"ok": True, "amount": str(amount)}

        if method == "depin/stake":
            self.stakes.stake(params["robot_id"], Decimal(str(params["amount"])))
            return {"ok": True, "staked": str(self.stakes.stake_of(params["robot_id"]))}

        if method == "depin/unstake":
            self.stakes.unstake(params["robot_id"], Decimal(str(params["amount"])))
            return {"ok": True, "staked": str(self.stakes.stake_of(params["robot_id"]))}

        if method == "depin/create_auction":
            auction_id = self.auctions.create_auction(
                params["resource"], Decimal(str(params.get("min_bid", "1")))
            )
            return {"auction_id": auction_id}

        if method == "depin/bid":
            self.auctions.place_bid(
                params["auction_id"], params["robot_id"],
                Decimal(str(params["bid"])), Decimal(str(params.get("collateral", "0")))
            )
            return {"ok": True}

        if method == "depin/close_auction":
            winner = self.auctions.close_auction(params["auction_id"])
            return {"winner": winner}

        if method == "depin/auctions":
            return {"auctions": self.auctions.list_auctions()}

        if method == "depin/record_task":
            self.rewards.record_task(
                params["task_id"], params["robot_id"],
                float(params.get("quality_score", 1.0)),
                Decimal(str(params.get("base_reward", "10")))
            )
            return {"ok": True}

        if method == "depin/claim_reward":
            amount = self.rewards.claim_reward(params["task_id"], params["robot_id"])
            return {"amount": str(amount)}

        if method == "depin/pending_rewards":
            return {"rewards": self.rewards.pending_rewards(params["robot_id"])}

        if method == "depin/tx_history":
            return {"txs": self.ledger.tx_history(params["robot_id"])}

        raise ValueError(f"Unknown DePIN method: {method}")
