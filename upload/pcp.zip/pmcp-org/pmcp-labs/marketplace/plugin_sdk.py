"""
P-MCP Plugin SDK — Client-side helpers for loading and running marketplace plugins.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


@dataclass
class PluginManifest:
    """Contents of plugin.json inside a plugin archive."""
    name: str
    version: str
    description: str
    author: str
    license: str
    pmcp_version: str
    entry_point: str         # e.g. "plugin.main:create_plugin"
    actuations: List[str]
    sensors: List[str]
    category: str = "tools"
    homepage: str = ""

    @classmethod
    def from_dict(cls, d: Dict) -> "PluginManifest":
        return cls(
            name=d.get("name", ""),
            version=d.get("version", "0.1.0"),
            description=d.get("description", ""),
            author=d.get("author", ""),
            license=d.get("license", "MIT"),
            pmcp_version=d.get("pmcp_version", "0.5"),
            entry_point=d.get("entry_point", "plugin:create_plugin"),
            actuations=d.get("actuations", []),
            sensors=d.get("sensors", []),
            category=d.get("category", "tools"),
            homepage=d.get("homepage", ""),
        )


class PluginLoader:
    """Load, verify, and install P-MCP plugins from ZIP archives."""

    def __init__(self, install_dir: str = os.path.expanduser("~/.pmcp/plugins")) -> None:
        self.install_dir = Path(install_dir)
        self.install_dir.mkdir(parents=True, exist_ok=True)
        self._loaded: Dict[str, Any] = {}

    def verify_archive(self, archive_path: str, expected_sha256: str) -> bool:
        """Verify the SHA-256 hash of a downloaded archive."""
        sha = hashlib.sha256()
        with open(archive_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        actual = sha.hexdigest()
        return actual == expected_sha256

    def install(self, archive_path: str, expected_sha256: str = "") -> PluginManifest:
        """Extract a plugin archive and return its manifest."""
        if expected_sha256 and not self.verify_archive(archive_path, expected_sha256):
            raise ValueError(f"SHA-256 mismatch for {archive_path}")

        with zipfile.ZipFile(archive_path, "r") as zf:
            if "plugin.json" not in zf.namelist():
                raise ValueError("Archive missing plugin.json")
            manifest_data = json.loads(zf.read("plugin.json"))
            manifest = PluginManifest.from_dict(manifest_data)
            plugin_dir = self.install_dir / manifest.name / manifest.version
            plugin_dir.mkdir(parents=True, exist_ok=True)
            zf.extractall(str(plugin_dir))

        return manifest

    def load(self, plugin_name: str, version: str = "latest") -> Optional[Any]:
        """Import and return the plugin object."""
        if plugin_name in self._loaded:
            return self._loaded[plugin_name]

        # Find best matching version
        plugin_base = self.install_dir / plugin_name
        if not plugin_base.exists():
            return None

        if version == "latest":
            versions = sorted(plugin_base.iterdir(), key=lambda p: p.name, reverse=True)
            if not versions:
                return None
            plugin_dir = versions[0]
        else:
            plugin_dir = plugin_base / version
            if not plugin_dir.exists():
                return None

        manifest_path = plugin_dir / "plugin.json"
        if not manifest_path.exists():
            return None

        manifest = PluginManifest.from_dict(json.loads(manifest_path.read_text()))

        # Import entry point
        module_name, factory_name = manifest.entry_point.rsplit(":", 1)
        spec = importlib.util.spec_from_file_location(
            module_name, str(plugin_dir / (module_name.replace(".", "/") + ".py"))
        )
        if spec is None or spec.loader is None:
            return None

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)  # type: ignore

        factory: Callable = getattr(module, factory_name)
        plugin = factory()
        self._loaded[plugin_name] = plugin
        return plugin

    def list_installed(self) -> List[PluginManifest]:
        manifests = []
        for plugin_dir in self.install_dir.iterdir():
            if plugin_dir.is_dir():
                for version_dir in plugin_dir.iterdir():
                    manifest_path = version_dir / "plugin.json"
                    if manifest_path.exists():
                        try:
                            manifests.append(
                                PluginManifest.from_dict(json.loads(manifest_path.read_text()))
                            )
                        except Exception:
                            pass
        return manifests
