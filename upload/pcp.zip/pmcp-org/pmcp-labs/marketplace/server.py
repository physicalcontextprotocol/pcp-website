"""
P-MCP Plugin Marketplace — Server
===================================
Hosts the plugin registry: developers publish plugins, robot operators
discover and install them. Plugins are ZIP archives containing a
`plugin.json` manifest and Python/WASM code.

Architecture:
  - Metadata stored in SQLite (dev/test) or PostgreSQL (prod)
  - Plugin archives stored on local disk (dev) or S3-compatible (prod)
  - REST API consumed by the Marketplace UI and robot SDK

API:
  GET  /api/v1/plugins              — list plugins
  GET  /api/v1/plugins/{id}         — plugin detail + versions
  POST /api/v1/plugins              — publish a new plugin
  GET  /api/v1/plugins/{id}/install — download plugin archive
  POST /api/v1/plugins/{id}/review  — add a review
  GET  /api/v1/categories           — list categories
  GET  /api/v1/search?q=...         — full-text search
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import sqlite3
import tempfile
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from aiohttp import web

log = logging.getLogger("pmcp.marketplace")

PLUGIN_STORE_DIR = os.environ.get("PLUGIN_STORE_DIR", "/tmp/pmcp_plugins")
DB_PATH = os.environ.get("PLUGIN_DB_PATH", "/tmp/pmcp_plugins.db")

CATEGORIES = [
    "navigation", "manipulation", "perception", "safety",
    "communication", "diagnostics", "simulation", "tools",
]


# ─────────────────────────────────────────────────────────────────────────────
#  Schema
# ─────────────────────────────────────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS plugins (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT,
    category    TEXT,
    author      TEXT,
    homepage    TEXT,
    license     TEXT,
    created_ms  INTEGER,
    updated_ms  INTEGER,
    downloads   INTEGER DEFAULT 0,
    rating_sum  REAL DEFAULT 0,
    rating_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS plugin_versions (
    id          TEXT PRIMARY KEY,
    plugin_id   TEXT NOT NULL REFERENCES plugins(id),
    version     TEXT NOT NULL,
    pmcp_version TEXT,
    archive_path TEXT,
    sha256      TEXT,
    size_bytes  INTEGER,
    published_ms INTEGER,
    changelog   TEXT,
    UNIQUE(plugin_id, version)
);

CREATE TABLE IF NOT EXISTS plugin_reviews (
    id          TEXT PRIMARY KEY,
    plugin_id   TEXT NOT NULL REFERENCES plugins(id),
    author      TEXT,
    rating      INTEGER,
    body        TEXT,
    created_ms  INTEGER
);

CREATE VIRTUAL TABLE IF NOT EXISTS plugins_fts USING fts5(
    id UNINDEXED,
    name,
    description,
    category,
    author
);
"""


# ─────────────────────────────────────────────────────────────────────────────
#  Database
# ─────────────────────────────────────────────────────────────────────────────

class MarketplaceDB:
    def __init__(self, db_path: str = DB_PATH) -> None:
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._conn.commit()
        log.info("Marketplace DB connected: %s", self.db_path)

    def _db(self) -> sqlite3.Connection:
        if self._conn is None:
            self.connect()
        return self._conn  # type: ignore

    def list_plugins(self, category: Optional[str] = None, page: int = 1, per_page: int = 20) -> List[Dict]:
        offset = (page - 1) * per_page
        if category:
            rows = self._db().execute(
                "SELECT * FROM plugins WHERE category=? ORDER BY downloads DESC LIMIT ? OFFSET ?",
                (category, per_page, offset)
            ).fetchall()
        else:
            rows = self._db().execute(
                "SELECT * FROM plugins ORDER BY downloads DESC LIMIT ? OFFSET ?",
                (per_page, offset)
            ).fetchall()
        return [dict(r) for r in rows]

    def get_plugin(self, plugin_id: str) -> Optional[Dict]:
        row = self._db().execute("SELECT * FROM plugins WHERE id=?", (plugin_id,)).fetchone()
        if row is None:
            return None
        p = dict(row)
        versions = self._db().execute(
            "SELECT * FROM plugin_versions WHERE plugin_id=? ORDER BY published_ms DESC",
            (plugin_id,)
        ).fetchall()
        p["versions"] = [dict(v) for v in versions]
        reviews = self._db().execute(
            "SELECT * FROM plugin_reviews WHERE plugin_id=? ORDER BY created_ms DESC LIMIT 10",
            (plugin_id,)
        ).fetchall()
        p["reviews"] = [dict(r) for r in reviews]
        p["rating"] = p["rating_sum"] / p["rating_count"] if p["rating_count"] > 0 else None
        return p

    def create_plugin(self, data: Dict) -> str:
        plugin_id = str(uuid.uuid4())
        now = int(time.time() * 1000)
        self._db().execute(
            "INSERT INTO plugins (id,name,description,category,author,homepage,license,created_ms,updated_ms) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (plugin_id, data.get("name",""), data.get("description",""),
             data.get("category","tools"), data.get("author",""),
             data.get("homepage",""), data.get("license","MIT"), now, now)
        )
        self._db().execute(
            "INSERT INTO plugins_fts (id,name,description,category,author) VALUES (?,?,?,?,?)",
            (plugin_id, data.get("name",""), data.get("description",""),
             data.get("category",""), data.get("author",""))
        )
        self._db().commit()
        return plugin_id

    def add_version(self, plugin_id: str, version: str, pmcp_version: str,
                    archive_path: str, sha256: str, size_bytes: int, changelog: str) -> str:
        version_id = str(uuid.uuid4())
        now = int(time.time() * 1000)
        self._db().execute(
            "INSERT INTO plugin_versions (id,plugin_id,version,pmcp_version,archive_path,sha256,size_bytes,published_ms,changelog) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (version_id, plugin_id, version, pmcp_version, archive_path, sha256, size_bytes, now, changelog)
        )
        self._db().execute("UPDATE plugins SET updated_ms=? WHERE id=?", (now, plugin_id))
        self._db().commit()
        return version_id

    def increment_downloads(self, plugin_id: str) -> None:
        self._db().execute("UPDATE plugins SET downloads=downloads+1 WHERE id=?", (plugin_id,))
        self._db().commit()

    def add_review(self, plugin_id: str, author: str, rating: int, body: str) -> str:
        review_id = str(uuid.uuid4())
        now = int(time.time() * 1000)
        rating = max(1, min(5, rating))
        self._db().execute(
            "INSERT INTO plugin_reviews (id,plugin_id,author,rating,body,created_ms) VALUES (?,?,?,?,?,?)",
            (review_id, plugin_id, author, rating, body, now)
        )
        self._db().execute(
            "UPDATE plugins SET rating_sum=rating_sum+?, rating_count=rating_count+1 WHERE id=?",
            (rating, plugin_id)
        )
        self._db().commit()
        return review_id

    def search(self, query: str, page: int = 1, per_page: int = 20) -> List[Dict]:
        offset = (page - 1) * per_page
        rows = self._db().execute(
            "SELECT p.* FROM plugins p JOIN plugins_fts f ON p.id=f.id WHERE plugins_fts MATCH ? "
            "ORDER BY rank LIMIT ? OFFSET ?",
            (query, per_page, offset)
        ).fetchall()
        return [dict(r) for r in rows]

    def stats(self) -> Dict:
        total = self._db().execute("SELECT COUNT(*) FROM plugins").fetchone()[0]
        downloads = self._db().execute("SELECT SUM(downloads) FROM plugins").fetchone()[0] or 0
        return {"total_plugins": total, "total_downloads": downloads,
                "categories": CATEGORIES}


# ─────────────────────────────────────────────────────────────────────────────
#  HTTP Handlers
# ─────────────────────────────────────────────────────────────────────────────

def create_marketplace_app(db: MarketplaceDB) -> web.Application:
    os.makedirs(PLUGIN_STORE_DIR, exist_ok=True)
    app = web.Application()
    app["db"] = db

    r = app.router
    r.add_get("/api/v1/plugins", h_list_plugins)
    r.add_get("/api/v1/plugins/{id}", h_get_plugin)
    r.add_post("/api/v1/plugins", h_create_plugin)
    r.add_post("/api/v1/plugins/{id}/versions", h_add_version)
    r.add_get("/api/v1/plugins/{id}/install", h_install_plugin)
    r.add_post("/api/v1/plugins/{id}/review", h_add_review)
    r.add_get("/api/v1/categories", h_categories)
    r.add_get("/api/v1/search", h_search)
    r.add_get("/api/v1/stats", h_stats)
    r.add_get("/health", h_health)
    return app


async def h_list_plugins(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    category = req.rel_url.query.get("category")
    page = int(req.rel_url.query.get("page", "1"))
    plugins = db.list_plugins(category=category, page=page)
    return web.json_response({"plugins": plugins, "count": len(plugins), "page": page})


async def h_get_plugin(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    plugin = db.get_plugin(req.match_info["id"])
    if not plugin:
        raise web.HTTPNotFound(reason="Plugin not found")
    return web.json_response(plugin)


async def h_create_plugin(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    try:
        body = await req.json()
    except Exception:
        raise web.HTTPBadRequest(reason="Invalid JSON")
    if not body.get("name"):
        raise web.HTTPBadRequest(reason="name is required")
    plugin_id = db.create_plugin(body)
    return web.json_response({"plugin_id": plugin_id}, status=201)


async def h_add_version(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    plugin_id = req.match_info["id"]
    reader = await req.multipart()
    meta: Dict[str, Any] = {}
    archive_path = ""
    sha256 = ""
    size = 0

    async for part in reader:
        if part.name == "metadata":
            meta = json.loads(await part.read())
        elif part.name == "archive":
            data = await part.read()
            sha256 = hashlib.sha256(data).hexdigest()
            size = len(data)
            fname = f"{plugin_id}-{meta.get('version','0.0.0')}.zip"
            archive_path = os.path.join(PLUGIN_STORE_DIR, fname)
            with open(archive_path, "wb") as f:
                f.write(data)

    version_id = db.add_version(
        plugin_id, meta.get("version","0.1.0"), meta.get("pmcp_version","0.5"),
        archive_path, sha256, size, meta.get("changelog","")
    )
    return web.json_response({"version_id": version_id}, status=201)


async def h_install_plugin(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    plugin_id = req.match_info["id"]
    version_str = req.rel_url.query.get("version")
    plugin = db.get_plugin(plugin_id)
    if not plugin or not plugin.get("versions"):
        raise web.HTTPNotFound(reason="Plugin or version not found")

    version_info = (
        next((v for v in plugin["versions"] if v["version"] == version_str), None)
        if version_str
        else plugin["versions"][0]
    )
    if not version_info:
        raise web.HTTPNotFound(reason=f"Version {version_str} not found")

    archive_path = version_info.get("archive_path", "")
    if not archive_path or not os.path.exists(archive_path):
        raise web.HTTPNotFound(reason="Archive file missing")

    db.increment_downloads(plugin_id)
    return web.FileResponse(archive_path, headers={
        "Content-Disposition": f"attachment; filename={os.path.basename(archive_path)}",
        "X-PMCP-SHA256": version_info.get("sha256", ""),
    })


async def h_add_review(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    plugin_id = req.match_info["id"]
    try:
        body = await req.json()
    except Exception:
        raise web.HTTPBadRequest(reason="Invalid JSON")
    review_id = db.add_review(plugin_id, body.get("author","anonymous"),
                              int(body.get("rating", 3)), body.get("body",""))
    return web.json_response({"review_id": review_id}, status=201)


async def h_categories(req: web.Request) -> web.Response:
    return web.json_response({"categories": CATEGORIES})


async def h_search(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    query = req.rel_url.query.get("q", "")
    if not query:
        raise web.HTTPBadRequest(reason="q parameter required")
    results = db.search(query)
    return web.json_response({"results": results, "count": len(results), "query": query})


async def h_stats(req: web.Request) -> web.Response:
    db: MarketplaceDB = req.app["db"]
    return web.json_response(db.stats())


async def h_health(req: web.Request) -> web.Response:
    return web.json_response({"status": "ok"})


async def main(port: int = 9000) -> None:
    logging.basicConfig(level=logging.INFO)
    db = MarketplaceDB()
    db.connect()
    app = create_marketplace_app(db)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    log.info("Plugin marketplace running on port %d", port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
