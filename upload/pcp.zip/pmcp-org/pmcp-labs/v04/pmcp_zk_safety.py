"""
P-MCP v0.4 — ZK Safety Proof System
=======================================
"Prove a Trajectory is Safe Without Revealing It"

Zero-Knowledge Safety Proofs allow a robot to prove to a verifier
that its planned trajectory satisfies ALL safety constraints —
without revealing the exact path coordinates.

Use Cases
---------
1. Multi-company factory: Robot A (OEM A) proves safe trajectory to
   Factory Safety Authority without exposing proprietary motion plans
2. Regulatory compliance: Submit proof to ISO auditor without
   disclosing trade-secret manufacturing processes
3. Byzantine fault tolerance: Multiple robots verify each other's
   safety proofs before granting zone leases

ZK Scheme Used: HMAC-SHA256 Commitment Scheme
----------------------------------------------
Production: Replace with Groth16 / PLONK ZK-SNARK via:
  - py_ecc (Ethereum ZK libraries)
  - arkworks-rs (via cffi)
  - gnark-prover (Go, via subprocess)

This module implements a practical commitment-based approximation:
1. Prover commits to trajectory hash
2. Prover reveals safety-check results + a nonce
3. Verifier checks that results + nonce → commitment hash
4. Verifier runs safety rules independently on the result summary
5. Result: safe-trajectory proof without revealing waypoints
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.zk_safety")

# ── Optional real ZK libraries ─────────────────────────────────────────────
try:
    from py_ecc.bn128 import G1, G2, pairing, multiply, add, neg, FQ, FQ2
    _REAL_ZK = True
    log.info("  🔏  py_ecc available — enhanced ZK proofs enabled")
except ImportError:
    _REAL_ZK = False


# ─────────────────────────────────────────────────────────────
#  SAFETY CHECK RESULT (the "witness" for ZK proof)
# ─────────────────────────────────────────────────────────────

@dataclass
class SafetyCheckResult:
    """
    Summary of safety checks — revealed to verifier but not the raw trajectory.
    The ZK proof proves this summary is honest without revealing coordinates.
    """
    call_id:        str
    robot_id:       str
    zone_id:        str
    check_speed:    bool   # speed ≤ limit
    check_floor:    bool   # z ≥ 0
    check_energy:   bool   # energy ≤ limit
    check_human:    bool   # no human in path
    check_collision: bool  # no obstacle collision
    max_speed_ms:   float  # actual max speed (without exact trajectory)
    energy_j:       float  # actual energy (without exact trajectory)
    duration_s:     float  # actual duration
    all_passed:     bool   = field(init=False)

    def __post_init__(self):
        self.all_passed = all([
            self.check_speed, self.check_floor, self.check_energy,
            self.check_human, self.check_collision
        ])

    def to_dict(self) -> dict:
        return {
            "call_id":       self.call_id,
            "robot_id":      self.robot_id,
            "zone_id":       self.zone_id,
            "checks": {
                "speed":     self.check_speed,
                "floor":     self.check_floor,
                "energy":    self.check_energy,
                "human":     self.check_human,
                "collision": self.check_collision,
            },
            "metrics": {
                "max_speed_ms": round(self.max_speed_ms, 3),
                "energy_j":     round(self.energy_j, 2),
                "duration_s":   round(self.duration_s, 3),
            },
            "all_passed": self.all_passed,
        }


# ─────────────────────────────────────────────────────────────
#  ZK PROOF
# ─────────────────────────────────────────────────────────────

@dataclass
class ZKSafetyProof:
    """
    A commitment-scheme ZK proof that a trajectory is safe.

    Verification algorithm:
    1. Compute expected_hash = HMAC-SHA256(secret_key, commitment_data)
    2. Compare with proof.commitment
    3. Verify safety_checks.all_passed == True
    4. Verify proof is fresh (timestamp < MAX_AGE_S)
    """
    proof_id:         str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    call_id:          str   = ""
    robot_id:         str   = ""
    commitment:       str   = ""     # HMAC-SHA256 of (trajectory + nonce + check_results)
    nonce:            str   = ""     # Random nonce revealed by prover
    safety_checks:    Optional[SafetyCheckResult] = None
    constitution_hash: str  = ""     # Hash of the safety rules applied
    issued_at:        float = field(default_factory=time.time)
    valid_for_s:      float = 5.0    # Short TTL — proofs are single-use
    prover_pubkey:    str   = ""     # Robot DID public key

    def is_fresh(self) -> bool:
        return time.time() - self.issued_at < self.valid_for_s

    def to_dict(self) -> dict:
        return {
            "proof_id":         self.proof_id,
            "call_id":          self.call_id,
            "robot_id":         self.robot_id,
            "commitment":       self.commitment,
            "nonce":            self.nonce,
            "safety_checks":    self.safety_checks.to_dict() if self.safety_checks else None,
            "constitution_hash": self.constitution_hash,
            "issued_at":        self.issued_at,
            "valid_for_s":      self.valid_for_s,
            "is_fresh":         self.is_fresh(),
        }


# ─────────────────────────────────────────────────────────────
#  ZK PROVER
# ─────────────────────────────────────────────────────────────

class ZKSafetyProver:
    """
    Robot-side ZK prover.
    Called BEFORE confirming a tool call — generates proof from shadow outcome.

    In production ZK-SNARK mode:
        1. Compile safety circuit to R1CS/PLONK
        2. Generate proof using robot's proving key (issued by authority)
        3. Proof is small (~200 bytes) and fast to verify
    """

    def __init__(self, robot_id: str, prover_key: Optional[bytes] = None,
                 constitution_rules=None):
        self._robot_id   = robot_id
        self._prover_key = prover_key or secrets.token_bytes(32)
        self._constitution_rules = constitution_rules
        self._proofs_generated = 0

    def prove(self, call, constitution_hash: str = "") -> ZKSafetyProof:
        """
        Generate a ZK safety proof for a pending ToolCall.
        call must have call.projected set (shadow validated).
        """
        p = call.projected
        if p is None:
            raise ValueError("Cannot prove: no projected outcome on call")

        nonce = secrets.token_hex(16)

        # Build the safety check result (the "witness")
        checks = SafetyCheckResult(
            call_id         = call.call_id,
            robot_id        = call.robot_id,
            zone_id         = call.arguments.get("zone_id", "world"),
            check_speed     = float(call.arguments.get("speed", 0)) <= 1.5,
            check_floor     = float(call.arguments.get("z", 1.0)) >= 0.0,
            check_energy    = p.energy_j <= 5000.0,
            check_human     = len(p.workspace_conflicts) == 0,
            check_collision = p.safe_to_execute,
            max_speed_ms    = float(call.arguments.get("speed", 0)),
            energy_j        = p.energy_j,
            duration_s      = p.duration_s,
        )

        # Commitment = HMAC(key, trajectory_hash || check_summary || nonce)
        # In real ZK: commitment = Pedersen_commit(witness, randomness)
        trajectory_hash = self._hash_trajectory(call.arguments)
        check_summary   = json.dumps(checks.to_dict(), sort_keys=True)
        commit_data     = f"{trajectory_hash}|{check_summary}|{nonce}|{call.call_id}"
        commitment      = hmac.new(
            self._prover_key,
            commit_data.encode(),
            hashlib.sha256,
        ).hexdigest()

        self._proofs_generated += 1

        proof = ZKSafetyProof(
            call_id          = call.call_id,
            robot_id         = call.robot_id,
            commitment       = commitment,
            nonce            = nonce,
            safety_checks    = checks,
            constitution_hash= constitution_hash,
            issued_at        = time.time(),
            valid_for_s      = 5.0,
            prover_pubkey    = self._prover_key.hex()[:32],
        )

        log.info(f"  🔏  ZK proof generated: {proof.proof_id} "
                 f"passed={checks.all_passed} call={call.call_id[:8]}")
        return proof

    def _hash_trajectory(self, arguments: dict) -> str:
        """Hash the trajectory arguments (path coordinates are hidden in commitment)."""
        canonical = json.dumps(
            {k: round(v, 6) if isinstance(v, float) else v
             for k, v in sorted(arguments.items())},
            sort_keys=True
        )
        return hashlib.sha256(canonical.encode()).hexdigest()[:32]


# ─────────────────────────────────────────────────────────────
#  ZK VERIFIER
# ─────────────────────────────────────────────────────────────

class ZKSafetyVerifier:
    """
    Server-side / TEE-side ZK verifier.
    Verifies a ZK proof is:
    1. Fresh (not stale)
    2. Consistent (commitment matches revealed data)
    3. Safe (all safety checks pass)
    4. Issued against the correct constitution
    """

    def __init__(self, verifier_id: str = "tee-verifier",
                 constitution_hash: str = ""):
        self._verifier_id       = verifier_id
        self._constitution_hash = constitution_hash
        self._verified_proofs:  Dict[str, dict] = {}   # proof_id → result
        self._used_nonces:      set = set()             # Replay protection

    def verify(
        self,
        proof: ZKSafetyProof,
        robot_prover_key: Optional[bytes] = None,
        call_arguments:   Optional[dict]  = None,
    ) -> Tuple[bool, List[str]]:
        """
        Verify a ZK safety proof.
        Returns (verified, list_of_violations).
        """
        violations = []

        # 1. Freshness
        if not proof.is_fresh():
            violations.append(f"Proof expired (age={time.time()-proof.issued_at:.2f}s > {proof.valid_for_s}s)")
            return False, violations

        # 2. Replay protection
        replay_key = f"{proof.call_id}:{proof.nonce}"
        if replay_key in self._used_nonces:
            violations.append("Replay attack detected — nonce already used")
            return False, violations
        self._used_nonces.add(replay_key)

        # 3. Commitment verification (if prover key provided)
        if robot_prover_key and call_arguments and proof.safety_checks:
            check_summary   = json.dumps(proof.safety_checks.to_dict(), sort_keys=True)
            traj_hash       = hashlib.sha256(
                json.dumps({k: round(v, 6) if isinstance(v, float) else v
                            for k, v in sorted(call_arguments.items())},
                           sort_keys=True).encode()
            ).hexdigest()[:32]

            commit_data = f"{traj_hash}|{check_summary}|{proof.nonce}|{proof.call_id}"
            expected    = hmac.new(robot_prover_key, commit_data.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected, proof.commitment):
                violations.append("Commitment mismatch — trajectory may have changed")
                return False, violations

        # 4. Safety check results
        if proof.safety_checks:
            sc = proof.safety_checks
            if not sc.check_speed:
                violations.append(f"PROOF: speed check FAILED ({sc.max_speed_ms:.2f} m/s)")
            if not sc.check_floor:
                violations.append("PROOF: floor guard FAILED")
            if not sc.check_energy:
                violations.append(f"PROOF: energy limit FAILED ({sc.energy_j:.0f}J)")
            if not sc.check_human:
                violations.append("PROOF: human clearance FAILED")
            if not sc.check_collision:
                violations.append("PROOF: collision check FAILED")

        # 5. Constitution hash consistency
        if (self._constitution_hash and proof.constitution_hash
                and self._constitution_hash != proof.constitution_hash):
            violations.append(
                f"Constitution hash mismatch: "
                f"expected={self._constitution_hash[:16]} "
                f"got={proof.constitution_hash[:16]}"
            )

        success = len(violations) == 0
        self._verified_proofs[proof.proof_id] = {
            "proof_id":  proof.proof_id,
            "call_id":   proof.call_id,
            "success":   success,
            "violations": violations,
            "verified_at": time.time(),
        }

        if success:
            log.info(f"  ✅  ZK proof VERIFIED: {proof.proof_id} robot={proof.robot_id}")
        else:
            log.warning(f"  ❌  ZK proof FAILED: {proof.proof_id} — {violations}")

        return success, violations

    def stats(self) -> dict:
        total    = len(self._verified_proofs)
        passed   = sum(1 for v in self._verified_proofs.values() if v["success"])
        return {"total": total, "passed": passed, "failed": total - passed}


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    print("\n" + "═"*60)
    print("  P-MCP ZK Safety Proof System — Demo")
    print("═"*60)

    # Simulate a tool call with projected outcome
    class _FakeVec3:
        def __init__(self, x, y, z): self.x, self.y, self.z = x, y, z
    class _FakePose:
        def __init__(self):
            self.position = _FakeVec3(1.0, 0.5, 0.8)
            self.roll = self.pitch = self.yaw = 0.0
            self.frame = "world"
    class _FakeProjected:
        duration_s = 2.0; energy_j = 150.0; risk_level = "low"
        workspace_conflicts = []; safe_to_execute = True
        final_pose = _FakePose()
    class _FakeCall:
        call_id  = "test-abc12345"
        robot_id = "arm-01"
        arguments = {"x": 1.0, "y": 0.5, "z": 0.8, "speed": 0.4}
        projected = _FakeProjected()

    call      = _FakeCall()
    prover    = ZKSafetyProver("arm-01")
    verifier  = ZKSafetyVerifier("tee-verifier")

    # Generate proof
    proof = prover.prove(call)
    print(f"\n  📜  Proof generated: {proof.proof_id}")
    print(f"       Commitment   : {proof.commitment[:24]}...")
    print(f"       Nonce        : {proof.nonce[:16]}...")
    print(f"       All checks   : {proof.safety_checks.all_passed}")

    # Verify proof
    ok, violations = verifier.verify(proof, prover._prover_key, call.arguments)
    print(f"\n  {'✅' if ok else '❌'}  Verification: {'PASSED' if ok else 'FAILED'}")
    for v in violations:
        print(f"       {v}")

    # Test replay detection
    print("\n  Replaying same proof (should fail)...")
    ok2, v2 = verifier.verify(proof, prover._prover_key, call.arguments)
    print(f"  {'✅' if ok2 else '❌'}  Replay: {'PASSED (unexpected!)' if ok2 else 'BLOCKED (correct)'}")

    # Test with unsafe call
    class _UnsafeCall(_FakeCall):
        call_id  = "unsafe-xyz9999"
        arguments = {"x": 1.0, "y": 0.5, "z": 0.8, "speed": 3.0}  # speed too high
        class _UnsafeProjected(_FakeProjected):
            energy_j = 6000.0   # too much energy
        projected = _UnsafeProjected()

    unsafe_call = _UnsafeCall()
    unsafe_proof = prover.prove(unsafe_call)
    ok3, v3 = verifier.verify(unsafe_proof, prover._prover_key, unsafe_call.arguments)
    print(f"\n  Unsafe call  → {'✅' if ok3 else '❌ BLOCKED'}")
    for v in v3:
        print(f"       {v}")

    print(f"\n  Verifier stats: {verifier.stats()}")
