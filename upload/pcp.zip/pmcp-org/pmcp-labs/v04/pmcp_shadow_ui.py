"""
P-MCP v0.4 — Shadow UI WebSocket Backend
==========================================
"Preview Before You Move — The 3D Safety Window for Physical AI"

Architecture:
    PMCPServer.invoke()
        ↓  ProjectedOutcome + TemporalEnvelope
    ShadowUIServer (asyncio WebSocket)
        ↓  JSON stream over ws://
    Browser / Unity / Three.js client
        ↓  renders ghost robot trajectory in 3D
        ↓  human supervisor sees move BEFORE hardware moves
        ↓  APPROVE / DENY buttons

Message Protocol (JSON-RPC over WebSocket)
-------------------------------------------
Server → Client:
  { "type": "shadow_preview",
    "call_id": "abc123",
    "robot_id": "arm-01",
    "tool_name": "move_to",
    "current_pose": { "x":0.5,"y":0.5,"z":1.0,"roll":0,"pitch":0,"yaw":0 },
    "final_pose":   { "x":1.0,"y":0.5,"z":0.8, ... },
    "path_waypoints": [ {...}, ... ],
    "duration_s": 2.1,
    "energy_j":   85.3,
    "risk_level": "low",
    "risk_reasons": [],
    "safe_to_execute": true,
    "temporal_envelope": [...],
    "carbon_g": 12.4,
    "expires_at_ms": 1714960005000
  }

Client → Server:
  { "type": "approve",  "call_id": "abc123" }
  { "type": "deny",     "call_id": "abc123", "reason": "path too close to worker" }
  { "type": "subscribe" }
  { "type": "get_twin" }

Server → Client (twin state):
  { "type": "twin_state",
    "robots": [ {"id":"arm-01", "pose":{...}} ],
    "zones":  [ {"name":"grow_zone_a","min":{...},"max":{...},"type":"clear"} ],
    "voxels": [ {"label":"human","x":1.2,"y":0.5,"z":0.9, ...} ],
    "reservations": [ ... ]
  }
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set

log = logging.getLogger("pmcp.shadow_ui")

# ── Optional websockets ────────────────────────────────────────────────────
try:
    import websockets
    from websockets.server import WebSocketServerProtocol
    _WS = True
except ImportError:
    _WS = False
    log.info("  🖥️  websockets not installed — Shadow UI stub mode")


# ─────────────────────────────────────────────────────────────
#  SHADOW SERIALISER
# ─────────────────────────────────────────────────────────────

def _pose_to_dict(pose) -> Optional[dict]:
    if pose is None:
        return None
    return {
        "x": round(pose.position.x, 4),
        "y": round(pose.position.y, 4),
        "z": round(pose.position.z, 4),
        "roll":  round(pose.roll,  4),
        "pitch": round(pose.pitch, 4),
        "yaw":   round(pose.yaw,   4),
        "frame": pose.frame,
    }


def _envelope_to_list(env) -> List[dict]:
    if env is None:
        return []
    return [
        {"zone_id": s.zone_id, "robot_id": s.robot_id,
         "start_ms": round(s.start_ms, 1), "end_ms": round(s.end_ms, 1),
         "x": round(s.position.x, 3), "y": round(s.position.y, 3),
         "z": round(s.position.z, 3)}
        for s in env.slots
    ]


def projected_to_shadow_msg(call, current_pose=None) -> dict:
    """Convert a ToolCall + ProjectedOutcome to a Shadow UI preview message."""
    p = call.projected
    if p is None:
        return {"type": "shadow_error", "call_id": call.call_id,
                "error": "No projection available"}

    return {
        "type":             "shadow_preview",
        "call_id":          call.call_id,
        "robot_id":         call.robot_id,
        "tool_name":        call.tool_name,
        "caller_id":        call.caller_id,
        "arguments":        call.arguments,
        "current_pose":     _pose_to_dict(current_pose),
        "final_pose":       _pose_to_dict(p.final_pose),
        "duration_s":       round(p.duration_s, 3),
        "energy_j":         round(p.energy_j, 2),
        "risk_level":       p.risk_level,
        "risk_reasons":     p.risk_reasons,
        "safe_to_execute":  p.safe_to_execute,
        "workspace_conflicts": p.workspace_conflicts,
        "carbon_g":         round(p.carbon_g, 3),
        "cost_usd":         round(p.cost_usd, 5),
        "utility_score":    round(p.utility_score, 3),
        "temporal_envelope": _envelope_to_list(p.temporal_envelope),
        "drift_warning":    p.drift_warning,
        "expires_at_ms":    round(call.confirm_deadline_ms, 1),
        "timestamp":        round(call.timestamp, 3),
    }


# ─────────────────────────────────────────────────────────────
#  SHADOW UI SERVER
# ─────────────────────────────────────────────────────────────

@dataclass
class PendingApproval:
    call_id:    str
    preview_msg: dict
    created_at: float = field(default_factory=time.time)
    event:      asyncio.Event = field(default_factory=asyncio.Event)
    approved:   bool  = False
    deny_reason: str  = ""

    def is_expired(self, deadline_ms: float) -> bool:
        return time.time() * 1000 > deadline_ms


class ShadowUIServer:
    """
    WebSocket server that:
    1. Broadcasts shadow previews to all connected supervisors
    2. Waits for APPROVE/DENY before releasing the tool call
    3. Auto-approves if no human connected (headless mode)
    4. Streams twin state on demand

    Usage:
        server = PMCPServer(...)
        shadow_ui = ShadowUIServer(server, twin, host="0.0.0.0", port=8765)
        await shadow_ui.start()

        # In tool flow:
        call  = await server.invoke("move_to", ...)
        ok    = await shadow_ui.request_approval(call, timeout_s=10.0)
        if ok:
            await server.confirm(call.call_id)
    """

    def __init__(self, pmcp_server=None, twin=None,
                 host: str = "0.0.0.0", port: int = 8765,
                 auto_approve_headless: bool = True):
        self._server  = pmcp_server
        self._twin    = twin
        self._host    = host
        self._port    = port
        self._auto_approve = auto_approve_headless

        self._clients:   Set[Any] = set()
        self._pending:   Dict[str, PendingApproval] = {}
        self._ws_server  = None
        self._event_log: List[dict] = []

    # ── Client management ─────────────────────────────────────────────────

    async def _register(self, ws):
        self._clients.add(ws)
        log.info(f"  🖥️  Shadow UI client connected ({len(self._clients)} total)")

    async def _unregister(self, ws):
        self._clients.discard(ws)
        log.info(f"  🖥️  Shadow UI client disconnected ({len(self._clients)} remaining)")

    async def _broadcast(self, msg: dict):
        if not self._clients:
            return
        payload = json.dumps(msg)
        dead = set()
        for ws in self._clients:
            try:
                await ws.send(payload)
            except Exception:
                dead.add(ws)
        self._clients -= dead

    # ── Shadow preview / approval flow ────────────────────────────────────

    async def request_approval(self, call, timeout_s: float = 10.0) -> bool:
        """
        Broadcast a shadow preview and wait for human approval.
        Returns True if approved (or auto-approved), False if denied/timeout.
        """
        if not hasattr(call, 'projected') or call.projected is None:
            return True  # No projection = pass-through

        # Build preview message
        current_pose = None
        if self._twin:
            current_pose = self._twin.get_pose(call.robot_id)
        preview = projected_to_shadow_msg(call, current_pose)

        # If no clients connected, auto-approve in headless mode
        if not self._clients and self._auto_approve:
            log.info(f"  🖥️  [{call.call_id}] Headless auto-approve (no supervisors)")
            return True

        # Register pending approval
        pa = PendingApproval(call_id=call.call_id, preview_msg=preview)
        self._pending[call.call_id] = pa

        # Broadcast to all supervisors
        await self._broadcast(preview)
        log.info(f"  🖥️  [{call.call_id}] Shadow preview sent to {len(self._clients)} supervisor(s)")

        # Wait for response or timeout
        try:
            await asyncio.wait_for(pa.event.wait(), timeout=timeout_s)
        except asyncio.TimeoutError:
            log.warning(f"  🖥️  [{call.call_id}] Supervisor timeout — auto-deny")
            del self._pending[call.call_id]
            return False

        del self._pending[call.call_id]
        if pa.approved:
            log.info(f"  ✅  [{call.call_id}] Supervisor APPROVED")
        else:
            log.warning(f"  ❌  [{call.call_id}] Supervisor DENIED: {pa.deny_reason}")
        return pa.approved

    async def broadcast_result(self, call_id: str, success: bool, message: str = ""):
        await self._broadcast({
            "type":     "execution_result",
            "call_id":  call_id,
            "success":  success,
            "message":  message,
            "timestamp": time.time(),
        })

    # ── Twin state stream ─────────────────────────────────────────────────

    def _build_twin_state(self) -> dict:
        if self._twin is None:
            return {"type": "twin_state", "robots": [], "zones": [], "voxels": []}

        robots = []
        try:
            for rid, pose in self._twin._robot_poses.items():
                robots.append({"id": rid, "pose": _pose_to_dict(pose)})
        except Exception:
            pass

        zones = []
        try:
            for z in self._twin._zones:
                zones.append({
                    "name": z.name,
                    "min": {"x": z.min.x, "y": z.min.y, "z": z.min.z},
                    "max": {"x": z.max.x, "y": z.max.y, "z": z.max.z},
                    "type": z.zone_type,
                })
        except Exception:
            pass

        reservations = []
        try:
            for s in self._twin._temporal_reservations:
                reservations.append({
                    "zone_id":   s.zone_id,
                    "robot_id":  s.robot_id,
                    "start_ms":  s.start_ms,
                    "end_ms":    s.end_ms,
                })
        except Exception:
            pass

        return {
            "type":         "twin_state",
            "robots":       robots,
            "zones":        zones,
            "voxels":       self._twin.get_vision_voxels() if hasattr(self._twin, 'get_vision_voxels') else [],
            "reservations": reservations,
            "timestamp":    time.time(),
        }

    # ── WebSocket handler ─────────────────────────────────────────────────

    async def _ws_handler(self, ws):
        await self._register(ws)
        # Send current twin state on connect
        try:
            await ws.send(json.dumps(self._build_twin_state()))
        except Exception:
            pass

        try:
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                msg_type = msg.get("type", "")

                if msg_type == "approve":
                    call_id = msg.get("call_id", "")
                    if call_id in self._pending:
                        self._pending[call_id].approved = True
                        self._pending[call_id].event.set()
                        self._event_log.append({"action": "approve", "call_id": call_id,
                                                "ts": time.time()})

                elif msg_type == "deny":
                    call_id    = msg.get("call_id", "")
                    deny_reason = msg.get("reason", "Denied by supervisor")
                    if call_id in self._pending:
                        self._pending[call_id].approved    = False
                        self._pending[call_id].deny_reason = deny_reason
                        self._pending[call_id].event.set()
                        self._event_log.append({"action": "deny", "call_id": call_id,
                                                "reason": deny_reason, "ts": time.time()})

                elif msg_type == "get_twin":
                    await ws.send(json.dumps(self._build_twin_state()))

                elif msg_type == "subscribe":
                    # Client confirms subscription; send latest pending previews
                    for pa in list(self._pending.values()):
                        try:
                            await ws.send(json.dumps(pa.preview_msg))
                        except Exception:
                            break

                elif msg_type == "emergency_halt":
                    log.critical("  🚨  EMERGENCY HALT from Shadow UI supervisor!")
                    await self._broadcast({"type": "halt_broadcast",
                                           "source": "supervisor", "ts": time.time()})

        except Exception as e:
            log.debug(f"  🖥️  WS client error: {e}")
        finally:
            await self._unregister(ws)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self):
        if not _WS:
            log.warning("  🖥️  websockets not installed — Shadow UI disabled")
            return
        self._ws_server = await websockets.serve(
            self._ws_handler, self._host, self._port,
            ping_interval=20, ping_timeout=10,
        )
        log.info(f"  🖥️  Shadow UI WebSocket server: ws://{self._host}:{self._port}")

    async def stop(self):
        if self._ws_server:
            self._ws_server.close()
            await self._ws_server.wait_closed()

    def pending_count(self) -> int:
        return len(self._pending)

    def client_count(self) -> int:
        return len(self._clients)

    def event_log(self) -> List[dict]:
        return list(self._event_log)


# ─────────────────────────────────────────────────────────────
#  STATIC HTML SHADOW VIEWER (served as a string for quick demo)
# ─────────────────────────────────────────────────────────────

SHADOW_UI_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>P-MCP Shadow UI — Robot Safety Visualizer</title>
<style>
  body { background: #0a0a0f; color: #e0e0e0; font-family: monospace; margin: 0; }
  #header { padding: 12px 20px; background: #111; border-bottom: 1px solid #333; }
  #header h1 { margin: 0; font-size: 16px; color: #00d4ff; }
  #container { display: flex; height: calc(100vh - 50px); }
  #canvas-panel { flex: 1; padding: 10px; }
  #sidebar { width: 360px; padding: 12px; border-left: 1px solid #333; overflow-y: auto; }
  canvas { background: #050510; border: 1px solid #222; border-radius: 4px; }
  .card { background: #111; border: 1px solid #333; border-radius: 6px;
          padding: 12px; margin-bottom: 10px; }
  .card.risk-high { border-color: #ff4444; }
  .card.risk-medium { border-color: #ffaa00; }
  .card.risk-low { border-color: #44ff88; }
  .approve-btn { background: #1a6b3a; color: #fff; border: none; border-radius: 4px;
                 padding: 8px 16px; cursor: pointer; margin-right: 8px; font-family: monospace; }
  .deny-btn    { background: #6b1a1a; color: #fff; border: none; border-radius: 4px;
                 padding: 8px 16px; cursor: pointer; font-family: monospace; }
  .approve-btn:hover { background: #22a050; }
  .deny-btn:hover    { background: #a02222; }
  .tag { display: inline-block; padding: 2px 8px; border-radius: 10px;
         font-size: 11px; margin: 2px; }
  .tag.low    { background: #0d3320; color: #44ff88; }
  .tag.medium { background: #332800; color: #ffaa00; }
  .tag.high   { background: #330d0d; color: #ff4444; }
  #status { font-size: 11px; color: #888; margin-top: 8px; }
</style>
</head>
<body>
<div id="header">
  <h1>⚡ P-MCP Shadow UI — Physical AI Safety Console</h1>
</div>
<div id="container">
  <div id="canvas-panel">
    <canvas id="workspace" width="700" height="550"></canvas>
    <div id="status">Connecting to Shadow Server...</div>
  </div>
  <div id="sidebar">
    <h3 style="color:#00d4ff;margin-top:0">Pending Approvals</h3>
    <div id="approvals"></div>
    <h3 style="color:#888">Event Log</h3>
    <div id="log" style="font-size:11px;color:#666;max-height:200px;overflow-y:auto"></div>
  </div>
</div>
<script>
const WS_URL = 'ws://' + location.hostname + ':8765';
let ws, twin = { robots:[], zones:[], voxels:[], reservations:[] };

function connect() {
  ws = new WebSocket(WS_URL);
  ws.onopen = () => {
    document.getElementById('status').textContent = '✅ Connected to Shadow Server';
    ws.send(JSON.stringify({type:'subscribe'}));
  };
  ws.onclose = () => {
    document.getElementById('status').textContent = '❌ Disconnected — retrying...';
    setTimeout(connect, 2000);
  };
  ws.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    if (msg.type === 'twin_state') {
      twin = msg; drawWorkspace();
    } else if (msg.type === 'shadow_preview') {
      addPreview(msg); drawWorkspace(msg);
    } else if (msg.type === 'execution_result') {
      addLog('Result: ' + msg.call_id + ' → ' + (msg.success ? '✅' : '❌') + ' ' + msg.message);
    }
  };
}

function addPreview(msg) {
  const div = document.createElement('div');
  div.className = 'card risk-' + msg.risk_level;
  div.id = 'preview-' + msg.call_id;
  const expiry = new Date(msg.expires_at_ms).toLocaleTimeString();
  div.innerHTML = `
    <div><strong>${msg.tool_name}</strong> on <code>${msg.robot_id}</code></div>
    <div style="margin:4px 0">
      <span class="tag ${msg.risk_level}">${msg.risk_level.toUpperCase()}</span>
      ${msg.safe_to_execute ? '<span class="tag low">SAFE</span>' : '<span class="tag high">BLOCKED</span>'}
    </div>
    <div style="font-size:11px;color:#aaa">
      ⏱ ${msg.duration_s.toFixed(1)}s &nbsp; ⚡ ${msg.energy_j.toFixed(0)}J
      &nbsp; 🌿 ${msg.carbon_g.toFixed(1)}g CO₂ &nbsp; Expires: ${expiry}
    </div>
    ${msg.risk_reasons.length ? '<div style="color:#ffaa00;font-size:11px;margin-top:4px">⚠️ ' + msg.risk_reasons.join(', ') + '</div>' : ''}
    <div style="margin-top:8px">
      <button class="approve-btn" onclick="approve('${msg.call_id}')">✅ Approve</button>
      <button class="deny-btn" onclick="deny('${msg.call_id}')">❌ Deny</button>
    </div>`;
  document.getElementById('approvals').prepend(div);
  setTimeout(() => { const el = document.getElementById('preview-'+msg.call_id); if(el) el.remove(); }, 15000);
}

function approve(id) {
  ws.send(JSON.stringify({type:'approve',call_id:id}));
  const el = document.getElementById('preview-'+id); if(el) el.remove();
  addLog('Approved: ' + id);
}
function deny(id) {
  const r = prompt('Reason for denial:') || 'Supervisor denied';
  ws.send(JSON.stringify({type:'deny',call_id:id,reason:r}));
  const el = document.getElementById('preview-'+id); if(el) el.remove();
  addLog('Denied: ' + id + ' — ' + r);
}
function addLog(msg) {
  const el = document.getElementById('log');
  el.innerHTML = '<div>' + new Date().toLocaleTimeString() + ' ' + msg + '</div>' + el.innerHTML;
}

function drawWorkspace(preview) {
  const canvas = document.getElementById('workspace');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const SCALE = 90; const OX = 40, OY = 40;
  ctx.clearRect(0,0,W,H);

  // Grid
  ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 1;
  for(let i=0;i<=6;i++) {
    ctx.beginPath(); ctx.moveTo(OX+i*SCALE,OY); ctx.lineTo(OX+i*SCALE,OY+5*SCALE); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(OX,OY+i*SCALE); ctx.lineTo(OX+6*SCALE,OY+i*SCALE); ctx.stroke();
  }

  // Zones
  (twin.zones||[]).forEach(z => {
    ctx.fillStyle = z.type==='human_zone' ? 'rgba(255,60,60,0.1)' : 'rgba(0,100,60,0.1)';
    ctx.strokeStyle = z.type==='human_zone' ? '#ff3c3c' : '#005c38';
    ctx.lineWidth = 1;
    const x=OX+z.min.x*SCALE, y=OY+z.min.y*SCALE;
    const w=(z.max.x-z.min.x)*SCALE, h=(z.max.y-z.min.y)*SCALE;
    ctx.fillRect(x,y,w,h); ctx.strokeRect(x,y,w,h);
    ctx.fillStyle='#555'; ctx.font='10px monospace';
    ctx.fillText(z.name,x+4,y+14);
  });

  // Voxels (humans/obstacles)
  (twin.voxels||[]).forEach(v => {
    ctx.fillStyle = v.is_human ? 'rgba(255,80,80,0.85)' : 'rgba(255,180,0,0.7)';
    const px=OX+v.x*SCALE-8, py=OY+v.y*SCALE-8;
    ctx.fillRect(px,py,16,16);
    ctx.fillStyle='#fff'; ctx.font='9px monospace';
    ctx.fillText(v.is_human?'H':v.label[0].toUpperCase(),px+5,py+11);
  });

  // Preview path
  if(preview && preview.current_pose && preview.final_pose) {
    const cp=preview.current_pose, fp=preview.final_pose;
    ctx.strokeStyle = preview.safe_to_execute ? '#00ff88' : '#ff4444';
    ctx.lineWidth = 2; ctx.setLineDash([6,4]);
    ctx.beginPath();
    ctx.moveTo(OX+cp.x*SCALE, OY+cp.y*SCALE);
    ctx.lineTo(OX+fp.x*SCALE, OY+fp.y*SCALE);
    ctx.stroke(); ctx.setLineDash([]);
    // Ghost robot at final
    ctx.fillStyle = preview.safe_to_execute ? 'rgba(0,255,136,0.4)' : 'rgba(255,68,68,0.4)';
    ctx.beginPath(); ctx.arc(OX+fp.x*SCALE,OY+fp.y*SCALE,12,0,Math.PI*2); ctx.fill();
  }

  // Robots
  (twin.robots||[]).forEach(r => {
    if(!r.pose) return;
    ctx.fillStyle='#00d4ff';
    ctx.beginPath(); ctx.arc(OX+r.pose.x*SCALE,OY+r.pose.y*SCALE,10,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#000'; ctx.font='bold 9px monospace';
    ctx.fillText(r.id.split('-')[1]||r.id, OX+r.pose.x*SCALE-8, OY+r.pose.y*SCALE+4);
  });

  // Legend
  ctx.fillStyle='#444'; ctx.font='10px monospace';
  ctx.fillText('● Robot  ─ ─ Path (green=safe, red=blocked)  ■ Human/Obstacle', 8, H-8);
}

connect();
setInterval(()=>{ if(ws&&ws.readyState===1) ws.send(JSON.stringify({type:'get_twin'})); }, 1000);
</script>
</body>
</html>"""


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import os
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    # Save the HTML for browser opening
    html_path = "/tmp/pmcp_shadow_ui.html"
    with open(html_path, "w") as f:
        f.write(SHADOW_UI_HTML)
    print(f"\n  🖥️  Shadow UI HTML saved: {html_path}")
    print(f"  🖥️  Open in browser after starting the WebSocket server")

    async def _demo():
        if not _WS:
            print("  ⚠️  websockets not installed: pip install websockets")
            print("       Shadow UI requires WebSocket support")
            return

        ui = ShadowUIServer(host="localhost", port=8765, auto_approve_headless=True)
        await ui.start()
        print(f"\n  🖥️  Shadow UI running: ws://localhost:8765")
        print(f"  🖥️  Open: {html_path}")
        print(f"  🖥️  Press Ctrl+C to stop\n")

        # Simulate a preview broadcast
        await asyncio.sleep(2)

        class _FakeVec3:
            def __init__(self, x, y, z): self.x, self.y, self.z = x, y, z
        class _FakePose:
            def __init__(self, x, y, z):
                self.position = _FakeVec3(x, y, z)
                self.roll = self.pitch = self.yaw = 0.0
                self.frame = "world"
        class _FakeOutcome:
            duration_s = 2.1; energy_j = 85.3; risk_level = "low"
            risk_reasons = []; carbon_g = 12.4; cost_usd = 0.0012
            workspace_conflicts = []; safe_to_execute = True
            utility_score = 0.85; temporal_envelope = None; drift_warning = ""
            final_pose = _FakePose(1.0, 0.5, 0.8)
        class _FakeCall:
            call_id = "demo-0001"; robot_id = "arm-01"; tool_name = "move_to"
            caller_id = "llm-agent"; arguments = {"x":1.0,"y":0.5,"z":0.8,"speed":0.3}
            timestamp = time.time(); confirm_deadline_ms = (time.time()+10)*1000
            projected = _FakeOutcome()

        call = _FakeCall()
        approved = await ui.request_approval(call, timeout_s=30.0)
        print(f"\n  Result: {'Approved' if approved else 'Denied/Timeout'}")

    asyncio.run(_demo())
