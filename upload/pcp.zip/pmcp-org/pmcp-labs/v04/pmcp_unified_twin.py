"""
P-MCP v0.4 — Unified Digital Twin UI
======================================
"One Pane of Glass for the Entire Robot Fleet"

This module extends the Shadow UI WebSocket backend to create a
Unified Digital Twin that synchronises state from all installed
drivers in real-time — with special support for the UR5 arm and
Siemens S7 PLC working in concert on an industrial production line.

Architecture
------------
    UR5Driver  ─────────→ DriverStateCollector ─→ UnifiedTwinSynchroniser
    SiemensS7Driver ─────→       (Zenoh/stub)   ─→        │
    TurtleBotDriver ─────→                               │
                                                          ▼
                                                  UnifiedDigitalTwin (in-memory)
                                                          │
                                            ┌─────────────┴─────────────┐
                                            ▼                           ▼
                                   ShadowUIServer               ZenohTwinBridge
                                   (WebSocket JSON)         (high-bandwidth vision)
                                            │
                                            ▼
                                  Browser / Unity / Three.js
                                   renders live 3D scene

UR5 + Siemens S7 Sync Protocol
------------------------------
The UR5 arm and the Siemens S7 PLC are tightly coupled on a conveyor
pick-and-place line:

  Step 1  S7 PLC signals "part present on conveyor"  (DI bit 0.0)
  Step 2  TwinSynchroniser sets "pick_ready" event
  Step 3  UR5 arm receives "pick" command via P-MCP
  Step 4  UR5 executes pick; sends "picked" status back
  Step 5  S7 PLC receives "picked" signal → releases conveyor clamp
  Step 6  Shadow UI shows both robots in their new state simultaneously

Zenoh Transport Strategy
-------------------------
  High-bandwidth (Vision):  Zenoh  (key=farm/vision/{cam_id})
  Low-power (Arduino/S7):   MQTT   (topic=pmcp/{robot_id}/state)
  Command channel:          P-MCP  (ZK-verified tool calls)

Zenoh Throughput Stress Test
-----------------------------
ZenohStressTest.run(n_streams, duration_s) will:
  - Spawn N concurrent TurtleBot-style telemetry streams
  - Measure latency percentiles (p50, p95, p99)
  - Report the stream count at which hub latency exceeds SLA (50 ms)
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import statistics
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

log = logging.getLogger("pmcp.unified_twin")

# ── Optional deps ──────────────────────────────────────────────────────────
try:
    import websockets
    from websockets.server import WebSocketServerProtocol
    _WS = True
except ImportError:
    _WS = False
    log.info("websockets not installed — Unified Twin in stub mode")

try:
    import zenoh
    _ZENOH = True
except ImportError:
    _ZENOH = False
    log.info("zenoh not installed — using in-memory pub/sub stub")

try:
    from v04.drivers.ur5_driver import UR5Driver
    _UR5 = True
except ImportError:
    _UR5 = False

try:
    from v04.drivers.siemens_s7_driver import SiemensS7Driver
    _S7 = True
except ImportError:
    _S7 = False

try:
    from v04.drivers.turtlebot_driver import TurtleBotDriver
    _TB = True
except ImportError:
    _TB = False


# ─────────────────────────────────────────────────────────────
#  DATA MODEL
# ─────────────────────────────────────────────────────────────

class DriverType(str, Enum):
    ARM        = "arm"
    MOBILE     = "mobile"
    PLC        = "plc"
    VISION     = "vision"
    SENSOR     = "sensor"


@dataclass
class DriverStateSnapshot:
    """
    Normalised real-time state snapshot from any driver.
    Fields unused by a driver type remain at their defaults.
    """
    driver_id:      str
    driver_type:    DriverType
    timestamp:      float = field(default_factory=time.time)

    # Pose (arm, mobile, vision)
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    roll:  float = 0.0
    pitch: float = 0.0
    yaw:   float = 0.0

    # Arm specifics
    joint_angles:   List[float] = field(default_factory=list)   # rad
    joint_torques:  List[float] = field(default_factory=list)   # Nm
    tcp_force_n:    float = 0.0
    gripper_open:   bool  = True
    payload_kg:     float = 0.0

    # Mobile specifics
    linear_vel:     float = 0.0   # m/s
    angular_vel:    float = 0.0   # rad/s
    battery_pct:    float = 100.0

    # PLC specifics
    digital_inputs:  Dict[str, bool]  = field(default_factory=dict)
    digital_outputs: Dict[str, bool]  = field(default_factory=dict)
    analog_values:   Dict[str, float] = field(default_factory=dict)
    plc_program_running: bool = False
    conveyor_speed:  float = 0.0   # m/s

    # Status
    is_active:      bool  = True
    mode:           str   = "auto"   # auto | manual | e-stop | hil
    error_code:     int   = 0
    error_message:  str   = ""
    energy_j_total: float = 0.0

    # Sync-specific: shared events between UR5 and S7
    sync_events:    Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = {
            "driver_id":   self.driver_id,
            "type":        self.driver_type.value,
            "timestamp":   round(self.timestamp, 4),
            "pose":        {"x": round(self.x, 4), "y": round(self.y, 4),
                            "z": round(self.z, 4), "roll": round(self.roll, 4),
                            "pitch": round(self.pitch, 4), "yaw": round(self.yaw, 4)},
            "status":      {"active": self.is_active, "mode": self.mode,
                            "error": self.error_code,
                            "energy_j": round(self.energy_j_total, 2)},
        }
        if self.driver_type == DriverType.ARM:
            d["arm"] = {
                "joints":     [round(j, 4) for j in self.joint_angles],
                "torques":    [round(t, 4) for t in self.joint_torques],
                "tcp_force":  round(self.tcp_force_n, 3),
                "gripper_open": self.gripper_open,
                "payload_kg": round(self.payload_kg, 3),
            }
        elif self.driver_type == DriverType.MOBILE:
            d["mobile"] = {
                "linear_vel":  round(self.linear_vel, 4),
                "angular_vel": round(self.angular_vel, 4),
                "battery_pct": round(self.battery_pct, 1),
            }
        elif self.driver_type == DriverType.PLC:
            d["plc"] = {
                "di":     self.digital_inputs,
                "do":     self.digital_outputs,
                "ai":     {k: round(v, 4) for k, v in self.analog_values.items()},
                "running": self.plc_program_running,
                "conveyor_speed": round(self.conveyor_speed, 4),
            }
        if self.sync_events:
            d["sync_events"] = self.sync_events
        return d


# ─────────────────────────────────────────────────────────────
#  DRIVER STATE COLLECTOR
# ─────────────────────────────────────────────────────────────

class DriverStateCollector:
    """
    Polls or subscribes to each registered driver and normalises its
    state into a DriverStateSnapshot.  Drivers can push state via
    register_push_callback() for event-driven models.
    """

    def __init__(self):
        self._drivers:    Dict[str, Any] = {}             # driver_id → driver obj
        self._snapshots:  Dict[str, DriverStateSnapshot] = {}
        self._callbacks:  List[Callable[[DriverStateSnapshot], None]] = []
        self._poll_hz:    Dict[str, float] = {}           # driver_id → poll rate

    def register_driver(
        self,
        driver_id:   str,
        driver_obj:  Any,
        driver_type: DriverType,
        poll_hz:     float = 10.0,
    ):
        self._drivers[driver_id]    = driver_obj
        self._poll_hz[driver_id]    = poll_hz
        # Initialise empty snapshot
        self._snapshots[driver_id]  = DriverStateSnapshot(
            driver_id=driver_id, driver_type=driver_type
        )
        log.info(f"  📡  Driver registered: {driver_id} ({driver_type.value}) @ {poll_hz}Hz")

    def on_update(self, cb: Callable[[DriverStateSnapshot], None]):
        self._callbacks.append(cb)

    def push_snapshot(self, snap: DriverStateSnapshot):
        """Drivers call this to push state updates."""
        self._snapshots[snap.driver_id] = snap
        for cb in self._callbacks:
            try:
                cb(snap)
            except Exception as e:
                log.debug(f"Collector callback error: {e}")

    async def poll_driver(self, driver_id: str) -> Optional[DriverStateSnapshot]:
        """Poll a driver for its current state."""
        driver = self._drivers.get(driver_id)
        snap   = self._snapshots.get(driver_id)
        if driver is None or snap is None:
            return None

        try:
            # UR5 driver
            if _UR5 and isinstance(driver, UR5Driver):
                pose = await asyncio.to_thread(driver._rtde_receive.getActualTCPPose) \
                       if hasattr(driver, '_rtde_receive') else [0]*6
                snap.x, snap.y, snap.z = pose[0], pose[1], pose[2]
                snap.roll, snap.pitch, snap.yaw = pose[3], pose[4], pose[5]
                joints = await asyncio.to_thread(driver._rtde_receive.getActualQ) \
                         if hasattr(driver, '_rtde_receive') else []
                snap.joint_angles = list(joints) if joints else []
                snap.timestamp    = time.time()
                self.push_snapshot(snap)

            # Siemens S7 driver
            elif _S7 and isinstance(driver, SiemensS7Driver):
                if hasattr(driver, '_client') and driver._client:
                    # Read DB1 block for conveyor state
                    snap.digital_inputs  = driver.read_digital_inputs()   if hasattr(driver, 'read_digital_inputs')  else {}
                    snap.digital_outputs = driver.read_digital_outputs()  if hasattr(driver, 'read_digital_outputs') else {}
                    snap.plc_program_running = True
                    snap.timestamp = time.time()
                    self.push_snapshot(snap)

            # TurtleBot driver
            elif _TB and isinstance(driver, TurtleBotDriver):
                if hasattr(driver, '_pose'):
                    p = driver._pose
                    snap.x, snap.y = getattr(p, 'x', 0.0), getattr(p, 'y', 0.0)
                    snap.yaw       = getattr(p, 'theta', 0.0)
                    snap.timestamp = time.time()
                    self.push_snapshot(snap)

        except Exception as e:
            log.debug(f"Poll error for {driver_id}: {e}")
            snap.error_message = str(e)

        return self._snapshots.get(driver_id)

    def get_all_snapshots(self) -> Dict[str, DriverStateSnapshot]:
        return dict(self._snapshots)

    async def poll_all(self):
        """Poll all registered drivers once."""
        for driver_id in list(self._drivers):
            await self.poll_driver(driver_id)


# ─────────────────────────────────────────────────────────────
#  UR5–SIEMENS S7 SYNCHRONISER
# ─────────────────────────────────────────────────────────────

class UR5S7Synchroniser:
    """
    Coordinates the UR5 arm and the Siemens S7 PLC on a pick-and-place
    conveyor line.

    State machine:
        IDLE          → Wait for S7 "part_present" DI signal
        PART_READY    → Signal UR5 to execute pick
        PICKING       → UR5 in motion (lease held)
        PICKED        → UR5 sends "picked" event; S7 releases conveyor
        PLACING       → UR5 moves to place position
        CYCLE_DONE    → Reset to IDLE; log to ledger

    The synchroniser emits sync_events into both driver snapshots so the
    Unified Digital Twin UI can display coordinated animations.
    """

    class State(str, Enum):
        IDLE        = "idle"
        PART_READY  = "part_ready"
        PICKING     = "picking"
        PICKED      = "picked"
        PLACING     = "placing"
        CYCLE_DONE  = "cycle_done"
        E_STOP      = "e_stop"

    def __init__(self, collector: DriverStateCollector, ur5_id: str, s7_id: str):
        self._collector = collector
        self._ur5_id    = ur5_id
        self._s7_id     = s7_id
        self._state     = self.State.IDLE
        self._cycles    = 0
        self._cycle_times: List[float] = []
        self._cycle_start: float = 0.0
        self._event_log: List[dict] = []

    @property
    def state(self) -> "UR5S7Synchroniser.State":
        return self._state

    def _emit_sync_event(self, event: str, payload: dict = {}):
        ts = time.time()
        entry = {"event": event, "ts": ts, **payload}
        self._event_log.append(entry)

        # Push into both driver snapshots so UI sees them
        for driver_id in (self._ur5_id, self._s7_id):
            snap = self._collector._snapshots.get(driver_id)
            if snap:
                snap.sync_events[event] = ts
                self._collector.push_snapshot(snap)

        log.info(f"  🔄  UR5↔S7 sync: {event} state={self._state.value}")

    async def step(self):
        """
        Advance the synchronisation state machine by one tick.
        Call this in a loop at ~20 Hz.
        """
        snaps = self._collector.get_all_snapshots()
        s7    = snaps.get(self._s7_id)
        ur5   = snaps.get(self._ur5_id)

        if self._state == self.State.IDLE:
            # Check S7 DI 0.0 for "part present"
            if s7 and s7.digital_inputs.get("DI_0_0", False):
                self._state      = self.State.PART_READY
                self._cycle_start = time.time()
                self._emit_sync_event("part_ready", {"s7_di": "DI_0_0"})

        elif self._state == self.State.PART_READY:
            # Signal UR5 — in real system this triggers a P-MCP tool call
            self._state = self.State.PICKING
            self._emit_sync_event("pick_start", {"ur5": self._ur5_id})

        elif self._state == self.State.PICKING:
            # Wait for UR5 to signal gripper closed (payload > 0)
            if ur5 and not ur5.gripper_open and ur5.payload_kg > 0.1:
                self._state = self.State.PICKED
                self._emit_sync_event("picked", {"payload_kg": ur5.payload_kg})
                # Release S7 conveyor clamp
                if s7:
                    s7.digital_outputs["DO_0_0"] = True   # conveyor release
                    self._collector.push_snapshot(s7)

        elif self._state == self.State.PICKED:
            # UR5 moves to place position
            self._state = self.State.PLACING
            self._emit_sync_event("place_start")

        elif self._state == self.State.PLACING:
            # Wait for UR5 to reach place position and open gripper
            if ur5 and ur5.gripper_open:
                cycle_t = time.time() - self._cycle_start
                self._cycles += 1
                self._cycle_times.append(cycle_t)
                self._state = self.State.CYCLE_DONE
                self._emit_sync_event("cycle_done", {
                    "cycle_n": self._cycles,
                    "cycle_t_s": round(cycle_t, 3),
                })

        elif self._state == self.State.CYCLE_DONE:
            # Reset for next cycle
            self._state = self.State.IDLE
            if s7:
                s7.digital_inputs["DI_0_0"] = False
                self._collector.push_snapshot(s7)

    def e_stop(self):
        """Emergency stop: transition all drivers to E_STOP."""
        self._state = self.State.E_STOP
        self._emit_sync_event("e_stop")
        log.error(f"  🚨  UR5↔S7 E-STOP activated")

    def stats(self) -> dict:
        ct = self._cycle_times
        return {
            "cycles":       self._cycles,
            "state":        self._state.value,
            "avg_cycle_s":  round(statistics.mean(ct), 3) if ct else 0.0,
            "min_cycle_s":  round(min(ct), 3) if ct else 0.0,
            "max_cycle_s":  round(max(ct), 3) if ct else 0.0,
        }

    def event_log(self) -> List[dict]:
        return list(self._event_log)


# ─────────────────────────────────────────────────────────────
#  ZENOH TWIN BRIDGE (high-bandwidth vision transport)
# ─────────────────────────────────────────────────────────────

class ZenohTwinBridge:
    """
    Bridges the UnifiedDigitalTwin state to a Zenoh key-space.

    Key design (Zenoh):
      farm/twin/{driver_id}/state       → JSON state snapshot
      farm/twin/{driver_id}/sync_event  → sync event stream
      farm/vision/{cam_id}/frame        → raw frame metadata

    MQTT strategy for low-power devices (Arduino, S7 sensors):
      pmcp/{driver_id}/state
      pmcp/{driver_id}/event

    Transport selection:
      high-bandwidth (vision, arm joints at 50Hz) → Zenoh
      low-power (Arduino GPIO, S7 DI/DO at 1Hz)  → MQTT
    """

    ZENOH_HZ = 50.0    # Joint state publish rate for arms
    MQTT_HZ  =  1.0    # State publish rate for PLCs / Arduinos

    def __init__(self, session=None):
        self._session   = session    # zenoh.Session (None in stub mode)
        self._pubs:     Dict[str, Any] = {}
        self._msg_count = 0
        self._latencies: List[float] = []   # round-trip latencies (ms)

    def get_transport_for(self, driver_type: DriverType) -> str:
        """Return 'zenoh' or 'mqtt' based on driver type."""
        if driver_type in (DriverType.ARM, DriverType.VISION, DriverType.MOBILE):
            return "zenoh"
        return "mqtt"   # PLC, sensor (low-power)

    def publish_snapshot(self, snap: DriverStateSnapshot) -> float:
        """
        Publish a snapshot.  Returns simulated latency (ms).
        In real mode uses zenoh.Session.put().
        """
        key  = f"farm/twin/{snap.driver_id}/state"
        data = json.dumps(snap.to_dict())
        t0   = time.perf_counter()

        if _ZENOH and self._session:
            self._session.put(key, data)
        # else: stub — data stays in-memory

        latency_ms = (time.perf_counter() - t0) * 1000
        self._latencies.append(latency_ms)
        self._msg_count += 1
        return latency_ms

    def latency_stats(self) -> dict:
        if not self._latencies:
            return {"count": 0}
        lats = sorted(self._latencies[-1000:])   # last 1000 samples
        n    = len(lats)
        return {
            "count":   self._msg_count,
            "p50_ms":  round(lats[int(n * 0.50)], 4),
            "p95_ms":  round(lats[int(n * 0.95)], 4),
            "p99_ms":  round(lats[int(n * 0.99)], 4),
            "max_ms":  round(max(lats), 4),
        }


# ─────────────────────────────────────────────────────────────
#  ZENOH STRESS TESTER
# ─────────────────────────────────────────────────────────────

class ZenohStressTest:
    """
    Simulates N concurrent TurtleBot telemetry streams into the
    ZenohTwinBridge and measures hub latency under load.

    Reports the stream count at which p99 latency exceeds 50 ms SLA.
    """

    SLA_LATENCY_MS = 50.0

    def __init__(self, bridge: ZenohTwinBridge):
        self._bridge = bridge

    async def _stream_robot(
        self,
        robot_id: str,
        duration_s: float,
        hz: float,
    ):
        interval = 1.0 / hz
        end_t    = time.time() + duration_s
        while time.time() < end_t:
            snap = DriverStateSnapshot(
                driver_id   = robot_id,
                driver_type = DriverType.MOBILE,
                x           = math.sin(time.time()),
                y           = math.cos(time.time()),
                linear_vel  = 0.3,
                battery_pct = 75.0,
            )
            self._bridge.publish_snapshot(snap)
            await asyncio.sleep(interval)

    async def run(
        self,
        n_streams:  int   = 10,
        duration_s: float = 5.0,
        hz:         float = 20.0,
    ) -> dict:
        """
        Spawn `n_streams` simulated TurtleBot streams for `duration_s` seconds.
        Returns latency report and SLA breach flag.
        """
        log.info(f"  🔥  Zenoh stress test: {n_streams} streams @ {hz}Hz for {duration_s}s")
        tasks = [
            asyncio.create_task(
                self._stream_robot(f"tb-stress-{i}", duration_s, hz)
            )
            for i in range(n_streams)
        ]
        await asyncio.gather(*tasks)

        stats = self._bridge.latency_stats()
        sla_ok = stats.get("p99_ms", 0) < self.SLA_LATENCY_MS
        stats["n_streams"]  = n_streams
        stats["hz"]         = hz
        stats["sla_ok"]     = sla_ok
        stats["sla_limit"]  = self.SLA_LATENCY_MS
        return stats


# ─────────────────────────────────────────────────────────────
#  UNIFIED DIGITAL TWIN
# ─────────────────────────────────────────────────────────────

class UnifiedDigitalTwin:
    """
    The single source of truth for the entire robot fleet state.

    Aggregates:
      - DriverStateSnapshot from all drivers (via DriverStateCollector)
      - Sync events from UR5↔S7 Synchroniser
      - Vision voxels from VisionVoxelBridge (if present)
      - Zenoh publish for high-bandwidth consumers

    WebSocket streaming:
      - Shadow UI protocol (JSON-RPC) for browser clients
      - 'twin_state' message sent on every state change
    """

    def __init__(
        self,
        twin_id:   str = "unified-twin-0",
        ws_port:   int = 8766,
    ):
        self._id         = twin_id
        self._ws_port    = ws_port
        self._collector  = DriverStateCollector()
        self._zenoh      = ZenohTwinBridge()
        self._synchronisers: Dict[str, UR5S7Synchroniser] = {}
        self._ws_clients: Set = set()
        self._running    = False

        # Register state change callback to push via Zenoh + WS
        self._collector.on_update(self._on_driver_update)

    # ── Driver registration ───────────────────────────────────────────────

    def add_driver(
        self,
        driver_id:   str,
        driver_obj:  Any,
        driver_type: DriverType,
        poll_hz:     float = 20.0,
    ):
        self._collector.register_driver(driver_id, driver_obj, driver_type, poll_hz)

    def add_stub_driver(
        self,
        driver_id:   str,
        driver_type: DriverType,
        initial_state: Optional[dict] = None,
    ) -> DriverStateSnapshot:
        """Register a stub driver for simulation/testing."""
        snap = DriverStateSnapshot(
            driver_id=driver_id, driver_type=driver_type,
            **(initial_state or {})
        )
        self._collector._drivers[driver_id]   = None
        self._collector._snapshots[driver_id] = snap
        self._collector._poll_hz[driver_id]   = 20.0
        log.info(f"  🤖  Stub driver added: {driver_id} ({driver_type.value})")
        return snap

    def add_ur5_s7_sync(
        self,
        sync_id: str,
        ur5_driver_id: str,
        s7_driver_id:  str,
    ) -> UR5S7Synchroniser:
        sync = UR5S7Synchroniser(self._collector, ur5_driver_id, s7_driver_id)
        self._synchronisers[sync_id] = sync
        log.info(f"  🔗  UR5↔S7 sync registered: {sync_id} ({ur5_driver_id} ↔ {s7_driver_id})")
        return sync

    # ── State access ──────────────────────────────────────────────────────

    def get_fleet_state(self) -> dict:
        """Full fleet state for 'get_twin' WebSocket message."""
        robots = []
        plcs   = []
        for snap in self._collector.get_all_snapshots().values():
            entry = snap.to_dict()
            if snap.driver_type == DriverType.PLC:
                plcs.append(entry)
            else:
                robots.append(entry)
        return {
            "type":      "twin_state",
            "twin_id":   self._id,
            "timestamp": time.time(),
            "robots":    robots,
            "plcs":      plcs,
            "sync_states": {
                k: v.stats() for k, v in self._synchronisers.items()
            },
        }

    def get_driver_state(self, driver_id: str) -> Optional[dict]:
        snap = self._collector._snapshots.get(driver_id)
        return snap.to_dict() if snap else None

    def _on_driver_update(self, snap: DriverStateSnapshot):
        """Called on every driver state change — publish via Zenoh."""
        self._zenoh.publish_snapshot(snap)

    # ── Main loop ─────────────────────────────────────────────────────────

    async def start(self, poll_interval_s: float = 0.05):
        """
        Start the unified twin main loop.
        - Polls all drivers at their configured rates
        - Advances all UR5↔S7 sync state machines
        - Broadcasts state to WS clients
        """
        self._running = True
        ws_task = None

        if _WS:
            ws_task = asyncio.create_task(self._ws_server())

        log.info(f"  🌐  UnifiedDigitalTwin [{self._id}] started (ws_port={self._ws_port})")

        try:
            while self._running:
                await self._collector.poll_all()
                for sync in self._synchronisers.values():
                    await sync.step()
                await self._broadcast_state()
                await asyncio.sleep(poll_interval_s)
        finally:
            if ws_task:
                ws_task.cancel()

    def stop(self):
        self._running = False

    # ── WebSocket server ──────────────────────────────────────────────────

    async def _ws_server(self):
        if not _WS:
            return
        async def handler(ws, path=None):
            self._ws_clients.add(ws)
            try:
                # Send initial full state on connect
                await ws.send(json.dumps(self.get_fleet_state()))
                async for msg in ws:
                    await self._handle_ws_message(ws, msg)
            except Exception:
                pass
            finally:
                self._ws_clients.discard(ws)

        async with websockets.serve(handler, "localhost", self._ws_port):
            await asyncio.Future()

    async def _handle_ws_message(self, ws, raw: str):
        try:
            msg = json.loads(raw)
            mtype = msg.get("type", "")
            if mtype == "get_twin":
                await ws.send(json.dumps(self.get_fleet_state()))
            elif mtype == "get_driver":
                driver_id = msg.get("driver_id", "")
                state = self.get_driver_state(driver_id)
                await ws.send(json.dumps({"type": "driver_state", "data": state}))
            elif mtype == "e_stop":
                for sync in self._synchronisers.values():
                    sync.e_stop()
                await ws.send(json.dumps({"type": "e_stop_ack"}))
        except Exception as e:
            log.debug(f"WS message error: {e}")

    async def _broadcast_state(self):
        if not self._ws_clients:
            return
        msg = json.dumps(self.get_fleet_state())
        dead = set()
        for ws in list(self._ws_clients):
            try:
                await ws.send(msg)
            except Exception:
                dead.add(ws)
        self._ws_clients -= dead

    # ── Stress test helper ────────────────────────────────────────────────

    async def zenoh_stress_test(
        self,
        n_streams:  int   = 10,
        duration_s: float = 5.0,
        hz:         float = 20.0,
    ) -> dict:
        """Stress test Zenoh transport and report latency at N streams."""
        tester = ZenohStressTest(self._zenoh)
        return await tester.run(n_streams, duration_s, hz)

    async def find_zenoh_sla_limit(
        self,
        max_streams: int = 100,
        duration_s:  float = 3.0,
        hz:          float = 20.0,
    ) -> dict:
        """
        Binary-search for the number of Turtlebot streams that keeps
        p99 latency below ZenohStressTest.SLA_LATENCY_MS.
        Returns the highest n_streams that stays under SLA.
        """
        sla_limit = ZenohStressTest.SLA_LATENCY_MS
        results   = []
        lo, hi    = 1, max_streams

        while lo <= hi:
            mid = (lo + hi) // 2
            self._zenoh._latencies.clear()
            stats = await self.zenoh_stress_test(mid, duration_s, hz)
            results.append({"n": mid, **stats})
            if stats["sla_ok"]:
                lo = mid + 1
            else:
                hi = mid - 1

        passing = max((r["n"] for r in results if r["sla_ok"]), default=0)
        return {
            "sla_limit_ms":     sla_limit,
            "max_passing_streams": passing,
            "hz":               hz,
            "results":          results,
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import asyncio

    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def demo():
        print("\n" + "=" * 65)
        print("  P-MCP Unified Digital Twin Demo")
        print("=" * 65)

        twin = UnifiedDigitalTwin("demo-twin", ws_port=8766)

        # ── Register stub drivers ─────────────────────────────────────────
        ur5_snap = twin.add_stub_driver("ur5-01", DriverType.ARM, {
            "x": 0.5, "y": 0.3, "z": 0.8,
            "joint_angles": [0.0, -1.57, 1.57, -1.57, -1.57, 0.0],
            "gripper_open": True, "payload_kg": 0.0,
        })
        s7_snap = twin.add_stub_driver("siemens-s7-01", DriverType.PLC, {
            "digital_inputs":  {"DI_0_0": False, "DI_0_1": True},
            "digital_outputs": {"DO_0_0": False},
            "conveyor_speed": 0.3,
            "plc_program_running": True,
        })
        tb_snap = twin.add_stub_driver("turtlebot-01", DriverType.MOBILE, {
            "x": 2.0, "y": 1.0, "battery_pct": 85.0, "linear_vel": 0.2,
        })

        # ── UR5↔S7 sync ───────────────────────────────────────────────────
        sync = twin.add_ur5_s7_sync("line-1-sync", "ur5-01", "siemens-s7-01")

        # ── Simulate one pick-and-place cycle ─────────────────────────────
        print("\n--- Simulating UR5 ↔ Siemens S7 Pick-and-Place Cycle ---")
        collector = twin._collector

        # Step 1: S7 signals part present
        s7_snap.digital_inputs["DI_0_0"] = True
        collector.push_snapshot(s7_snap)
        await sync.step()   # IDLE → PART_READY

        await sync.step()   # PART_READY → PICKING

        # Simulate UR5 picking (gripper closes, payload detected)
        ur5_snap.gripper_open = False
        ur5_snap.payload_kg   = 0.5
        collector.push_snapshot(ur5_snap)
        await sync.step()   # PICKING → PICKED

        await sync.step()   # PICKED → PLACING

        # Simulate UR5 placing (gripper opens)
        ur5_snap.gripper_open = True
        ur5_snap.payload_kg   = 0.0
        collector.push_snapshot(ur5_snap)
        await sync.step()   # PLACING → CYCLE_DONE

        await sync.step()   # CYCLE_DONE → IDLE

        print(f"\n  Sync stats: {sync.stats()}")
        print(f"  Event log: {len(sync.event_log())} events")
        for ev in sync.event_log():
            print(f"    {ev['event']:20s}  t={ev['ts']:.3f}")

        # ── Fleet state snapshot ──────────────────────────────────────────
        print("\n--- Fleet State Snapshot ---")
        fleet = twin.get_fleet_state()
        print(f"  Robots: {len(fleet['robots'])}  PLCs: {len(fleet['plcs'])}")
        for r in fleet["robots"]:
            print(f"  {r['driver_id']:20s}  type={r['type']:8s}  active={r['status']['active']}")
        for p in fleet["plcs"]:
            print(f"  {p['driver_id']:20s}  type={p['type']:8s}  "
                  f"conveyor={p['plc']['conveyor_speed']} m/s")

        # ── Zenoh stress test ─────────────────────────────────────────────
        print("\n--- Zenoh Latency Stress Test (stub mode, 20 streams) ---")
        stats = await twin.zenoh_stress_test(n_streams=20, duration_s=1.0, hz=20.0)
        print(f"  Messages: {stats['count']}  p50={stats.get('p50_ms',0):.4f}ms  "
              f"p99={stats.get('p99_ms',0):.4f}ms  SLA={'✅' if stats['sla_ok'] else '❌'}")

        print("\n--- Finding SLA Stream Limit ---")
        limit_result = await twin.find_zenoh_sla_limit(max_streams=50, duration_s=0.5, hz=20.0)
        print(f"  Max streams within {limit_result['sla_limit_ms']}ms SLA: "
              f"{limit_result['max_passing_streams']} streams @ {limit_result['hz']}Hz")

        # ── Zenoh transport routing ───────────────────────────────────────
        print("\n--- Transport Routing Strategy ---")
        bridge = twin._zenoh
        for dtype in DriverType:
            transport = bridge.get_transport_for(dtype)
            print(f"  {dtype.value:15s} → {transport}")

    asyncio.run(demo())
