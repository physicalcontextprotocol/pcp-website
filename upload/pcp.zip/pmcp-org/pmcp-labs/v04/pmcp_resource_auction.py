"""
P-MCP v0.4 — Multi-Token Resource Auction
==========================================
"Pay-as-you-Go Robotics Grid"

Architecture
------------
Robots compete for scarce physical resources (charging power,
compute slots, vision-server bandwidth, zone leases) using a
sealed-bid Vickrey auction extended to MULTIPLE token types:

    Energy tokens  (EJ)   — joules of charging capacity
    Compute tokens (CU)   — CPU/GPU cores × seconds
    Priority tokens (PT)  — SLA-urgency credits
    Carbon tokens  (CO2)  — carbon offset allowance

A bid is a vector:  (EJ, CU, PT, CO2)
The auctioneer weights each dimension by live grid conditions
(from EnergyAwareScheduler) and crop metabolic pressure
(from MetabolicTwin) to score bids.

Metabolic Pay-As-You-Grow
--------------------------
The MetabolicPricingOracle reads crop stress and adjusts the
EJ price dynamically:

    green_slot   → EJ price ×0.6  (cheap green power)
    normal       → EJ price ×1.0
    peak_dirty   → EJ price ×2.5  (discourage non-essential moves)
    crop_stress  → compute priority boosted for climate robots

Ledger Integration
------------------
All auction settlements are recorded as LedgerEntry objects in the
SpatiotemporalGSet CRDT ledger from v03.  This gives a tamper-evident
log of who paid what for which resource at which time.

Usage
-----
    auctioneer = ResourceAuctioneer(scheduler, ledger)
    auctioneer.register_resource("charging_bay_1", ResourceType.ENERGY, capacity=3000)

    bid = MultiTokenBid(
        bidder_id="ur5-01",
        resource_id="charging_bay_1",
        tokens={TokenType.ENERGY_J: 500.0, TokenType.PRIORITY: 80.0},
        duration_s=30.0,
    )
    result = await auctioneer.submit_bid(bid)
    if result.won:
        # robot charges for 30 s
        await auctioneer.settle(result.auction_id, proof="...")
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import secrets
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.resource_auction")

# ── Optional imports ───────────────────────────────────────────────────────
try:
    from v04.pmcp_energy_scheduler import (
        EnergyAwareScheduler, GridSignal, TaskPriority,
    )
    _SCHEDULER = True
except ImportError:
    _SCHEDULER = False
    log.info("EnergyAwareScheduler not available — auction uses stub pricing")

try:
    from v03.pmcp_ledger import LedgerEntry, SpatiotemporalLedger
    _LEDGER = True
except ImportError:
    _LEDGER = False
    log.info("v03 ledger not available — auction records in-memory only")

try:
    from v03.pmcp_metabolic import CropGrowthModel, CropState, CropEnvironment
    _METABOLIC = True
except ImportError:
    _METABOLIC = False
    log.info("MetabolicTwin not available — static pricing")


# ─────────────────────────────────────────────────────────────
#  TOKEN TYPES
# ─────────────────────────────────────────────────────────────

class TokenType(str, Enum):
    ENERGY_J    = "energy_j"      # Joules of charging capacity
    COMPUTE_CUS = "compute_cus"   # Compute Unit Seconds (CU·s)
    PRIORITY    = "priority"      # SLA priority credits (0–100)
    CARBON_G    = "carbon_g"      # Carbon offset grams (allowance)
    CREDITS     = "credits"       # DePIN payment credits


class ResourceKind(str, Enum):
    CHARGING_BAY  = "charging_bay"    # Physical charging station
    COMPUTE_SLOT  = "compute_slot"    # Vision server / GPU worker
    ZONE_LEASE    = "zone_lease"      # Spatial zone for movement
    BANDWIDTH     = "bandwidth"       # Zenoh/MQTT topic bandwidth
    VISION_STREAM = "vision_stream"   # Camera stream allocation


# ─────────────────────────────────────────────────────────────
#  RESOURCE DESCRIPTOR
# ─────────────────────────────────────────────────────────────

@dataclass
class AuctionResource:
    """
    A physical or logical resource available for auction.

    capacity:   Maximum simultaneous users (e.g., 1 for a charging bay)
    base_price: Minimum bid per second per token type
    """
    resource_id:    str
    kind:           ResourceKind
    name:           str
    capacity:       int     = 1
    location_zone:  str     = "world"
    base_price_per_s: Dict[str, float] = field(default_factory=dict)  # TokenType.value → price
    available:      bool    = True
    current_holders: List[str] = field(default_factory=list)   # bidder_ids

    def is_available_for(self, duration_s: float) -> bool:
        return self.available and len(self.current_holders) < self.capacity

    def to_dict(self) -> dict:
        return {
            "resource_id":  self.resource_id,
            "kind":         self.kind.value,
            "name":         self.name,
            "capacity":     self.capacity,
            "zone":         self.location_zone,
            "base_price":   self.base_price_per_s,
            "holders":      self.current_holders,
            "available":    self.is_available_for(0),
        }


# ─────────────────────────────────────────────────────────────
#  MULTI-TOKEN BID
# ─────────────────────────────────────────────────────────────

@dataclass
class MultiTokenBid:
    """
    A sealed bid from a robot for a resource slot.

    tokens:  Dict of TokenType → amount the robot is willing to spend.
             A bid may include multiple token types (e.g., 200 EJ + 50 PT).
    """
    bid_id:       str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    bidder_id:    str   = ""
    resource_id:  str   = ""
    tokens:       Dict[str, float] = field(default_factory=dict)
    duration_s:   float = 10.0
    priority:     int   = 3        # TaskPriority: 1=CRITICAL … 5=GREEN_ONLY
    task_type:    str   = "charge"
    submitted_at: float = field(default_factory=time.time)
    # Commitment hash prevents bid modification after submission
    commitment:   str   = field(default_factory=str)

    def __post_init__(self):
        if not self.commitment:
            self.commitment = self._build_commitment()

    def _build_commitment(self) -> str:
        payload = json.dumps({
            "bid_id":      self.bid_id,
            "bidder_id":   self.bidder_id,
            "resource_id": self.resource_id,
            "tokens":      {k: round(v, 6) for k, v in self.tokens.items()},
            "duration_s":  self.duration_s,
        }, sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()[:32]

    def total_value(self, weights: Dict[str, float]) -> float:
        """Weighted token value used by the auctioneer to score bids."""
        return sum(
            amount * weights.get(ttype, 1.0)
            for ttype, amount in self.tokens.items()
        )

    def to_dict(self) -> dict:
        return {
            "bid_id":      self.bid_id,
            "bidder_id":   self.bidder_id,
            "resource_id": self.resource_id,
            "tokens":      self.tokens,
            "duration_s":  self.duration_s,
            "priority":    self.priority,
            "task_type":   self.task_type,
            "commitment":  self.commitment,
        }


# ─────────────────────────────────────────────────────────────
#  AUCTION RESULT
# ─────────────────────────────────────────────────────────────

@dataclass
class AuctionResult:
    auction_id:   str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    resource_id:  str   = ""
    winner_bid_id: str  = ""
    winner_id:    str   = ""
    # Vickrey: winner pays second-highest price (or 80% of their bid if solo)
    clearing_tokens: Dict[str, float] = field(default_factory=dict)
    won:          bool  = False
    reason:       str   = ""
    competing_bids: int = 0
    green_slot:   bool  = False
    carbon_saved_g: float = 0.0
    settled:      bool  = False
    settled_at:   Optional[float] = None
    ledger_entry_id: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "auction_id":    self.auction_id,
            "resource_id":   self.resource_id,
            "winner_id":     self.winner_id,
            "clearing_tokens": self.clearing_tokens,
            "won":           self.won,
            "reason":        self.reason,
            "green_slot":    self.green_slot,
            "carbon_saved_g": self.carbon_saved_g,
            "settled":       self.settled,
        }


# ─────────────────────────────────────────────────────────────
#  METABOLIC PRICING ORACLE
# ─────────────────────────────────────────────────────────────

class MetabolicPricingOracle:
    """
    Connects the CropGrowthModel (v03 pmcp_metabolic) to the
    resource auction pricing engine.

    When crops are stressed:
      - Climate / irrigation robots get CHEAPER priority tokens
      - Harvest robots pay MORE (protect stressed crops)
      - During green power surplus, EJ price halved

    Pay-As-You-Grow formula:
        price_multiplier = (1 + crop_stress) × grid_factor × priority_factor
        where:
            grid_factor = 0.6 (green) | 1.0 (normal) | 2.5 (peak dirty)
            priority_factor = 1 / task_priority   (1=CRITICAL gets discount)
    """

    def __init__(
        self,
        base_ej_price:     float = 0.001,    # credits per joule
        base_cu_price:     float = 0.010,    # credits per CU·s
        base_credit_price: float = 1.0,
    ):
        self.base_ej_price     = base_ej_price
        self.base_cu_price     = base_cu_price
        self.base_credit_price = base_credit_price
        self._crop_stress      = 0.0    # 0=healthy, 1=critical
        self._grid_factor      = 1.0    # updated by scheduler

    def update_from_metabolic(self, crop_state) -> None:
        """Receive updated crop stress from MetabolicTwin."""
        self._crop_stress = getattr(crop_state, "stress_index", 0.0)
        log.debug(f"  🌱  MetabolicOracle: crop_stress={self._crop_stress:.3f}")

    def update_from_grid(self, grid_signal) -> None:
        """Receive updated grid state from EnergyAwareScheduler."""
        if grid_signal.is_green():
            self._grid_factor = 0.6
        elif grid_signal.is_peak():
            self._grid_factor = 2.5
        else:
            self._grid_factor = 1.0
        log.debug(f"  ⚡  MetabolicOracle: grid_factor={self._grid_factor:.2f}")

    def price_multiplier(
        self,
        task_type: str = "general",
        priority:  int = 3,
    ) -> float:
        """
        Compute the price multiplier for a given task.
        Climate/irrigation tasks are subsidised when crops are stressed.
        """
        climate_tasks = {"irrigate", "climate_control", "vent", "co2_adjust"}
        harvest_tasks = {"harvest", "pick", "cut"}

        stress_factor = 1.0 + self._crop_stress

        task_discount = 1.0
        if task_type in climate_tasks and self._crop_stress > 0.3:
            # Subsidise climate tasks when crops stressed
            task_discount = max(0.3, 1.0 - self._crop_stress * 0.7)
        elif task_type in harvest_tasks and self._crop_stress > 0.3:
            # Penalise harvest when crops stressed (protect them)
            task_discount = 1.0 + self._crop_stress

        # Higher priority tasks get cheaper rates (they're important)
        priority_factor = 1.0 / max(1, priority)

        return round(stress_factor * self._grid_factor * task_discount * priority_factor, 4)

    def compute_clearing_price(
        self,
        bid: MultiTokenBid,
        second_bid_value: float,
    ) -> Dict[str, float]:
        """
        Vickrey second-price clearing:
            winner pays second-highest total-value equivalent,
            distributed across token types proportionally.
        If only one bidder, pays 80% of their bid.
        """
        m = self.price_multiplier(bid.task_type, bid.priority)
        total_bid_val = sum(bid.tokens.values())
        if total_bid_val == 0:
            return {}

        pay_fraction = (second_bid_value / total_bid_val) if second_bid_value > 0 else 0.80
        pay_fraction  = min(pay_fraction, 1.0)

        clearing = {}
        for ttype, amount in bid.tokens.items():
            adjusted = amount * pay_fraction * m
            clearing[ttype] = round(adjusted, 4)
        return clearing

    def token_weights(self) -> Dict[str, float]:
        """
        Return per-token weights for bid scoring.
        During green surplus, energy tokens are worth more
        (encourage energy-intensive tasks now, not later).
        """
        ej_weight = 1.0 / self._grid_factor   # cheap green → higher weight
        return {
            TokenType.ENERGY_J.value:    ej_weight,
            TokenType.COMPUTE_CUS.value: 1.0,
            TokenType.PRIORITY.value:    1.5,
            TokenType.CARBON_G.value:    0.5,
            TokenType.CREDITS.value:     1.2,
        }


# ─────────────────────────────────────────────────────────────
#  RESOURCE AUCTIONEER
# ─────────────────────────────────────────────────────────────

class ResourceAuctioneer:
    """
    Central auctioneer for multi-token resource auctions.

    For each resource, collects bids over a ROUND_DURATION_S window,
    then runs a second-price (Vickrey) auction weighted by the
    MetabolicPricingOracle's token_weights().

    All settlements are recorded in the SpatiotemporalLedger (v03).

    Charging Example
    ----------------
    Robot UR5 wants to charge for 30 s.  It bids:
        { energy_j: 500, priority: 80 }

    TurtleBot also wants the same bay:
        { energy_j: 300, priority: 60 }

    EnergyAwareScheduler: green power active → EJ weight = 1.67
    Token weights: EJ=1.67, priority=1.5

    UR5 score    = 500×1.67 + 80×1.5  = 835 + 120 = 955
    TurtleBot    = 300×1.67 + 60×1.5  = 501 + 90  = 591

    UR5 wins; second price = 591/955 = 61.9% of UR5 bid.
    UR5 actually pays: EJ=309.5, priority=49.5
    """

    ROUND_DURATION_S = 2.0    # Auction window before closing

    def __init__(
        self,
        auctioneer_id:  str = "auction-0",
        scheduler       = None,   # EnergyAwareScheduler
        ledger          = None,   # SpatiotemporalLedger
        pricing_oracle: Optional[MetabolicPricingOracle] = None,
    ):
        self._id        = auctioneer_id
        self._scheduler = scheduler
        self._ledger    = ledger
        self._oracle    = pricing_oracle or MetabolicPricingOracle()

        self._resources: Dict[str, AuctionResource] = {}
        self._pending_bids: Dict[str, List[MultiTokenBid]] = {}   # resource_id → [bid]
        self._results:   Dict[str, AuctionResult] = {}
        self._robot_balances: Dict[str, Dict[str, float]] = {}    # robot_id → tokens

        log.info(f"  🏷️   ResourceAuctioneer [{auctioneer_id}] started")

    # ── Resource management ───────────────────────────────────────────────

    def register_resource(
        self,
        resource_id: str,
        kind: ResourceKind,
        name: str = "",
        capacity: int = 1,
        zone: str = "world",
        base_price: Optional[Dict[str, float]] = None,
    ) -> AuctionResource:
        res = AuctionResource(
            resource_id=resource_id,
            kind=kind,
            name=name or resource_id,
            capacity=capacity,
            location_zone=zone,
            base_price_per_s=base_price or {
                TokenType.ENERGY_J.value:    0.001,
                TokenType.CREDITS.value:     0.05,
            },
        )
        self._resources[resource_id] = res
        self._pending_bids[resource_id] = []
        log.info(f"  📦  Resource registered: {resource_id} ({kind.value})")
        return res

    def credit_robot(self, robot_id: str, token_type: TokenType, amount: float):
        """Top up a robot's token balance."""
        bal = self._robot_balances.setdefault(robot_id, {})
        bal[token_type.value] = bal.get(token_type.value, 0.0) + amount

    def get_balance(self, robot_id: str) -> Dict[str, float]:
        return dict(self._robot_balances.get(robot_id, {}))

    # ── Bidding ───────────────────────────────────────────────────────────

    async def submit_bid(self, bid: MultiTokenBid) -> AuctionResult:
        """
        Submit a sealed bid and run the auction if the round window closes.

        For simplicity, each call_submit triggers an immediate single-round
        auction.  Production: collect bids over ROUND_DURATION_S window.
        """
        resource_id = bid.resource_id
        if resource_id not in self._resources:
            return AuctionResult(
                resource_id=resource_id, won=False,
                reason=f"Unknown resource: {resource_id}"
            )

        res = self._resources[resource_id]
        if not res.is_available_for(bid.duration_s):
            return AuctionResult(
                resource_id=resource_id, won=False,
                reason="Resource at capacity"
            )

        # Validate token balance
        ok, msg = self._check_balance(bid)
        if not ok:
            return AuctionResult(
                resource_id=resource_id, won=False, reason=msg
            )

        # Update oracle with current grid state if scheduler available
        if _SCHEDULER and self._scheduler:
            try:
                signal = await self._scheduler.get_grid_signal()
                self._oracle.update_from_grid(signal)
            except Exception:
                pass

        # Add bid to pending pool
        self._pending_bids[resource_id].append(bid)

        # Run the auction with all pending bids for this resource
        result = await self._run_auction(resource_id, bid.bid_id)

        # Clear pending bids after auction
        self._pending_bids[resource_id].clear()

        return result

    async def _run_auction(
        self, resource_id: str, trigger_bid_id: str
    ) -> AuctionResult:
        """
        Vickrey (second-price) auction with multi-token scoring.
        """
        bids    = self._pending_bids.get(resource_id, [])
        weights = self._oracle.token_weights()
        res     = self._resources[resource_id]

        # Score all bids
        scored: List[Tuple[float, MultiTokenBid]] = [
            (b.total_value(weights), b) for b in bids
        ]
        scored.sort(key=lambda x: x[0], reverse=True)

        if not scored:
            return AuctionResult(
                resource_id=resource_id, won=False,
                reason="No bids submitted"
            )

        winner_score, winner_bid = scored[0]
        second_score = scored[1][0] if len(scored) > 1 else 0.0

        if winner_bid.bid_id != trigger_bid_id:
            # The triggering robot did not win
            return AuctionResult(
                resource_id=resource_id,
                winner_bid_id=winner_bid.bid_id,
                winner_id=winner_bid.bidder_id,
                won=False,
                competing_bids=len(bids),
                reason=f"Outbid by {winner_bid.bidder_id} (score {winner_score:.1f} vs your {trigger_bid_id})",
            )

        # Compute clearing price
        clearing = self._oracle.compute_clearing_price(
            winner_bid, second_score
        )

        # Deduct tokens from winner's balance
        self._deduct_balance(winner_bid.bidder_id, clearing)

        # Record winner as resource holder
        res.current_holders.append(winner_bid.bidder_id)

        # Log to ledger if available
        ledger_id = None
        if _LEDGER and self._ledger:
            entry = LedgerEntry(
                robot_id      = winner_bid.bidder_id,
                zone_id       = res.location_zone,
                start_ms      = time.time() * 1000,
                end_ms        = (time.time() + winner_bid.duration_s) * 1000,
                tool_name     = f"auction:{resource_id}",
                energy_bid_j  = clearing.get(TokenType.ENERGY_J.value, 0.0),
            )
            self._ledger.add(entry)
            ledger_id = entry.entry_id

        # Determine if this was a green slot
        grid_factor = self._oracle._grid_factor
        green_slot  = grid_factor < 1.0
        carbon_saved = winner_bid.tokens.get(TokenType.ENERGY_J.value, 0.0) * 0.3 \
                       if green_slot else 0.0

        result = AuctionResult(
            resource_id      = resource_id,
            winner_bid_id    = winner_bid.bid_id,
            winner_id        = winner_bid.bidder_id,
            clearing_tokens  = clearing,
            won              = True,
            competing_bids   = len(bids),
            green_slot       = green_slot,
            carbon_saved_g   = round(carbon_saved, 2),
            ledger_entry_id  = ledger_id,
        )
        self._results[result.auction_id] = result

        log.info(
            f"  🏆  Auction [{resource_id}]: winner={winner_bid.bidder_id} "
            f"score={winner_score:.1f} clearing={clearing} "
            f"{'🌿 green' if green_slot else ''}"
        )
        return result

    # ── Settlement ────────────────────────────────────────────────────────

    async def settle(
        self,
        auction_id: str,
        completion_proof: str = "",
    ) -> Tuple[bool, str]:
        """
        Called when a robot completes its resource usage.
        Releases the resource slot and marks auction as settled.
        """
        result = self._results.get(auction_id)
        if result is None:
            return False, f"Auction not found: {auction_id}"
        if result.settled:
            return False, "Already settled"

        res = self._resources.get(result.resource_id)
        if res and result.winner_id in res.current_holders:
            res.current_holders.remove(result.winner_id)

        result.settled    = True
        result.settled_at = time.time()
        log.info(f"  ✅  Auction {auction_id} settled: {result.winner_id} released {result.resource_id}")
        return True, "Settlement complete"

    # ── Balance helpers ───────────────────────────────────────────────────

    def _check_balance(self, bid: MultiTokenBid) -> Tuple[bool, str]:
        bal = self._robot_balances.get(bid.bidder_id, {})
        for ttype, amount in bid.tokens.items():
            if bal.get(ttype, 0.0) < amount:
                return False, f"Insufficient {ttype} balance (need {amount}, have {bal.get(ttype, 0.0):.2f})"
        return True, ""

    def _deduct_balance(self, robot_id: str, tokens: Dict[str, float]):
        bal = self._robot_balances.setdefault(robot_id, {})
        for ttype, amount in tokens.items():
            bal[ttype] = max(0.0, bal.get(ttype, 0.0) - amount)

    # ── Stats ─────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        total    = len(self._results)
        green    = sum(1 for r in self._results.values() if r.green_slot)
        settled  = sum(1 for r in self._results.values() if r.settled)
        return {
            "total_auctions":  total,
            "green_slots":     green,
            "settled":         settled,
            "resources":       len(self._resources),
            "balances":        {r: dict(b) for r, b in self._robot_balances.items()},
        }

    def resource_status(self) -> List[dict]:
        return [r.to_dict() for r in self._resources.values()]


# ─────────────────────────────────────────────────────────────
#  PAY-AS-YOU-GROW GRID MANAGER
# ─────────────────────────────────────────────────────────────

class PayAsYouGrowGrid:
    """
    High-level coordinator that wires the ResourceAuctioneer to:
      - MetabolicTwin (crop state → price pressure)
      - EnergyAwareScheduler (grid signal → green pricing)
      - SpatiotemporalLedger (CRDT record keeping)

    Exposes a simple `charge_robot()` and `allocate_compute()` API
    for use by robot agents.
    """

    def __init__(
        self,
        scheduler   = None,
        ledger      = None,
        metabolic_model = None,
    ):
        self._oracle      = MetabolicPricingOracle()
        self._auctioneer  = ResourceAuctioneer(
            scheduler=scheduler,
            ledger=ledger,
            pricing_oracle=self._oracle,
        )
        self._metabolic   = metabolic_model

        # Register default resources
        self._auctioneer.register_resource(
            "charging_bay_1", ResourceKind.CHARGING_BAY,
            name="Main Charging Bay", capacity=2, zone="service_zone"
        )
        self._auctioneer.register_resource(
            "charging_bay_2", ResourceKind.CHARGING_BAY,
            name="Aux Charging Bay",  capacity=1, zone="service_zone_b"
        )
        self._auctioneer.register_resource(
            "gpu_worker_1", ResourceKind.COMPUTE_SLOT,
            name="Vision GPU Worker", capacity=4, zone="compute"
        )
        self._auctioneer.register_resource(
            "zenoh_bandwidth_1", ResourceKind.BANDWIDTH,
            name="Zenoh HiBW Channel", capacity=8, zone="network"
        )

    def credit_robot(self, robot_id: str, energy_j: float, credits: float = 0.0):
        self._auctioneer.credit_robot(robot_id, TokenType.ENERGY_J, energy_j)
        self._auctioneer.credit_robot(robot_id, TokenType.PRIORITY, 100.0)
        if credits > 0:
            self._auctioneer.credit_robot(robot_id, TokenType.CREDITS, credits)

    def update_crop_state(self, crop_state) -> None:
        """Feed metabolic twin output into the pricing oracle."""
        self._oracle.update_from_metabolic(crop_state)

    async def charge_robot(
        self,
        robot_id:    str,
        energy_bid:  float,
        duration_s:  float = 30.0,
        priority:    int   = 3,
        task_type:   str   = "charge",
    ) -> AuctionResult:
        """Submit a charging bay bid for a robot."""
        bid = MultiTokenBid(
            bidder_id   = robot_id,
            resource_id = "charging_bay_1",
            tokens      = {
                TokenType.ENERGY_J.value: energy_bid,
                TokenType.PRIORITY.value: float(100 - priority * 15),
            },
            duration_s  = duration_s,
            priority    = priority,
            task_type   = task_type,
        )
        return await self._auctioneer.submit_bid(bid)

    async def allocate_compute(
        self,
        robot_id:   str,
        compute_bid: float,
        duration_s: float = 10.0,
        priority:   int   = 3,
    ) -> AuctionResult:
        """Submit a compute slot bid (e.g., for vision inference)."""
        bid = MultiTokenBid(
            bidder_id   = robot_id,
            resource_id = "gpu_worker_1",
            tokens      = {
                TokenType.COMPUTE_CUS.value: compute_bid,
                TokenType.PRIORITY.value:    float(100 - priority * 15),
            },
            duration_s  = duration_s,
            priority    = priority,
            task_type   = "vision_inference",
        )
        return await self._auctioneer.submit_bid(bid)

    def stats(self) -> dict:
        return {
            "auctioneer": self._auctioneer.stats(),
            "oracle": {
                "crop_stress":  self._oracle._crop_stress,
                "grid_factor":  self._oracle._grid_factor,
                "token_weights": self._oracle.token_weights(),
            },
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import asyncio

    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def demo():
        print("\n" + "=" * 65)
        print("  P-MCP Multi-Token Resource Auction Demo")
        print("=" * 65)

        grid = PayAsYouGrowGrid()

        # Fund robots with token budgets
        grid.credit_robot("ur5-01",       energy_j=5000.0, credits=200.0)
        grid.credit_robot("turtlebot-01", energy_j=3000.0, credits=150.0)
        grid.credit_robot("turtlebot-02", energy_j=2500.0, credits=100.0)

        # ── Test 1: Single robot charges ──────────────────────────────────
        print("\n--- Test 1: UR5 bids for charging bay (no competition) ---")
        r1 = await grid.charge_robot("ur5-01", energy_bid=500.0, duration_s=30.0)
        print(f"  Won: {r1.won}  Clearing: {r1.clearing_tokens}  Green: {r1.green_slot}")
        if r1.won:
            await grid._auctioneer.settle(r1.auction_id, "proof_ur5")

        # ── Test 2: Competitive auction ───────────────────────────────────
        print("\n--- Test 2: Three robots compete for charging bay ---")
        bay = grid._auctioneer._resources["charging_bay_1"]
        bay.capacity = 1   # force competition

        # Submit bids concurrently  
        bid_tb1 = MultiTokenBid(
            bidder_id="turtlebot-01", resource_id="charging_bay_1",
            tokens={TokenType.ENERGY_J.value: 300.0, TokenType.PRIORITY.value: 60.0},
            duration_s=20.0, priority=3,
        )
        bid_tb2 = MultiTokenBid(
            bidder_id="turtlebot-02", resource_id="charging_bay_1",
            tokens={TokenType.ENERGY_J.value: 250.0, TokenType.PRIORITY.value: 90.0},
            duration_s=20.0, priority=2,
        )

        # Add bids to pool manually then run auction
        grid._auctioneer._pending_bids["charging_bay_1"] = [bid_tb1, bid_tb2]
        result = await grid._auctioneer._run_auction("charging_bay_1", bid_tb1.bid_id)
        print(f"  Winner: {result.winner_id}  Competing bids: {result.competing_bids}")
        print(f"  Clearing: {result.clearing_tokens}")

        # ── Test 3: Metabolic pricing (stressed crops) ────────────────────
        print("\n--- Test 3: Crop stress inflates harvest robot price ---")

        class StubCropState:
            stress_index = 0.7   # High stress

        grid.update_crop_state(StubCropState())

        m_harvest = grid._oracle.price_multiplier("harvest", priority=3)
        m_climate = grid._oracle.price_multiplier("climate_control", priority=3)
        print(f"  Harvest task multiplier: {m_harvest:.3f}  (higher = more expensive)")
        print(f"  Climate task multiplier: {m_climate:.3f}  (lower = subsidised)")

        # ── Test 4: Green slot discount ───────────────────────────────────
        print("\n--- Test 4: Green power slot (carbon_g/kWh < 300) ---")

        class StubGridSignal:
            def is_green(self): return True
            def is_peak(self):  return False
            carbon_g_kwh  = 150.0
            price_usd_kwh = 0.06

        grid._oracle.update_from_grid(StubGridSignal())
        grid.credit_robot("ur5-01", energy_j=5000.0)
        r4 = await grid.charge_robot("ur5-01", energy_bid=400.0, duration_s=30.0)
        print(f"  Won: {r4.won}  Green: {r4.green_slot}  Carbon saved: {r4.carbon_saved_g}g")
        print(f"  Clearing: {r4.clearing_tokens}")

        print("\n--- Final Stats ---")
        import json
        print(json.dumps(grid.stats(), indent=2))

    asyncio.run(demo())
