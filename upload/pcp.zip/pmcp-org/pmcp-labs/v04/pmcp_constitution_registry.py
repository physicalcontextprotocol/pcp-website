"""
P-MCP v0.4 — Safety Constitution Registry
==========================================
"The Rule-of-Law for Physical AI — TEE-Signed Safety Rules, Globally Distributed"

Architecture:
    Safety Authority (offline, air-gapped)
        ↓  signs ConstitutionBundle with Ed25519 HSM key
    HTTPS / IPFS distribution
        ↓
    ConstitutionRegistry (on-device cache)
        ↓  verify signature before loading
    TEECommandGate (v0.3)
        ↓  rules embedded + verifiable

Why a Registry?
---------------
- Single robots can pull the latest safety rules on boot
- Rules can be domain-specific: "ISO 10218 industrial arm" vs "EN ISO 13482 service robot"
- Third-party audit: anyone can verify a rule bundle was issued by a trusted authority
- Immutable: once published with a timestamp, history cannot be altered

Rule Bundle Format
------------------
{
  "bundle_id": "pmcp-safety-v1.2.0",
  "authority":  "PMCP-SafetyAuthority-v1",
  "issued_at":  1714960000,
  "valid_until": 1746496000,
  "standard":   "ISO 10218-1:2011",
  "rules": [ { "id": "CONST-01", "description": ..., "check_expr": ... } ],
  "signature":  "<Ed25519 hex signature of canonical JSON>"
}
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.constitution_registry")

# ── Optional crypto ────────────────────────────────────────────────────────
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey, Ed25519PublicKey)
    from cryptography.hazmat.primitives.serialization import (
        Encoding, PublicFormat, PrivateFormat, NoEncryption)
    from cryptography.exceptions import InvalidSignature
    _CRYPTO = True
except ImportError:
    _CRYPTO = False
    log.warning("  📜  cryptography not installed — signature verification disabled")

# ── Optional HTTP fetch ────────────────────────────────────────────────────
try:
    import urllib.request
    _HTTP = True
except ImportError:
    _HTTP = False


# ─────────────────────────────────────────────────────────────
#  RULE DEFINITION
# ─────────────────────────────────────────────────────────────

@dataclass
class ConstitutionRule:
    """
    One safety rule in the registry.

    check_expr:
        A Python lambda expression string.
        Evaluated in a restricted namespace with only the tool-call payload.

        Example: "float(p.get('speed', 0)) <= 1.5"

        For production: replace with a structured DSL or Rego policies.
    """
    rule_id:      str
    description:  str
    check_expr:   str          # Python expression string (sandboxed eval)
    veto_reason:  str
    standard:     str = ""     # ISO reference
    severity:     str = "HARD" # HARD (blocks) | SOFT (warns)
    category:     str = "motion"

    def evaluate(self, payload: dict) -> Tuple[bool, str]:
        """
        Run the rule against a tool-call payload.
        Returns (passed, veto_reason_if_failed).
        """
        try:
            # Restricted namespace: only payload dict 'p'
            result = eval(self.check_expr, {"__builtins__": {}},   # noqa: S307
                          {"p": payload, "float": float, "int": int,
                           "str": str, "bool": bool, "len": len,
                           "abs": abs, "min": min, "max": max,
                           "time": time.time})
            if not result:
                return False, f"[{self.rule_id}] {self.veto_reason}"
            return True, ""
        except Exception as e:
            return False, f"[{self.rule_id}] Rule eval error: {e}"


# ─────────────────────────────────────────────────────────────
#  RULE BUNDLE
# ─────────────────────────────────────────────────────────────

@dataclass
class ConstitutionBundle:
    bundle_id:   str
    authority:   str
    issued_at:   float
    valid_until: float
    standard:    str
    rules:       List[ConstitutionRule] = field(default_factory=list)
    signature:   str = ""      # hex-encoded Ed25519 signature
    pub_key_hex: str = ""      # hex-encoded public key of issuer

    def canonical_json(self) -> bytes:
        """Deterministic JSON for signing (excludes signature field)."""
        d = {
            "bundle_id":   self.bundle_id,
            "authority":   self.authority,
            "issued_at":   self.issued_at,
            "valid_until": self.valid_until,
            "standard":    self.standard,
            "rules": [
                {"id":          r.rule_id,
                 "description": r.description,
                 "check_expr":  r.check_expr,
                 "veto_reason": r.veto_reason,
                 "standard":    r.standard,
                 "severity":    r.severity,
                 "category":    r.category}
                for r in sorted(self.rules, key=lambda x: x.rule_id)
            ]
        }
        return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()

    def fingerprint(self) -> str:
        return hashlib.sha256(self.canonical_json()).hexdigest()[:16]

    def is_valid_time(self) -> bool:
        now = time.time()
        return self.issued_at <= now <= self.valid_until

    def to_dict(self) -> dict:
        return {
            "bundle_id":   self.bundle_id,
            "authority":   self.authority,
            "issued_at":   self.issued_at,
            "valid_until": self.valid_until,
            "standard":    self.standard,
            "fingerprint": self.fingerprint(),
            "rules":       len(self.rules),
            "signature":   self.signature[:24] + "...",
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ConstitutionBundle":
        rules = [ConstitutionRule(**r) for r in d.get("rules", [])]
        return cls(
            bundle_id   = d["bundle_id"],
            authority   = d["authority"],
            issued_at   = d["issued_at"],
            valid_until = d["valid_until"],
            standard    = d["standard"],
            rules       = rules,
            signature   = d.get("signature", ""),
            pub_key_hex = d.get("pub_key_hex", ""),
        )


# ─────────────────────────────────────────────────────────────
#  SAFETY AUTHORITY (issues + signs bundles)
# ─────────────────────────────────────────────────────────────

class SafetyAuthority:
    """
    Trusted offline entity that creates and signs ConstitutionBundles.

    In production:
        - Run on an air-gapped HSM (Thales Luna / YubiHSM)
        - Private key never leaves secure enclave
        - Bundles published via signed git commit to known IPFS CID
    """

    def __init__(self, authority_id: str):
        self.authority_id = authority_id
        self._priv_key: Optional[Any] = None
        self._pub_key:  Optional[Any] = None

        if _CRYPTO:
            self._priv_key = Ed25519PrivateKey.generate()
            self._pub_key  = self._priv_key.public_key()
            log.info(f"  📜  SafetyAuthority [{authority_id}] keys generated")
        else:
            log.warning("  📜  Crypto unavailable — authority running unsigned")

    def pub_key_hex(self) -> str:
        if not self._pub_key:
            return ""
        return self._pub_key.public_bytes(Encoding.Raw, PublicFormat.Raw).hex()

    def sign_bundle(self, bundle: ConstitutionBundle) -> ConstitutionBundle:
        """Sign the bundle and embed signature + pub key."""
        bundle.pub_key_hex = self.pub_key_hex()
        if self._priv_key:
            sig = self._priv_key.sign(bundle.canonical_json())
            bundle.signature = sig.hex()
        return bundle

    def create_bundle(
        self,
        standard: str = "ISO 10218-1:2011",
        valid_days: int = 365,
        extra_rules: Optional[List[ConstitutionRule]] = None,
    ) -> ConstitutionBundle:
        rules = self._default_rules() + (extra_rules or [])
        bundle = ConstitutionBundle(
            bundle_id   = f"pmcp-safety-{standard.replace(':', '-').replace(' ', '-')}-{int(time.time())}",
            authority   = self.authority_id,
            issued_at   = time.time(),
            valid_until = time.time() + valid_days * 86400,
            standard    = standard,
            rules       = rules,
        )
        return self.sign_bundle(bundle)

    @staticmethod
    def _default_rules() -> List[ConstitutionRule]:
        return [
            ConstitutionRule(
                rule_id     = "CONST-01",
                description = "Maximum speed hard limit — 1.5 m/s absolute",
                check_expr  = "float(p.get('speed', 0)) <= 1.5",
                veto_reason = "Speed exceeds TEE hard limit of 1.5 m/s",
                standard    = "ISO 10218-1 §5.4.2",
                severity    = "HARD",
                category    = "motion",
            ),
            ConstitutionRule(
                rule_id     = "CONST-02",
                description = "Z-axis floor guard — robot cannot go below 0 m",
                check_expr  = "float(p.get('z', 1.0)) >= 0.0",
                veto_reason = "Z target below floor — collision with grow rack",
                standard    = "ISO 10218-1 §5.4.3",
                severity    = "HARD",
                category    = "motion",
            ),
            ConstitutionRule(
                rule_id     = "CONST-03",
                description = "Energy burst limit — single call max 5000 J",
                check_expr  = "float(p.get('_energy_j', 0)) <= 5000.0",
                veto_reason = "Energy burst exceeds limit — power rail protection",
                standard    = "IEC 60204-1",
                severity    = "HARD",
                category    = "energy",
            ),
            ConstitutionRule(
                rule_id     = "CONST-04",
                description = "Shadow validation freshness — token < 500 ms old",
                check_expr  = "(time() - float(p.get('_shadow_ts', 0))) < 0.5",
                veto_reason = "Shadow validation stale — re-validate required",
                standard    = "P-MCP Safety Protocol §3.2",
                severity    = "HARD",
                category    = "temporal",
            ),
            ConstitutionRule(
                rule_id     = "CONST-05",
                description = "Minimum human clearance — 0.5 m",
                check_expr  = "float(p.get('_human_distance_m', 99)) >= 0.5",
                veto_reason = "Robot within 0.5 m of human — ISO 10218 safety stop",
                standard    = "ISO 10218-2:2011 §5.10.5",
                severity    = "HARD",
                category    = "human_safety",
            ),
            ConstitutionRule(
                rule_id     = "CONST-06",
                description = "No motion while E-Stop is active",
                check_expr  = "not bool(p.get('_estop_active', False))",
                veto_reason = "E-Stop active — all motion commands blocked",
                standard    = "IEC 62061",
                severity    = "HARD",
                category    = "safety_system",
            ),
            ConstitutionRule(
                rule_id     = "CONST-07",
                description = "Tool call must target a registered robot",
                check_expr  = "len(str(p.get('robot_id', ''))) > 0",
                veto_reason = "robot_id missing — unregistered target rejected",
                standard    = "P-MCP Identity Protocol §2.1",
                severity    = "HARD",
                category    = "identity",
            ),
            ConstitutionRule(
                rule_id     = "CONST-08",
                description = "Payload integrity — call_id must be UUID format",
                check_expr  = "len(str(p.get('call_id', ''))) >= 8",
                veto_reason = "Invalid call_id — replay attack mitigation",
                standard    = "P-MCP Security §4.1",
                severity    = "HARD",
                category    = "security",
            ),
        ]


# ─────────────────────────────────────────────────────────────
#  CONSTITUTION REGISTRY (on-device, with cache)
# ─────────────────────────────────────────────────────────────

class ConstitutionRegistry:
    """
    On-device registry of ConstitutionBundles.

    Robots pull bundles from a remote URL or IPFS CID on boot,
    verify the signature, and cache locally.

    The registry also merges rules from multiple bundles,
    allowing domain-specific extensions on top of a base standard.
    """

    KNOWN_AUTHORITIES: Dict[str, str] = {
        # authority_id → expected public key hex (pinned at device provisioning)
        # In production: loaded from secure device keystore (TPM 2.0)
    }

    def __init__(self, device_id: str, cache_dir: str = "/tmp/pmcp_rules"):
        self.device_id  = device_id
        self.cache_dir  = cache_dir
        self._bundles:  Dict[str, ConstitutionBundle] = {}
        self._active_rules: List[ConstitutionRule]   = []
        os.makedirs(cache_dir, exist_ok=True)

    def load_bundle(self, bundle: ConstitutionBundle,
                    trusted_pub_key_hex: str = "") -> Tuple[bool, str]:
        """
        Load and verify a bundle.
        Returns (success, error_message).
        """
        if not bundle.is_valid_time():
            return False, f"Bundle {bundle.bundle_id} expired or not yet valid"

        if _CRYPTO and bundle.signature and trusted_pub_key_hex:
            try:
                pub_bytes = bytes.fromhex(trusted_pub_key_hex)
                pub_key   = Ed25519PublicKey.from_public_bytes(pub_bytes)
                sig_bytes = bytes.fromhex(bundle.signature)
                pub_key.verify(sig_bytes, bundle.canonical_json())
            except (InvalidSignature, Exception) as e:
                return False, f"Signature verification FAILED for {bundle.bundle_id}: {e}"

        self._bundles[bundle.bundle_id] = bundle
        self._rebuild_active_rules()
        log.info(f"  📜  Constitution bundle loaded: {bundle.bundle_id} "
                 f"({len(bundle.rules)} rules, fp={bundle.fingerprint()})")
        return True, ""

    def load_from_dict(self, d: dict, trusted_pub_key_hex: str = "") -> Tuple[bool, str]:
        bundle = ConstitutionBundle.from_dict(d)
        return self.load_bundle(bundle, trusted_pub_key_hex)

    def load_from_file(self, path: str, trusted_pub_key_hex: str = "") -> Tuple[bool, str]:
        with open(path) as f:
            d = json.load(f)
        return self.load_from_dict(d, trusted_pub_key_hex)

    def fetch_from_url(self, url: str, trusted_pub_key_hex: str = "") -> Tuple[bool, str]:
        """Pull a bundle from HTTPS URL and verify."""
        if not _HTTP:
            return False, "urllib not available"
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:   # noqa: S310
                d = json.loads(resp.read())
            return self.load_from_dict(d, trusted_pub_key_hex)
        except Exception as e:
            return False, f"HTTP fetch failed: {e}"

    def _rebuild_active_rules(self):
        """Merge rules from all valid bundles (no duplicates by rule_id)."""
        seen = set()
        self._active_rules = []
        for bundle in sorted(self._bundles.values(), key=lambda b: b.issued_at):
            if not bundle.is_valid_time():
                continue
            for rule in bundle.rules:
                if rule.rule_id not in seen:
                    self._active_rules.append(rule)
                    seen.add(rule.rule_id)
        log.info(f"  📜  Active rules rebuilt: {len(self._active_rules)} rules")

    def evaluate_call(self, payload: dict) -> Tuple[bool, List[str]]:
        """
        Run ALL active rules against a tool-call payload.
        Returns (cleared, list_of_violations).
        """
        violations = []
        for rule in self._active_rules:
            passed, reason = rule.evaluate(payload)
            if not passed:
                violations.append(reason)
                if rule.severity == "HARD":
                    # Short-circuit on first hard block
                    break
        return len(violations) == 0, violations

    def list_bundles(self) -> List[dict]:
        return [b.to_dict() for b in self._bundles.values()]

    def rule_count(self) -> int:
        return len(self._active_rules)

    def export_cache(self, path: str):
        """Save all loaded bundles to a local JSON cache."""
        data = []
        for bundle in self._bundles.values():
            d = bundle.to_dict()
            d["rules"] = [{"rule_id": r.rule_id, "description": r.description,
                            "check_expr": r.check_expr, "veto_reason": r.veto_reason,
                            "standard": r.standard, "severity": r.severity,
                            "category": r.category} for r in bundle.rules]
            d["signature"]   = bundle.signature
            d["pub_key_hex"] = bundle.pub_key_hex
            data.append(d)
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        log.info(f"  📜  Registry cache exported: {path}")


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    print("\n" + "═"*64)
    print("  P-MCP Safety Constitution Registry — Demo")
    print("═"*64)

    # 1. Authority creates and signs a bundle
    authority = SafetyAuthority("PMCP-SafetyAuthority-v1")
    bundle    = authority.create_bundle("ISO 10218-1:2011", valid_days=365)
    print(f"\n  📜  Bundle created: {bundle.bundle_id}")
    print(f"       Fingerprint : {bundle.fingerprint()}")
    print(f"       Rules       : {len(bundle.rules)}")
    print(f"       Valid until : {time.strftime('%Y-%m-%d', time.localtime(bundle.valid_until))}")

    # 2. Device loads and verifies
    registry = ConstitutionRegistry("robot-arm-01")
    ok, err  = registry.load_bundle(bundle, trusted_pub_key_hex=authority.pub_key_hex())
    print(f"\n  {'✅' if ok else '❌'}  Registry load: {'OK' if ok else err}")

    # 3. Evaluate safe call
    safe_payload = {"robot_id": "arm-01", "call_id": "abc12345",
                    "speed": 0.5, "z": 0.3, "_energy_j": 100.0,
                    "_shadow_ts": time.time(), "_human_distance_m": 2.0,
                    "_estop_active": False}
    cleared, violations = registry.evaluate_call(safe_payload)
    print(f"\n  Safe call  → {'✅ CLEARED' if cleared else '❌ BLOCKED'}")

    # 4. Evaluate dangerous call
    danger_payload = {**safe_payload, "speed": 2.5, "_human_distance_m": 0.2}
    cleared2, v2 = registry.evaluate_call(danger_payload)
    print(f"  Danger call → {'✅ CLEARED' if cleared2 else '❌ BLOCKED'}")
    for v in v2:
        print(f"       {v}")
