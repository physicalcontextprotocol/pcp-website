"""
P-MCP v0.4 — Physical Model Context Protocol
Production-Ready Sovereign Infrastructure for Physical AI

Modules
-------
pmcp_vision_server        Vision resources: OpenCV/YOLO → P-MCP
pmcp_plc_bridge           OPC UA / Siemens S7 / Beckhoff → P-MCP tools
pmcp_constitution_registry  Remote TEE-signed safety rule registry
pmcp_shadow_ui            WebSocket 3D shadow visualizer backend
pmcp_energy_scheduler     Energy-aware task queue & green scheduler
pmcp_zenoh_transport      Zenoh/DDS P2P transport abstraction
pmcp_temporal_lease       Temporal lease system (zone rental)
pmcp_hub                  P-MCP Hub CLI — driver registry
pmcp_zk_safety            ZK Safety proof generation & verification
pmcp_depin                DePIN coordination layer
drivers/                  Hardware-specific P-MCP drivers
tests/                    Unit & integration tests
"""

__version__ = "0.4.0"
__protocol__ = "P-MCP/0.4"
__author__   = "P-MCP Project"
__url__      = "https://pmcp.ai"
