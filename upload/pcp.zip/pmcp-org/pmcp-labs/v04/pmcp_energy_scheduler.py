"""
P-MCP v0.4 — Energy-Aware Scheduler
======================================
"Green Robots — Execute When Power is Cheapest and Greenest"

Architecture:
    GridSignal (carbon intensity + price stream)
        ↓  real-time or forecast
    EnergyAwareScheduler
        ↓  evaluates each pending task
        ↓  delays deferrable tasks during peak/dirty power
        ↓  grants "green slots" to high-utility tasks
    PMCPServer.invoke() → placed in queue if not urgent

Task Priority Model
-------------------
Priority 1 (CRITICAL)  — Safety/emergency, executes immediately always
Priority 2 (URGENT)    — SLA-driven (e.g., crop harvest window closing)
Priority 3 (NORMAL)    — Standard robot task, can wait for green slot
Priority 4 (DEFERRABLE)— Charging, non-time-sensitive moves
Priority 5 (GREEN_ONLY)— Only execute during green power window

Green Slot Definition
---------------------
A "green slot" is a time window where:
  - carbon_intensity_g_kwh < green_threshold (default 300)
  - energy_price_usd_kwh   < price_threshold (default 0.10)
  - available_power_w      > task_power_w

Energy Sources Integrated
--------------------------
- ElectricityMap API (real-time carbon intensity)
- P-MCP DigitalTwin market_price resource
- Forecast: simple moving average over last N readings
"""

from __future__ import annotations

import asyncio
import heapq
import logging
import math
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.energy_scheduler")

# ── Optional ElectricityMap API ────────────────────────────────────────────
try:
    import urllib.request as _req
    import json as _json
    _HTTP = True
except ImportError:
    _HTTP = False


# ─────────────────────────────────────────────────────────────
#  ENUMS & CONSTANTS
# ─────────────────────────────────────────────────────────────

class TaskPriority(IntEnum):
    CRITICAL    = 1   # always immediate
    URGENT      = 2   # runs if safe
    NORMAL      = 3   # waits for price window
    DEFERRABLE  = 4   # waits for green + cheap
    GREEN_ONLY  = 5   # only during renewable surplus

DEFAULT_GREEN_CARBON_THRESHOLD  = 300.0   # g CO2 / kWh
DEFAULT_PRICE_THRESHOLD_USD_KWH = 0.10    # USD / kWh
DEFAULT_PEAK_PRICE_USD_KWH      = 0.18    # USD / kWh (defer above this)


# ─────────────────────────────────────────────────────────────
#  GRID SIGNAL (carbon intensity + price)
# ─────────────────────────────────────────────────────────────

@dataclass
class GridSignal:
    carbon_g_kwh:     float = 450.0
    price_usd_kwh:    float = 0.08
    renewable_pct:    float = 30.0    # % renewable in grid mix
    forecast_1h:      List[float] = field(default_factory=list)  # carbon/kWh forecast
    source:           str  = "stub"
    timestamp:        float = field(default_factory=time.time)

    def is_green(self, carbon_thresh: float = DEFAULT_GREEN_CARBON_THRESHOLD,
                 price_thresh: float = DEFAULT_PRICE_THRESHOLD_USD_KWH) -> bool:
        return (self.carbon_g_kwh < carbon_thresh and
                self.price_usd_kwh < price_thresh)

    def is_peak(self, peak_thresh: float = DEFAULT_PEAK_PRICE_USD_KWH) -> bool:
        return self.price_usd_kwh >= peak_thresh

    def green_score(self) -> float:
        """0–1 score: 1 = perfectly green and cheap, 0 = dirty and expensive."""
        c_score = max(0, 1 - self.carbon_g_kwh / 600)
        p_score = max(0, 1 - self.price_usd_kwh / 0.20)
        return round((c_score + p_score) / 2, 3)

    def best_window_in_forecast(self) -> Optional[int]:
        """Return the hour offset (0-N) with lowest forecast carbon."""
        if not self.forecast_1h:
            return None
        return int(min(range(len(self.forecast_1h)), key=lambda i: self.forecast_1h[i]))


# ─────────────────────────────────────────────────────────────
#  GRID SIGNAL PROVIDER
# ─────────────────────────────────────────────────────────────

class GridSignalProvider:
    """
    Provides real-time or stub grid signal data.

    Production: integrate ElectricityMap API
        GET https://api.electricitymap.org/v3/carbon-intensity/latest
        Authorization: auth-token <YOUR_TOKEN>
    """

    def __init__(self, zone: str = "DE", api_token: str = "",
                 use_twin: bool = True):
        self._zone      = zone
        self._token     = api_token
        self._use_twin  = use_twin
        self._twin      = None
        self._history:  List[GridSignal] = []
        self._tick      = 0

    def set_twin(self, twin):
        self._twin = twin

    async def fetch(self) -> GridSignal:
        """Fetch latest grid signal (live or stub)."""
        if self._twin is not None and hasattr(self._twin, '_market_price'):
            mp = self._twin._market_price
            sig = GridSignal(
                carbon_g_kwh  = mp.get("carbon_intensity_g_kwh", 450),
                price_usd_kwh = mp.get("energy_price_usd_kwh", 0.08),
                source        = "twin",
            )
            self._history.append(sig)
            return sig

        if self._token and _HTTP:
            try:
                return await self._fetch_electricitymap()
            except Exception as e:
                log.debug(f"  ⚡  ElectricityMap fetch failed: {e} — using stub")

        return self._stub_signal()

    async def _fetch_electricitymap(self) -> GridSignal:
        url = f"https://api.electricitymap.org/v3/carbon-intensity/latest?zone={self._zone}"
        req = _req.Request(url, headers={"auth-token": self._token})
        with _req.urlopen(req, timeout=5) as resp:  # noqa: S310
            d = _json.loads(resp.read())
        return GridSignal(
            carbon_g_kwh = d.get("carbonIntensity", 450),
            source       = "electricitymap",
        )

    def _stub_signal(self) -> GridSignal:
        """Simulates diurnal carbon intensity pattern."""
        import math, random
        self._tick += 1
        hour = (self._tick // 60) % 24   # Simulated hour-of-day
        # Renewable surplus midday, peak demand evening
        carbon = 250 + 200 * abs(math.sin(math.pi * hour / 24 + 0.5))
        price  = 0.05 + 0.10 * abs(math.sin(math.pi * hour / 12))
        renew  = 30 + 40 * max(0, math.sin(math.pi * (hour - 6) / 12))
        return GridSignal(
            carbon_g_kwh  = round(carbon + random.gauss(0, 5), 1),
            price_usd_kwh = round(price  + random.gauss(0, 0.003), 4),
            renewable_pct = round(renew, 1),
            source        = "stub",
        )

    def moving_avg_carbon(self, n: int = 10) -> float:
        if not self._history:
            return 450.0
        vals = [s.carbon_g_kwh for s in self._history[-n:]]
        return round(sum(vals) / len(vals), 1)


# ─────────────────────────────────────────────────────────────
#  SCHEDULED TASK
# ─────────────────────────────────────────────────────────────

@dataclass
class ScheduledTask:
    task_id:         str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    tool_name:       str = ""
    robot_id:        str = ""
    arguments:       Dict[str, Any] = field(default_factory=dict)
    caller_id:       str = ""
    priority:        TaskPriority = TaskPriority.NORMAL
    estimated_energy_j: float = 100.0
    estimated_power_w:  float = 50.0
    deadline_unix:   Optional[float] = None   # latest acceptable start time
    created_at:      float = field(default_factory=time.time)
    scheduled_at:    Optional[float] = None   # when actually dispatched
    cancelled:       bool  = False
    callback:        Optional[Callable] = field(default=None, repr=False)

    # For priority queue: (priority, created_at, task_id)
    def __lt__(self, other: "ScheduledTask") -> bool:
        return (self.priority, self.created_at) < (other.priority, other.created_at)

    def is_overdue(self) -> bool:
        return self.deadline_unix is not None and time.time() > self.deadline_unix

    def age_s(self) -> float:
        return time.time() - self.created_at

    def energy_kwh(self) -> float:
        return self.estimated_energy_j / 3_600_000


# ─────────────────────────────────────────────────────────────
#  ENERGY-AWARE SCHEDULER
# ─────────────────────────────────────────────────────────────

class EnergyAwareScheduler:
    """
    Queues robot tasks and dispatches them based on energy cost,
    carbon intensity, and task priority.

    Usage:
        scheduler = EnergyAwareScheduler(twin, signal_provider)
        await scheduler.start()

        task = ScheduledTask(
            tool_name="harvest_tray",
            robot_id="harvester-01",
            priority=TaskPriority.DEFERRABLE,
            estimated_energy_j=500.0,
        )
        await scheduler.enqueue(task)
        # Task is held until green slot, then dispatcher calls callback

    Integration with PMCPServer:
        scheduler.set_server(server)
        # scheduler will call server.invoke() when slot is available
    """

    def __init__(
        self,
        twin=None,
        signal_provider: Optional[GridSignalProvider] = None,
        green_carbon_thresh: float = DEFAULT_GREEN_CARBON_THRESHOLD,
        peak_price_thresh:   float = DEFAULT_PEAK_PRICE_USD_KWH,
        dispatch_interval_s: float = 5.0,
    ):
        self._twin           = twin
        self._provider       = signal_provider or GridSignalProvider()
        self._provider.set_twin(twin)
        self._green_thresh   = green_carbon_thresh
        self._peak_thresh    = peak_price_thresh
        self._interval       = dispatch_interval_s

        self._queue:  List[ScheduledTask] = []   # min-heap
        self._done:   List[dict] = []
        self._running = False
        self._server  = None
        self._latest_signal: Optional[GridSignal] = None
        self._dispatched_count = 0
        self._deferred_count   = 0
        self._saved_carbon_g   = 0.0
        self._saved_cost_usd   = 0.0
        heapq.heapify(self._queue)

    def set_server(self, server):
        self._server = server

    async def enqueue(self, task: ScheduledTask):
        """Add a task to the scheduling queue."""
        heapq.heappush(self._queue, task)
        log.info(f"  ⚡  [{task.task_id}] Scheduled: {task.tool_name} "
                 f"priority={task.priority.name} energy={task.estimated_energy_j:.0f}J")

    async def start(self):
        self._running = True
        asyncio.create_task(self._dispatch_loop(), name="pmcp-energy-scheduler")
        log.info(f"  ⚡  EnergyScheduler started (interval={self._interval}s)")

    async def stop(self):
        self._running = False

    async def _dispatch_loop(self):
        while self._running:
            try:
                sig = await self._provider.fetch()
                self._latest_signal = sig

                await self._process_queue(sig)
            except Exception as e:
                log.warning(f"  ⚡  Scheduler loop error: {e}")

            await asyncio.sleep(self._interval)

    async def _process_queue(self, sig: GridSignal):
        if not self._queue:
            return

        dispatched_this_cycle = 0
        remaining = []

        # Pop all tasks and re-evaluate each
        while self._queue:
            task = heapq.heappop(self._queue)

            if task.cancelled:
                continue

            should_run = self._should_run_now(task, sig)

            if should_run:
                await self._dispatch(task, sig)
                dispatched_this_cycle += 1
            else:
                remaining.append(task)
                self._deferred_count += 1
                if self._deferred_count % 10 == 0:
                    best_h = sig.best_window_in_forecast()
                    log.info(f"  ⚡  [{task.task_id}] Deferred "
                             f"(carbon={sig.carbon_g_kwh:.0f}g/kWh "
                             f"price={sig.price_usd_kwh:.3f}$/kWh "
                             f"best_h={best_h})")

        for t in remaining:
            heapq.heappush(self._queue, t)

        if dispatched_this_cycle:
            log.info(f"  ⚡  Dispatched {dispatched_this_cycle} task(s) "
                     f"green_score={sig.green_score():.2f} "
                     f"carbon={sig.carbon_g_kwh:.0f}g/kWh")

    def _should_run_now(self, task: ScheduledTask, sig: GridSignal) -> bool:
        # CRITICAL always runs
        if task.priority == TaskPriority.CRITICAL:
            return True

        # URGENT runs unless peak price
        if task.priority == TaskPriority.URGENT:
            return not sig.is_peak(self._peak_thresh)

        # Overdue tasks get URGENT promotion
        if task.is_overdue():
            log.warning(f"  ⚡  [{task.task_id}] Overdue — promoting to URGENT")
            task.priority = TaskPriority.URGENT
            return True

        # NORMAL: run if not peak price
        if task.priority == TaskPriority.NORMAL:
            return not sig.is_peak(self._peak_thresh)

        # DEFERRABLE / GREEN_ONLY: wait for green window
        return sig.is_green(self._green_thresh)

    async def _dispatch(self, task: ScheduledTask, sig: GridSignal):
        task.scheduled_at = time.time()
        self._dispatched_count += 1

        # Calculate savings vs. average grid (450 g/kWh, $0.10/kWh)
        avg_carbon = 450.0
        avg_price  = 0.10
        kwh = task.energy_kwh()
        self._saved_carbon_g  += (avg_carbon - sig.carbon_g_kwh) * kwh * 1000
        self._saved_cost_usd  += (avg_price  - sig.price_usd_kwh) * kwh

        log.info(f"  🟢  [{task.task_id}] DISPATCHING {task.tool_name} "
                 f"({sig.carbon_g_kwh:.0f}g/kWh, ${sig.price_usd_kwh:.3f}/kWh "
                 f"green_score={sig.green_score():.2f})")

        if task.callback:
            try:
                await task.callback(task)
            except Exception as e:
                log.error(f"  ⚡  Task callback error: {e}")
        elif self._server:
            try:
                call = await self._server.invoke(
                    task.tool_name, caller_id=task.caller_id, **task.arguments
                )
                if call:
                    await self._server.confirm(call.call_id)
            except Exception as e:
                log.error(f"  ⚡  Server dispatch error: {e}")

        self._done.append({
            "task_id":     task.task_id,
            "tool_name":   task.tool_name,
            "dispatched_at": task.scheduled_at,
            "carbon_g_kwh": sig.carbon_g_kwh,
            "price_usd_kwh": sig.price_usd_kwh,
            "green_score": sig.green_score(),
        })

    def cancel_task(self, task_id: str) -> bool:
        for t in self._queue:
            if t.task_id == task_id:
                t.cancelled = True
                return True
        return False

    def queue_length(self) -> int:
        return sum(1 for t in self._queue if not t.cancelled)

    def stats(self) -> dict:
        return {
            "queued":              self.queue_length(),
            "dispatched":          self._dispatched_count,
            "deferred":            self._deferred_count,
            "saved_carbon_g":      round(self._saved_carbon_g, 2),
            "saved_cost_usd":      round(self._saved_cost_usd, 4),
            "latest_carbon_g_kwh": self._latest_signal.carbon_g_kwh if self._latest_signal else None,
            "latest_price":        self._latest_signal.price_usd_kwh if self._latest_signal else None,
            "green_score":         self._latest_signal.green_score() if self._latest_signal else None,
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        provider  = GridSignalProvider()
        scheduler = EnergyAwareScheduler(
            signal_provider    = provider,
            green_carbon_thresh= 350.0,
            dispatch_interval_s= 1.0,
        )

        results = []

        async def _cb(task: ScheduledTask):
            results.append(task.task_id)
            print(f"  ✅  Task dispatched: {task.tool_name} ({task.task_id})")

        # Queue various priority tasks
        await scheduler.enqueue(ScheduledTask(
            tool_name="harvest_tray_07", priority=TaskPriority.DEFERRABLE,
            estimated_energy_j=500.0, callback=_cb))
        await scheduler.enqueue(ScheduledTask(
            tool_name="emergency_stop", priority=TaskPriority.CRITICAL,
            estimated_energy_j=5.0, callback=_cb))
        await scheduler.enqueue(ScheduledTask(
            tool_name="charge_battery", priority=TaskPriority.GREEN_ONLY,
            estimated_energy_j=3600.0, callback=_cb))
        await scheduler.enqueue(ScheduledTask(
            tool_name="inspect_sensor", priority=TaskPriority.NORMAL,
            estimated_energy_j=50.0, callback=_cb))

        print(f"\n  Queue: {scheduler.queue_length()} tasks")
        await scheduler.start()
        await asyncio.sleep(5.0)
        await scheduler.stop()

        print(f"\n  Stats: {scheduler.stats()}")

    asyncio.run(_demo())
