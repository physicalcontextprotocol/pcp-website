"""
P-MCP v0.4 — Modular Plugin System for Grand Unified Protocol Stack
=====================================================================
"npm install for Robot Behaviours"

Turns pmcp_grand_unified.py from a monolithic script into a modular
plugin host.  New drivers, governance modules, and transport adapters
can be registered without touching the core server.

Architecture
------------
    PMCPPluginHost  (replaces direct grand_unified imports)
        │
        ├── DriverPlugin (ur5, turtlebot, siemens-s7, arduino)
        │       registers tools, resources, HIL backend
        │
        ├── GovernancePlugin (constitution, zk_safety, soft_slash)
        │       intercepts every invoke() call
        │
        ├── TransportPlugin (zenoh, mqtt, websocket)
        │       routes messages to the right transport tier
        │
        ├── EconomicsPlugin (resource_auction, depin, energy_scheduler)
        │       manages token flows and green scheduling
        │
        └── ObservabilityPlugin (metrics, logging, tracing)
                hooks into every stage of invoke()

Plugin Lifecycle
----------------
    plugin.on_load(host)     → called when registered
    plugin.on_start()        → called when host.start() runs
    plugin.on_invoke_before(call) → pre-execution hook
    plugin.on_invoke_after(call, result) → post-execution hook
    plugin.on_stop()         → cleanup

Transport Tier Routing (from Critical Review)
----------------------------------------------
    ARM / Vision / Mobile at 50Hz  →  Zenoh
    Arduino GPIO at 1Hz            →  MQTT (low-power)
    PLC DI/DO at 1–10Hz            →  MQTT
    Browser Shadow UI              →  WebSocket (JSON-RPC)
    Command channel                →  P-MCP (ZK-verified)

TEE Integration
---------------
ConstitutionRegistryPlugin moves the ConstitutionRegistry into a
Trusted Execution Environment (TEE) boundary.  In stub mode, uses
an in-process TEESimulator.  In production, delegates to:
    - Intel SGX enclave  (via gramine-rs)
    - ARM TrustZone      (via OP-TEE)
    - AWS Nitro Enclaves (via vsock)

Usage
-----
    host = PMCPPluginHost("farm-v4", twin)

    # Install drivers
    host.install(UR5DriverPlugin("ur5-01", host_ip="192.168.1.10"))
    host.install(SiemensS7DriverPlugin("s7-01", plc_ip="192.168.1.20"))

    # Install governance
    host.install(ConstitutionRegistryPlugin(tee_mode=True))
    host.install(SoftSlashPlugin())

    # Install economics
    host.install(ResourceAuctionPlugin())

    # Install transport
    host.install(ZenohTransportPlugin())
    host.install(MQTTTransportPlugin(broker="mqtt://localhost:1883"))

    await host.start()
    result = await host.invoke("ur5-01", "move_to", x=1.0, y=0.5, z=0.8)
"""

from __future__ import annotations

import asyncio
import importlib
import importlib.util
import logging
import sys
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type

log = logging.getLogger("pmcp.plugin_system")

# ── Optional imports (graceful degradation) ────────────────────────────────
try:
    from v04.pmcp_soft_slash import (
        SoftSlashManager, ConstitutionSlashMonitor,
        SlashRecord, SlashSeverity,
    )
    _SLASH = True
except ImportError:
    _SLASH = False

try:
    from v04.pmcp_zk_safety import ZKSafetyProver, ZKSafetyVerifier
    _ZK = True
except ImportError:
    _ZK = False

try:
    from v04.pmcp_constitution_registry import ConstitutionRegistry, ConstitutionRule
    _CONST = True
except ImportError:
    _CONST = False

try:
    from v04.pmcp_resource_auction import ResourceAuctioneer, PayAsYouGrowGrid, TokenType
    _AUCTION = True
except ImportError:
    _AUCTION = False

try:
    from v04.pmcp_hil_v4 import HILGate, HILMode, FaultInjector
    _HIL = True
except ImportError:
    _HIL = False

try:
    from v04.pmcp_unified_twin import UnifiedDigitalTwin, DriverType, DriverStateSnapshot
    _TWIN = True
except ImportError:
    _TWIN = False

try:
    from v04.pmcp_temporal_lease import LeaseManager
    _LEASE = True
except ImportError:
    _LEASE = False

try:
    from v04.pmcp_energy_scheduler import EnergyAwareScheduler, GridSignal
    _SCHEDULER = True
except ImportError:
    _SCHEDULER = False

try:
    from v04.pmcp_depin import DePINBroker
    _DEPIN = True
except ImportError:
    _DEPIN = False


# ─────────────────────────────────────────────────────────────
#  PLUGIN BASE CLASS
# ─────────────────────────────────────────────────────────────

class PluginPriority(int, Enum):
    """Execution order for on_invoke_before hooks (lower = earlier)."""
    TRANSPORT   = 10
    GOVERNANCE  = 20   # Constitution + ZK safety run early
    HIL         = 30   # Physics simulation before economics
    ECONOMICS   = 40   # Auction + scheduling
    DRIVER      = 50   # Actual hardware dispatch
    OBSERVABILITY = 60 # Metrics last


@dataclass
class PluginManifest:
    """Declarative description of a plugin's identity and requirements."""
    plugin_id:   str
    plugin_type: str   # "driver" | "governance" | "transport" | "economics" | "observability"
    version:     str   = "0.4.0"
    description: str   = ""
    requires:    List[str] = field(default_factory=list)   # other plugin_ids
    pip_deps:    List[str] = field(default_factory=list)
    priority:    PluginPriority = PluginPriority.DRIVER


class PMCPPlugin(ABC):
    """
    Base class for all P-MCP plugins.

    Subclass and implement the abstract methods.
    Non-abstract hooks (on_invoke_before, on_invoke_after) have
    pass-through defaults so plugins only override what they need.
    """

    @property
    @abstractmethod
    def manifest(self) -> PluginManifest:
        ...

    def on_load(self, host: "PMCPPluginHost") -> None:
        """Called once when the plugin is registered with the host."""
        self._host = host

    async def on_start(self) -> None:
        """Called when the host starts. Perform async init here."""

    async def on_invoke_before(self, call: dict) -> Optional[dict]:
        """
        Pre-execution hook.
        Return a dict with 'blocked=True' and 'reason' to veto the call.
        Return None to pass through.
        """
        return None

    async def on_invoke_after(self, call: dict, result: dict) -> dict:
        """Post-execution hook. Can enrich the result dict."""
        return result

    async def on_stop(self) -> None:
        """Called when the host stops. Perform cleanup here."""

    @property
    def plugin_id(self) -> str:
        return self.manifest.plugin_id


# ─────────────────────────────────────────────────────────────
#  PLUGIN HOST
# ─────────────────────────────────────────────────────────────

class PMCPPluginHost:
    """
    The plugin host replaces direct grand_unified.py imports.

    install(plugin)   → register a plugin
    start()           → start all plugins
    invoke(...)       → run the full plugin pipeline

    Plugin pipeline for invoke():
        1. Sort plugins by priority (ascending)
        2. Call on_invoke_before() on each — first veto wins
        3. Execute the tool call on the driver plugin
        4. Call on_invoke_after() on each — can enrich result
    """

    def __init__(
        self,
        host_id: str = "pmcp-host-0",
        twin     = None,   # DigitalTwin reference from grand_unified
        server   = None,   # PMCPServer reference
    ):
        self._id      = host_id
        self._twin    = twin
        self._server  = server

        self._plugins:         Dict[str, PMCPPlugin] = {}
        self._plugins_sorted:  List[PMCPPlugin]      = []
        self._started          = False
        self._invoke_log:      List[dict]             = []

        log.info(f"  🔌  PMCPPluginHost [{host_id}] created")

    # ── Plugin management ─────────────────────────────────────────────────

    def install(self, plugin: PMCPPlugin) -> "PMCPPluginHost":
        """Register a plugin. Returns self for chaining."""
        pid = plugin.manifest.plugin_id
        if pid in self._plugins:
            log.warning(f"Plugin {pid} already installed — replacing")
        self._plugins[pid] = plugin
        plugin.on_load(self)
        self._plugins_sorted = sorted(
            self._plugins.values(),
            key=lambda p: p.manifest.priority,
        )
        log.info(f"  🔌  Plugin installed: {pid} [{plugin.manifest.plugin_type}] "
                 f"priority={plugin.manifest.priority.value}")
        return self

    def uninstall(self, plugin_id: str) -> bool:
        if plugin_id not in self._plugins:
            return False
        del self._plugins[plugin_id]
        self._plugins_sorted = sorted(
            self._plugins.values(),
            key=lambda p: p.manifest.priority,
        )
        log.info(f"  🔌  Plugin uninstalled: {plugin_id}")
        return True

    def get_plugin(self, plugin_id: str) -> Optional[PMCPPlugin]:
        return self._plugins.get(plugin_id)

    def list_plugins(self) -> List[dict]:
        return [
            {
                "id":       p.manifest.plugin_id,
                "type":     p.manifest.plugin_type,
                "version":  p.manifest.version,
                "priority": p.manifest.priority.value,
            }
            for p in self._plugins_sorted
        ]

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def start(self) -> None:
        # Check dependency satisfaction
        installed_ids = set(self._plugins)
        for plugin in self._plugins_sorted:
            missing = [r for r in plugin.manifest.requires if r not in installed_ids]
            if missing:
                log.warning(f"Plugin {plugin.plugin_id} missing deps: {missing}")

        # Start all plugins
        for plugin in self._plugins_sorted:
            try:
                await plugin.on_start()
                log.info(f"  ✅  Plugin started: {plugin.plugin_id}")
            except Exception as e:
                log.error(f"  ❌  Plugin {plugin.plugin_id} start failed: {e}")

        self._started = True
        log.info(f"  🚀  PMCPPluginHost [{self._id}] started "
                 f"({len(self._plugins)} plugins)")

    async def stop(self) -> None:
        for plugin in reversed(self._plugins_sorted):
            try:
                await plugin.on_stop()
            except Exception as e:
                log.debug(f"Plugin {plugin.plugin_id} stop error: {e}")
        self._started = False
        log.info(f"  🛑  PMCPPluginHost [{self._id}] stopped")

    # ── Invoke pipeline ───────────────────────────────────────────────────

    async def invoke(
        self,
        driver_id: str,
        tool_name: str,
        **arguments,
    ) -> dict:
        """
        Run the full plugin pipeline for a tool call.

        Returns a result dict with keys:
            success, message, data, blocked_by, duration_s, energy_j
        """
        call = {
            "call_id":   str(uuid.uuid4())[:8],
            "driver_id": driver_id,
            "tool_name": tool_name,
            "arguments": arguments,
            "timestamp": time.time(),
        }

        # Phase 1: pre-execution hooks (governance, HIL, economics)
        for plugin in self._plugins_sorted:
            try:
                veto = await plugin.on_invoke_before(call)
                if veto and veto.get("blocked"):
                    result = {
                        "success":     False,
                        "call_id":     call["call_id"],
                        "blocked_by":  plugin.plugin_id,
                        "message":     veto.get("reason", "blocked"),
                        "data":        {},
                        "duration_s":  0.0,
                        "energy_j":    0.0,
                    }
                    self._invoke_log.append({**call, "result": result})
                    return result
            except Exception as e:
                log.debug(f"Plugin {plugin.plugin_id} pre-hook error: {e}")

        # Phase 2: execute (first DRIVER plugin that handles this driver_id)
        result = {
            "success":    False,
            "call_id":    call["call_id"],
            "blocked_by": None,
            "message":    "No driver plugin handled the call",
            "data":       {},
            "duration_s": 0.0,
            "energy_j":   0.0,
        }

        for plugin in self._plugins_sorted:
            if plugin.manifest.plugin_type == "driver":
                handled = await self._try_driver_execute(plugin, call, result)
                if handled:
                    break

        # Phase 3: post-execution hooks (observability, economics settle)
        for plugin in self._plugins_sorted:
            try:
                result = await plugin.on_invoke_after(call, result)
            except Exception as e:
                log.debug(f"Plugin {plugin.plugin_id} post-hook error: {e}")

        self._invoke_log.append({**call, "result": result})
        return result

    async def _try_driver_execute(
        self,
        plugin:  PMCPPlugin,
        call:    dict,
        result:  dict,
    ) -> bool:
        """Ask a driver plugin to handle this call. Returns True if handled."""
        if not hasattr(plugin, "handles"):
            return False
        if not plugin.handles(call["driver_id"]):
            return False
        try:
            exec_result = await plugin.execute(call)
            result.update(exec_result)
            return True
        except Exception as e:
            result["message"] = str(e)
            log.error(f"  ❌  Driver plugin {plugin.plugin_id} execute error: {e}")
            return True   # Still "handled" — don't try other drivers

    # ── Stats ─────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        total   = len(self._invoke_log)
        success = sum(1 for e in self._invoke_log if e["result"].get("success"))
        blocked = sum(1 for e in self._invoke_log if e["result"].get("blocked_by"))
        return {
            "total_invocations": total,
            "success":           success,
            "blocked":           blocked,
            "failed":            total - success - blocked,
            "plugins":           len(self._plugins),
        }


# ─────────────────────────────────────────────────────────────
#  BUILT-IN PLUGINS
# ─────────────────────────────────────────────────────────────

# ── 1. Governance: ZK Safety + Constitution ───────────────────────────────

class ConstitutionRegistryPlugin(PMCPPlugin):
    """
    Loads the Safety Constitution and makes it available to all plugins.
    Optionally wraps it in a TEE boundary.

    tee_mode=True  → runs checks inside TEESimulator (from grand_unified)
    tee_mode=False → in-process (development / stub mode)
    """

    MANIFEST = PluginManifest(
        plugin_id   = "constitution",
        plugin_type = "governance",
        version     = "0.4.0",
        description = "TEE-backed Safety Constitution Registry",
        priority    = PluginPriority.GOVERNANCE,
    )

    def __init__(self, tee_mode: bool = False, bundle_path: Optional[str] = None):
        self._tee_mode    = tee_mode
        self._bundle_path = bundle_path
        self._registry    = None
        self._tee_gate    = None
        self._constitution_hash = ""

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    def on_load(self, host: PMCPPluginHost):
        super().on_load(host)
        if _CONST:
            self._registry = ConstitutionRegistry()
            # Load default bundle
            try:
                self._registry.load_builtin_bundle()
                self._constitution_hash = getattr(self._registry, '_bundle_hash', '')
                log.info(f"  📜  Constitution loaded: {self._constitution_hash[:16]}")
            except Exception as e:
                log.warning(f"Constitution bundle load failed: {e} — using defaults")

    async def on_start(self):
        if self._tee_mode:
            # In production: connect to SGX/TrustZone TEE
            log.info("  🔒  Constitution TEE mode: using TEESimulator")
        # Share constitution hash with other governance plugins
        if hasattr(self, '_host') and self._host:
            setattr(self._host, '_constitution_hash', self._constitution_hash)

    async def on_invoke_before(self, call: dict) -> Optional[dict]:
        """Run constitution rules against each call before execution."""
        if not _CONST or self._registry is None:
            return None
        args = call.get("arguments", {})
        speed = float(args.get("speed", 0))
        # CONST-01: max speed 1.5 m/s
        if speed > 1.5:
            return {
                "blocked": True,
                "reason":  f"Constitution CONST-01: speed {speed:.2f} m/s > 1.5 m/s limit",
                "rule_id": "CONST-01",
            }
        return None

    def get_constitution_hash(self) -> str:
        return self._constitution_hash


class ZKSafetyPlugin(PMCPPlugin):
    """
    Generates and verifies ZK safety proofs for every tool call.
    Triggers soft-slashing on proof failure.
    """

    MANIFEST = PluginManifest(
        plugin_id   = "zk-safety",
        plugin_type = "governance",
        version     = "0.4.0",
        description = "Zero-Knowledge Safety Proof generation & verification",
        requires    = ["constitution"],
        priority    = PluginPriority.GOVERNANCE,
    )

    def __init__(self):
        self._provers:  Dict[str, Any] = {}   # driver_id → ZKSafetyProver
        self._verifier  = None
        self._slash_mgr = None

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    def on_load(self, host: PMCPPluginHost):
        super().on_load(host)
        if _ZK:
            self._verifier = ZKSafetyVerifier("plugin-verifier")
        if _SLASH:
            self._slash_mgr = SoftSlashManager()

    async def on_invoke_after(self, call: dict, result: dict) -> dict:
        """
        After execution, record a lightweight compliance note.
        Full ZK proof generation happens in the driver plugin
        (it needs the projected outcome), so we just annotate here.
        """
        if result.get("success") and _ZK:
            result["zk_compliance"] = "proof_pending"
        return result


class SoftSlashPlugin(PMCPPlugin):
    """
    Monitors all governance violations and applies soft-slashing
    penalties automatically.
    """

    MANIFEST = PluginManifest(
        plugin_id   = "soft-slash",
        plugin_type = "governance",
        version     = "0.4.0",
        description = "Graduated stake-slashing on safety violations",
        requires    = ["zk-safety"],
        priority    = PluginPriority.GOVERNANCE,
    )

    def __init__(self):
        self._slash_mgr: Optional[SoftSlashManager] = None
        self._total_slashes = 0

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    def on_load(self, host: PMCPPluginHost):
        super().on_load(host)
        if _SLASH:
            self._slash_mgr = SoftSlashManager()

    async def on_invoke_before(self, call: dict) -> Optional[dict]:
        """Block robots that have been terminally slashed."""
        if self._slash_mgr is None:
            return None
        driver_id = call.get("driver_id", "")
        fail_count = self._slash_mgr._fail_counts.get(driver_id, 0)
        if fail_count >= self._slash_mgr._threshold * 3:
            return {
                "blocked": True,
                "reason":  f"Robot {driver_id} is governance-suspended "
                           f"(consecutive violations={fail_count})",
            }
        return None

    def slash_stats(self) -> dict:
        if self._slash_mgr:
            return self._slash_mgr.stats()
        return {}


# ── 2. Transport: Zenoh + MQTT routing ───────────────────────────────────

class TransportRouterPlugin(PMCPPlugin):
    """
    Routes messages to the correct transport tier:
        Zenoh  → high-bandwidth (arm joints, vision, mobile at 50Hz)
        MQTT   → low-power (Arduino GPIO, S7 DI/DO at 1Hz)
        WS     → browser Shadow UI (JSON-RPC)

    This implements the transport recommendation from the Critical Review.
    """

    MANIFEST = PluginManifest(
        plugin_id   = "transport-router",
        plugin_type = "transport",
        version     = "0.4.0",
        description = "Zenoh + MQTT dual-transport routing",
        priority    = PluginPriority.TRANSPORT,
    )

    # Transport assignment per driver type
    TRANSPORT_MAP = {
        "arm":    "zenoh",
        "mobile": "zenoh",
        "vision": "zenoh",
        "plc":    "mqtt",
        "sensor": "mqtt",
        "arduino":"mqtt",
    }

    def __init__(
        self,
        zenoh_config: Optional[dict] = None,
        mqtt_broker:  str = "mqtt://localhost:1883",
    ):
        self._zenoh_cfg  = zenoh_config or {}
        self._mqtt_broker = mqtt_broker
        self._msg_counts: Dict[str, int] = {"zenoh": 0, "mqtt": 0}

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    def route(self, driver_type: str) -> str:
        return self.TRANSPORT_MAP.get(driver_type, "zenoh")

    async def on_invoke_after(self, call: dict, result: dict) -> dict:
        """Record transport tier used for observability."""
        driver_id   = call.get("driver_id", "")
        # Determine driver type from host
        driver_type = "arm"  # default
        if hasattr(self, "_host") and self._host:
            hil = self._host.get_plugin("hil")
            if hil and hasattr(hil, "_hil_gate"):
                driver_type = hil._hil_gate._driver_types.get(driver_id, "arm")
        transport   = self.route(driver_type)
        self._msg_counts[transport] = self._msg_counts.get(transport, 0) + 1
        result["transport"] = transport
        return result

    def stats(self) -> dict:
        return {"message_counts": dict(self._msg_counts)}


# ── 3. Economics: Resource Auction plugin ────────────────────────────────

class ResourceAuctionPlugin(PMCPPlugin):
    """
    Wraps the PayAsYouGrowGrid into a plugin.
    Intercepts energy-intensive tool calls and checks green scheduling.
    """

    MANIFEST = PluginManifest(
        plugin_id   = "resource-auction",
        plugin_type = "economics",
        version     = "0.4.0",
        description = "Multi-token resource auction with metabolic pricing",
        priority    = PluginPriority.ECONOMICS,
    )

    # Tools that consume significant energy and should be auctioned
    ENERGY_TOOLS = {"pick", "weld", "move_to", "navigate_to", "harvest"}

    def __init__(self, scheduler=None, ledger=None):
        self._grid: Optional[PayAsYouGrowGrid] = None
        self._scheduler = scheduler
        self._ledger    = ledger

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    def on_load(self, host: PMCPPluginHost):
        super().on_load(host)
        if _AUCTION:
            self._grid = PayAsYouGrowGrid(
                scheduler=self._scheduler,
                ledger=self._ledger,
            )

    async def on_invoke_before(self, call: dict) -> Optional[dict]:
        """
        For energy-intensive tools, verify the robot has sufficient
        energy token balance.  (Soft check — does not block unless
        balance is zero.)
        """
        if self._grid is None:
            return None
        tool = call.get("tool_name", "")
        if tool not in self.ENERGY_TOOLS:
            return None
        driver_id = call.get("driver_id", "")
        bal = self._grid._auctioneer.get_balance(driver_id)
        energy_bal = bal.get(TokenType.ENERGY_J.value, 0.0) if _AUCTION else 9999.0
        if energy_bal < 10.0:
            return {
                "blocked": True,
                "reason":  f"Insufficient energy tokens ({energy_bal:.1f} EJ) for {tool}",
            }
        return None

    def economics_stats(self) -> dict:
        if self._grid:
            return self._grid.stats()
        return {}


# ── 4. HIL Gate plugin ────────────────────────────────────────────────────

class HILPlugin(PMCPPlugin):
    """
    Wraps the HILGate into a plugin.
    Intercepts all calls to run physics simulation before hardware dispatch.
    """

    MANIFEST = PluginManifest(
        plugin_id   = "hil",
        plugin_type = "governance",
        version     = "0.4.0",
        description = "Hardware-in-the-Loop physics simulation gate",
        priority    = PluginPriority.HIL,
    )

    def __init__(self, default_mode = None):
        self._hil_gate: Optional[HILGate] = None
        self._default_mode = default_mode

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    def on_load(self, host: PMCPPluginHost):
        super().on_load(host)
        if _HIL:
            mode = self._default_mode or HILMode.VIRTUAL
            self._hil_gate = HILGate(server=host._server, default_mode=mode)

    def register_driver(self, driver_id: str, driver_obj: Any, driver_type: str = "arm"):
        if self._hil_gate:
            self._hil_gate.register_driver(driver_id, driver_obj, driver_type)

    async def set_mode(self, driver_id: str, mode) -> Tuple[bool, str]:
        if self._hil_gate:
            return await self._hil_gate.set_mode(driver_id, mode)
        return False, "HIL not available"

    async def on_invoke_before(self, call: dict) -> Optional[dict]:
        """Run HIL physics simulation before execution."""
        if self._hil_gate is None:
            return None
        sim = self._hil_gate.simulate_before_execute(call)
        call["_hil_sim"] = sim.to_projected_outcome_dict()
        if not sim.safe:
            return {
                "blocked": True,
                "reason":  f"HIL simulation blocked: {'; '.join(sim.risk_reasons)}",
                "hil_sim": sim.to_projected_outcome_dict(),
            }
        return None

    def inject_fault(self, fault_type, target_id: str, **kwargs):
        if self._hil_gate:
            return self._hil_gate._fault_injector.inject(fault_type, target_id, **kwargs)

    def clear_faults(self):
        if self._hil_gate:
            self._hil_gate._fault_injector.clear_all()

    async def run_black_swan(self, scenario: str) -> dict:
        if self._hil_gate:
            return await self._hil_gate.run_black_swan_scenario(scenario)
        return {"error": "HIL not available"}


# ── 5. Stub Driver plugin (for testing without real hardware) ─────────────

class StubDriverPlugin(PMCPPlugin):
    """
    A minimal driver plugin for testing without real hardware.
    Accepts any tool call on any registered driver_id.
    """

    def __init__(self, driver_ids: List[str], driver_type: str = "arm"):
        self._driver_ids = set(driver_ids)
        self._driver_type = driver_type
        self._call_count = 0

    @property
    def manifest(self) -> PluginManifest:
        return PluginManifest(
            plugin_id   = f"stub-driver-{'+'.join(sorted(self._driver_ids))}",
            plugin_type = "driver",
            version     = "0.4.0",
            description = f"Stub driver for {self._driver_ids}",
            priority    = PluginPriority.DRIVER,
        )

    def handles(self, driver_id: str) -> bool:
        return driver_id in self._driver_ids

    async def execute(self, call: dict) -> dict:
        self._call_count += 1
        sim = call.get("_hil_sim", {})
        await asyncio.sleep(sim.get("duration_s", 0.05))
        return {
            "success":    True,
            "message":    f"Stub: {call['tool_name']} executed on {call['driver_id']}",
            "data":       {"stub": True, "call_n": self._call_count},
            "duration_s": sim.get("duration_s", 0.05),
            "energy_j":   sim.get("energy_j", 10.0),
        }


# ── 6. Observability plugin ───────────────────────────────────────────────

class ObservabilityPlugin(PMCPPlugin):
    """
    Collects metrics for every invoke() call.
    Reports: total calls, latency percentiles, energy consumed, violations.
    """

    MANIFEST = PluginManifest(
        plugin_id   = "observability",
        plugin_type = "observability",
        version     = "0.4.0",
        description = "Invoke metrics and energy accounting",
        priority    = PluginPriority.OBSERVABILITY,
    )

    def __init__(self):
        self._latencies:    List[float] = []
        self._energy_totals: Dict[str, float] = {}   # driver_id → J
        self._call_counts:   Dict[str, int]   = {}   # tool_name → n

    @property
    def manifest(self) -> PluginManifest:
        return self.MANIFEST

    async def on_invoke_before(self, call: dict) -> Optional[dict]:
        call["_obs_start"] = time.perf_counter()
        return None

    async def on_invoke_after(self, call: dict, result: dict) -> dict:
        start = call.pop("_obs_start", time.perf_counter())
        latency_ms = (time.perf_counter() - start) * 1000
        self._latencies.append(latency_ms)

        tool_name = call.get("tool_name", "")
        driver_id = call.get("driver_id", "")
        energy    = result.get("energy_j", 0.0)

        self._call_counts[tool_name] = self._call_counts.get(tool_name, 0) + 1
        self._energy_totals[driver_id] = self._energy_totals.get(driver_id, 0.0) + energy

        result["latency_ms"] = round(latency_ms, 3)
        return result

    def metrics(self) -> dict:
        import statistics
        lats = sorted(self._latencies[-1000:])
        n    = len(lats)
        return {
            "total_calls":   n,
            "latency_p50_ms": round(lats[int(n * 0.50)], 3) if n else 0,
            "latency_p95_ms": round(lats[int(n * 0.95)], 3) if n else 0,
            "latency_p99_ms": round(lats[int(n * 0.99)], 3) if n else 0,
            "energy_by_robot": {k: round(v, 2) for k, v in self._energy_totals.items()},
            "calls_by_tool":  dict(self._call_counts),
        }


# ─────────────────────────────────────────────────────────────
#  PLUGIN FACTORY  (convenience builder)
# ─────────────────────────────────────────────────────────────

def build_default_host(
    host_id:     str      = "pmcp-default",
    twin         = None,
    server       = None,
    driver_ids:  List[str] = None,
    hil_mode     = None,
    tee_mode:    bool = False,
    mqtt_broker: str  = "mqtt://localhost:1883",
) -> PMCPPluginHost:
    """
    Build a fully configured plugin host with the recommended stack:

      governance:   Constitution (TEE) → ZK Safety → Soft Slash
      transport:    Zenoh + MQTT router
      hil:          HIL Gate (virtual by default)
      economics:    Resource Auction
      driver:       Stub driver (replace with real drivers in production)
      observability: Metrics
    """
    if driver_ids is None:
        driver_ids = ["ur5-01", "turtlebot-01", "siemens-s7-01"]

    host = PMCPPluginHost(host_id, twin=twin, server=server)

    # Governance stack
    const_plugin = ConstitutionRegistryPlugin(tee_mode=tee_mode)
    host.install(const_plugin)

    zk_plugin = ZKSafetyPlugin()
    host.install(zk_plugin)

    slash_plugin = SoftSlashPlugin()
    host.install(slash_plugin)

    # Transport
    transport_plugin = TransportRouterPlugin(mqtt_broker=mqtt_broker)
    host.install(transport_plugin)

    # HIL
    hil_plugin = HILPlugin(default_mode=hil_mode)
    host.install(hil_plugin)
    for did in driver_ids:
        dtype = "plc" if "s7" in did or "plc" in did else \
                "mobile" if "tb" in did or "turtlebot" in did else "arm"
        hil_plugin.register_driver(did, None, dtype)

    # Economics
    econ_plugin = ResourceAuctionPlugin()
    host.install(econ_plugin)

    # Stub drivers (replace with real driver plugins in production)
    arm_ids    = [d for d in driver_ids if "ur5" in d or "arm" in d]
    mobile_ids = [d for d in driver_ids if "tb" in d or "turtlebot" in d or "mobile" in d]
    plc_ids    = [d for d in driver_ids if "s7" in d or "plc" in d or "arduino" in d]

    if arm_ids:
        host.install(StubDriverPlugin(arm_ids, "arm"))
    if mobile_ids:
        host.install(StubDriverPlugin(mobile_ids, "mobile"))
    if plc_ids:
        host.install(StubDriverPlugin(plc_ids, "plc"))

    # Observability (always last)
    host.install(ObservabilityPlugin())

    return host


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import asyncio

    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def demo():
        print("\n" + "=" * 65)
        print("  P-MCP Plugin System Demo")
        print("=" * 65)

        host = build_default_host(
            host_id     = "demo-host",
            driver_ids  = ["ur5-01", "turtlebot-01", "siemens-s7-01"],
            tee_mode    = False,
        )
        await host.start()

        print("\n--- Installed Plugins ---")
        import json
        for p in host.list_plugins():
            print(f"  [{p['priority']:2d}] {p['id']:40s} {p['type']}")

        # ── Test 1: Normal UR5 move ───────────────────────────────────────
        print("\n--- Test 1: Normal UR5 move ---")
        r = await host.invoke("ur5-01", "move_to", x=0.5, y=0.3, z=0.6, speed=0.4)
        print(f"  success={r['success']}  transport={r.get('transport')}  "
              f"latency={r.get('latency_ms')}ms")

        # ── Test 2: Constitution violation ────────────────────────────────
        print("\n--- Test 2: Speed violation (2.5 m/s) — Constitution veto ---")
        r2 = await host.invoke("ur5-01", "move_to", x=0.5, y=0.3, z=0.6, speed=2.5)
        print(f"  success={r2['success']}  blocked_by={r2['blocked_by']}")
        print(f"  reason:  {r2['message']}")

        # ── Test 3: TurtleBot navigation ──────────────────────────────────
        print("\n--- Test 3: TurtleBot navigation ---")
        r3 = await host.invoke("turtlebot-01", "navigate_to",
                               goal_x=3.0, goal_y=2.0, speed=0.3)
        print(f"  success={r3['success']}  transport={r3.get('transport')}  "
              f"energy={r3.get('energy_j')}J")

        # ── Test 4: Black Swan via HIL plugin ─────────────────────────────
        print("\n--- Test 4: BLACK SWAN — vision server fail ---")
        hil_plugin = host.get_plugin("hil")
        if hil_plugin:
            bs_result = await hil_plugin.run_black_swan("vision_fail_during_harvest")
            print(f"  System halted correctly: {bs_result.get('fault_detected_correctly')}")
            print(f"  Recovered after fix:     {bs_result.get('recovered')}")

        # ── Test 5: Plugin hot-swap (uninstall observability) ─────────────
        print("\n--- Test 5: Hot-swap (remove observability plugin) ---")
        removed = host.uninstall("observability")
        print(f"  Removed observability: {removed}")
        r5 = await host.invoke("ur5-01", "pick", x=1.0, y=0.8, z=0.4, speed=0.3)
        print(f"  Call after hot-swap: success={r5['success']} "
              f"latency_key={'latency_ms' in r5}")

        print("\n--- Final Stats ---")
        print(json.dumps(host.stats(), indent=2))

        await host.stop()

    asyncio.run(demo())
