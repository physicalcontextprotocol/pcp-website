"""
P-MCP v0.4 — PLC Bridge
========================
"Industrial Control Meets Physical AI"

Maps OPC UA / Siemens S7 / Beckhoff registers to P-MCP Tools and Resources.

Architecture:
    PLC/Fieldbus
        ↓  OPC UA (asyncua) / Snap7 / Modbus TCP
    PMCPPLCBridge
        ↓  auto-registers PMCPTools per node
        ↓  streams PMCPResources at configured Hz
    PMCPServer  ←  same interface as any other robot

Supported protocols
-------------------
- OPC UA        — asyncua (pip install asyncua)
- Siemens S7    — snap7  (pip install python-snap7)
- Modbus TCP    — pymodbus (pip install pymodbus)
- Stub          — simulated PLC (no hardware needed)

Node Mapping Convention
-----------------------
OPC UA NodeID → P-MCP tool name
  "ns=2;s=Conveyor/Speed"   → set_conveyor_speed(value: float, unit="m/s")
  "ns=2;s=Valve/Open"       → open_valve(valve_id: str)
  "ns=2;s=Press/Force"      → read as Resource (force_torque)

The bridge reads a YAML/JSON config file that describes the mapping:
  {
    "plc_id": "line-1",
    "endpoint": "opc.tcp://192.168.1.10:4840",
    "nodes": [
      { "node_id": "ns=2;s=Conv1/Speed", "name": "set_conveyor_speed",
        "type": "tool", "unit": "m/s", "min": 0.0, "max": 2.0 },
      { "node_id": "ns=2;s=Sensor/Temp", "name": "temperature_c",
        "type": "resource", "rate_hz": 1.0 }
    ]
  }
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.plc_bridge")

# ── Optional protocol libraries ────────────────────────────────────────────
try:
    from asyncua import Client as _OPCClient, ua as _ua
    _OPCUA = True
except ImportError:
    _OPCUA = False
    log.info("  🏭  asyncua not installed — OPC UA stub mode")

try:
    import snap7
    _SNAP7 = True
except ImportError:
    _SNAP7 = False

try:
    from pymodbus.client import ModbusTcpClient as _ModbusClient
    _MODBUS = True
except ImportError:
    _MODBUS = False


# ─────────────────────────────────────────────────────────────
#  NODE DESCRIPTOR
# ─────────────────────────────────────────────────────────────

class NodeMapType(str, Enum):
    TOOL     = "tool"       # write → executes action
    RESOURCE = "resource"   # read  → streamed as P-MCP resource
    MONITOR  = "monitor"    # read-only alarm/status


@dataclass
class PLCNodeDescriptor:
    node_id:     str
    name:        str
    map_type:    NodeMapType   = NodeMapType.TOOL
    unit:        str           = ""
    data_type:   str           = "float"   # float | bool | int | str
    min_val:     Optional[float] = None
    max_val:     Optional[float] = None
    rate_hz:     float         = 1.0
    description: str           = ""
    safety_critical: bool      = False     # blocks if write fails


@dataclass
class PLCBridgeConfig:
    plc_id:    str
    protocol:  str = "opcua"          # opcua | s7 | modbus | stub
    endpoint:  str = "opc.tcp://localhost:4840"
    ip:        str = "192.168.1.10"   # for s7 / modbus
    rack:      int = 0                # s7 only
    slot:      int = 2                # s7 only
    modbus_port: int = 502
    nodes:     List[PLCNodeDescriptor] = field(default_factory=list)
    poll_interval_s: float = 0.1
    reconnect_delay_s: float = 5.0

    @classmethod
    def from_json(cls, path: str) -> "PLCBridgeConfig":
        with open(path) as f:
            d = json.load(f)
        nodes = [PLCNodeDescriptor(**n) for n in d.get("nodes", [])]
        d_clean = {k: v for k, v in d.items() if k != "nodes"}
        return cls(nodes=nodes, **d_clean)

    @classmethod
    def example_factory_line(cls) -> "PLCBridgeConfig":
        """Stub config representing a typical conveyor/press line."""
        return cls(
            plc_id   = "factory-line-1",
            protocol = "stub",
            nodes    = [
                PLCNodeDescriptor("ns=2;s=Conv1/Speed",  "set_conveyor_speed",
                                  NodeMapType.TOOL, "m/s", "float", 0.0, 3.0,
                                  description="Conveyor 1 belt speed"),
                PLCNodeDescriptor("ns=2;s=Conv1/Stop",   "stop_conveyor",
                                  NodeMapType.TOOL, "", "bool",
                                  description="Emergency stop conveyor 1",
                                  safety_critical=True),
                PLCNodeDescriptor("ns=2;s=Press1/Force", "set_press_force",
                                  NodeMapType.TOOL, "kN", "float", 0.0, 50.0,
                                  description="Hydraulic press target force"),
                PLCNodeDescriptor("ns=2;s=Valve1/Open",  "open_valve",
                                  NodeMapType.TOOL, "", "bool",
                                  description="Open pneumatic valve 1",
                                  safety_critical=True),
                PLCNodeDescriptor("ns=2;s=Sensor/Temp",  "temperature_c",
                                  NodeMapType.RESOURCE, "°C", "float",
                                  rate_hz=2.0, description="Zone temperature"),
                PLCNodeDescriptor("ns=2;s=Sensor/Vibration", "vibration_mm_s",
                                  NodeMapType.RESOURCE, "mm/s", "float",
                                  rate_hz=10.0, description="Machine vibration RMS"),
                PLCNodeDescriptor("ns=2;s=Safety/EStop",    "estop_active",
                                  NodeMapType.MONITOR, "", "bool",
                                  rate_hz=20.0, description="E-Stop status",
                                  safety_critical=True),
            ]
        )


# ─────────────────────────────────────────────────────────────
#  STUB PLC BACKEND (simulation — no hardware required)
# ─────────────────────────────────────────────────────────────

class StubPLCBackend:
    """Simulates a PLC with realistic register behaviour."""

    def __init__(self, cfg: PLCBridgeConfig):
        self._cfg   = cfg
        self._tick  = 0
        self._state: Dict[str, Any] = {}
        # Initialize registers with default values
        for node in cfg.nodes:
            if node.data_type == "float":
                self._state[node.node_id] = 0.0
            elif node.data_type == "bool":
                self._state[node.node_id] = False
            else:
                self._state[node.node_id] = 0

    async def connect(self): 
        log.info(f"  🏭  [StubPLC] Connected to {self._cfg.plc_id}")

    async def disconnect(self): 
        log.info(f"  🏭  [StubPLC] Disconnected from {self._cfg.plc_id}")

    async def read_node(self, node_id: str) -> Any:
        self._tick += 1
        val = self._state.get(node_id, 0.0)
        # Add realistic sensor noise
        if isinstance(val, float):
            import random
            val += random.gauss(0, 0.02)
        # Simulate temperature rising slowly
        if "Temp" in node_id:
            self._state[node_id] = 22.0 + 3.0 * (1 - 2.71 ** (-self._tick / 500))
            val = self._state[node_id]
        # Simulate vibration
        if "Vibration" in node_id:
            import math, random
            val = abs(1.2 * math.sin(self._tick * 0.3) + random.gauss(0, 0.1))
        return val

    async def write_node(self, node_id: str, value: Any) -> bool:
        old = self._state.get(node_id)
        self._state[node_id] = value
        log.info(f"  🏭  [StubPLC] WRITE {node_id}: {old} → {value}")
        return True


# ─────────────────────────────────────────────────────────────
#  OPC UA BACKEND
# ─────────────────────────────────────────────────────────────

class OPCUABackend:
    """Production OPC UA backend using asyncua."""

    def __init__(self, cfg: PLCBridgeConfig):
        if not _OPCUA:
            raise RuntimeError("asyncua not installed: pip install asyncua")
        self._cfg    = cfg
        self._client: Optional[_OPCClient] = None

    async def connect(self):
        self._client = _OPCClient(url=self._cfg.endpoint)
        await self._client.connect()
        log.info(f"  🏭  [OPC UA] Connected to {self._cfg.endpoint}")

    async def disconnect(self):
        if self._client:
            await self._client.disconnect()

    async def read_node(self, node_id: str) -> Any:
        node = self._client.get_node(node_id)
        val  = await node.read_value()
        return val

    async def write_node(self, node_id: str, value: Any) -> bool:
        node  = self._client.get_node(node_id)
        dval  = _ua.DataValue(_ua.Variant(value))
        await node.write_value(dval)
        return True


# ─────────────────────────────────────────────────────────────
#  SIEMENS S7 BACKEND
# ─────────────────────────────────────────────────────────────

class S7Backend:
    """Siemens S7-1200/1500 via snap7."""

    def __init__(self, cfg: PLCBridgeConfig):
        if not _SNAP7:
            raise RuntimeError("python-snap7 not installed: pip install python-snap7")
        self._cfg    = cfg
        self._client = snap7.client.Client()

    async def connect(self):
        self._client.connect(self._cfg.ip, self._cfg.rack, self._cfg.slot)
        log.info(f"  🏭  [S7] Connected to {self._cfg.ip} rack={self._cfg.rack} slot={self._cfg.slot}")

    async def disconnect(self):
        self._client.disconnect()

    async def read_node(self, node_id: str) -> Any:
        # node_id format: "DB{n}.DBD{offset}" → DB block, REAL at offset
        parts = node_id.split(".")
        db_num = int(parts[0].replace("DB", ""))
        offset = int(parts[1].replace("DBD", "").replace("DBW", "").replace("DBX", ""))
        data = self._client.db_read(db_num, offset, 4)
        return snap7.util.get_real(data, 0)

    async def write_node(self, node_id: str, value: Any) -> bool:
        parts  = node_id.split(".")
        db_num = int(parts[0].replace("DB", ""))
        offset = int(parts[1].replace("DBD", ""))
        data   = bytearray(4)
        snap7.util.set_real(data, 0, float(value))
        self._client.db_write(db_num, offset, data)
        return True


# ─────────────────────────────────────────────────────────────
#  MODBUS TCP BACKEND
# ─────────────────────────────────────────────────────────────

class ModbusBackend:
    """Generic Modbus TCP backend (works with most PLCs & VFDs)."""

    def __init__(self, cfg: PLCBridgeConfig):
        if not _MODBUS:
            raise RuntimeError("pymodbus not installed: pip install pymodbus")
        self._cfg    = cfg
        self._client = _ModbusClient(host=cfg.ip, port=cfg.modbus_port)

    async def connect(self):
        self._client.connect()
        log.info(f"  🏭  [Modbus] Connected to {self._cfg.ip}:{self._cfg.modbus_port}")

    async def disconnect(self):
        self._client.close()

    async def read_node(self, node_id: str) -> Any:
        # node_id = "HR{address}" (holding register) or "IR{address}"
        addr = int(node_id.replace("HR", "").replace("IR", ""))
        rr   = self._client.read_holding_registers(addr, count=2)
        if rr.isError():
            return 0.0
        from pymodbus.payload import BinaryPayloadDecoder, Endian
        dec = BinaryPayloadDecoder.fromRegisters(rr.registers, byteorder=Endian.Big)
        return dec.decode_32bit_float()

    async def write_node(self, node_id: str, value: float) -> bool:
        addr = int(node_id.replace("HR", ""))
        from pymodbus.payload import BinaryPayloadBuilder, Endian
        builder = BinaryPayloadBuilder(byteorder=Endian.Big)
        builder.add_32bit_float(float(value))
        regs = builder.to_registers()
        self._client.write_registers(addr, regs)
        return True


# ─────────────────────────────────────────────────────────────
#  P-MCP PLC BRIDGE  (main class)
# ─────────────────────────────────────────────────────────────

class PMCPPLCBridge:
    """
    Connects a PLC to P-MCP by auto-generating Tools and Resources
    from a node map configuration.

    Usage:
        cfg    = PLCBridgeConfig.example_factory_line()
        bridge = PMCPPLCBridge(cfg, pmcp_server)
        await bridge.connect()
        await bridge.start_polling()
        # Tools and resources are now live in the P-MCP server
    """

    def __init__(self, cfg: PLCBridgeConfig, server=None):
        self._cfg    = cfg
        self._server = server
        self._backend = self._make_backend(cfg)
        self._resources: Dict[str, Any] = {}   # node_id → latest value
        self._running  = False
        self._estop    = False
        self._connected = False

    def _make_backend(self, cfg: PLCBridgeConfig):
        if cfg.protocol == "stub":
            return StubPLCBackend(cfg)
        elif cfg.protocol == "opcua":
            return OPCUABackend(cfg)
        elif cfg.protocol == "s7":
            return S7Backend(cfg)
        elif cfg.protocol == "modbus":
            return ModbusBackend(cfg)
        else:
            raise ValueError(f"Unknown PLC protocol: {cfg.protocol}")

    async def connect(self):
        await self._backend.connect()
        self._connected = True
        log.info(f"  🏭  PLCBridge [{self._cfg.plc_id}] connected via {self._cfg.protocol}")

    async def disconnect(self):
        self._running = False
        await self._backend.disconnect()
        self._connected = False

    # ── Tool execution (called by P-MCP server) ────────────────────────────

    async def execute_tool(self, node_id: str, value: Any, robot_id: str = "") -> Dict[str, Any]:
        """Write a value to a PLC node. Returns success/error dict."""
        if self._estop:
            return {"success": False, "error": "E-Stop active — all writes blocked",
                    "node_id": node_id}
        if not self._connected:
            return {"success": False, "error": "PLC not connected", "node_id": node_id}

        try:
            ok = await self._backend.write_node(node_id, value)
            log.info(f"  🏭  [{self._cfg.plc_id}] WRITE {node_id}={value}  ok={ok}")
            return {"success": ok, "node_id": node_id, "written_value": value}
        except Exception as e:
            log.error(f"  🏭  PLC write error: {e}")
            return {"success": False, "error": str(e), "node_id": node_id}

    # ── Resource polling ───────────────────────────────────────────────────

    async def start_polling(self):
        """Background task: continuously poll resource nodes."""
        self._running = True
        resource_nodes = [n for n in self._cfg.nodes if n.map_type in
                          (NodeMapType.RESOURCE, NodeMapType.MONITOR)]
        log.info(f"  🏭  PLCBridge polling {len(resource_nodes)} nodes")
        await asyncio.gather(*[self._poll_node(n) for n in resource_nodes])

    async def _poll_node(self, node: PLCNodeDescriptor):
        interval = 1.0 / max(node.rate_hz, 0.01)
        while self._running:
            try:
                val = await self._backend.read_node(node.node_id)
                self._resources[node.node_id] = {
                    "name":      node.name,
                    "value":     val,
                    "unit":      node.unit,
                    "timestamp": time.time(),
                }
                # E-Stop monitor
                if node.safety_critical and node.map_type == NodeMapType.MONITOR:
                    if bool(val):
                        self._estop = True
                        log.critical(f"  🚨  E-STOP ACTIVE from PLC node {node.node_id}!")
                    else:
                        self._estop = False
            except Exception as e:
                log.warning(f"  🏭  PLC read error {node.node_id}: {e}")

            await asyncio.sleep(interval)

    def read_resource(self, name: str) -> Optional[dict]:
        """Return latest polled value for a resource by name."""
        for v in self._resources.values():
            if v["name"] == name:
                return v
        return None

    def list_tools(self) -> List[dict]:
        """Return P-MCP tool schema for each TOOL node."""
        tools = []
        for node in self._cfg.nodes:
            if node.map_type != NodeMapType.TOOL:
                continue
            tools.append({
                "name":        node.name,
                "description": node.description or f"Write to PLC node {node.node_id}",
                "robot_id":    self._cfg.plc_id,
                "category":    "utility",
                "parameters":  [{"name": "value", "type": node.data_type,
                                  "description": f"Target value ({node.unit})",
                                  "unit": node.unit,
                                  **({"min": node.min_val} if node.min_val is not None else {}),
                                  **({"max": node.max_val} if node.max_val is not None else {})}],
                "safety_critical": node.safety_critical,
                "node_id":     node.node_id,
                "plc_id":      self._cfg.plc_id,
                "protocol":    self._cfg.protocol,
            })
        return tools

    def list_resources(self) -> List[dict]:
        return [{"name": n.name, "node_id": n.node_id,
                 "unit": n.unit, "rate_hz": n.rate_hz,
                 "plc_id": self._cfg.plc_id}
                for n in self._cfg.nodes if n.map_type == NodeMapType.RESOURCE]

    def estop_active(self) -> bool:
        return self._estop

    def status(self) -> dict:
        return {
            "plc_id":    self._cfg.plc_id,
            "protocol":  self._cfg.protocol,
            "connected": self._connected,
            "estop":     self._estop,
            "resources": len(self._resources),
            "tools":     len(self.list_tools()),
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        cfg    = PLCBridgeConfig.example_factory_line()
        bridge = PMCPPLCBridge(cfg)
        await bridge.connect()

        print("\n  📋  Auto-generated P-MCP Tools:")
        for t in bridge.list_tools():
            print(f"       [{t['plc_id']}].{t['name']}  node={t['node_id']}")

        print("\n  📡  Resources:")
        for r in bridge.list_resources():
            print(f"       {r['name']} @ {r['rate_hz']}Hz  ({r['unit']})")

        # Simulate polling for 2 seconds
        poll_task = asyncio.create_task(bridge.start_polling())
        await asyncio.sleep(2.0)
        poll_task.cancel()

        # Execute a tool
        result = await bridge.execute_tool("ns=2;s=Conv1/Speed", 1.5)
        print(f"\n  🔧  Conveyor speed set: {result}")
        print(f"\n  📊  Bridge status: {bridge.status()}")

    asyncio.run(_demo())
