"""
P-MCP v0.4 — DePIN Layer (Decentralized Physical Infrastructure Network)
=========================================================================
"Robot-as-a-Service with On-Chain Coordination"

DePIN turns physical robots into decentralized service nodes:
- Robots stake tokens to join the network (skin-in-the-game safety)
- Service requests go to highest-reputation/lowest-price node
- Payments settle on completion (cryptographic proof-of-work)
- Reputation degrades after failures; restores after successes
- Works WITHOUT blockchain (stub mode using local CRDT ledger)

Architecture
------------
    TaskRequester
        ↓  request_service(task, bid_credits)
    DePINBroker
        ↓  auction_task() → find_best_provider()
    RobotServiceNode (robot that won auction)
        ↓  execute_task()
        ↓  submit_completion_proof(ZK proof)
    DePINBroker
        ↓  verify_proof() → settle_payment()

Economics
---------
- Stake:      Robot locks N credits to join → lost on safety violation
- Bid:        Robot offers to do task for M credits
- Payment:    Requester pays M credits on verified completion
- Reputation: 0–100 score, updated after each task
- Slashing:   Safety violation → −50% stake, −20 reputation

Why DePIN for Robots?
---------------------
- No central orchestrator to trust (or attack)
- Robots self-select tasks they're good at (specialization)
- Bad actors lose stake — economic incentive for safety
- Auditable: all task proofs stored in CRDT ledger
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import secrets
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.depin")


# ─────────────────────────────────────────────────────────────
#  NODE STATES
# ─────────────────────────────────────────────────────────────

class NodeState(str, Enum):
    AVAILABLE  = "available"
    BUSY       = "busy"
    SLASHED    = "slashed"
    OFFLINE    = "offline"


class TaskState(str, Enum):
    OPEN       = "open"
    ASSIGNED   = "assigned"
    EXECUTING  = "executing"
    COMPLETED  = "completed"
    FAILED     = "failed"
    DISPUTED   = "disputed"


# ─────────────────────────────────────────────────────────────
#  ROBOT SERVICE NODE
# ─────────────────────────────────────────────────────────────

@dataclass
class RobotServiceNode:
    """
    A robot registered in the DePIN network.
    Publishes its capabilities and bids on tasks.
    """
    node_id:          str
    name:             str
    capabilities:     List[str]   # e.g. ["move_to", "pick", "weld"]
    stake_credits:    float = 1000.0
    reputation:       float = 80.0       # 0–100
    rate_credits_per_s: float = 0.1      # Pricing
    location_zone:    str  = "world"
    max_payload_kg:   float = 5.0
    max_reach_m:      float = 1.0
    state:            NodeState = NodeState.AVAILABLE
    tasks_completed:  int  = 0
    tasks_failed:     int  = 0
    total_earned:     float = 0.0
    joined_at:        float = field(default_factory=time.time)
    last_seen:        float = field(default_factory=time.time)

    @property
    def is_available(self) -> bool:
        return self.state == NodeState.AVAILABLE and self.stake_credits > 0

    @property
    def min_stake_required(self) -> float:
        return 100.0

    @property
    def trust_score(self) -> float:
        """Composite trust score for auction ranking."""
        if self.tasks_completed + self.tasks_failed == 0:
            completion_rate = 0.5
        else:
            completion_rate = self.tasks_completed / (self.tasks_completed + self.tasks_failed)
        # Weighted: reputation (60%), completion rate (30%), stake (10%)
        stake_factor = min(1.0, self.stake_credits / 5000.0)
        return 0.6 * (self.reputation / 100) + 0.3 * completion_rate + 0.1 * stake_factor

    def to_dict(self) -> dict:
        return {
            "node_id":          self.node_id,
            "name":             self.name,
            "capabilities":     self.capabilities,
            "stake":            round(self.stake_credits, 2),
            "reputation":       round(self.reputation, 1),
            "trust_score":      round(self.trust_score, 3),
            "rate":             self.rate_credits_per_s,
            "state":            self.state.value,
            "tasks_completed":  self.tasks_completed,
            "tasks_failed":     self.tasks_failed,
            "total_earned":     round(self.total_earned, 2),
        }


# ─────────────────────────────────────────────────────────────
#  SERVICE TASK
# ─────────────────────────────────────────────────────────────

@dataclass
class ServiceTask:
    """A task posted by a requester node."""
    task_id:        str  = field(default_factory=lambda: str(uuid.uuid4())[:12])
    requester_id:   str  = ""
    tool_name:      str  = ""
    arguments:      dict = field(default_factory=dict)
    max_bid_credits: float = 50.0
    deadline_s:     Optional[float] = None   # UNIX timestamp
    required_caps:  List[str] = field(default_factory=list)
    state:          TaskState = TaskState.OPEN
    assigned_node:  Optional[str] = None
    bid_credits:    float = 0.0
    created_at:     float = field(default_factory=time.time)
    completed_at:   Optional[float] = None
    completion_proof: Optional[str] = None
    result:         Optional[dict] = None

    def is_expired(self) -> bool:
        return self.deadline_s is not None and time.time() > self.deadline_s


# ─────────────────────────────────────────────────────────────
#  SERVICE BID
# ─────────────────────────────────────────────────────────────

@dataclass
class ServiceBid:
    bid_id:     str   = field(default_factory=lambda: str(uuid.uuid4())[:8])
    task_id:    str   = ""
    node_id:    str   = ""
    bid_credits: float = 0.0
    est_duration_s: float = 5.0
    commitment: str   = ""   # HMAC commitment to bid terms
    submitted_at: float = field(default_factory=time.time)


# ─────────────────────────────────────────────────────────────
#  DEPIN BROKER
# ─────────────────────────────────────────────────────────────

class DePINBroker:
    """
    Central-coordinator-free task broker.
    In production, replaced by a smart contract.
    This implementation uses a local CRDT-compatible ledger.
    """

    def __init__(self, broker_id: str = "depin-broker-0",
                 registry=None):
        self._broker_id = broker_id
        self._registry  = registry
        self._nodes:    Dict[str, RobotServiceNode] = {}
        self._tasks:    Dict[str, ServiceTask]      = {}
        self._bids:     Dict[str, List[ServiceBid]] = {}   # task_id → [bid]
        self._audit:    List[dict] = []
        log.info(f"  🌐  DePINBroker [{broker_id}] initialized")

    # ── Node Registration ──────────────────────────────────────────────────

    def register_node(self, node: RobotServiceNode) -> Tuple[bool, str]:
        if node.stake_credits < node.min_stake_required:
            return False, (f"Insufficient stake: {node.stake_credits:.0f} < "
                           f"{node.min_stake_required:.0f} credits required")
        self._nodes[node.node_id] = node
        self._audit_event("node_registered", {"node_id": node.node_id,
                                                "stake": node.stake_credits})
        log.info(f"  🤖  Node registered: {node.node_id} "
                 f"(stake={node.stake_credits:.0f} rep={node.reputation:.0f})")
        return True, f"Node {node.node_id} registered"

    def deregister_node(self, node_id: str) -> Tuple[bool, str]:
        if node_id not in self._nodes:
            return False, "Node not found"
        node = self._nodes.pop(node_id)
        log.info(f"  👋  Node deregistered: {node_id} (earned={node.total_earned:.0f})")
        return True, f"Node deregistered, earned {node.total_earned:.2f} credits"

    # ── Task Lifecycle ─────────────────────────────────────────────────────

    async def post_task(self, task: ServiceTask) -> Tuple[bool, str]:
        """Post a task and collect bids via reverse auction."""
        if task.is_expired():
            return False, "Task deadline already passed"

        self._tasks[task.task_id] = task
        self._bids[task.task_id]  = []

        # Invite bids from eligible nodes
        eligible = [n for n in self._nodes.values()
                    if n.is_available and
                    all(cap in n.capabilities for cap in task.required_caps)]

        if not eligible:
            task.state = TaskState.FAILED
            return False, f"No eligible nodes for task {task.task_id}"

        # Each eligible node submits a bid
        for node in eligible:
            bid = self._simulate_bid(node, task)
            self._bids[task.task_id].append(bid)

        # Run Vickrey auction (lowest bid wins, pays 2nd-lowest price)
        winner, winning_price = self._vickrey_auction(task.task_id)
        if not winner:
            task.state = TaskState.FAILED
            return False, "No valid bids"

        task.assigned_node = winner.node_id
        task.bid_credits   = winning_price
        task.state         = TaskState.ASSIGNED
        winner.state       = NodeState.BUSY

        self._audit_event("task_assigned", {
            "task_id": task.task_id, "node": winner.node_id,
            "price":   winning_price,
        })
        log.info(f"  📋  Task {task.task_id} assigned to {winner.node_id} "
                 f"@ {winning_price:.2f} credits")
        return True, winner.node_id

    async def submit_completion(
        self,
        task_id: str,
        node_id: str,
        result: dict,
        proof_token: str,
    ) -> Tuple[bool, str]:
        """
        Node submits task completion with a proof token.
        Verifies proof, settles payment, updates reputation.
        """
        task = self._tasks.get(task_id)
        if not task:
            return False, "Task not found"
        if task.assigned_node != node_id:
            return False, f"Task assigned to {task.assigned_node}, not {node_id}"
        if task.state != TaskState.ASSIGNED:
            return False, f"Task not in ASSIGNED state (current={task.state})"

        # Verify completion proof
        expected = self._compute_proof_token(task_id, node_id, result)
        if not self._safe_compare(proof_token, expected):
            # Proof mismatch — penalize node
            self._slash_node(node_id, "completion_proof_mismatch")
            task.state = TaskState.FAILED
            return False, "Completion proof verification failed"

        # Settle payment
        task.state            = TaskState.COMPLETED
        task.completed_at     = time.time()
        task.completion_proof = proof_token
        task.result           = result

        node = self._nodes.get(node_id)
        if node:
            node.state            = NodeState.AVAILABLE
            node.tasks_completed += 1
            node.total_earned    += task.bid_credits
            node.reputation       = min(100.0, node.reputation + 2.0)
            node.last_seen        = time.time()

        self._audit_event("task_completed", {
            "task_id": task_id, "node": node_id, "payment": task.bid_credits,
        })
        log.info(f"  ✅  Task {task_id} completed by {node_id} "
                 f"— paid {task.bid_credits:.2f} credits")
        return True, f"Task completed, payment: {task.bid_credits:.2f} credits"

    def slash_node(self, node_id: str, reason: str, penalty_pct: float = 0.5):
        """Externally trigger a slash (e.g., safety violation)."""
        self._slash_node(node_id, reason, penalty_pct)

    # ── Internal helpers ───────────────────────────────────────────────────

    def _simulate_bid(self, node: RobotServiceNode, task: ServiceTask) -> ServiceBid:
        """Each node generates a competitive bid."""
        # Bid = rate * estimated_duration + random competition factor
        import random
        est_duration = 5.0 + random.uniform(0, 10)
        base_bid     = node.rate_credits_per_s * est_duration
        # Higher reputation nodes bid slightly higher (they know their value)
        trust_premium = 1 + 0.2 * (1 - node.trust_score)
        bid_amount    = min(base_bid * trust_premium, task.max_bid_credits)

        commitment = hashlib.sha256(
            f"{task.task_id}:{node.node_id}:{bid_amount:.4f}".encode()
        ).hexdigest()[:16]

        return ServiceBid(
            task_id       = task.task_id,
            node_id       = node.node_id,
            bid_credits   = round(bid_amount, 4),
            est_duration_s = est_duration,
            commitment    = commitment,
        )

    def _vickrey_auction(self, task_id: str) -> Tuple[Optional[RobotServiceNode], float]:
        """
        Second-price sealed-bid auction.
        Lowest bid wins, pays second-lowest price.
        """
        bids = sorted(self._bids.get(task_id, []), key=lambda b: b.bid_credits)
        if not bids:
            return None, 0.0
        winner_node = self._nodes.get(bids[0].node_id)
        winning_price = bids[1].bid_credits if len(bids) > 1 else bids[0].bid_credits
        return winner_node, winning_price

    def _slash_node(self, node_id: str, reason: str, penalty_pct: float = 0.5):
        node = self._nodes.get(node_id)
        if not node:
            return
        slashed_amount    = node.stake_credits * penalty_pct
        node.stake_credits -= slashed_amount
        node.reputation    = max(0.0, node.reputation - 20.0)
        node.tasks_failed += 1
        node.state         = NodeState.SLASHED if node.stake_credits < node.min_stake_required \
                             else NodeState.AVAILABLE
        self._audit_event("node_slashed", {
            "node_id": node_id, "reason": reason,
            "slashed": slashed_amount, "remaining_stake": node.stake_credits,
        })
        log.warning(f"  ⚔️   Node {node_id} SLASHED -{slashed_amount:.0f} credits: {reason}")

    def _compute_proof_token(self, task_id: str, node_id: str, result: dict) -> str:
        payload = json.dumps({"task_id": task_id, "node_id": node_id,
                              "result": result}, sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()[:32]

    @staticmethod
    def _safe_compare(a: str, b: str) -> bool:
        import hmac as _hmac
        return _hmac.compare_digest(a.encode(), b.encode())

    def _audit_event(self, action: str, data: dict):
        self._audit.append({"action": action, "ts": time.time(), **data})

    # ── Introspection ──────────────────────────────────────────────────────

    def network_stats(self) -> dict:
        nodes = list(self._nodes.values())
        tasks = list(self._tasks.values())
        return {
            "nodes":          len(nodes),
            "available":      sum(1 for n in nodes if n.state == NodeState.AVAILABLE),
            "busy":           sum(1 for n in nodes if n.state == NodeState.BUSY),
            "slashed":        sum(1 for n in nodes if n.state == NodeState.SLASHED),
            "avg_reputation": round(sum(n.reputation for n in nodes) / max(1, len(nodes)), 1),
            "total_tasks":    len(tasks),
            "completed_tasks": sum(1 for t in tasks if t.state == TaskState.COMPLETED),
            "failed_tasks":   sum(1 for t in tasks if t.state == TaskState.FAILED),
            "total_credits_settled": sum(
                t.bid_credits for t in tasks if t.state == TaskState.COMPLETED
            ),
        }

    def list_nodes(self) -> List[dict]:
        return [n.to_dict() for n in self._nodes.values()]


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        print("\n" + "═"*60)
        print("  P-MCP DePIN Layer — Demo")
        print("═"*60)

        broker = DePINBroker("farm-broker")

        # Register 3 robot nodes with different capabilities
        nodes = [
            RobotServiceNode("arm-01", "Arm Alpha",  ["move_to", "pick", "place"],
                              stake_credits=2000, reputation=90.0, rate_credits_per_s=0.05),
            RobotServiceNode("arm-02", "Arm Beta",   ["move_to", "pick", "weld"],
                              stake_credits=500,  reputation=70.0, rate_credits_per_s=0.08),
            RobotServiceNode("cart-01","Cart One",   ["navigate_to", "transport"],
                              stake_credits=1500, reputation=85.0, rate_credits_per_s=0.03),
        ]
        for n in nodes:
            ok, msg = broker.register_node(n)
            print(f"  Register {n.name}: {msg}")

        # Post a task
        task = ServiceTask(
            requester_id  = "planner-01",
            tool_name     = "pick",
            arguments     = {"x": 1.0, "y": 0.5, "z": 0.3},
            max_bid_credits = 50.0,
            required_caps = ["pick"],
        )
        print(f"\n  Posting task: {task.tool_name} {task.arguments}")
        ok, winner = await broker.post_task(task)
        print(f"  Assigned to: {winner} @ {task.bid_credits:.2f} credits")

        # Node submits completion proof
        result_data  = {"pose": {"x": 1.0, "y": 0.5, "z": 0.3}, "grasped": True}
        proof_token  = hashlib.sha256(
            json.dumps({"task_id": task.task_id, "node_id": winner,
                        "result": result_data}, sort_keys=True).encode()
        ).hexdigest()[:32]

        ok2, msg2 = await broker.submit_completion(
            task.task_id, winner, result_data, proof_token
        )
        print(f"  Completion: {msg2}")

        # Safety violation on another node
        print("\n  Simulating safety violation on arm-02...")
        broker.slash_node("arm-02", "Exceeded speed limit — TEE violation")

        print(f"\n  Network Stats:\n  {json.dumps(broker.network_stats(), indent=4)}")
        print("\n  Node details:")
        for n_dict in broker.list_nodes():
            print(f"    {n_dict['node_id']:<12} rep={n_dict['reputation']:.0f} "
                  f"trust={n_dict['trust_score']:.2f} "
                  f"stake={n_dict['stake']:.0f} state={n_dict['state']}")

    asyncio.run(_demo())
