"""
P-MCP v0.4 — Hub CLI & Driver Registry
=========================================
"npm install for Robot Drivers"

P-MCP Hub is the package manager and registry for hardware drivers.
Install drivers with a single command; the Hub validates, caches, and
makes them available to the P-MCP server.

Usage:
    pmcp-hub list                        # List installed drivers
    pmcp-hub search [query]              # Search registry
    pmcp-hub install ur5                 # Install UR5 driver
    pmcp-hub install turtlebot3          # Install TurtleBot3 driver
    pmcp-hub install plc/siemens-s7      # Install Siemens S7 PLC driver
    pmcp-hub publish my_driver/          # Publish a driver package
    pmcp-hub info ur5                    # Show driver details
    pmcp-hub update                      # Update all drivers
    pmcp-hub server start                # Start P-MCP server with installed drivers

Driver Manifest Format (driver.json):
--------------------------------------
{
  "id":          "ur5",
  "name":        "Universal Robots UR5",
  "version":     "0.4.0",
  "protocol":    "P-MCP/0.4",
  "type":        "arm",
  "vendor":      "Universal Robots",
  "description": "6-DOF collaborative robot arm driver",
  "pip_deps":    ["rtde-control", "rtde-receive"],
  "pmcp_tools":  ["move_to", "open_gripper", "close_gripper", "home"],
  "pmcp_resources": ["joints", "pose", "force_torque"],
  "safety_constraints": {
    "max_speed": 1.0,
    "max_payload_kg": 5.0,
    "work_envelope": {"radius": 0.85, "height": 1.3}
  },
  "entry_point": "pmcp.v04.drivers.ur5_driver:UR5Driver"
}
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib
import importlib.util
import json
import logging
import os
import sys
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.hub")

# ─────────────────────────────────────────────────────────────
#  BUILT-IN DRIVER REGISTRY
# ─────────────────────────────────────────────────────────────

BUILTIN_REGISTRY: Dict[str, dict] = {
    "ur5": {
        "id":      "ur5",
        "name":    "Universal Robots UR5",
        "version": "0.4.0",
        "type":    "arm",
        "vendor":  "Universal Robots",
        "description": "6-DOF collaborative robot arm — RTDE control interface",
        "pip_deps":    ["ur-rtde"],
        "pmcp_tools":  ["move_to", "move_joints", "open_gripper", "close_gripper", "home"],
        "pmcp_resources": ["pose", "joints", "force_torque"],
        "entry_point":    "v04.drivers.ur5_driver:UR5Driver",
        "safety_constraints": {
            "max_speed_ms": 1.0, "max_payload_kg": 5.0,
        },
    },
    "turtlebot3": {
        "id":      "turtlebot3",
        "name":    "TurtleBot3 (ROS2)",
        "version": "0.4.0",
        "type":    "mobile",
        "vendor":  "ROBOTIS",
        "description": "Differential-drive mobile robot via ROS2 Nav2",
        "pip_deps":    [],
        "ros_deps":    ["rclpy", "nav2_simple_commander"],
        "pmcp_tools":  ["navigate_to", "stop", "rotate"],
        "pmcp_resources": ["pose", "battery", "scan"],
        "entry_point":    "v04.drivers.turtlebot_driver:TurtleBotDriver",
        "safety_constraints": {
            "max_speed_ms": 0.5, "min_obstacle_dist_m": 0.2,
        },
    },
    "siemens-s7": {
        "id":      "siemens-s7",
        "name":    "Siemens S7 PLC Driver",
        "version": "0.4.0",
        "type":    "plc",
        "vendor":  "Siemens",
        "description": "Siemens S7-1200/1500 via python-snap7",
        "pip_deps":    ["python-snap7"],
        "pmcp_tools":  ["write_register", "read_register", "emergency_stop"],
        "pmcp_resources": ["status", "io_map"],
        "entry_point":    "v04.drivers.siemens_s7_driver:S7Driver",
    },
    "arduino": {
        "id":      "arduino",
        "name":    "Arduino Serial Bridge",
        "version": "0.4.0",
        "type":    "microcontroller",
        "vendor":  "Arduino",
        "description": "Arduino actuator bridge via pyserial JSON protocol",
        "pip_deps":    ["pyserial"],
        "pmcp_tools":  ["set_servo", "set_pin", "set_pwm"],
        "pmcp_resources": ["analog_in", "digital_in", "temperature"],
        "entry_point":    "v04.drivers.arduino_driver:ArduinoDriver",
    },
    "modbus-tcp": {
        "id":      "modbus-tcp",
        "name":    "Modbus TCP Driver",
        "version": "0.4.0",
        "type":    "plc",
        "vendor":  "Generic",
        "description": "Generic Modbus TCP device driver via pymodbus",
        "pip_deps":    ["pymodbus"],
        "pmcp_tools":  ["read_holding", "write_holding", "read_coil", "write_coil"],
        "pmcp_resources": ["registers", "coils"],
        "entry_point":    "v04.drivers.modbus_driver:ModbusDriver",
    },
    "opcua": {
        "id":      "opcua",
        "name":    "OPC UA Driver",
        "version": "0.4.0",
        "type":    "industrial",
        "vendor":  "Generic",
        "description": "Generic OPC UA client driver via asyncua",
        "pip_deps":    ["asyncua"],
        "pmcp_tools":  ["read_node", "write_node", "subscribe_node"],
        "pmcp_resources": ["nodes", "subscriptions"],
        "entry_point":    "v04.drivers.opcua_driver:OPCUADriver",
    },
    "stub-robot": {
        "id":      "stub-robot",
        "name":    "Stub Robot (Testing)",
        "version": "0.4.0",
        "type":    "stub",
        "vendor":  "P-MCP",
        "description": "Simulated robot driver — no hardware required. Ideal for CI/CD.",
        "pip_deps":    [],
        "pmcp_tools":  ["move_to", "move_joints", "pick", "place"],
        "pmcp_resources": ["pose", "joints"],
        "entry_point":    "v04.drivers.stub_driver:StubRobotDriver",
    },
}


# ─────────────────────────────────────────────────────────────
#  DRIVER RECORD
# ─────────────────────────────────────────────────────────────

@dataclass
class DriverRecord:
    """Installed driver metadata."""
    driver_id:   str
    name:        str
    version:     str
    driver_type: str
    vendor:      str
    description: str
    pip_deps:    List[str]
    pmcp_tools:  List[str]
    pmcp_resources: List[str]
    entry_point: str
    install_dir: str   = ""
    installed_at: float = field(default_factory=time.time)
    enabled:     bool  = True
    checksum:    str   = ""
    safety_constraints: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "DriverRecord":
        return cls(
            driver_id    = d["id"],
            name         = d["name"],
            version      = d["version"],
            driver_type  = d["type"],
            vendor       = d["vendor"],
            description  = d["description"],
            pip_deps     = d.get("pip_deps", []),
            pmcp_tools   = d.get("pmcp_tools", []),
            pmcp_resources = d.get("pmcp_resources", []),
            entry_point  = d["entry_point"],
            safety_constraints = d.get("safety_constraints", {}),
        )

    def to_dict(self) -> dict:
        return {
            "id":           self.driver_id,
            "name":         self.name,
            "version":      self.version,
            "type":         self.driver_type,
            "vendor":       self.vendor,
            "description":  self.description,
            "tools":        self.pmcp_tools,
            "resources":    self.pmcp_resources,
            "enabled":      self.enabled,
            "installed_at": self.installed_at,
        }


# ─────────────────────────────────────────────────────────────
#  DRIVER HUB
# ─────────────────────────────────────────────────────────────

class PMCPHub:
    """
    Driver registry and manager for P-MCP.
    Persists driver manifest to ~/.pmcp/drivers.json.
    """

    def __init__(self, config_dir: Optional[str] = None):
        self._config_dir = Path(config_dir or os.path.expanduser("~/.pmcp"))
        self._config_dir.mkdir(parents=True, exist_ok=True)
        self._manifest_path = self._config_dir / "drivers.json"
        self._drivers: Dict[str, DriverRecord] = {}
        self._load_manifest()

    # ── Core operations ────────────────────────────────────────────────────

    def install(self, driver_id: str) -> Tuple[bool, str]:
        """
        Install a driver by ID from the built-in registry.
        In production, this would also pip install deps.
        """
        if driver_id not in BUILTIN_REGISTRY:
            return False, f"Driver '{driver_id}' not found in registry. Try: pmcp-hub search {driver_id}"

        spec = BUILTIN_REGISTRY[driver_id]
        record = DriverRecord.from_dict(spec)
        record.install_dir = str(self._config_dir / "drivers" / driver_id)
        record.checksum    = hashlib.sha256(
            json.dumps(spec, sort_keys=True).encode()
        ).hexdigest()[:16]

        self._drivers[driver_id] = record
        self._save_manifest()

        pip_note = ""
        if record.pip_deps:
            pip_note = f" (pip: {', '.join(record.pip_deps)})"
        log.info(f"  📦  Installed driver: {driver_id} v{record.version}{pip_note}")
        return True, f"Driver '{driver_id}' installed successfully{pip_note}"

    def uninstall(self, driver_id: str) -> Tuple[bool, str]:
        if driver_id not in self._drivers:
            return False, f"Driver '{driver_id}' not installed"
        del self._drivers[driver_id]
        self._save_manifest()
        return True, f"Driver '{driver_id}' removed"

    def search(self, query: str = "") -> List[dict]:
        results = []
        q = query.lower()
        for driver_id, spec in BUILTIN_REGISTRY.items():
            if not q or any(q in str(v).lower() for v in spec.values()):
                installed = driver_id in self._drivers
                results.append({
                    **spec,
                    "installed": installed,
                })
        return results

    def list_installed(self) -> List[dict]:
        return [r.to_dict() for r in self._drivers.values()]

    def get_driver_info(self, driver_id: str) -> Optional[dict]:
        record = self._drivers.get(driver_id)
        if record:
            return record.to_dict()
        spec = BUILTIN_REGISTRY.get(driver_id)
        if spec:
            return {**spec, "installed": False}
        return None

    def load_driver_class(self, driver_id: str):
        """
        Dynamically import and return the driver class.
        Returns None if import fails (hardware lib not installed).
        """
        record = self._drivers.get(driver_id)
        if not record:
            return None

        module_path, class_name = record.entry_point.rsplit(":", 1)
        try:
            module = importlib.import_module(module_path)
            return getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            log.warning(f"  ⚠️   Cannot load driver {driver_id}: {e}")
            return None

    def update_all(self) -> dict:
        """Re-install all drivers from registry (picks up spec changes)."""
        updated = {}
        for driver_id in list(self._drivers.keys()):
            ok, msg = self.install(driver_id)
            updated[driver_id] = msg
        return updated

    # ── Persistence ────────────────────────────────────────────────────────

    def _load_manifest(self):
        if self._manifest_path.exists():
            try:
                data = json.loads(self._manifest_path.read_text())
                for d in data.get("drivers", []):
                    record = DriverRecord.from_dict(d)
                    record.installed_at = d.get("installed_at", time.time())
                    self._drivers[record.driver_id] = record
                log.debug(f"  📦  Loaded {len(self._drivers)} drivers from manifest")
            except Exception as e:
                log.warning(f"  📦  Could not load manifest: {e}")

    def _save_manifest(self):
        data = {
            "pmcp_hub_version": "0.4.0",
            "drivers": [
                {**r.to_dict(), "entry_point": r.entry_point,
                 "pip_deps": r.pip_deps, "installed_at": r.installed_at,
                 "checksum": r.checksum}
                for r in self._drivers.values()
            ]
        }
        self._manifest_path.write_text(json.dumps(data, indent=2))


# ─────────────────────────────────────────────────────────────
#  CLI
# ─────────────────────────────────────────────────────────────

def _fmt_table(rows: List[dict], cols: List[str]) -> str:
    widths = {c: max(len(c), max((len(str(r.get(c, ""))) for r in rows), default=0))
              for c in cols}
    header = "  " + "  ".join(c.upper().ljust(widths[c]) for c in cols)
    sep    = "  " + "  ".join("─" * widths[c] for c in cols)
    lines  = [header, sep]
    for row in rows:
        lines.append("  " + "  ".join(str(row.get(c, "")).ljust(widths[c]) for c in cols))
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="pmcp-hub",
        description="P-MCP Hub — Robot Driver Registry & Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pmcp-hub list                  List installed drivers
  pmcp-hub search arm            Search for arm drivers
  pmcp-hub install ur5           Install UR5 driver
  pmcp-hub info ur5              Show driver details
  pmcp-hub update                Update all drivers
        """,
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="List installed drivers")

    p_search = sub.add_parser("search", help="Search registry")
    p_search.add_argument("query", nargs="?", default="", help="Search query")

    p_install = sub.add_parser("install", help="Install a driver")
    p_install.add_argument("driver_id", help="Driver ID (e.g. ur5, turtlebot3)")

    p_uninstall = sub.add_parser("uninstall", help="Uninstall a driver")
    p_uninstall.add_argument("driver_id")

    p_info = sub.add_parser("info", help="Show driver details")
    p_info.add_argument("driver_id")

    sub.add_parser("update", help="Update all installed drivers")

    args = parser.parse_args(argv)
    hub  = PMCPHub()

    if args.cmd == "list":
        installed = hub.list_installed()
        if not installed:
            print("  No drivers installed. Try: pmcp-hub install ur5")
            return
        print(f"\n  Installed P-MCP Drivers ({len(installed)} total)\n")
        print(_fmt_table(installed, ["id", "name", "version", "type", "vendor"]))
        print()

    elif args.cmd == "search":
        results = hub.search(args.query)
        print(f"\n  P-MCP Driver Registry ({len(results)} drivers)\n")
        for r in results:
            status = "✅ installed" if r.get("installed") else "   available"
            print(f"  {status}  {r['id']:<20} {r['name']:<35} {r['description'][:50]}")
        print()

    elif args.cmd == "install":
        ok, msg = hub.install(args.driver_id)
        print(f"  {'✅' if ok else '❌'}  {msg}")

    elif args.cmd == "uninstall":
        ok, msg = hub.uninstall(args.driver_id)
        print(f"  {'✅' if ok else '❌'}  {msg}")

    elif args.cmd == "info":
        info = hub.get_driver_info(args.driver_id)
        if not info:
            print(f"  ❌  Driver '{args.driver_id}' not found")
            return
        print(f"\n  {info['name']} v{info['version']}")
        print(f"  {'─'*60}")
        print(f"  Type:        {info['type']}")
        print(f"  Vendor:      {info['vendor']}")
        print(f"  Description: {info['description']}")
        print(f"  Tools:       {', '.join(info.get('pmcp_tools', info.get('tools', [])))}")
        print(f"  Resources:   {', '.join(info.get('pmcp_resources', info.get('resources', [])))}")
        deps = info.get("pip_deps", [])
        if deps:
            print(f"  pip deps:    {', '.join(deps)}")
        print()

    elif args.cmd == "update":
        result = hub.update_all()
        for driver_id, msg in result.items():
            print(f"  ✅  {driver_id}: {msg}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")
    main()
