"""
P-MCP v0.4 — Comprehensive Test Suite
========================================
Tests for all v0.4 modules without requiring physical hardware.
Run: python -m pytest v04/tests/ -v
  or: python v04/tests/test_all.py
"""

import asyncio
import hashlib
import json
import sys
import time
import unittest
from pathlib import Path

# Add workspace root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))


# ═══════════════════════════════════════════════════════════════
#  TEMPORAL LEASE TESTS
# ═══════════════════════════════════════════════════════════════

class TestTemporalLease(unittest.IsolatedAsyncioTestCase):

    async def test_grant_simple_lease(self):
        from v04.pmcp_temporal_lease import LeaseManager, LeaseState
        mgr = LeaseManager("test-mgr-1")
        l = await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000)
        self.assertEqual(l.state, LeaseState.ACTIVE)
        self.assertTrue(l.is_active())

    async def test_deny_conflicting_lease_lower_bid(self):
        from v04.pmcp_temporal_lease import LeaseManager, LeaseState
        mgr = LeaseManager("test-mgr-2")
        l1 = await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000, bid_energy_j=100)
        l2 = await mgr.request_lease("arm-02", "zone-a", duration_ms=5_000, bid_energy_j=50)
        self.assertEqual(l1.state, LeaseState.ACTIVE)
        self.assertEqual(l2.state, LeaseState.DENIED)

    async def test_preempt_lease_higher_bid(self):
        from v04.pmcp_temporal_lease import LeaseManager, LeaseState
        mgr = LeaseManager("test-mgr-3")
        l1 = await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000, bid_energy_j=100)
        l2 = await mgr.request_lease("arm-02", "zone-a", duration_ms=5_000, bid_energy_j=200)
        self.assertEqual(l2.state, LeaseState.ACTIVE)
        # arm-01 should be preempted
        from v04.pmcp_temporal_lease import LeaseState as LS
        self.assertIn(l1.state, [LS.REVOKED, LS.EXPIRED])

    async def test_tool_call_allowed_with_lease(self):
        from v04.pmcp_temporal_lease import LeaseManager
        mgr = LeaseManager("test-mgr-4")
        await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000, bid_energy_j=100)
        ok, reason = mgr.check_tool_call("arm-01", "zone-a")
        self.assertTrue(ok, reason)

    async def test_zone_revoke_blocks_tool_calls(self):
        from v04.pmcp_temporal_lease import LeaseManager
        mgr = LeaseManager("test-mgr-5")
        await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000)
        mgr.revoke_zone("zone-a", "test halt")
        ok, reason = mgr.check_tool_call("arm-01", "zone-a")
        self.assertFalse(ok)
        self.assertIn("revoked", reason.lower())

    async def test_zone_restore_allows_new_lease(self):
        from v04.pmcp_temporal_lease import LeaseManager, LeaseState
        mgr = LeaseManager("test-mgr-6")
        mgr.revoke_zone("zone-b", "test")
        mgr.restore_zone("zone-b")
        l = await mgr.request_lease("arm-01", "zone-b", duration_ms=3_000)
        self.assertEqual(l.state, LeaseState.ACTIVE)

    async def test_lease_renewal(self):
        from v04.pmcp_temporal_lease import LeaseManager
        mgr = LeaseManager("test-mgr-7")
        l = await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000)
        ok, err = mgr.renew_lease(l.lease_id, 3_000)
        self.assertTrue(ok, err)
        self.assertAlmostEqual(l.duration_ms, 8_000, delta=100)

    async def test_max_tool_calls_limit(self):
        from v04.pmcp_temporal_lease import LeaseManager
        mgr = LeaseManager("test-mgr-8")
        await mgr.request_lease("arm-01", "zone-a", duration_ms=5_000, max_tool_calls=2)
        ok1, _ = mgr.check_tool_call("arm-01", "zone-a")
        ok2, _ = mgr.check_tool_call("arm-01", "zone-a")
        ok3, reason3 = mgr.check_tool_call("arm-01", "zone-a")
        self.assertTrue(ok1)
        self.assertTrue(ok2)
        self.assertFalse(ok3)
        self.assertIn("limit", reason3.lower())


# ═══════════════════════════════════════════════════════════════
#  ZK SAFETY PROOF TESTS
# ═══════════════════════════════════════════════════════════════

class _FakeProjected:
    duration_s = 2.0; energy_j = 100.0; risk_level = "low"
    workspace_conflicts = []; safe_to_execute = True
    class _FakePose:
        class _V: x=1.0; y=0.5; z=0.8
        position = _V(); roll=0.0; pitch=0.0; yaw=0.0; frame="world"
    final_pose = _FakePose()

class _FakeCall:
    call_id  = "test-zk-001"
    robot_id = "arm-01"
    arguments = {"x": 1.0, "y": 0.5, "z": 0.8, "speed": 0.4}
    projected = _FakeProjected()


class TestZKSafety(unittest.TestCase):

    def test_proof_generation(self):
        from v04.pmcp_zk_safety import ZKSafetyProver
        prover = ZKSafetyProver("arm-01")
        proof  = prover.prove(_FakeCall())
        self.assertIsNotNone(proof.commitment)
        self.assertIsNotNone(proof.nonce)
        self.assertTrue(proof.safety_checks.all_passed)

    def test_proof_verification(self):
        from v04.pmcp_zk_safety import ZKSafetyProver, ZKSafetyVerifier
        prover   = ZKSafetyProver("arm-01")
        verifier = ZKSafetyVerifier()
        proof    = prover.prove(_FakeCall())
        ok, violations = verifier.verify(proof, prover._prover_key, _FakeCall.arguments)
        self.assertTrue(ok, violations)
        self.assertEqual(violations, [])

    def test_replay_protection(self):
        from v04.pmcp_zk_safety import ZKSafetyProver, ZKSafetyVerifier
        prover   = ZKSafetyProver("arm-01")
        verifier = ZKSafetyVerifier()
        proof    = prover.prove(_FakeCall())
        verifier.verify(proof, prover._prover_key, _FakeCall.arguments)
        ok, v = verifier.verify(proof, prover._prover_key, _FakeCall.arguments)
        self.assertFalse(ok)
        self.assertTrue(any("replay" in x.lower() or "nonce" in x.lower() for x in v))

    def test_expired_proof_rejected(self):
        from v04.pmcp_zk_safety import ZKSafetyProver, ZKSafetyVerifier
        prover = ZKSafetyProver("arm-01")
        proof  = prover.prove(_FakeCall())
        proof.issued_at = time.time() - 100   # Force expire
        ok, v = ZKSafetyVerifier().verify(proof)
        self.assertFalse(ok)
        self.assertTrue(any("expired" in x.lower() for x in v))

    def test_unsafe_call_proof_fails(self):
        from v04.pmcp_zk_safety import ZKSafetyProver, ZKSafetyVerifier
        class UnsafeProjected(_FakeProjected):
            energy_j = 9999.0
            safe_to_execute = False
        class UnsafeCall(_FakeCall):
            call_id   = "unsafe-001"
            arguments = {"x": 1.0, "y": 0.5, "z": 0.8, "speed": 5.0}
            projected = UnsafeProjected()

        prover   = ZKSafetyProver("arm-bad")
        verifier = ZKSafetyVerifier()
        proof    = prover.prove(UnsafeCall())
        ok, v    = verifier.verify(proof)
        self.assertFalse(ok)
        self.assertTrue(len(v) > 0)


# ═══════════════════════════════════════════════════════════════
#  CONSTITUTION REGISTRY TESTS
# ═══════════════════════════════════════════════════════════════

class TestConstitutionRegistry(unittest.TestCase):

    def setUp(self):
        from v04.pmcp_constitution_registry import SafetyAuthority, ConstitutionRegistry
        self.authority = SafetyAuthority("test-auth")
        self.bundle    = self.authority.create_bundle()
        self.registry  = ConstitutionRegistry("test-reg")
        self.registry.load_bundle(self.bundle)

    def test_load_bundle(self):
        self.assertGreater(len(self.bundle.rules), 0)

    def test_valid_call_passes(self):
        import time as _t
        call = {"robot_id": "arm-01", "call_id": "c-001-valid",
                "speed": 0.4, "z": 0.5, "energy_j": 100,
                "_shadow_ts": _t.time()}  # fresh shadow validation token
        cleared, violations = self.registry.evaluate_call(call)
        self.assertTrue(cleared, violations)

    def test_speed_violation(self):
        call = {"robot_id": "arm-01", "call_id": "c-002",
                "speed": 3.0, "z": 0.5, "energy_j": 100}
        cleared, violations = self.registry.evaluate_call(call)
        self.assertFalse(cleared)

    def test_floor_guard_violation(self):
        call = {"robot_id": "arm-01", "call_id": "c-003",
                "speed": 0.4, "z": -0.5, "energy_j": 100}
        cleared, violations = self.registry.evaluate_call(call)
        self.assertFalse(cleared)

    def test_bundle_signature_verified(self):
        from v04.pmcp_constitution_registry import ConstitutionRegistry
        reg2 = ConstitutionRegistry("test-reg-2")
        ok, err = reg2.load_bundle(self.bundle,
                                    trusted_pub_key_hex=self.authority.pub_key_hex())
        self.assertTrue(ok, err)

    def test_tampered_bundle_rejected(self):
        from v04.pmcp_constitution_registry import ConstitutionRegistry
        import copy
        tampered = copy.deepcopy(self.bundle)
        if tampered.rules:
            tampered.rules[0].description = "HACKED"
        tampered.signature = "deadbeef" * 8
        reg2 = ConstitutionRegistry("test-reg-3")
        ok, _ = reg2.load_bundle(tampered,
                                  trusted_pub_key_hex=self.authority.pub_key_hex())
        # Tampered signature should fail
        self.assertFalse(ok)


# ═══════════════════════════════════════════════════════════════
#  ENERGY SCHEDULER TESTS
# ═══════════════════════════════════════════════════════════════

class TestEnergyScheduler(unittest.IsolatedAsyncioTestCase):

    async def test_critical_task_runs_immediately(self):
        from v04.pmcp_energy_scheduler import (
            EnergyAwareScheduler, ScheduledTask, TaskPriority, GridSignal
        )
        scheduler = EnergyAwareScheduler("sched-test-1")
        ran = asyncio.Event()
        async def cb(task): ran.set(); return {}

        signal = GridSignal(carbon_g_kwh=500, price_usd_kwh=0.30,
                            renewable_pct=10, timestamp=time.time())
        task = ScheduledTask(task_id="t1", tool_name="Critical Task",
                             priority=TaskPriority.CRITICAL,
                             deadline_unix=time.time()+3600,
                             estimated_energy_j=100, callback=cb)
        await scheduler.enqueue(task)
        await scheduler._process_queue(signal)
        self.assertTrue(ran.is_set(), "CRITICAL task should run despite peak signal")

    async def test_green_only_deferred_on_peak(self):
        from v04.pmcp_energy_scheduler import (
            EnergyAwareScheduler, ScheduledTask, TaskPriority, GridSignal
        )
        scheduler = EnergyAwareScheduler("sched-test-2")
        ran = asyncio.Event()
        async def cb(task): ran.set(); return {}

        signal = GridSignal(carbon_g_kwh=500, price_usd_kwh=0.30,
                            renewable_pct=10, timestamp=time.time())
        task = ScheduledTask(task_id="t2", tool_name="Green Task",
                             priority=TaskPriority.GREEN_ONLY,
                             deadline_unix=time.time()+3600,
                             estimated_energy_j=100, callback=cb)
        await scheduler.enqueue(task)
        await scheduler._process_queue(signal)
        # GREEN_ONLY should NOT run on peak grid
        self.assertFalse(ran.is_set(), "GREEN_ONLY task should be deferred on peak grid")

    async def test_green_task_runs_on_clean_grid(self):
        from v04.pmcp_energy_scheduler import (
            EnergyAwareScheduler, ScheduledTask, TaskPriority, GridSignal
        )
        scheduler = EnergyAwareScheduler("sched-test-3")
        ran = asyncio.Event()
        async def cb(task): ran.set(); return {}

        signal = GridSignal(carbon_g_kwh=100, price_usd_kwh=0.05,
                            renewable_pct=90, timestamp=time.time())
        task = ScheduledTask(task_id="t3", tool_name="Green Task",
                             priority=TaskPriority.GREEN_ONLY,
                             deadline_unix=time.time()+3600,
                             estimated_energy_j=100, callback=cb)
        await scheduler.enqueue(task)
        await scheduler._process_queue(signal)
        self.assertTrue(ran.is_set(), "GREEN_ONLY task should run on clean grid")


# ═══════════════════════════════════════════════════════════════
#  ZENOH TRANSPORT TESTS
# ═══════════════════════════════════════════════════════════════

class TestStubTransport(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        from v04.pmcp_zenoh_transport import StubTransport
        StubTransport.reset()

    async def test_publish_subscribe(self):
        from v04.pmcp_zenoh_transport import StubTransport
        t1 = StubTransport(farm_id="test-farm", node_id="pub")
        t2 = StubTransport(farm_id="test-farm", node_id="sub")
        await t1.connect()
        await t2.connect()

        received = []
        await t2.subscribe("tool_call/**",
                           lambda k, p: received.append((k, p)))

        await t1.publish("tool_call/abc", {"call_id": "abc", "tool": "move_to"})
        await asyncio.sleep(0.05)
        self.assertEqual(len(received), 1)
        self.assertEqual(received[0][1]["call_id"], "abc")

    async def test_query_latest(self):
        from v04.pmcp_zenoh_transport import StubTransport
        t = StubTransport(farm_id="test-farm", node_id="q")
        await t.connect()
        await t.publish("robot/r1/pose", {"x": 1.0, "y": 2.0})
        result = await t.query("robot/r1/pose")
        self.assertIsNotNone(result)
        self.assertEqual(result["x"], 1.0)

    async def test_factory_returns_stub_when_no_zenoh(self):
        from v04.pmcp_zenoh_transport import create_transport, StubTransport
        t = create_transport("stub", farm_id="x")
        self.assertIsInstance(t, StubTransport)


# ═══════════════════════════════════════════════════════════════
#  DEPIN TESTS
# ═══════════════════════════════════════════════════════════════

class TestDePIN(unittest.IsolatedAsyncioTestCase):

    async def test_node_registration(self):
        from v04.pmcp_depin import DePINBroker, RobotServiceNode
        broker = DePINBroker("test-broker-1")
        node   = RobotServiceNode("arm-01", "Arm", ["pick"], stake_credits=1000, reputation=80)
        ok, msg = broker.register_node(node)
        self.assertTrue(ok, msg)

    async def test_insufficient_stake_rejected(self):
        from v04.pmcp_depin import DePINBroker, RobotServiceNode
        broker = DePINBroker("test-broker-2")
        node   = RobotServiceNode("arm-poor", "Poor Arm", ["pick"], stake_credits=10)
        ok, msg = broker.register_node(node)
        self.assertFalse(ok)
        self.assertIn("stake", msg.lower())

    async def test_task_assignment(self):
        from v04.pmcp_depin import DePINBroker, RobotServiceNode, ServiceTask
        broker = DePINBroker("test-broker-3")
        broker.register_node(
            RobotServiceNode("arm-01", "A1", ["pick"], stake_credits=1000, reputation=80))
        broker.register_node(
            RobotServiceNode("arm-02", "A2", ["pick"], stake_credits=1000, reputation=75))

        task = ServiceTask(requester_id="r1", tool_name="pick",
                           arguments={}, required_caps=["pick"], max_bid_credits=50)
        ok, winner = await broker.post_task(task)
        self.assertTrue(ok, winner)
        self.assertIn(winner, ["arm-01", "arm-02"])

    async def test_completion_payment(self):
        from v04.pmcp_depin import DePINBroker, RobotServiceNode, ServiceTask, TaskState
        broker = DePINBroker("test-broker-4")
        broker.register_node(
            RobotServiceNode("arm-01", "A1", ["pick"], stake_credits=1000, reputation=80))

        task = ServiceTask(requester_id="r1", tool_name="pick",
                           arguments={}, required_caps=["pick"])
        ok, winner = await broker.post_task(task)

        result = {"grasped": True}
        proof  = hashlib.sha256(
            json.dumps({"task_id": task.task_id, "node_id": winner,
                        "result": result}, sort_keys=True).encode()
        ).hexdigest()[:32]

        ok2, msg2 = await broker.submit_completion(task.task_id, winner, result, proof)
        self.assertTrue(ok2, msg2)
        self.assertEqual(task.state, TaskState.COMPLETED)

    async def test_slash_on_bad_proof(self):
        from v04.pmcp_depin import DePINBroker, RobotServiceNode, ServiceTask, NodeState
        broker = DePINBroker("test-broker-5")
        node   = RobotServiceNode("arm-01", "A1", ["pick"], stake_credits=1000, reputation=80)
        broker.register_node(node)

        task = ServiceTask(requester_id="r1", tool_name="pick",
                           arguments={}, required_caps=["pick"])
        ok, winner = await broker.post_task(task)

        original_stake = node.stake_credits
        ok2, _ = await broker.submit_completion(task.task_id, winner, {}, "bad_proof_token")
        self.assertFalse(ok2)
        # Node should be slashed
        self.assertLess(node.stake_credits, original_stake)


# ═══════════════════════════════════════════════════════════════
#  HARDWARE DRIVER TESTS
# ═══════════════════════════════════════════════════════════════

class TestUR5Driver(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        from v04.drivers.ur5_driver import UR5Driver, UR5Config
        self.driver = UR5Driver(UR5Config(robot_id="test-ur5"))
        await self.driver.connect()

    async def asyncTearDown(self):
        await self.driver.disconnect()

    async def test_move_to_success(self):
        r = await self.driver.move_to(0.5, 0.2, 0.3)
        self.assertTrue(r["success"], r)

    async def test_floor_guard(self):
        r = await self.driver.move_to(0.5, 0.2, -0.1)
        self.assertFalse(r["success"])
        self.assertIn("floor", r["error"].lower())

    async def test_speed_limit(self):
        r = await self.driver.move_to(0.5, 0.2, 0.3, speed=5.0)
        self.assertFalse(r["success"])
        self.assertIn("speed", r["error"].lower())

    async def test_gripper_open_close(self):
        r1 = await self.driver.open_gripper()
        r2 = await self.driver.close_gripper()
        self.assertTrue(r1["success"])
        self.assertTrue(r2["success"])
        self.assertEqual(r1["gripper"], "open")
        self.assertEqual(r2["gripper"], "closed")

    async def test_get_pose(self):
        pose = await self.driver.get_pose()
        self.assertIn("x", pose)
        self.assertIn("y", pose)
        self.assertIn("z", pose)


class TestArduinoDriver(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        from v04.drivers.arduino_driver import ArduinoDriver, ArduinoConfig
        self.driver = ArduinoDriver(ArduinoConfig(robot_id="test-ard"))
        await self.driver.connect()

    async def asyncTearDown(self):
        await self.driver.disconnect()

    async def test_set_servo(self):
        r = await self.driver.set_servo(9, 90)
        self.assertTrue(r["success"])

    async def test_set_pin(self):
        r = await self.driver.set_pin(2, True)
        self.assertTrue(r["success"])

    async def test_read_analog(self):
        r = await self.driver.read_analog(0)
        self.assertIn("raw", r)
        self.assertGreaterEqual(r["raw"], 0)
        self.assertLessEqual(r["raw"], 1023)

    async def test_temperature(self):
        r = await self.driver.get_temperature()
        self.assertIn("temperature_c", r)
        # Temperature should be in reasonable room-temp range
        if r["temperature_c"] is not None:
            self.assertGreater(r["temperature_c"], 0)
            self.assertLess(r["temperature_c"], 60)

    async def test_pin_validation(self):
        r = await self.driver.set_servo(1, 90)   # Pin 1 not in servo_pins
        self.assertFalse(r["success"])
        self.assertIn("servo_pins", r["error"])


# ═══════════════════════════════════════════════════════════════
#  HUB TESTS
# ═══════════════════════════════════════════════════════════════

class TestHub(unittest.TestCase):

    def setUp(self):
        import tempfile
        from v04.pmcp_hub import PMCPHub
        self._tmpdir = tempfile.mkdtemp()
        self.hub = PMCPHub(config_dir=self._tmpdir)

    def test_install_driver(self):
        ok, msg = self.hub.install("ur5")
        self.assertTrue(ok, msg)
        installed = self.hub.list_installed()
        self.assertTrue(any(d["id"] == "ur5" for d in installed))

    def test_unknown_driver(self):
        ok, msg = self.hub.install("nonexistent-robot-xyz")
        self.assertFalse(ok)

    def test_search_all(self):
        results = self.hub.search()
        self.assertGreater(len(results), 0)

    def test_search_filtered(self):
        results = self.hub.search("arm")
        ids = [r["id"] for r in results]
        self.assertIn("ur5", ids)

    def test_uninstall(self):
        self.hub.install("arduino")
        ok, _ = self.hub.uninstall("arduino")
        self.assertTrue(ok)
        installed = self.hub.list_installed()
        self.assertFalse(any(d["id"] == "arduino" for d in installed))

    def test_driver_info(self):
        info = self.hub.get_driver_info("turtlebot3")
        self.assertIsNotNone(info)
        self.assertEqual(info["id"], "turtlebot3")

    def test_manifest_persistence(self):
        import tempfile
        from v04.pmcp_hub import PMCPHub
        self.hub.install("siemens-s7")
        # Create new hub instance from same dir — should load manifest
        hub2 = PMCPHub(config_dir=self._tmpdir)
        installed = hub2.list_installed()
        self.assertTrue(any(d["id"] == "siemens-s7" for d in installed))


# ═══════════════════════════════════════════════════════════════
#  RUNNER
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    test_classes = [
        TestTemporalLease,
        TestZKSafety,
        TestConstitutionRegistry,
        TestEnergyScheduler,
        TestStubTransport,
        TestDePIN,
        TestUR5Driver,
        TestArduinoDriver,
        TestHub,
    ]

    for cls in test_classes:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
