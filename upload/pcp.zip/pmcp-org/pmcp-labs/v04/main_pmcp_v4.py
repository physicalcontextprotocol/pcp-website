"""
P-MCP v0.4 — Full Integration Demo
=====================================
"All Layers Running Together"

This demo spins up the complete P-MCP v0.4 stack:

    VisionServer        → detects humans/obstacles → DigitalTwin
    PLCBridge           → industrial sensors/actuators ↔ P-MCP tools
    ConstitutionRegistry → TEE-signed safety rules (on-boot pull)
    LeaseManager        → temporal zone leases (replace per-call auction)
    ZKSafetyProver      → generates ZK safety proofs for each tool call
    EnergyScheduler     → delays non-critical tasks during peak power
    ZenohTransport      → P2P mesh broadcast of tool calls + results
    ShadowUIServer      → WebSocket dashboard (open browser to localhost:8765)
    DePINBroker         → decentralized task assignment
    UR5 + TurtleBot stubs → hardware drivers in stub mode

Scenario:
----------
1. Boot: Constitution Registry pulls 8 safety rules from Authority
2. arm-01 requests temporal lease on grow_zone_a (10 seconds)
3. arm-01 picks a plant tray (3 tool calls, no re-auction)
4. Vision detects human → all leases in zone revoked → E-Stop
5. Human clears → zone restored → arm-01 re-leases
6. Energy scheduler delays a battery-drain task (conveyor cycle)
7. DePIN broker assigns irrigation task to best reputation node
8. ZK proofs validated for all tool calls
9. Zenoh broadcasts results to all network nodes
10. Shadow UI streams 3D preview to browser supervisor

Run:
    python -m v04.main_pmcp_v4

Optional: Open http://localhost:8765 in a browser to see live Shadow UI
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Optional

log = logging.getLogger("pmcp.main_v4")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-28s  %(message)s",
    datefmt="%H:%M:%S",
)

# ── P-MCP v0.4 imports ─────────────────────────────────────────────────────
from v04.pmcp_temporal_lease      import LeaseManager
from v04.pmcp_zk_safety           import ZKSafetyProver, ZKSafetyVerifier
from v04.pmcp_energy_scheduler    import EnergyAwareScheduler, GridSignal, ScheduledTask, TaskPriority
from v04.pmcp_zenoh_transport     import create_transport
from v04.pmcp_constitution_registry import ConstitutionRegistry, SafetyAuthority, ConstitutionBundle
from v04.pmcp_depin               import DePINBroker, RobotServiceNode, ServiceTask
from v04.drivers.ur5_driver       import UR5Driver, UR5Config
from v04.drivers.turtlebot_driver import TurtleBotDriver, TurtleBotConfig

# Optional heavy modules — graceful if missing
try:
    from v04.pmcp_vision_server    import PMCPVisionServer, CameraConfig
    _VISION = True
except Exception:
    _VISION = False

try:
    from v04.pmcp_shadow_ui        import ShadowUIServer
    _SHADOW_UI = True
except Exception:
    _SHADOW_UI = False

try:
    from v04.pmcp_plc_bridge       import PMCPPLCBridge, PLCBridgeConfig
    _PLC = True
except Exception:
    _PLC = False


# ─────────────────────────────────────────────────────────────
#  FAKE TOOL CALL (simulating PMCPServer.invoke output)
# ─────────────────────────────────────────────────────────────

class _FakeProjected:
    duration_s = 2.5; energy_j = 180.0; risk_level = "low"
    workspace_conflicts = []; safe_to_execute = True
    class _FakePose:
        class _V: x=1.0; y=0.5; z=0.8
        position = _V(); roll=0.0; pitch=0.0; yaw=0.0; frame="world"
    final_pose = _FakePose()

class FakeToolCall:
    call_id  = "demo-abc12345"
    robot_id = "arm-01"
    arguments = {"x": 1.0, "y": 0.5, "z": 0.8, "speed": 0.4,
                 "zone_id": "grow_zone_a"}
    projected = _FakeProjected()


# ─────────────────────────────────────────────────────────────
#  INTEGRATION DEMO
# ─────────────────────────────────────────────────────────────

async def run_integration_demo():
    print("\n" + "═"*70)
    print("  P-MCP v0.4 — Full Integration Demo")
    print("  Physical Model Context Protocol — Robot Safety Layer")
    print("═"*70 + "\n")

    # ── 1. Constitution Registry (TEE-signed safety rules) ─────────────────
    print("  [1/10] Bootstrapping Safety Constitution Registry...")
    authority = SafetyAuthority("farm-authority-01")
    bundle    = authority.create_bundle()
    registry  = ConstitutionRegistry("farm-registry")
    registry.load_bundle(bundle)
    print(f"        Loaded {len(bundle.rules)} safety rules "
          f"(fingerprint={bundle.fingerprint()[:12]}...)")

    # Test a tool call against constitution
    test_call = {"robot_id": "arm-01", "call_id": "test-001",
                 "speed": 0.4, "z": 0.5, "energy_j": 100}
    cleared, violations = registry.evaluate_call(test_call)
    print(f"        Test call: {'✅ CLEARED' if cleared else '❌ BLOCKED'} "
          f"({violations or 'all rules passed'})")

    # ── 2. Temporal Lease System ────────────────────────────────────────────
    print("\n  [2/10] Temporal Lease System...")
    lease_mgr = LeaseManager("farm-lease-mgr")

    l1 = await lease_mgr.request_lease("arm-01", "grow_zone_a",
                                        duration_ms=10_000, bid_energy_j=100.0)
    print(f"        arm-01 lease: {l1.state.value.upper()} "
          f"(id={l1.lease_id} remaining={l1.remaining_ms:.0f}ms)")

    # Simulate 3 tool calls under single lease (no re-auction)
    for i in range(3):
        ok, reason = lease_mgr.check_tool_call("arm-01", "grow_zone_a")
        print(f"        Tool call {i+1}: {'✅' if ok else '❌'} {reason}")

    # Competing robot tries lower bid
    l2 = await lease_mgr.request_lease("arm-02", "grow_zone_a",
                                        duration_ms=5_000, bid_energy_j=50.0)
    print(f"        arm-02 lower bid: {l2.state.value.upper()}")

    # ── 3. ZK Safety Proofs ─────────────────────────────────────────────────
    print("\n  [3/10] ZK Safety Proof System...")
    prover   = ZKSafetyProver("arm-01")
    verifier = ZKSafetyVerifier("tee-verifier",
                                 constitution_hash=bundle.fingerprint())

    call  = FakeToolCall()
    proof = prover.prove(call, constitution_hash=bundle.fingerprint())
    ok_p, violations_p = verifier.verify(proof, prover._prover_key, call.arguments)

    print(f"        Proof generated: {proof.proof_id}")
    print(f"        Verification:    {'✅ PASSED' if ok_p else '❌ FAILED'}")
    for v in violations_p:
        print(f"          ⚠ {v}")

    # ── 4. Energy-Aware Scheduler ───────────────────────────────────────────
    print("\n  [4/10] Energy-Aware Scheduler...")
    scheduler = EnergyAwareScheduler("farm-scheduler")

    # Override with green grid signal
    from v04.pmcp_energy_scheduler import GridSignalProvider
    provider  = GridSignalProvider()
    signal    = provider.get_stub_signal()
    print(f"        Grid: carbon={signal.carbon_g_kwh:.0f}g/kWh "
          f"price=${signal.price_usd_kwh:.3f} "
          f"renewable={signal.renewable_pct:.0f}% "
          f"green={signal.is_green()}")

    ran = asyncio.Event()
    async def conveyor_cycle(task): ran.set(); return {"conveyor": "cycle_complete"}

    task = ScheduledTask(
        task_id          = "conveyor-001",
        tool_name        = "Conveyor Flush Cycle",
        priority         = TaskPriority.GREEN_ONLY,
        deadline_unix    = time.time() + 3600,
        estimated_energy_j = 800.0,
        callback         = conveyor_cycle,
    )
    await scheduler.enqueue(task)
    await scheduler._process_queue(signal)
    print(f"        Conveyor task: {'deferred' if not ran.is_set() else 'ran immediately'} "
          f"(priority=GREEN_ONLY, signal={'green' if signal.is_green() else 'peak'})")

    # ── 5. Transport (Zenoh/Stub) ───────────────────────────────────────────
    print("\n  [5/10] Transport Layer (Zenoh/Stub)...")
    transport = create_transport("stub", farm_id="demo-farm", node_id="server")
    await transport.connect()

    received_msgs = []
    async def _msg_handler(key: str, payload: dict):
        received_msgs.append((key, payload))

    await transport.subscribe("tool_call/**",
                              lambda k, p: asyncio.ensure_future(_msg_handler(k, p)))

    # Broadcast a tool call
    await transport.publish("tool_call/demo-abc12345",
                             {"call_id": "demo-abc12345", "robot_id": "arm-01",
                              "tool": "move_to", "x": 1.0, "y": 0.5, "z": 0.8})
    await asyncio.sleep(0.05)
    print(f"        Published tool call → received by {len(received_msgs)} subscriber(s)")

    # Query latest pose
    await transport.publish("robot/arm-01/pose", {"x": 0.5, "y": 0.0, "z": 1.1})
    pose = await transport.query("robot/arm-01/pose")
    print(f"        Queried arm-01 pose: {pose}")

    # ── 6. Hardware Drivers ─────────────────────────────────────────────────
    print("\n  [6/10] Hardware Drivers (stub mode)...")
    ur5     = UR5Driver(UR5Config(robot_id="arm-01"))
    turtle  = TurtleBotDriver(TurtleBotConfig(robot_id="turtle-01"))
    await ur5.connect()
    await turtle.connect()

    r_move  = await ur5.move_to(1.0, 0.5, 0.8, speed=0.4)
    r_grip  = await ur5.close_gripper()
    r_nav   = await turtle.navigate_to(1.5, 0.5)
    r_bat   = await turtle.get_battery()

    print(f"        UR5 move_to:     {'✅' if r_move['success'] else '❌'}")
    print(f"        UR5 gripper:     {'✅' if r_grip['success'] else '❌'} ({r_grip['gripper']})")
    print(f"        TurtleBot nav:   {'✅' if r_nav['success'] else '❌'}")
    print(f"        TurtleBot batt:  {r_bat['percentage']:.0f}%")

    # ── 7. DePIN Task Auction ───────────────────────────────────────────────
    print("\n  [7/10] DePIN Task Broker...")
    broker = DePINBroker("farm-broker")

    nodes = [
        RobotServiceNode("arm-01", "Arm Alpha",  ["move_to","pick","place"],
                          stake_credits=2000, reputation=90.0, rate_credits_per_s=0.05),
        RobotServiceNode("arm-02", "Arm Beta",   ["move_to","pick","weld"],
                          stake_credits=500,  reputation=70.0, rate_credits_per_s=0.08),
    ]
    for n in nodes:
        broker.register_node(n)

    irrigation_task = ServiceTask(
        requester_id  = "farm-planner",
        tool_name     = "pick",
        arguments     = {"x": 2.0, "y": 1.0, "z": 0.3},
        max_bid_credits = 30.0,
        required_caps = ["pick"],
    )
    ok_d, winner_id = await broker.post_task(irrigation_task)
    print(f"        Task assigned to: {winner_id} "
          f"@ {irrigation_task.bid_credits:.2f} credits")

    # ── 8. Vision Server (stub) ─────────────────────────────────────────────
    if _VISION:
        print("\n  [8/10] Vision Server (YOLO stub)...")
        from v04.pmcp_vision_server import PMCPVisionServer, CameraConfig, StubDetector
        detector = StubDetector()
        detections = detector.detect(None)
        print(f"        Stub detections: {len(detections)} objects")
        for d in detections[:3]:
            print(f"          {d.obj_class.value:<15} conf={d.confidence:.2f}")
    else:
        print("\n  [8/10] Vision Server — skipped (import error)")

    # ── 9. PLC Bridge (stub) ────────────────────────────────────────────────
    if _PLC:
        print("\n  [9/10] PLC Bridge (OPC UA stub)...")
        from v04.pmcp_plc_bridge import PMCPPLCBridge, PLCBridgeConfig, StubPLCBackend
        cfg = PLCBridgeConfig.example_factory_line()
        plc = PMCPPLCBridge(cfg)
        await plc.connect()
        tools = plc.list_tools()
        print(f"        PLC tools available: {[t['name'] for t in tools[:4]]}...")
        await plc.disconnect()
    else:
        print("\n  [9/10] PLC Bridge — skipped (import error)")

    # ── 10. Emergency Halt & Zone Restore ───────────────────────────────────
    print("\n  [10/10] Emergency Halt Simulation...")
    print("         Simulating human incursion in grow_zone_a...")
    halted = lease_mgr.revoke_zone("grow_zone_a", "Human detected by vision")
    print(f"         Revoked {len(halted)} robot lease(s): {halted}")

    ok_post, reason = lease_mgr.check_tool_call("arm-01", "grow_zone_a")
    print(f"         Tool call after halt: {'✅' if ok_post else '❌ BLOCKED'} — {reason}")

    print("\n         [Human clears zone...]")
    lease_mgr.restore_zone("grow_zone_a")
    l3 = await lease_mgr.request_lease("arm-01", "grow_zone_a",
                                        duration_ms=10_000, bid_energy_j=120.0)
    print(f"         Re-lease: {l3.state.value.upper()}")

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n" + "═"*70)
    print("  ✅  P-MCP v0.4 Integration Demo Complete\n")
    print(f"  Constitution rules: {len(bundle.rules)}")
    print(f"  Leases granted:     {sum(1 for l in [l1,l3] if l.state.value == 'active')}")
    print(f"  ZK proofs issued:   {prover._proofs_generated}")
    print(f"  ZK proofs verified: {verifier.stats()['passed']}/{verifier.stats()['total']}")
    print(f"  Transport msgs:     {len(received_msgs)}")
    print(f"  DePIN tasks done:   {broker.network_stats()['total_tasks']}")
    print(f"  Lease stats:        {lease_mgr.stats()}")
    print("═"*70 + "\n")

    await ur5.disconnect()
    await turtle.disconnect()
    await transport.disconnect()


if __name__ == "__main__":
    asyncio.run(run_integration_demo())
