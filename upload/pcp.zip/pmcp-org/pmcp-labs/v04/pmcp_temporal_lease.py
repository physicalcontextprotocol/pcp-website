"""
P-MCP v0.4 — Temporal Lease System
=====================================
"Rent Space-Time, Not Just Permissions"

Architecture:
    Robot requests TemporalLease (zone + duration)
        ↓  LeaseManager validates against existing leases
        ↓  Issues signed lease token
        ↓  Robot executes N tool calls within the lease
        ↓  No per-call auction overhead while lease is active
    Lease expires → zone re-enters pool

Why Temporal Leases Beat Per-Move Auctions
-------------------------------------------
- Vickrey auction for each mm of movement → too slow for real-time control
- A lease lets a robot "own" a zone for 10–30 seconds
- Multiple motion primitives (grasp, lift, place) share one lease
- Reduces coordination overhead from O(N_moves) to O(1) per task
- Lease revocation: emergency halt can cancel all leases instantly

Lease Protocol
--------------
1. Robot calls lease_manager.request_lease(zone_id, duration_ms, bid_energy_j)
2. LeaseManager checks conflicts (existing leases, human presence)
3. If granted: returns TemporalLease with token
4. Robot executes tool calls within the zone — no re-auction needed
5. Robot calls release_lease(lease_id) on completion or timeout
6. Emergency: lease_manager.revoke_all(zone_id) — instant halt

Conflict Resolution
-------------------
- If two robots request the same zone simultaneously:
  → Higher bid_energy_j wins (Vickrey-compatible)
  → Equal bids: longer-running robot wins (fairness)
  → Safety override: lease with human-presence flag rejected always
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

log = logging.getLogger("pmcp.temporal_lease")

# ── Optional crypto ────────────────────────────────────────────────────────
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    _CRYPTO = True
except ImportError:
    _CRYPTO = False


# ─────────────────────────────────────────────────────────────
#  LEASE STATES
# ─────────────────────────────────────────────────────────────

class LeaseState(str, Enum):
    PENDING   = "pending"     # Requested, not yet granted
    ACTIVE    = "active"      # Granted, in use
    RELEASED  = "released"    # Voluntarily released
    EXPIRED   = "expired"     # Timed out
    REVOKED   = "revoked"     # Force-cancelled (e.g., emergency halt)
    DENIED    = "denied"      # Rejected by lease manager


# ─────────────────────────────────────────────────────────────
#  TEMPORAL LEASE
# ─────────────────────────────────────────────────────────────

@dataclass
class TemporalLease:
    """
    A space-time "rental" agreement for one robot in one zone.

    The lease grants the holding robot exclusive access to a zone
    for a bounded duration. Tool calls made within the lease window
    skip the Vickrey auction step entirely.
    """
    lease_id:       str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    robot_id:       str   = ""
    zone_id:        str   = ""
    start_ms:       float = field(default_factory=lambda: time.time() * 1000)
    duration_ms:    float = 10_000.0       # Default: 10 seconds
    bid_energy_j:   float = 0.0
    state:          LeaseState = LeaseState.PENDING
    token:          str   = ""             # Signed grant token
    tool_calls_made: int  = 0
    max_tool_calls: Optional[int] = None   # Limit calls per lease
    created_at:     float = field(default_factory=time.time)
    granted_at:     Optional[float] = None
    released_at:    Optional[float] = None
    caller_did:     str   = ""

    @property
    def end_ms(self) -> float:
        return self.start_ms + self.duration_ms

    @property
    def remaining_ms(self) -> float:
        return max(0, self.end_ms - time.time() * 1000)

    def is_active(self) -> bool:
        return (self.state == LeaseState.ACTIVE and
                self.end_ms > time.time() * 1000)

    def is_expired(self) -> bool:
        return self.end_ms <= time.time() * 1000

    def can_execute(self) -> Tuple[bool, str]:
        """Returns (allowed, reason)."""
        if self.state == LeaseState.REVOKED:
            return False, "Lease revoked (emergency halt)"
        if self.state == LeaseState.DENIED:
            return False, "Lease was denied"
        if self.state != LeaseState.ACTIVE:
            return False, f"Lease not active (state={self.state})"
        if self.is_expired():
            return False, f"Lease expired {time.time()*1000 - self.end_ms:.0f}ms ago"
        if self.max_tool_calls and self.tool_calls_made >= self.max_tool_calls:
            return False, f"Lease tool call limit reached ({self.max_tool_calls})"
        return True, ""

    def record_tool_call(self):
        self.tool_calls_made += 1

    def overlaps(self, other: "TemporalLease") -> bool:
        if self.zone_id != other.zone_id:
            return False
        if self.robot_id == other.robot_id:
            return False
        return self.start_ms < other.end_ms and self.end_ms > other.start_ms

    def to_dict(self) -> dict:
        return {
            "lease_id":     self.lease_id,
            "robot_id":     self.robot_id,
            "zone_id":      self.zone_id,
            "state":        self.state.value,
            "start_ms":     round(self.start_ms, 1),
            "end_ms":       round(self.end_ms, 1),
            "remaining_ms": round(self.remaining_ms, 1),
            "duration_ms":  self.duration_ms,
            "bid_energy_j": self.bid_energy_j,
            "tool_calls":   self.tool_calls_made,
            "token":        self.token[:16] + "..." if self.token else "",
        }


# ─────────────────────────────────────────────────────────────
#  LEASE MANAGER
# ─────────────────────────────────────────────────────────────

class LeaseManager:
    """
    Central (or distributed) lease coordinator.

    Features:
    - Conflict detection with existing leases
    - Vickrey auction resolution for simultaneous requests
    - Emergency revocation
    - Lease renewal (extend duration while active)
    - Statistics and audit trail
    """

    def __init__(self, manager_id: str = "lease-mgr-0",
                 twin=None, max_lease_duration_ms: float = 60_000):
        self.manager_id          = manager_id
        self._twin               = twin
        self._max_duration_ms    = max_lease_duration_ms
        self._leases:     Dict[str, TemporalLease] = {}
        self._audit:      List[dict] = []
        self._pending_requests: Dict[str, List[TemporalLease]] = {}   # zone → [pending]
        self._revoked_zones: Set[str] = set()

        # Signing key for tokens
        if _CRYPTO:
            self._priv_key = Ed25519PrivateKey.generate()
        else:
            self._priv_key = None

        log.info(f"  🔐  LeaseManager [{manager_id}] started")

    # ── Core lease operations ──────────────────────────────────────────────

    async def request_lease(
        self,
        robot_id:    str,
        zone_id:     str,
        duration_ms: float = 10_000.0,
        bid_energy_j: float = 100.0,
        max_tool_calls: Optional[int] = None,
        caller_did:  str = "",
    ) -> TemporalLease:
        """
        Request a temporal lease.
        If no conflict: immediately grant.
        If conflict:    hold in pending queue, run Vickrey auction.
        If zone revoked: deny immediately.
        """
        self._cleanup_expired()

        lease = TemporalLease(
            robot_id       = robot_id,
            zone_id        = zone_id,
            start_ms       = time.time() * 1000,
            duration_ms    = min(duration_ms, self._max_duration_ms),
            bid_energy_j   = bid_energy_j,
            max_tool_calls = max_tool_calls,
            caller_did     = caller_did,
        )

        # Zone revoked (emergency halt active)
        if zone_id in self._revoked_zones:
            lease.state = LeaseState.DENIED
            self._audit_event("denied", lease, "Zone revoked — emergency halt")
            log.warning(f"  🚨  [{robot_id}] Lease DENIED — zone {zone_id} is revoked")
            return lease

        # Check human presence in twin
        if self._twin:
            if self._twin._humans_present.get(zone_id, False):
                lease.state = LeaseState.DENIED
                self._audit_event("denied", lease, "Human present in zone")
                log.warning(f"  👤  [{robot_id}] Lease DENIED — human in zone {zone_id}")
                return lease

        # Check conflicts with active leases
        conflicts = self._find_conflicts(lease)

        if not conflicts:
            self._grant(lease)
        else:
            # Run auction — current holder vs requester
            winner = self._run_auction(lease, conflicts)
            if winner.lease_id == lease.lease_id:
                # Preempt existing lease
                for c in conflicts:
                    self._preempt(c, winner)
                self._grant(lease)
            else:
                lease.state = LeaseState.DENIED
                self._audit_event("denied", lease,
                                  f"Lost auction to {conflicts[0].robot_id}")
                log.info(f"  💰  [{robot_id}] Lost auction for zone {zone_id} "
                         f"(bid={bid_energy_j:.0f}J vs {conflicts[0].bid_energy_j:.0f}J)")

        self._leases[lease.lease_id] = lease
        return lease

    def release_lease(self, lease_id: str) -> bool:
        """Voluntarily release a lease."""
        lease = self._leases.get(lease_id)
        if not lease:
            return False
        if lease.state == LeaseState.ACTIVE:
            lease.state       = LeaseState.RELEASED
            lease.released_at = time.time()
            self._audit_event("released", lease, "Voluntarily released")
            log.info(f"  🔓  [{lease.robot_id}] Released lease {lease_id} "
                     f"({lease.tool_calls_made} calls made)")
            return True
        return False

    def renew_lease(self, lease_id: str, extension_ms: float) -> Tuple[bool, str]:
        """Extend an active lease duration."""
        lease = self._leases.get(lease_id)
        if not lease:
            return False, "Lease not found"
        if not lease.is_active():
            return False, f"Cannot renew lease in state {lease.state}"
        if lease.duration_ms + extension_ms > self._max_duration_ms:
            return False, f"Extension would exceed max duration ({self._max_duration_ms}ms)"

        # Check no new conflicts would be created
        old_dur = lease.duration_ms
        lease.duration_ms += extension_ms
        new_conflicts = self._find_conflicts(lease, exclude_id=lease_id)
        if new_conflicts:
            lease.duration_ms = old_dur
            return False, f"Renewal conflicts with {new_conflicts[0].robot_id}"

        log.info(f"  🔄  [{lease.robot_id}] Lease renewed +{extension_ms:.0f}ms "
                 f"(remaining={lease.remaining_ms:.0f}ms)")
        self._audit_event("renewed", lease, f"Extended by {extension_ms:.0f}ms")
        return True, ""

    def revoke_zone(self, zone_id: str, reason: str = "emergency halt"):
        """
        Immediately revoke ALL leases in a zone.
        Used for emergency halt or human incursion.
        """
        self._revoked_zones.add(zone_id)
        revoked = []
        for lease in self._leases.values():
            if lease.zone_id == zone_id and lease.state == LeaseState.ACTIVE:
                lease.state = LeaseState.REVOKED
                self._audit_event("revoked", lease, reason)
                revoked.append(lease.robot_id)

        log.critical(f"  🚨  Zone [{zone_id}] REVOKED — robots halted: {revoked}")
        return revoked

    def restore_zone(self, zone_id: str):
        """Re-open a zone for leasing (after emergency cleared)."""
        self._revoked_zones.discard(zone_id)
        log.info(f"  ✅  Zone [{zone_id}] restored — leasing re-enabled")

    # ── Lease-aware tool call gate ─────────────────────────────────────────

    def check_tool_call(self, robot_id: str, zone_id: str) -> Tuple[bool, str]:
        """
        Called before each tool execution.
        Returns (allowed, reason). If robot holds active lease, skip auction.
        """
        active = self._get_active_lease(robot_id, zone_id)
        if active:
            ok, reason = active.can_execute()
            if ok:
                active.record_tool_call()
            return ok, reason

        # No active lease — check if zone is free for opportunistic execution
        if zone_id in self._revoked_zones:
            return False, f"Zone {zone_id} revoked"

        if self._twin and self._twin._humans_present.get(zone_id, False):
            return False, f"Human present in zone {zone_id}"

        conflicts = [l for l in self._leases.values()
                     if l.zone_id == zone_id and l.robot_id != robot_id
                     and l.is_active()]
        if conflicts:
            return False, f"Zone held by {conflicts[0].robot_id} (lease {conflicts[0].lease_id})"

        return True, "No lease required (zone free)"

    # ── Internal helpers ───────────────────────────────────────────────────

    def _grant(self, lease: TemporalLease):
        lease.state      = LeaseState.ACTIVE
        lease.granted_at = time.time()
        lease.token      = self._sign_token(lease)
        self._audit_event("granted", lease, "")
        log.info(f"  🔐  [{lease.robot_id}] Lease GRANTED zone={lease.zone_id} "
                 f"dur={lease.duration_ms:.0f}ms bid={lease.bid_energy_j:.0f}J")

    def _preempt(self, existing: TemporalLease, winner: "TemporalLease"):
        existing.state = LeaseState.REVOKED
        self._audit_event("preempted", existing,
                          f"Outbid by {winner.robot_id} ({winner.bid_energy_j:.0f}J)")
        log.info(f"  💰  [{existing.robot_id}] Lease PREEMPTED by {winner.robot_id}")

    def _run_auction(self, challenger: TemporalLease,
                     holders: List[TemporalLease]) -> TemporalLease:
        """Vickrey-style: highest bid wins. Equal bids: existing holder wins."""
        all_bids = [(l.bid_energy_j, l) for l in holders] + [(challenger.bid_energy_j, challenger)]
        all_bids.sort(key=lambda x: (-x[0], x[1].created_at))
        return all_bids[0][1]

    def _find_conflicts(self, lease: TemporalLease,
                        exclude_id: str = "") -> List[TemporalLease]:
        return [l for l in self._leases.values()
                if l.is_active() and l.lease_id != exclude_id
                and lease.overlaps(l)]

    def _get_active_lease(self, robot_id: str, zone_id: str) -> Optional[TemporalLease]:
        for lease in self._leases.values():
            if (lease.robot_id == robot_id and lease.zone_id == zone_id
                    and lease.is_active()):
                return lease
        return None

    def _sign_token(self, lease: TemporalLease) -> str:
        payload = json.dumps({
            "lease_id": lease.lease_id,
            "robot_id": lease.robot_id,
            "zone_id":  lease.zone_id,
            "end_ms":   lease.end_ms,
        }, sort_keys=True).encode()

        if _CRYPTO and self._priv_key:
            sig = self._priv_key.sign(payload)
            return sig.hex()[:32]
        else:
            return hashlib.sha256(payload).hexdigest()[:32]

    def _cleanup_expired(self):
        for lease in list(self._leases.values()):
            if lease.state == LeaseState.ACTIVE and lease.is_expired():
                lease.state = LeaseState.EXPIRED
                self._audit_event("expired", lease, "")
                log.debug(f"  ⏰  Lease {lease.lease_id} [{lease.robot_id}] expired")

    def _audit_event(self, action: str, lease: TemporalLease, reason: str):
        self._audit.append({
            "action":    action,
            "lease_id":  lease.lease_id,
            "robot_id":  lease.robot_id,
            "zone_id":   lease.zone_id,
            "reason":    reason,
            "ts":        time.time(),
        })

    # ── Introspection ──────────────────────────────────────────────────────

    def active_leases(self) -> List[dict]:
        self._cleanup_expired()
        return [l.to_dict() for l in self._leases.values() if l.is_active()]

    def all_leases(self) -> List[dict]:
        return [l.to_dict() for l in self._leases.values()]

    def audit_log(self) -> List[dict]:
        return list(self._audit)

    def stats(self) -> dict:
        self._cleanup_expired()
        all_l = list(self._leases.values())
        return {
            "total_leases":    len(all_l),
            "active":          sum(1 for l in all_l if l.is_active()),
            "granted":         sum(1 for l in all_l if l.state in (LeaseState.ACTIVE, LeaseState.RELEASED)),
            "denied":          sum(1 for l in all_l if l.state == LeaseState.DENIED),
            "revoked":         sum(1 for l in all_l if l.state == LeaseState.REVOKED),
            "revoked_zones":   list(self._revoked_zones),
            "audit_events":    len(self._audit),
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        mgr = LeaseManager("demo-mgr")

        print("\n" + "═"*60)
        print("  P-MCP Temporal Lease System — Demo")
        print("═"*60)

        # Robot arm-01 requests a lease
        print("\n  1. arm-01 requests lease on grow_zone_a (bid=100J, 15s)")
        l1 = await mgr.request_lease("arm-01", "grow_zone_a",
                                      duration_ms=15_000, bid_energy_j=100.0)
        print(f"     → {l1.state.value.upper()} | token={l1.token[:12]}...")

        # arm-01 can now execute multiple tool calls without re-auctioning
        print("\n  2. arm-01 executes 3 tool calls under the lease")
        for i in range(3):
            ok, reason = mgr.check_tool_call("arm-01", "grow_zone_a")
            print(f"     Call {i+1}: {'✅ ALLOWED' if ok else '❌ BLOCKED'} — {reason}")

        # arm-02 tries to grab the same zone with lower bid
        print("\n  3. arm-02 tries lower bid (50J) — should lose auction")
        l2 = await mgr.request_lease("arm-02", "grow_zone_a",
                                      duration_ms=5_000, bid_energy_j=50.0)
        print(f"     → {l2.state.value.upper()}")

        # arm-02 tries higher bid (200J) — should WIN, preempt arm-01
        print("\n  4. arm-02 tries higher bid (200J) — should win")
        l3 = await mgr.request_lease("arm-02", "grow_zone_a",
                                      duration_ms=5_000, bid_energy_j=200.0)
        print(f"     → {l3.state.value.upper()}")

        # Emergency halt
        print("\n  5. Emergency halt — zone revoked")
        revoked = mgr.revoke_zone("grow_zone_a", "Human incursion detected")
        print(f"     Robots halted: {revoked}")

        ok, reason = mgr.check_tool_call("arm-02", "grow_zone_a")
        print(f"     arm-02 tool call: {'✅' if ok else '❌'} {reason}")

        print(f"\n  Stats: {mgr.stats()}")

    asyncio.run(_demo())
