"""
P-MCP v0.4 — Zenoh/DDS Transport Abstraction
===============================================
"Sub-Millisecond Robot Coordination — From JSON-RPC to Real-Time Mesh"

Architecture:
    PMCPServer (tool_call → confirm → execute)
        ↓  PMCPTransport interface
    ZenohTransport  ← production (eclipse-zenoh)
    StubTransport   ← testing/CI (in-process queue)
    MQTTTransport   ← IoT/edge deployments

Why Zenoh over JSON-RPC/HTTP?
------------------------------
- Zenoh: pub/sub + query + streaming in a single protocol
- Sub-millisecond latency on local network / 5G
- Works on lossy mesh (WiFi, LoRa, BLE) — critical for field robots
- Peer-to-peer: no central broker needed
- Built-in QoS, congestion control, fragmentation
- Compatible with ROS2 DDS via rmw_zenoh

Key Space Layout
----------------
  pmcp/{farm_id}/tool_call/{call_id}      → ToolCall JSON (pub by agent)
  pmcp/{farm_id}/shadow_result/{call_id}  → ProjectedOutcome (pub by server)
  pmcp/{farm_id}/confirm/{call_id}        → Confirmation token
  pmcp/{farm_id}/result/{call_id}         → ToolResult (pub after execution)
  pmcp/{farm_id}/robot/{robot_id}/pose    → Live pose stream (10 Hz)
  pmcp/{farm_id}/robot/{robot_id}/joints  → Joint states (50 Hz)
  pmcp/{farm_id}/ledger/{entry_id}        → CRDT ledger entries
  pmcp/{farm_id}/grid_signal              → Energy/carbon signal (1 Hz)

Zenoh install: pip install eclipse-zenoh
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.transport")

# ── Optional Zenoh ─────────────────────────────────────────────────────────
try:
    import zenoh as _zenoh
    _ZENOH = True
    log.info("  📡  eclipse-zenoh available — using real P2P transport")
except ImportError:
    _ZENOH = False
    log.info("  📡  eclipse-zenoh not installed — using stub transport")


# ─────────────────────────────────────────────────────────────
#  TRANSPORT INTERFACE
# ─────────────────────────────────────────────────────────────

MessageHandler = Callable[[str, dict], None]   # (key, payload) → None


class PMCPTransport(ABC):
    """
    Abstract transport interface for P-MCP messages.
    Implementations: ZenohTransport, StubTransport, MQTTTransport
    """

    @abstractmethod
    async def connect(self): ...

    @abstractmethod
    async def disconnect(self): ...

    @abstractmethod
    async def publish(self, key: str, payload: dict, priority: int = 5): ...

    @abstractmethod
    async def subscribe(self, key_pattern: str, handler: MessageHandler): ...

    @abstractmethod
    async def query(self, key: str, timeout_ms: int = 500) -> Optional[dict]: ...

    @abstractmethod
    def is_connected(self) -> bool: ...


# ─────────────────────────────────────────────────────────────
#  ZENOH TRANSPORT (production)
# ─────────────────────────────────────────────────────────────

class ZenohTransport(PMCPTransport):
    """
    Production transport using eclipse-zenoh.
    Supports peer-to-peer (no broker) and routed (via zenoh router) modes.

    Config:
        mode:     "peer" | "client" (peer = P2P, client = via router)
        locators: ["tcp/192.168.1.100:7447"] (router address if client mode)
        farm_id:  "greenhouse-01"
    """

    def __init__(self, farm_id: str = "pmcp-farm",
                 mode: str = "peer",
                 locators: Optional[List[str]] = None):
        if not _ZENOH:
            raise RuntimeError("eclipse-zenoh not installed: pip install eclipse-zenoh")
        self._farm_id  = farm_id
        self._mode     = mode
        self._locators = locators or []
        self._session  = None
        self._subs:    List[Any] = []

    async def connect(self):
        conf = _zenoh.Config()
        if self._mode == "client" and self._locators:
            conf.insert_json5("mode", f'"{self._mode}"')
            conf.insert_json5("connect/endpoints", json.dumps(self._locators))

        # Zenoh 0.11+ async API
        self._session = await _zenoh.open(conf)
        log.info(f"  📡  Zenoh connected (mode={self._mode} farm={self._farm_id})")

    async def disconnect(self):
        if self._session:
            await self._session.close()

    def is_connected(self) -> bool:
        return self._session is not None

    async def publish(self, key: str, payload: dict, priority: int = 5):
        if not self._session:
            raise RuntimeError("Not connected")
        full_key = f"pmcp/{self._farm_id}/{key}"
        data     = json.dumps(payload).encode()
        await self._session.put(full_key, data)

    async def subscribe(self, key_pattern: str, handler: MessageHandler):
        if not self._session:
            raise RuntimeError("Not connected")
        full_pattern = f"pmcp/{self._farm_id}/{key_pattern}"

        def _cb(sample):
            try:
                payload = json.loads(bytes(sample.payload))
                key_str = str(sample.key_expr)
                rel_key = key_str.replace(f"pmcp/{self._farm_id}/", "")
                handler(rel_key, payload)
            except Exception as e:
                log.debug(f"  📡  Zenoh sub error: {e}")

        sub = await self._session.declare_subscriber(full_pattern, _cb)
        self._subs.append(sub)

    async def query(self, key: str, timeout_ms: int = 500) -> Optional[dict]:
        if not self._session:
            return None
        full_key = f"pmcp/{self._farm_id}/{key}"
        replies  = await self._session.get(full_key, timeout=timeout_ms / 1000)
        async for reply in replies:
            if hasattr(reply, 'ok'):
                return json.loads(bytes(reply.ok.payload))
        return None


# ─────────────────────────────────────────────────────────────
#  STUB TRANSPORT (in-process, no network)
# ─────────────────────────────────────────────────────────────

class StubTransport(PMCPTransport):
    """
    In-process publish/subscribe transport for testing.
    Simulates Zenoh behaviour without any network dependency.
    Messages are delivered synchronously within the process.
    """

    # Class-level shared message bus (simulates P2P mesh within one process)
    _BUS: Dict[str, List[Tuple[str, MessageHandler]]] = {}
    _STORE: Dict[str, dict] = {}   # latest value store

    def __init__(self, farm_id: str = "test-farm", node_id: str = ""):
        self._farm_id  = farm_id
        self._node_id  = node_id or str(uuid.uuid4())[:8]
        self._connected = False
        self._latency_ms = 0.1   # Simulated latency

    async def connect(self):
        self._connected = True
        log.debug(f"  📡  StubTransport [{self._node_id}] connected")

    async def disconnect(self):
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    async def publish(self, key: str, payload: dict, priority: int = 5):
        full_key = f"{self._farm_id}/{key}"
        StubTransport._STORE[full_key] = payload

        # Deliver to all matching subscribers
        for pattern, handlers in StubTransport._BUS.items():
            if self._key_matches(pattern, full_key):
                for _, handler in handlers:
                    try:
                        if self._latency_ms > 0:
                            await asyncio.sleep(self._latency_ms / 1000)
                        handler(full_key, payload)
                    except Exception as e:
                        log.debug(f"  📡  Stub handler error: {e}")

    async def subscribe(self, key_pattern: str, handler: MessageHandler):
        full_pattern = f"{self._farm_id}/{key_pattern}"
        if full_pattern not in StubTransport._BUS:
            StubTransport._BUS[full_pattern] = []
        StubTransport._BUS[full_pattern].append((self._node_id, handler))

    async def query(self, key: str, timeout_ms: int = 500) -> Optional[dict]:
        full_key = f"{self._farm_id}/{key}"
        return StubTransport._STORE.get(full_key)

    @staticmethod
    def _key_matches(pattern: str, key: str) -> bool:
        """Simple wildcard matching: ** matches any segments."""
        if pattern == key:
            return True
        p_parts = pattern.split("/")
        k_parts = key.split("/")
        return StubTransport._match_parts(p_parts, k_parts)

    @staticmethod
    def _match_parts(p: List[str], k: List[str]) -> bool:
        if not p and not k:
            return True
        if p and p[0] == "**":
            return True   # ** matches everything remaining
        if not p or not k:
            return False
        if p[0] == "*" or p[0] == k[0]:
            return StubTransport._match_parts(p[1:], k[1:])
        return False

    @classmethod
    def reset(cls):
        cls._BUS.clear()
        cls._STORE.clear()


# ─────────────────────────────────────────────────────────────
#  MQTT TRANSPORT (IoT / edge)
# ─────────────────────────────────────────────────────────────

class MQTTTransport(PMCPTransport):
    """
    MQTT 5 transport for IoT/edge deployments.
    Uses asyncio-mqtt (pip install asyncio-mqtt).
    """

    def __init__(self, broker: str = "localhost", port: int = 1883,
                 farm_id: str = "pmcp-farm", username: str = "", password: str = ""):
        self._broker   = broker
        self._port     = port
        self._farm_id  = farm_id
        self._username = username
        self._password = password
        self._client   = None
        self._handlers: List[Tuple[str, MessageHandler]] = []

        try:
            import asyncio_mqtt as _mqtt
            self._mqtt_lib = _mqtt
        except ImportError:
            self._mqtt_lib = None

    async def connect(self):
        if not self._mqtt_lib:
            raise RuntimeError("asyncio-mqtt not installed: pip install asyncio-mqtt")
        kwargs: dict = {"hostname": self._broker, "port": self._port}
        if self._username:
            kwargs["username"] = self._username
            kwargs["password"] = self._password
        self._client = self._mqtt_lib.Client(**kwargs)
        await self._client.__aenter__()
        asyncio.create_task(self._message_loop())
        log.info(f"  📡  MQTT connected: {self._broker}:{self._port}")

    async def disconnect(self):
        if self._client:
            await self._client.__aexit__(None, None, None)

    def is_connected(self) -> bool:
        return self._client is not None

    async def publish(self, key: str, payload: dict, priority: int = 5):
        topic = f"pmcp/{self._farm_id}/{key}"
        await self._client.publish(topic, json.dumps(payload).encode(), qos=1)

    async def subscribe(self, key_pattern: str, handler: MessageHandler):
        topic = f"pmcp/{self._farm_id}/{key_pattern}".replace("**", "#").replace("*", "+")
        await self._client.subscribe(topic)
        self._handlers.append((topic, handler))

    async def query(self, key: str, timeout_ms: int = 500) -> Optional[dict]:
        # MQTT doesn't have native query — use retained messages
        topic = f"pmcp/{self._farm_id}/{key}"
        result: Optional[dict] = None
        event = asyncio.Event()

        async def _tmp_handler(k: str, p: dict):
            nonlocal result
            result = p
            event.set()

        self._handlers.append((topic, _tmp_handler))
        try:
            await asyncio.wait_for(event.wait(), timeout=timeout_ms / 1000)
        except asyncio.TimeoutError:
            pass
        return result

    async def _message_loop(self):
        async with self._client.messages() as msgs:
            async for msg in msgs:
                try:
                    payload = json.loads(msg.payload)
                    topic   = str(msg.topic)
                    for pattern, handler in self._handlers:
                        if topic.startswith(pattern.rstrip("#")):
                            handler(topic, payload)
                except Exception as e:
                    log.debug(f"  📡  MQTT message error: {e}")


# ─────────────────────────────────────────────────────────────
#  TRANSPORT FACTORY
# ─────────────────────────────────────────────────────────────

def create_transport(
    transport_type: str = "auto",
    farm_id:        str = "pmcp-farm",
    **kwargs,
) -> PMCPTransport:
    """
    Factory method to create the best available transport.

    transport_type:
        "auto"  — Zenoh if available, else Stub
        "zenoh" — force Zenoh (raises if not installed)
        "stub"  — always use in-process stub
        "mqtt"  — MQTT broker
    """
    if transport_type == "zenoh" or (transport_type == "auto" and _ZENOH):
        return ZenohTransport(farm_id=farm_id, **kwargs)
    elif transport_type == "mqtt":
        return MQTTTransport(farm_id=farm_id, **kwargs)
    else:
        log.info(f"  📡  Transport: StubTransport (type={transport_type})")
        return StubTransport(farm_id=farm_id, **kwargs)


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        t1 = create_transport("stub", farm_id="demo-farm", node_id="server")
        t2 = create_transport("stub", farm_id="demo-farm", node_id="robot")

        await t1.connect()
        await t2.connect()

        received = []

        async def _handler(key: str, payload: dict):
            received.append((key, payload))
            print(f"  📩  [{key}]: {payload}")

        # Robot subscribes to tool calls
        await t2.subscribe("tool_call/**", lambda k, p: asyncio.ensure_future(_handler(k, p)))

        # Server publishes a tool call
        call = {"call_id": "abc123", "tool_name": "move_to",
                "robot_id": "arm-01", "x": 1.0, "y": 0.5, "z": 0.8}
        await t1.publish("tool_call/abc123", call)
        await asyncio.sleep(0.1)

        # Query latest pose
        await t2.publish("robot/arm-01/pose", {"x": 0.5, "y": 0.5, "z": 1.0})
        pose = await t1.query("robot/arm-01/pose")
        print(f"\n  📍  Queried pose: {pose}")
        print(f"\n  ✅  Messages received: {len(received)}")

    asyncio.run(_demo())
