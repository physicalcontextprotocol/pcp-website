"""
P-MCP v0.4 — Arduino Serial Bridge Driver
==========================================
"From Microcontroller to P-MCP in 100 Lines"

Hardware:  Arduino Uno / Mega / Nano / ESP32
Protocol:  Serial JSON over USB (9600–115200 baud)
Requires:  pyserial (pip install pyserial)

Arduino Firmware Protocol
--------------------------
Host sends newline-terminated JSON commands:
    {"cmd": "set_pin",  "pin": 13,  "val": 1}
    {"cmd": "set_pwm",  "pin": 9,   "val": 128}
    {"cmd": "set_servo","pin": 5,   "val": 90}
    {"cmd": "read_analog","pin": 0}
    {"cmd": "read_digital","pin": 2}
    {"cmd": "ping"}

Arduino replies with JSON:
    {"ok": true, "pin": 13}
    {"ok": true, "pin": 0, "val": 512}
    {"ok": false, "err": "pin not supported"}
    {"pong": true, "uptime_ms": 12345}

Companion Arduino sketch: see docs/arduino_pmcp_bridge.ino

Stub Mode: No Arduino → StubArduino simulates analog sensors
            (temperature, light, potentiometer) with realistic noise.

P-MCP Tools:
    set_servo    → Set servo angle (0–180°)
    set_pin      → Set digital output pin
    set_pwm      → Set PWM duty cycle (0–255)
    read_analog  → Read ADC value (0–1023)
    read_digital → Read digital pin state

P-MCP Resources:
    analog_in   → All analog readings (A0–A5)
    digital_in  → All digital input states
    temperature → NTC thermistor on A0 (Steinhart-Hart)
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import random
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.driver.arduino")

# ── Optional pyserial ──────────────────────────────────────────────────────
try:
    import serial
    import serial.tools.list_ports
    _SERIAL = True
    log.info("  🔌  pyserial available — real Arduino control")
except ImportError:
    _SERIAL = False
    log.info("  🔌  pyserial not installed — Arduino stub mode")


# ─────────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────────

@dataclass
class ArduinoConfig:
    port:          str   = "auto"        # "auto" → scan for Arduino
    baud:          int   = 115200
    robot_id:      str   = "arduino-01"
    timeout_s:     float = 2.0
    analog_pins:   List[int] = field(default_factory=lambda: [0,1,2,3,4,5])
    digital_pins:  List[int] = field(default_factory=lambda: [2,3,4,5,6,7])
    servo_pins:    List[int] = field(default_factory=lambda: [9,10,11])
    pwm_pins:      List[int] = field(default_factory=lambda: [3,5,6,9,10,11])

    @staticmethod
    def auto_detect_port() -> Optional[str]:
        if not _SERIAL:
            return None
        for p in serial.tools.list_ports.comports():
            desc = (p.description or "").lower()
            if any(k in desc for k in ["arduino","ch340","cp210","ftdi","usb serial"]):
                return p.device
        return None


# ─────────────────────────────────────────────────────────────
#  STUB ARDUINO
# ─────────────────────────────────────────────────────────────

class _StubArduino:
    """Simulated Arduino with realistic sensor models."""

    def __init__(self):
        self._pins: Dict[int, int] = {}      # pin → value
        self._servos: Dict[int, int] = {}
        self._analog: Dict[int, float] = {}
        self._start  = time.time()

    def _analog_sim(self, pin: int) -> int:
        """Simulate analog sensors with time-varying noise."""
        t = time.time() - self._start
        if pin == 0:
            # NTC thermistor — temperature 20–25°C, slow drift
            raw_temp = 22.0 + 2 * math.sin(t / 60) + random.gauss(0, 0.3)
            return self._temp_to_adc(raw_temp)
        elif pin == 1:
            # LDR — light level follows time-of-day simulation
            light = 512 + 400 * math.sin(t / 30) + random.gauss(0, 20)
            return max(0, min(1023, int(light)))
        elif pin == 2:
            # Potentiometer — slow random walk
            val  = self._analog.get(2, 512)
            val += random.gauss(0, 5)
            val  = max(0, min(1023, val))
            self._analog[2] = val
            return int(val)
        else:
            return random.randint(400, 620)   # Generic sensor noise

    @staticmethod
    def _temp_to_adc(temp_c: float) -> int:
        """Convert °C to ADC value via simplified Steinhart-Hart."""
        R0, B, R_series = 10000, 3950, 10000
        T_K = temp_c + 273.15
        T0  = 298.15
        Rntc = R0 * math.exp(B * (1/T_K - 1/T0))
        adc  = int(1023 * Rntc / (Rntc + R_series))
        return max(0, min(1023, adc))

    def send_command(self, cmd: dict) -> dict:
        action = cmd.get("cmd", "")
        pin    = cmd.get("pin", 0)

        if action == "ping":
            return {"pong": True, "uptime_ms": int((time.time()-self._start)*1000)}
        elif action == "set_pin":
            self._pins[pin] = int(bool(cmd.get("val", 0)))
            return {"ok": True, "pin": pin}
        elif action == "set_pwm":
            val = max(0, min(255, int(cmd.get("val", 0))))
            self._pins[pin] = val
            return {"ok": True, "pin": pin, "val": val}
        elif action == "set_servo":
            angle = max(0, min(180, int(cmd.get("val", 90))))
            self._servos[pin] = angle
            return {"ok": True, "pin": pin, "angle": angle}
        elif action == "read_analog":
            return {"ok": True, "pin": pin, "val": self._analog_sim(pin)}
        elif action == "read_digital":
            return {"ok": True, "pin": pin, "val": self._pins.get(pin, 0)}
        else:
            return {"ok": False, "err": f"Unknown command: {action}"}


# ─────────────────────────────────────────────────────────────
#  ARDUINO DRIVER
# ─────────────────────────────────────────────────────────────

class ArduinoDriver:
    """P-MCP hardware driver for Arduino via serial JSON protocol."""

    def __init__(self, config: Optional[ArduinoConfig] = None):
        self._cfg    = config or ArduinoConfig()
        self._serial = None
        self._stub   = None
        self._connected = False
        self._lock   = asyncio.Lock()

    async def connect(self) -> bool:
        if _SERIAL:
            port = self._cfg.port
            if port == "auto":
                port = ArduinoConfig.auto_detect_port()

            if port:
                try:
                    self._serial = serial.Serial(
                        port, self._cfg.baud, timeout=self._cfg.timeout_s
                    )
                    await asyncio.sleep(2.0)   # Arduino reset delay
                    resp = await self._send({"cmd": "ping"})
                    if resp.get("pong"):
                        self._connected = True
                        log.info(f"  🔌  Arduino connected: {port} "
                                 f"uptime={resp.get('uptime_ms',0)}ms")
                        return True
                except Exception as e:
                    log.warning(f"  🔌  Arduino connect failed on {port}: {e}")

        self._stub = _StubArduino()
        self._connected = True
        log.info(f"  🔌  Arduino stub mode (robot_id={self._cfg.robot_id})")
        return True

    async def disconnect(self):
        self._connected = False
        if self._serial:
            self._serial.close()

    # ── Command transport ──────────────────────────────────────────────────

    async def _send(self, cmd: dict) -> dict:
        if self._stub:
            return self._stub.send_command(cmd)
        async with self._lock:
            raw = json.dumps(cmd) + "\n"
            self._serial.write(raw.encode())
            deadline = time.time() + self._cfg.timeout_s
            buf      = b""
            while time.time() < deadline:
                await asyncio.sleep(0.01)
                if self._serial.in_waiting:
                    buf += self._serial.read(self._serial.in_waiting)
                    if b"\n" in buf:
                        line = buf.split(b"\n")[0]
                        try:
                            return json.loads(line)
                        except json.JSONDecodeError:
                            return {"ok": False, "err": "bad JSON"}
            return {"ok": False, "err": "timeout"}

    # ── P-MCP Tools ────────────────────────────────────────────────────────

    async def set_servo(self, pin: int, angle: float) -> dict:
        if pin not in self._cfg.servo_pins:
            return {"success": False, "error": f"Pin {pin} not in servo_pins config"}
        angle = max(0, min(180, int(angle)))
        resp  = await self._send({"cmd": "set_servo", "pin": pin, "val": angle})
        return {"success": resp.get("ok", False), "pin": pin, "angle": angle}

    async def set_pin(self, pin: int, value: bool) -> dict:
        if pin not in self._cfg.digital_pins:
            return {"success": False, "error": f"Pin {pin} not in digital_pins config"}
        resp = await self._send({"cmd": "set_pin", "pin": pin, "val": int(value)})
        return {"success": resp.get("ok", False), "pin": pin, "value": value}

    async def set_pwm(self, pin: int, duty: int) -> dict:
        if pin not in self._cfg.pwm_pins:
            return {"success": False, "error": f"Pin {pin} not in pwm_pins config"}
        duty = max(0, min(255, int(duty)))
        resp = await self._send({"cmd": "set_pwm", "pin": pin, "val": duty})
        return {"success": resp.get("ok", False), "pin": pin, "duty": duty}

    async def read_analog(self, pin: int) -> dict:
        if pin not in self._cfg.analog_pins:
            return {"success": False, "error": f"Pin A{pin} not in analog_pins config"}
        resp = await self._send({"cmd": "read_analog", "pin": pin})
        raw  = resp.get("val", 0)
        voltage = raw * 5.0 / 1023.0
        return {"success": resp.get("ok", True), "pin": pin, "raw": raw,
                "voltage": round(voltage, 3)}

    async def read_digital(self, pin: int) -> dict:
        resp = await self._send({"cmd": "read_digital", "pin": pin})
        return {"success": resp.get("ok", True), "pin": pin,
                "value": bool(resp.get("val", 0))}

    # ── P-MCP Resources ────────────────────────────────────────────────────

    async def get_analog_in(self) -> dict:
        readings = {}
        for pin in self._cfg.analog_pins:
            r = await self.read_analog(pin)
            readings[f"A{pin}"] = {"raw": r["raw"], "voltage": r.get("voltage")}
        return {"analog": readings, "robot_id": self._cfg.robot_id}

    async def get_digital_in(self) -> dict:
        readings = {}
        for pin in self._cfg.digital_pins:
            r = await self.read_digital(pin)
            readings[f"D{pin}"] = r["value"]
        return {"digital": readings, "robot_id": self._cfg.robot_id}

    async def get_temperature(self) -> dict:
        """Read NTC thermistor on A0 and convert to °C."""
        r = await self.read_analog(0)
        raw = r["raw"]
        # Steinhart-Hart inverse: compute R_ntc from ADC
        R_series = 10000
        if raw == 0:
            return {"temperature_c": None, "error": "ADC=0"}
        R_ntc  = R_series * raw / (1023 - raw)
        R0, B  = 10000, 3950
        T0     = 298.15
        try:
            T_K = 1.0 / (math.log(R_ntc / R0) / B + 1.0 / T0)
            T_C = round(T_K - 273.15, 2)
        except (ValueError, ZeroDivisionError):
            T_C = None
        return {"temperature_c": T_C, "raw_adc": raw, "robot_id": self._cfg.robot_id}

    def pmcp_tools(self) -> List[dict]:
        return [
            {"name": "set_servo",    "description": "Set servo angle (0–180°)", "args": ["pin","angle"]},
            {"name": "set_pin",      "description": "Set digital output",       "args": ["pin","value"]},
            {"name": "set_pwm",      "description": "Set PWM duty cycle 0–255","args": ["pin","duty"]},
            {"name": "read_analog",  "description": "Read ADC value 0–1023",   "args": ["pin"]},
            {"name": "read_digital", "description": "Read digital input",       "args": ["pin"]},
        ]

    def pmcp_resources(self) -> List[dict]:
        return [
            {"name": "analog_in",   "description": "All analog pin readings",   "hz": 10},
            {"name": "digital_in",  "description": "All digital pin states",    "hz": 10},
            {"name": "temperature", "description": "NTC thermistor °C (A0)",   "hz": 1},
        ]


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        driver = ArduinoDriver(ArduinoConfig(robot_id="ard-demo"))
        await driver.connect()

        print("\n  ── Arduino Driver Demo ──")

        r1 = await driver.set_servo(9, 90)
        print(f"  Servo 9 → 90°: {r1}")

        r2 = await driver.set_pin(13, True)
        print(f"  LED ON:        {r2}")

        r3 = await driver.set_pwm(3, 128)
        print(f"  PWM 3 50%:     {r3}")

        r4 = await driver.read_analog(0)
        print(f"  A0 (NTC):      {r4}")

        r5 = await driver.get_temperature()
        print(f"  Temperature:   {r5}")

        r6 = await driver.get_analog_in()
        print(f"  All Analog:    { {k: v['raw'] for k,v in r6['analog'].items()} }")

        await driver.disconnect()

    asyncio.run(_demo())
