"""
P-MCP v0.4 — TurtleBot3 Driver (ROS2 / Nav2)
=============================================
"Mobile Robot Navigation with P-MCP Safety"

Hardware:  TurtleBot3 (Burger / Waffle / Waffle Pi)
Protocol:  ROS2 rclpy + nav2_simple_commander
Requires:  ROS2 Humble/Iron + rclpy + nav2_simple_commander

Stub Mode: No ROS2 → StubTurtleBot simulates navigation with
            dead-reckoning odometry and battery drain model.

Safety:
- Minimum obstacle distance: 0.2 m (from /scan)
- Max speed: 0.5 m/s (Burger limit)
- Battery warning at 15%

P-MCP Tools:
    navigate_to  → Send Nav2 goal (x, y, yaw)
    stop         → Cancel navigation + zero velocity
    rotate       → Rotate in place by angle (rad)
    follow_path  → Follow a list of waypoints

P-MCP Resources:
    pose         → Odometry pose (10 Hz)
    battery      → Battery state (1 Hz)
    scan         → Nearest obstacle distance (5 Hz)
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.driver.turtlebot")

# ── Optional ROS2 ──────────────────────────────────────────────────────────
try:
    import rclpy
    from rclpy.node import Node
    from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
    from geometry_msgs.msg import PoseStamped
    _ROS2 = True
    log.info("  🐢  rclpy + nav2 available — real TurtleBot3 control")
except ImportError:
    _ROS2 = False
    log.info("  🐢  rclpy not installed — TurtleBot3 stub mode")


# ─────────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────────

@dataclass
class TurtleBotConfig:
    robot_id:       str   = "turtle-01"
    namespace:      str   = ""
    max_speed_ms:   float = 0.22     # Burger max: 0.22 m/s
    max_turn_rad:   float = 2.84     # Burger max angular
    min_obstacle_m: float = 0.2      # Safety halt distance
    battery_warn:   float = 0.15     # 15%


# ─────────────────────────────────────────────────────────────
#  STUB TURTLEBOT (no ROS2)
# ─────────────────────────────────────────────────────────────

class _StubTurtleBot:
    """Simulated TurtleBot3 with dead-reckoning and battery model."""

    def __init__(self):
        self.x     = 0.0
        self.y     = 0.0
        self.yaw   = 0.0
        self.battery = 1.0          # 0–1
        self.scan_min = 2.0         # Nearest obstacle (m)
        self._nav_task: Optional[asyncio.Task] = None

    async def navigate_to(self, x: float, y: float, yaw: float = 0.0,
                           speed: float = 0.15) -> dict:
        dist  = math.sqrt((x - self.x)**2 + (y - self.y)**2)
        angle = math.atan2(y - self.y, x - self.x) - self.yaw
        travel_s = dist / max(speed, 0.01)

        # Drain battery
        self.battery -= dist * 0.002
        self.battery  = max(0.0, self.battery)

        await asyncio.sleep(min(travel_s, 10.0))

        self.x   = x
        self.y   = y
        self.yaw = yaw
        return {"success": True, "x": self.x, "y": self.y, "yaw": self.yaw}

    async def rotate(self, angle_rad: float, speed: float = 0.5) -> dict:
        duration = abs(angle_rad) / max(speed, 0.01)
        await asyncio.sleep(min(duration, 5.0))
        self.yaw += angle_rad
        return {"success": True, "yaw": self.yaw}

    def stop(self):
        if self._nav_task:
            self._nav_task.cancel()

    def get_pose(self) -> dict:
        return {"x": self.x, "y": self.y, "yaw": round(self.yaw, 4)}

    def get_battery(self) -> dict:
        return {"percentage": round(self.battery * 100, 1),
                "charging": False}

    def get_scan_min(self) -> float:
        import random
        return self.scan_min + random.gauss(0, 0.05)


# ─────────────────────────────────────────────────────────────
#  TURTLEBOT DRIVER
# ─────────────────────────────────────────────────────────────

class TurtleBotDriver:
    """P-MCP driver for TurtleBot3 via ROS2 Nav2."""

    def __init__(self, config: Optional[TurtleBotConfig] = None):
        self._cfg  = config or TurtleBotConfig()
        self._stub = None
        self._nav  = None
        self._connected = False

    async def connect(self) -> bool:
        if _ROS2:
            try:
                rclpy.init(args=None)
                self._nav = BasicNavigator(namespace=self._cfg.namespace)
                self._nav.waitUntilNav2Active()
                self._connected = True
                log.info(f"  🐢  TurtleBot3 Nav2 connected (ns={self._cfg.namespace})")
                return True
            except Exception as e:
                log.warning(f"  🐢  Nav2 connect failed: {e} — using stub")

        self._stub = _StubTurtleBot()
        self._connected = True
        log.info(f"  🐢  TurtleBot3 stub mode (robot_id={self._cfg.robot_id})")
        return True

    async def disconnect(self):
        self._connected = False
        if _ROS2 and self._nav:
            rclpy.shutdown()

    # ── Safety checks ──────────────────────────────────────────────────────

    def _check_safety(self) -> Tuple[bool, str]:
        if self._stub:
            scan_min = self._stub.get_scan_min()
            battery  = self._stub.battery
        else:
            scan_min = self._cfg.min_obstacle_m + 0.5  # No real scan in this path
            battery  = 1.0

        if scan_min < self._cfg.min_obstacle_m:
            return False, f"Obstacle too close: {scan_min:.2f}m < {self._cfg.min_obstacle_m}m"
        if battery < 0.05:
            return False, f"Battery critical: {battery*100:.0f}%"
        return True, ""

    # ── P-MCP Tools ────────────────────────────────────────────────────────

    async def navigate_to(self, x: float, y: float, yaw: float = 0.0) -> dict:
        ok, reason = self._check_safety()
        if not ok:
            return {"success": False, "error": reason}

        log.info(f"  🐢  [{self._cfg.robot_id}] Navigate → ({x:.2f},{y:.2f},{yaw:.2f}rad)")

        if self._stub:
            return await self._stub.navigate_to(x, y, yaw, self._cfg.max_speed_ms)

        # ROS2 Nav2 path
        goal = PoseStamped()
        goal.header.frame_id = "map"
        goal.header.stamp    = self._nav.get_clock().now().to_msg()
        goal.pose.position.x = x
        goal.pose.position.y = y
        # Convert yaw → quaternion
        import math as _math
        goal.pose.orientation.z = _math.sin(yaw / 2)
        goal.pose.orientation.w = _math.cos(yaw / 2)
        self._nav.goToPose(goal)

        while not self._nav.isTaskComplete():
            await asyncio.sleep(0.1)

        result = self._nav.getResult()
        ok     = result == TaskResult.SUCCEEDED
        return {"success": ok, "x": x, "y": y, "yaw": yaw,
                "result": str(result)}

    async def stop(self) -> dict:
        log.info(f"  🐢  [{self._cfg.robot_id}] STOP")
        if self._stub:
            self._stub.stop()
        else:
            self._nav.cancelTask()
        return {"success": True}

    async def rotate(self, angle_rad: float, speed: float = 0.5) -> dict:
        log.info(f"  🐢  [{self._cfg.robot_id}] Rotate {math.degrees(angle_rad):.1f}°")
        if self._stub:
            return await self._stub.rotate(angle_rad, speed)
        # ROS2: use spin action
        self._nav.spin(spin_dist=angle_rad)
        while not self._nav.isTaskComplete():
            await asyncio.sleep(0.1)
        return {"success": True, "angle_rad": angle_rad}

    async def follow_path(self, waypoints: List[dict]) -> dict:
        """Navigate through a list of {x, y, yaw} waypoints."""
        ok_count = 0
        for wp in waypoints:
            result = await self.navigate_to(wp["x"], wp["y"], wp.get("yaw", 0.0))
            if not result["success"]:
                return {"success": False, "reached": ok_count,
                        "total": len(waypoints), "error": result.get("error")}
            ok_count += 1
        return {"success": True, "reached": ok_count, "total": len(waypoints)}

    # ── P-MCP Resources ────────────────────────────────────────────────────

    async def get_pose(self) -> dict:
        if self._stub:
            p = self._stub.get_pose()
            p["robot_id"] = self._cfg.robot_id
            return p
        pose = self._nav.getCurrentPose()
        return {
            "x": pose.pose.position.x,
            "y": pose.pose.position.y,
            "z": 0.0,
            "robot_id": self._cfg.robot_id,
        }

    async def get_battery(self) -> dict:
        if self._stub:
            b = self._stub.get_battery()
            b["robot_id"] = self._cfg.robot_id
            b["warning"]  = b["percentage"] < self._cfg.battery_warn * 100
            return b
        return {"percentage": 100.0, "robot_id": self._cfg.robot_id}

    async def get_scan(self) -> dict:
        if self._stub:
            return {"min_distance_m": self._stub.get_scan_min(),
                    "robot_id": self._cfg.robot_id}
        return {"min_distance_m": 2.0, "robot_id": self._cfg.robot_id}

    def pmcp_tools(self) -> List[dict]:
        return [
            {"name": "navigate_to",  "description": "Navigate to goal pose (x, y, yaw)", "args": ["x","y","yaw"]},
            {"name": "stop",         "description": "Cancel navigation and stop"},
            {"name": "rotate",       "description": "Rotate in place (angle_rad)", "args": ["angle_rad","speed"]},
            {"name": "follow_path",  "description": "Follow waypoints list"},
        ]

    def pmcp_resources(self) -> List[dict]:
        return [
            {"name": "pose",    "description": "Odometry pose (x, y, yaw)", "hz": 10},
            {"name": "battery", "description": "Battery percentage",        "hz": 1},
            {"name": "scan",    "description": "Min obstacle distance (m)", "hz": 5},
        ]


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        driver = TurtleBotDriver(TurtleBotConfig(robot_id="turtle-demo"))
        await driver.connect()

        print("\n  ── TurtleBot3 Driver Demo ──")
        pose = await driver.get_pose()
        print(f"  Pose:    {pose}")
        battery = await driver.get_battery()
        print(f"  Battery: {battery}")

        r1 = await driver.navigate_to(1.0, 0.5, 0.785)
        print(f"  Nav:     {r1}")

        r2 = await driver.rotate(math.pi / 2)
        print(f"  Rotate:  {r2}")

        path = [{"x": 0.0, "y": 0.0, "yaw": 0.0},
                {"x": 0.5, "y": 0.5, "yaw": 0.0}]
        r3 = await driver.follow_path(path)
        print(f"  Path:    {r3}")

        await driver.disconnect()

    asyncio.run(_demo())
