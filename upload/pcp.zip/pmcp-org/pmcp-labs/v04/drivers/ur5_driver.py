"""
P-MCP v0.4 — Universal Robots UR5 Driver
=========================================
"Industrial 6-DOF Arm with P-MCP Native Safety Envelope"

Hardware:  Universal Robots UR5 / UR5e / UR10e
Protocol:  RTDE (Real-Time Data Exchange) over TCP/IP
Requires:  ur-rtde  (pip install ur-rtde)

Stub Mode: No hardware → StubUR5 simulates realistic joint motion,
            FK/IK approximation, and force sensing.

Safety Envelope enforced:
- Joint position limits (UR5 default)
- TCP speed ≤ 1.0 m/s  (override with max_tcp_speed)
- Payload ≤ 5.0 kg
- Z ≥ 0 (floor guard)

P-MCP Tools provided:
    move_to         → MoveL to Cartesian pose
    move_joints     → MoveJ to joint configuration
    open_gripper    → Digital output to gripper relay
    close_gripper   → Digital output to gripper relay
    home            → Return to safe home configuration
    set_freedrive   → Enable/disable hand-guided freedrive
    get_force_torque → Read TCP wrench

P-MCP Resources:
    pose            → Live TCP pose  (10 Hz)
    joints          → Joint states   (50 Hz)
    force_torque    → TCP force/torque (10 Hz)
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.driver.ur5")

# ── Optional RTDE ──────────────────────────────────────────────────────────
try:
    import rtde_control
    import rtde_receive
    _RTDE = True
    log.info("  🦾  ur-rtde available — real UR5 control enabled")
except ImportError:
    _RTDE = False
    log.info("  🦾  ur-rtde not installed — UR5 stub mode")


# ─────────────────────────────────────────────────────────────
#  UR5 CONFIG
# ─────────────────────────────────────────────────────────────

@dataclass
class UR5Config:
    host:             str   = "192.168.1.100"
    port:             int   = 30004
    robot_id:         str   = "ur5-01"
    max_tcp_speed:    float = 1.0          # m/s
    max_tcp_accel:    float = 1.2          # m/s²
    max_joint_speed:  float = 1.0          # rad/s
    max_payload_kg:   float = 5.0
    home_joints:      List[float] = field(default_factory=lambda:
        [-1.5708, -1.5708, 1.5708, -1.5708, -1.5708, 0.0])    # [rad]
    gripper_open_do:  int   = 0            # Digital output channel
    gripper_close_do: int   = 1
    floor_z:          float = 0.01         # Minimum TCP z (m) — floor guard


# ─────────────────────────────────────────────────────────────
#  STUB UR5 (no hardware)
# ─────────────────────────────────────────────────────────────

class _StubUR5:
    """Realistic UR5 simulation for testing without hardware."""

    JOINT_LIMITS = [
        (-2*math.pi, 2*math.pi),   # Base
        (-math.pi,   0),            # Shoulder
        (-math.pi,   math.pi),      # Elbow
        (-2*math.pi, 2*math.pi),   # Wrist 1
        (-2*math.pi, 2*math.pi),   # Wrist 2
        (-2*math.pi, 2*math.pi),   # Wrist 3
    ]

    def __init__(self):
        self.joints = [-1.5708, -1.5708, 1.5708, -1.5708, -1.5708, 0.0]
        self.tcp    = [0.5, 0.0, 0.5, 0.0, 3.1416, 0.0]   # x,y,z,rx,ry,rz
        self.speed  = 0.0
        self.force  = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    def moveL(self, pose, speed, accel):
        # Simulate motion delay
        dist = math.sqrt(sum((a-b)**2 for a,b in zip(pose[:3], self.tcp[:3])))
        time.sleep(min(dist / max(speed, 0.01), 5.0))
        self.tcp    = list(pose)
        self.speed  = 0.0
        return True

    def moveJ(self, joints, speed, accel):
        dist = math.sqrt(sum((a-b)**2 for a,b in zip(joints, self.joints)))
        time.sleep(min(dist / max(speed, 0.01) * 0.3, 5.0))
        self.joints = list(joints)
        # Approximate FK: very simplified
        self.tcp = self._fk_approx()
        return True

    def _fk_approx(self) -> List[float]:
        # Placeholder FK — L1=0.425m, L2=0.392m (UR5 link lengths)
        L1, L2 = 0.425, 0.392
        j = self.joints
        x = L1 * math.cos(j[0]) + L2 * math.cos(j[0] + j[1])
        y = L1 * math.sin(j[0]) + L2 * math.sin(j[0] + j[1])
        z = 0.089 + 0.135 * math.cos(j[1])   # Very approximate
        return [x, y, max(0.01, z), 0.0, 3.1416, 0.0]

    def setDigitalOut(self, ch, val): pass
    def getForceTorque(self): return list(self.force)
    def getActualQ(self): return list(self.joints)
    def getActualTCPPose(self): return list(self.tcp)
    def getActualTCPSpeed(self): return [self.speed]*6
    def isConnected(self): return True
    def disconnect(self): pass


# ─────────────────────────────────────────────────────────────
#  UR5 DRIVER
# ─────────────────────────────────────────────────────────────

class UR5Driver:
    """
    P-MCP hardware driver for Universal Robots UR5.
    Exposes tools and resources consumable by PMCPServer.
    """

    def __init__(self, config: Optional[UR5Config] = None):
        self._cfg  = config or UR5Config()
        self._ctrl  = None
        self._recv  = None
        self._stub  = None
        self._connected = False
        self._pose_stream: Optional[asyncio.Queue] = None
        self._joint_stream: Optional[asyncio.Queue] = None
        self._gripper_open = True
        self._last_pose:   List[float] = [0]*6
        self._last_joints: List[float] = list(self._cfg.home_joints)

    async def connect(self) -> bool:
        if _RTDE:
            try:
                self._ctrl = rtde_control.RTDEControlInterface(self._cfg.host)
                self._recv = rtde_receive.RTDEReceiveInterface(self._cfg.host)
                self._connected = True
                log.info(f"  🦾  UR5 connected: {self._cfg.host}")
                asyncio.create_task(self._stream_loop())
                return True
            except Exception as e:
                log.warning(f"  🦾  UR5 RTDE connect failed: {e} — falling back to stub")

        # Stub mode
        self._stub = _StubUR5()
        self._connected = True
        self._pose_stream  = asyncio.Queue(maxsize=10)
        self._joint_stream = asyncio.Queue(maxsize=50)
        asyncio.create_task(self._stub_stream_loop())
        log.info(f"  🦾  UR5 stub mode active (robot_id={self._cfg.robot_id})")
        return True

    async def disconnect(self):
        self._connected = False
        if self._ctrl:
            self._ctrl.disconnect()
        if self._recv:
            self._recv.disconnect()

    # ── P-MCP Tools ────────────────────────────────────────────────────────

    async def move_to(self, x: float, y: float, z: float,
                       rx: float = 0.0, ry: float = math.pi, rz: float = 0.0,
                       speed: float = 0.25) -> dict:
        """Move TCP to Cartesian pose (MoveL)."""
        # Safety checks
        if z < self._cfg.floor_z:
            return {"success": False, "error": f"Floor guard: z={z:.3f} < {self._cfg.floor_z}"}
        if speed > self._cfg.max_tcp_speed:
            return {"success": False, "error": f"Speed {speed} > limit {self._cfg.max_tcp_speed}"}

        pose  = [x, y, z, rx, ry, rz]
        accel = self._cfg.max_tcp_accel

        log.info(f"  🦾  [{self._cfg.robot_id}] MoveL → [{x:.3f},{y:.3f},{z:.3f}] @{speed:.2f}m/s")

        if self._stub:
            self._stub.moveL(pose, speed, accel)
            self._last_pose = list(pose)
        else:
            await asyncio.get_event_loop().run_in_executor(
                None, self._ctrl.moveL, pose, speed, accel)
            self._last_pose = list(pose)

        return {"success": True, "pose": pose, "robot_id": self._cfg.robot_id}

    async def move_joints(self, j0: float, j1: float, j2: float,
                           j3: float, j4: float, j5: float,
                           speed: float = 0.5) -> dict:
        """Move to joint configuration (MoveJ)."""
        joints = [j0, j1, j2, j3, j4, j5]
        for i, (j, (lo, hi)) in enumerate(zip(joints, _StubUR5.JOINT_LIMITS)):
            if not lo <= j <= hi:
                return {"success": False, "error": f"Joint {i} out of range: {j:.3f}"}

        log.info(f"  🦾  [{self._cfg.robot_id}] MoveJ → {[round(j,3) for j in joints]}")
        if self._stub:
            self._stub.moveJ(joints, speed, 0.8)
            self._last_joints = list(joints)
        else:
            await asyncio.get_event_loop().run_in_executor(
                None, self._ctrl.moveJ, joints, speed, 0.8)
            self._last_joints = joints

        return {"success": True, "joints": joints}

    async def open_gripper(self) -> dict:
        if self._stub:
            self._stub.setDigitalOut(self._cfg.gripper_open_do, True)
        else:
            self._ctrl.setDigitalOut(self._cfg.gripper_open_do, True)
        self._gripper_open = True
        log.info(f"  🦾  [{self._cfg.robot_id}] Gripper OPEN")
        return {"success": True, "gripper": "open"}

    async def close_gripper(self) -> dict:
        if self._stub:
            self._stub.setDigitalOut(self._cfg.gripper_close_do, True)
        else:
            self._ctrl.setDigitalOut(self._cfg.gripper_close_do, True)
        self._gripper_open = False
        log.info(f"  🦾  [{self._cfg.robot_id}] Gripper CLOSE")
        return {"success": True, "gripper": "closed"}

    async def home(self) -> dict:
        """Move to safe home joint position."""
        j = self._cfg.home_joints
        return await self.move_joints(*j, speed=0.3)

    async def get_force_torque(self) -> dict:
        if self._stub:
            ft = self._stub.getForceTorque()
        else:
            ft = self._recv.getActualTCPForce()
        return {"fx": ft[0], "fy": ft[1], "fz": ft[2],
                "tx": ft[3], "ty": ft[4], "tz": ft[5]}

    # ── P-MCP Resources ────────────────────────────────────────────────────

    async def get_pose(self) -> dict:
        if self._stub:
            p = self._stub.getActualTCPPose()
        else:
            p = self._recv.getActualTCPPose()
        return {"x": p[0], "y": p[1], "z": p[2],
                "rx": p[3], "ry": p[4], "rz": p[5],
                "robot_id": self._cfg.robot_id}

    async def get_joints(self) -> dict:
        if self._stub:
            j = self._stub.getActualQ()
        else:
            j = self._recv.getActualQ()
        return {"joints": [round(x, 5) for x in j],
                "robot_id": self._cfg.robot_id}

    # ── Streaming loops ────────────────────────────────────────────────────

    async def _stub_stream_loop(self):
        """Simulate live sensor streams."""
        import random
        tick = 0
        while self._connected and self._stub:
            await asyncio.sleep(0.02)   # 50 Hz
            tick += 1
            # Add small noise to joints
            noise_j = [j + random.gauss(0, 0.0001) for j in self._stub.joints]
            if self._joint_stream and not self._joint_stream.full():
                await self._joint_stream.put(noise_j)
            if tick % 5 == 0:   # 10 Hz pose
                noise_p = [p + random.gauss(0, 0.00005) for p in self._stub.tcp]
                if self._pose_stream and not self._pose_stream.full():
                    await self._pose_stream.put(noise_p)

    async def _stream_loop(self):
        """Read real RTDE data streams."""
        while self._connected:
            await asyncio.sleep(0.02)
            try:
                j = self._recv.getActualQ()
                p = self._recv.getActualTCPPose()
                self._last_joints = j
                self._last_pose   = p
            except Exception:
                break

    # ── Tool/Resource schema (for PMCPServer.register_driver) ──────────────

    def pmcp_tools(self) -> List[dict]:
        return [
            {"name": "move_to",         "description": "Move TCP to Cartesian pose (MoveL)",
             "args": ["x","y","z","rx","ry","rz","speed"]},
            {"name": "move_joints",     "description": "Move to joint configuration (MoveJ)",
             "args": ["j0","j1","j2","j3","j4","j5","speed"]},
            {"name": "open_gripper",    "description": "Open the end-effector gripper"},
            {"name": "close_gripper",   "description": "Close the end-effector gripper"},
            {"name": "home",            "description": "Move to safe home configuration"},
            {"name": "get_force_torque","description": "Read TCP force/torque sensor"},
        ]

    def pmcp_resources(self) -> List[dict]:
        return [
            {"name": "pose",         "description": "Live TCP Cartesian pose", "hz": 10},
            {"name": "joints",       "description": "Joint angles (6 DOF)",    "hz": 50},
            {"name": "force_torque", "description": "TCP wrench (6-axis)",     "hz": 10},
        ]


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def _demo():
        cfg    = UR5Config(robot_id="arm-demo")
        driver = UR5Driver(cfg)
        await driver.connect()

        print("\n  ── UR5 Driver Demo ──")
        pose = await driver.get_pose()
        print(f"  Initial pose: {pose}")

        r1 = await driver.move_to(0.5, 0.2, 0.3, speed=0.3)
        print(f"  MoveL:  {r1}")

        r2 = await driver.open_gripper()
        print(f"  Gripper: {r2}")

        r3 = await driver.home()
        print(f"  Home:   {r3}")

        ft = await driver.get_force_torque()
        print(f"  Force:  {ft}")

        await driver.disconnect()

    asyncio.run(_demo())
