"""
P-MCP v0.4 — Soft-Slashing Governance Layer
==============================================
"Prove Guilt Without Exposing Secrets"

Soft-Slashing allows the P-MCP network to penalise a robot that
violates a safety rule defined in the Constitution WITHOUT leaking the
robot's full telemetry history to any third party.

Protocol Flow
-------------
1.  Robot submits a ZKSafetyProof for every ToolCall.
2.  ZKSafetyVerifier checks the proof and records the result.
3.  On violation, SoftSlashManager calls:
        a. prove_violation()  →  SlashViolationProof
           (ZK commitment that proves the specific rule failed,
            but does NOT reveal any other trajectory waypoints)
        b. execute_slash()    →  deducts stake in DePINBroker,
           reduces reputation, and revokes active leases via
           LeaseManager.
4.  SlashAppeal window: robot has APPEAL_WINDOW_S seconds to submit a
    counter-proof.  If accepted, stake is restored.

Slashing Schedule (Soft = graduated, not binary)
-------------------------------------------------
Severity   | Stake penalty  | Reputation penalty | Lease revocation
-----------+----------------+--------------------+------------------
WARN       |   0 %          |   − 2              |  No
MINOR      |   5 %          |   − 5              |  No
MAJOR      |  20 %          |  − 15              |  Yes (zone only)
CRITICAL   |  50 %          |  − 30              |  Yes (all zones)
TERMINAL   | 100 %          |   → 0              |  Yes + offline

Privacy Guarantee
-----------------
The SlashViolationProof contains:
  • proof_id, robot_id, rule_id, zone_id
  • commitment to the violating sensor value (HMAC-SHA256)
  • The specific threshold exceeded (e.g. "speed > 1.5 m/s")
  • A ZK witness hash (prover demonstrates knowledge of violating value)

It does NOT contain:
  • Individual trajectory waypoints
  • Joint angles, torques, or other raw sensor streams
  • Location data beyond "zone_id"
  • Any prior run history

This is equivalent to a commitment-reveal scheme where only the
VIOLATING fact is revealed, not the witness (the full trajectory).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.soft_slash")

# ── Sibling module imports (optional to avoid circular deps) ───────────────
try:
    from v04.pmcp_zk_safety import ZKSafetyProof, SafetyCheckResult, ZKSafetyVerifier
    _ZK = True
except ImportError:
    _ZK = False
    log.warning("pmcp_zk_safety not available — soft-slash in stub mode")

try:
    from v04.pmcp_temporal_lease import LeaseManager, LeaseState
    _LEASE = True
except ImportError:
    _LEASE = False

try:
    from v04.pmcp_depin import DePINBroker, RobotServiceNode, NodeState
    _DEPIN = True
except ImportError:
    _DEPIN = False

try:
    from v04.pmcp_constitution_registry import ConstitutionRegistry
    _CONST = True
except ImportError:
    _CONST = False


# ─────────────────────────────────────────────────────────────
#  ENUMS
# ─────────────────────────────────────────────────────────────

class SlashSeverity(str, Enum):
    WARN     = "warn"      # informational; no penalty
    MINOR    = "minor"     # 5 % stake, −2 rep
    MAJOR    = "major"     # 20% stake, −15 rep, zone lease revoked
    CRITICAL = "critical"  # 50% stake, −30 rep, all leases revoked
    TERMINAL = "terminal"  # 100% stake, offline


class SlashReason(str, Enum):
    SPEED_VIOLATION      = "speed_violation"
    ENERGY_OVERSHOOT     = "energy_overshoot"
    HUMAN_CLEARANCE      = "human_clearance"
    CONSTITUTION_BREACH  = "constitution_breach"
    PROOF_FORGERY        = "proof_forgery"       # commitment hash mismatch
    REPLAY_ATTACK        = "replay_attack"
    CONSECUTIVE_FAILURES = "consecutive_failures"
    COLLUSION            = "collusion"            # two robots coordinating bad moves


SEVERITY_SCHEDULE: Dict[SlashReason, SlashSeverity] = {
    SlashReason.SPEED_VIOLATION:      SlashSeverity.MINOR,
    SlashReason.ENERGY_OVERSHOOT:     SlashSeverity.MINOR,
    SlashReason.HUMAN_CLEARANCE:      SlashSeverity.CRITICAL,
    SlashReason.CONSTITUTION_BREACH:  SlashSeverity.MAJOR,
    SlashReason.PROOF_FORGERY:        SlashSeverity.TERMINAL,
    SlashReason.REPLAY_ATTACK:        SlashSeverity.MAJOR,
    SlashReason.CONSECUTIVE_FAILURES: SlashSeverity.MAJOR,
    SlashReason.COLLUSION:            SlashSeverity.TERMINAL,
}

STAKE_PENALTY_PCT: Dict[SlashSeverity, float] = {
    SlashSeverity.WARN:     0.0,
    SlashSeverity.MINOR:    5.0,
    SlashSeverity.MAJOR:   20.0,
    SlashSeverity.CRITICAL: 50.0,
    SlashSeverity.TERMINAL: 100.0,
}

REPUTATION_PENALTY: Dict[SlashSeverity, float] = {
    SlashSeverity.WARN:     2.0,
    SlashSeverity.MINOR:    5.0,
    SlashSeverity.MAJOR:   15.0,
    SlashSeverity.CRITICAL: 30.0,
    SlashSeverity.TERMINAL: 100.0,
}

APPEAL_WINDOW_S = 300.0   # 5 minutes to submit counter-proof


# ─────────────────────────────────────────────────────────────
#  VIOLATION PROOF  (the ZK object that proves guilt)
# ─────────────────────────────────────────────────────────────

@dataclass
class SlashViolationProof:
    """
    Zero-Knowledge violation certificate.

    Proves that robot `robot_id` violated rule `rule_id` at `event_time`
    without revealing any trajectory data beyond the specific metric.

    Verification:
        HMAC(secret, robot_id||rule_id||value||nonce) == commitment

    The verifier knows: which rule, which metric value, which robot.
    The verifier does NOT know: the full path, joint states, other metrics.
    """
    slash_proof_id:   str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    robot_id:         str   = ""
    rule_id:          str   = ""
    zone_id:          str   = ""
    reason:           SlashReason = SlashReason.CONSTITUTION_BREACH
    severity:         SlashSeverity = SlashSeverity.MINOR

    # ZK commitment to the violating metric (without the raw trajectory)
    commitment:       str   = ""    # HMAC-SHA256(key, robot||rule||value||nonce)
    nonce:            str   = ""    # Revealed nonce
    violating_metric: str   = ""    # e.g. "speed_ms" or "energy_j"
    violating_value:  float = 0.0   # The actual offending value
    threshold:        float = 0.0   # The limit that was breached
    threshold_name:   str   = ""    # e.g. "max_speed_ms"

    # Anchoring to the original ZK proof
    original_proof_id:  str   = ""
    original_call_id:   str   = ""
    constitution_hash:  str   = ""

    # Timing
    event_time:       float = field(default_factory=time.time)
    issued_at:        float = field(default_factory=time.time)
    appeal_deadline:  float = field(default_factory=lambda: time.time() + APPEAL_WINDOW_S)

    # Appeal status
    appealed:         bool  = False
    appeal_accepted:  bool  = False
    appeal_proof_id:  Optional[str] = None

    def is_appealable(self) -> bool:
        return not self.appealed and time.time() < self.appeal_deadline

    def describe(self) -> str:
        return (
            f"[{self.severity.value.upper()}] {self.robot_id} violated "
            f"rule {self.rule_id}: {self.violating_metric}="
            f"{self.violating_value:.3f} > threshold {self.threshold} "
            f"({self.threshold_name}) in zone {self.zone_id}"
        )

    def to_dict(self) -> dict:
        return {
            "slash_proof_id":   self.slash_proof_id,
            "robot_id":         self.robot_id,
            "rule_id":          self.rule_id,
            "zone_id":          self.zone_id,
            "reason":           self.reason.value,
            "severity":         self.severity.value,
            "commitment":       self.commitment,
            "nonce":            self.nonce,
            "violation":        {
                "metric":     self.violating_metric,
                "value":      round(self.violating_value, 4),
                "threshold":  self.threshold,
                "threshold_name": self.threshold_name,
            },
            "original_proof_id": self.original_proof_id,
            "original_call_id":  self.original_call_id,
            "constitution_hash": self.constitution_hash,
            "event_time":        self.event_time,
            "appeal_deadline":   self.appeal_deadline,
            "appealed":          self.appealed,
            "appeal_accepted":   self.appeal_accepted,
        }


# ─────────────────────────────────────────────────────────────
#  SLASH RECORD  (the executed penalty)
# ─────────────────────────────────────────────────────────────

@dataclass
class SlashRecord:
    """Immutable record of a completed slash execution."""
    record_id:      str   = field(default_factory=lambda: str(uuid.uuid4())[:12])
    robot_id:       str   = ""
    severity:       SlashSeverity = SlashSeverity.MINOR
    reason:         SlashReason   = SlashReason.CONSTITUTION_BREACH
    stake_before:   float = 0.0
    stake_after:    float = 0.0
    rep_before:     float = 0.0
    rep_after:      float = 0.0
    leases_revoked: List[str] = field(default_factory=list)
    slash_proof_id: str   = ""
    executed_at:    float = field(default_factory=time.time)
    reversed_at:    Optional[float] = None   # set if appeal succeeds

    def penalty_summary(self) -> dict:
        return {
            "stake_lost":  round(self.stake_before - self.stake_after, 2),
            "rep_lost":    round(self.rep_before  - self.rep_after,   2),
            "leases_revoked": len(self.leases_revoked),
        }


# ─────────────────────────────────────────────────────────────
#  VIOLATION DETECTOR  (maps ZK proof failures to reasons)
# ─────────────────────────────────────────────────────────────

class ViolationDetector:
    """
    Analyses a failed ZKSafetyProof and extracts the specific
    violation without exposing the full safety check payload.

    Only the single failing metric is surfaced in the SlashViolationProof.
    """

    # Constitution rule IDs mapped to SlashReason
    RULE_REASON_MAP: Dict[str, SlashReason] = {
        "CONST-01":  SlashReason.SPEED_VIOLATION,
        "CONST-02":  SlashReason.ENERGY_OVERSHOOT,
        "CONST-03":  SlashReason.HUMAN_CLEARANCE,
        "CONST-04":  SlashReason.CONSTITUTION_BREACH,
        "CONST-SPEED": SlashReason.SPEED_VIOLATION,
        "CONST-ENERGY": SlashReason.ENERGY_OVERSHOOT,
        "CONST-FLOOR":  SlashReason.CONSTITUTION_BREACH,
        "CONST-HUMAN":  SlashReason.HUMAN_CLEARANCE,
    }

    def __init__(self, slash_key: Optional[bytes] = None):
        # Private key used to generate ZK commitments for violation proofs
        self._slash_key = slash_key or secrets.token_bytes(32)

    def detect(
        self,
        proof,           # ZKSafetyProof or dict-like
        violations: List[str],
        constitution_hash: str = "",
    ) -> Optional[SlashViolationProof]:
        """
        Inspect a failed ZKSafetyProof and build a SlashViolationProof
        for the FIRST (most severe) violation found.
        """
        if not violations:
            return None

        # Determine the primary violation reason
        primary = self._classify_violations(violations)
        sc = getattr(proof, "safety_checks", None)
        if sc is None:
            return None

        # Extract ONLY the violating metric — not the full check suite
        metric_name, metric_value, threshold, threshold_name = \
            self._extract_violating_metric(primary, sc)

        rule_id = self._reason_to_rule(primary)
        nonce   = secrets.token_hex(16)

        # ZK commitment: proves we know the violating value without
        # revealing any other part of the telemetry
        commit_input = (
            f"{proof.robot_id}|{rule_id}|"
            f"{metric_name}={metric_value:.6f}|{nonce}"
        )
        commitment = hmac.new(
            self._slash_key,
            commit_input.encode(),
            hashlib.sha256,
        ).hexdigest()

        severity = SEVERITY_SCHEDULE.get(primary, SlashSeverity.MINOR)

        sp = SlashViolationProof(
            robot_id          = getattr(proof, "robot_id", "unknown"),
            rule_id           = rule_id,
            zone_id           = getattr(sc, "zone_id", "world"),
            reason            = primary,
            severity          = severity,
            commitment        = commitment,
            nonce             = nonce,
            violating_metric  = metric_name,
            violating_value   = metric_value,
            threshold         = threshold,
            threshold_name    = threshold_name,
            original_proof_id = getattr(proof, "proof_id", ""),
            original_call_id  = getattr(proof, "call_id",  ""),
            constitution_hash = constitution_hash,
        )

        log.warning(f"  ⚡  Violation detected: {sp.describe()}")
        return sp

    # ── helpers ───────────────────────────────────────────────────────────

    def _classify_violations(self, violations: List[str]) -> SlashReason:
        """Map violation strings to the most severe SlashReason."""
        for v in violations:
            vl = v.lower()
            if "human" in vl or "clearance" in vl:
                return SlashReason.HUMAN_CLEARANCE
            if "replay" in vl:
                return SlashReason.REPLAY_ATTACK
            if "commitment" in vl or "mismatch" in vl:
                return SlashReason.PROOF_FORGERY
            if "speed" in vl:
                return SlashReason.SPEED_VIOLATION
            if "energy" in vl:
                return SlashReason.ENERGY_OVERSHOOT
        return SlashReason.CONSTITUTION_BREACH

    def _extract_violating_metric(
        self,
        reason: SlashReason,
        sc,   # SafetyCheckResult
    ) -> Tuple[str, float, float, str]:
        """Return (metric_name, value, threshold, threshold_label) for the violation."""
        SPEED_LIMIT  = 1.5   # m/s  — from Constitution CONST-01
        ENERGY_LIMIT = 5000.0  # J

        if reason == SlashReason.SPEED_VIOLATION:
            return "speed_ms", getattr(sc, "max_speed_ms", 0.0), SPEED_LIMIT, "max_speed_ms"
        if reason == SlashReason.ENERGY_OVERSHOOT:
            return "energy_j", getattr(sc, "energy_j", 0.0), ENERGY_LIMIT, "max_energy_j"
        if reason == SlashReason.HUMAN_CLEARANCE:
            # The violating value is "human_in_zone=True"; encode as 1.0
            return "human_in_zone", 1.0, 0.0, "max_human_presence"
        # Default: return the energy metric as a fallback
        return "energy_j", getattr(sc, "energy_j", 0.0), ENERGY_LIMIT, "max_energy_j"

    def _reason_to_rule(self, reason: SlashReason) -> str:
        return {
            SlashReason.SPEED_VIOLATION:     "CONST-01",
            SlashReason.ENERGY_OVERSHOOT:    "CONST-02",
            SlashReason.HUMAN_CLEARANCE:     "CONST-03",
            SlashReason.CONSTITUTION_BREACH: "CONST-04",
            SlashReason.PROOF_FORGERY:       "CONST-INTEGRITY",
            SlashReason.REPLAY_ATTACK:       "CONST-REPLAY",
            SlashReason.CONSECUTIVE_FAILURES:"CONST-RELIABILITY",
            SlashReason.COLLUSION:           "CONST-COLLUSION",
        }.get(reason, "CONST-00")

    def verify_violation_proof(
        self,
        slash_proof: SlashViolationProof,
    ) -> Tuple[bool, str]:
        """
        Re-derive the commitment from the revealed (robot_id, rule_id,
        metric, nonce) and confirm it matches.  Anyone can verify this
        without the original trajectory.
        """
        commit_input = (
            f"{slash_proof.robot_id}|{slash_proof.rule_id}|"
            f"{slash_proof.violating_metric}={slash_proof.violating_value:.6f}"
            f"|{slash_proof.nonce}"
        )
        expected = hmac.new(
            self._slash_key,
            commit_input.encode(),
            hashlib.sha256,
        ).hexdigest()
        if hmac.compare_digest(expected, slash_proof.commitment):
            return True, "commitment verified"
        return False, "commitment mismatch — proof may be tampered"


# ─────────────────────────────────────────────────────────────
#  SOFT-SLASH MANAGER
# ─────────────────────────────────────────────────────────────

class SoftSlashManager:
    """
    Orchestrates the full soft-slashing lifecycle:

    1. Monitor incoming ZK proof results from ZKSafetyVerifier
    2. Detect violations via ViolationDetector
    3. Issue SlashViolationProof (ZK-private)
    4. Execute graduated penalty via DePINBroker + LeaseManager
    5. Accept / reject appeals within the appeal window

    Wire-up example
    ---------------
    slash_mgr = SoftSlashManager(depin_broker, lease_mgr)
    verifier  = ZKSafetyVerifier()

    # After every ZK proof verify:
    ok, violations = verifier.verify(proof, ...)
    if not ok:
        slash_record = await slash_mgr.process_violation(proof, violations)
    """

    def __init__(
        self,
        depin_broker = None,   # DePINBroker (optional)
        lease_manager = None,  # LeaseManager (optional)
        slash_key: Optional[bytes] = None,
        consecutive_fail_threshold: int = 3,
    ):
        self._broker        = depin_broker
        self._lease_mgr     = lease_manager
        self._detector      = ViolationDetector(slash_key)
        self._threshold     = consecutive_fail_threshold

        # State
        self._slash_proofs:  Dict[str, SlashViolationProof] = {}
        self._slash_records: Dict[str, SlashRecord]         = {}
        self._fail_counts:   Dict[str, int]                 = {}   # robot_id → consecutive fails
        self._constitution_hash: str = ""

        log.info("  ⚖️   SoftSlashManager initialised")

    def set_constitution_hash(self, h: str):
        self._constitution_hash = h

    # ── Main entry point ──────────────────────────────────────────────────

    async def process_violation(
        self,
        proof,
        violations: List[str],
    ) -> Optional[SlashRecord]:
        """
        Called when ZKSafetyVerifier.verify() returns False.
        Returns a SlashRecord if a penalty was executed.
        """
        if not violations:
            return None

        robot_id = getattr(proof, "robot_id", "unknown")

        # Track consecutive failures
        self._fail_counts[robot_id] = self._fail_counts.get(robot_id, 0) + 1
        if self._fail_counts[robot_id] >= self._threshold:
            violations = [f"CONSECUTIVE_FAILURES({self._fail_counts[robot_id]})"] + violations

        # Build ZK violation proof
        slash_proof = self._detector.detect(
            proof, violations, self._constitution_hash
        )
        if slash_proof is None:
            return None

        self._slash_proofs[slash_proof.slash_proof_id] = slash_proof
        log.warning(f"  🔴  SLASH PROOF: {slash_proof.slash_proof_id} — {slash_proof.describe()}")

        # Execute the penalty
        record = await self._execute_slash(slash_proof)
        return record

    # ── Penalty execution ─────────────────────────────────────────────────

    async def _execute_slash(self, slash_proof: SlashViolationProof) -> SlashRecord:
        """Apply graduated penalty to the robot node."""
        robot_id    = slash_proof.robot_id
        severity    = slash_proof.severity
        stake_before = 0.0
        stake_after  = 0.0
        rep_before   = 0.0
        rep_after    = 0.0
        leases_revoked: List[str] = []

        stake_pct   = STAKE_PENALTY_PCT[severity]
        rep_penalty = REPUTATION_PENALTY[severity]

        # ── DePIN stake + reputation ──────────────────────────────────────
        if self._broker is not None and _DEPIN:
            node = self._broker._nodes.get(robot_id)
            if node is not None:
                stake_before = node.stake_credits
                rep_before   = node.reputation

                stake_deduction = stake_before * (stake_pct / 100.0)
                node.stake_credits = max(0.0, stake_before - stake_deduction)
                node.reputation    = max(0.0, node.reputation - rep_penalty)

                # Terminal: force offline
                if severity == SlashSeverity.TERMINAL:
                    node.state = NodeState.OFFLINE if _DEPIN else node.state

                stake_after = node.stake_credits
                rep_after   = node.reputation

                log.warning(
                    f"  ⚡  STAKE SLASHED: {robot_id} "
                    f"stake {stake_before:.1f}→{stake_after:.1f} "
                    f"rep {rep_before:.1f}→{rep_after:.1f}"
                )

        # ── Lease revocation ─────────────────────────────────────────────
        if self._lease_mgr is not None and _LEASE:
            if severity in (SlashSeverity.MAJOR, SlashSeverity.CRITICAL, SlashSeverity.TERMINAL):
                # Revoke only the zone lease on MAJOR; all leases on CRITICAL+
                if severity == SlashSeverity.MAJOR:
                    leases_revoked = await self._revoke_zone_leases(
                        robot_id, slash_proof.zone_id
                    )
                else:
                    leases_revoked = await self._revoke_all_leases(robot_id)

        record = SlashRecord(
            robot_id        = robot_id,
            severity        = severity,
            reason          = slash_proof.reason,
            stake_before    = stake_before,
            stake_after     = stake_after,
            rep_before      = rep_before,
            rep_after       = rep_after,
            leases_revoked  = leases_revoked,
            slash_proof_id  = slash_proof.slash_proof_id,
        )
        self._slash_records[record.record_id] = record

        log.warning(
            f"  📋  SLASH RECORD {record.record_id}: "
            f"penalty={record.penalty_summary()}"
        )
        # Reset consecutive fail counter after punishment applied
        self._fail_counts[robot_id] = 0
        return record

    async def _revoke_zone_leases(self, robot_id: str, zone_id: str) -> List[str]:
        """Revoke all active leases for robot in a specific zone."""
        revoked = []
        if self._lease_mgr is None:
            return revoked
        for lease_id, lease in list(self._lease_mgr._leases.items()):
            if (lease.robot_id == robot_id and
                    lease.zone_id == zone_id and
                    lease.is_active()):
                lease.state = LeaseState.REVOKED if _LEASE else lease.state
                revoked.append(lease_id)
                log.warning(f"  🚫  Lease revoked (slash): {lease_id} zone={zone_id}")
        return revoked

    async def _revoke_all_leases(self, robot_id: str) -> List[str]:
        """Revoke ALL active leases for a robot."""
        revoked = []
        if self._lease_mgr is None:
            return revoked
        for lease_id, lease in list(self._lease_mgr._leases.items()):
            if lease.robot_id == robot_id and lease.is_active():
                lease.state = LeaseState.REVOKED if _LEASE else lease.state
                revoked.append(lease_id)
        if revoked:
            log.warning(f"  🚫  ALL {len(revoked)} leases revoked for {robot_id}")
        return revoked

    # ── Appeal mechanism ──────────────────────────────────────────────────

    def submit_appeal(
        self,
        slash_proof_id: str,
        counter_proof_commitment: str,
        counter_nonce: str,
    ) -> Tuple[bool, str]:
        """
        Robot submits a counter-proof.
        If the commitment verifies correctly, the appeal is accepted
        and the penalty is reversed.

        In production: counter-proof is a full ZK-SNARK that proves
        the safety check DID pass (i.e., the original violation proof
        was based on tampered data or a race condition).
        """
        sp = self._slash_proofs.get(slash_proof_id)
        if sp is None:
            return False, f"No slash proof found: {slash_proof_id}"
        if not sp.is_appealable():
            return False, "Appeal window has closed"
        if sp.appealed:
            return False, "Already appealed"

        sp.appealed = True

        # Verify counter-proof commitment (simplified: check nonce length)
        # Production: verify Groth16 proof against circuit verifying key
        if len(counter_proof_commitment) >= 32 and len(counter_nonce) >= 16:
            sp.appeal_accepted   = True
            sp.appeal_proof_id   = counter_proof_commitment[:12]
            # Reverse the penalty
            self._reverse_slash(slash_proof_id)
            log.info(f"  ✅  Appeal ACCEPTED for slash {slash_proof_id}")
            return True, "Appeal accepted — penalty reversed"
        else:
            log.warning(f"  ❌  Appeal REJECTED for slash {slash_proof_id}")
            return False, "Counter-proof insufficient"

    def _reverse_slash(self, slash_proof_id: str):
        """Restore stake and reputation after a successful appeal."""
        # Find matching record
        for record in self._slash_records.values():
            if record.slash_proof_id == slash_proof_id:
                record.reversed_at = time.time()
                robot_id = record.robot_id
                if self._broker is not None and _DEPIN:
                    node = self._broker._nodes.get(robot_id)
                    if node is not None:
                        node.stake_credits = record.stake_before
                        node.reputation    = record.rep_before
                        log.info(
                            f"  ↩️   Penalty reversed for {robot_id}: "
                            f"stake→{record.stake_before} rep→{record.rep_before}"
                        )
                break

    # ── Stats & audit ─────────────────────────────────────────────────────

    def audit_trail(self, robot_id: Optional[str] = None) -> List[dict]:
        records = list(self._slash_records.values())
        if robot_id:
            records = [r for r in records if r.robot_id == robot_id]
        return [
            {
                "record_id":    r.record_id,
                "robot_id":     r.robot_id,
                "severity":     r.severity.value,
                "reason":       r.reason.value,
                "penalty":      r.penalty_summary(),
                "executed_at":  r.executed_at,
                "reversed":     r.reversed_at is not None,
            }
            for r in records
        ]

    def stats(self) -> dict:
        total    = len(self._slash_records)
        reversed_  = sum(1 for r in self._slash_records.values() if r.reversed_at)
        by_severity = {}
        for r in self._slash_records.values():
            by_severity[r.severity.value] = by_severity.get(r.severity.value, 0) + 1
        return {
            "total_slashes":    total,
            "reversed_appeals": reversed_,
            "by_severity":      by_severity,
            "robots_tracked":   len(self._fail_counts),
        }

    def get_violation_proof(self, slash_proof_id: str) -> Optional[dict]:
        sp = self._slash_proofs.get(slash_proof_id)
        return sp.to_dict() if sp else None


# ─────────────────────────────────────────────────────────────
#  CONSTITUTION-AWARE SLASH MONITOR
# ─────────────────────────────────────────────────────────────

class ConstitutionSlashMonitor:
    """
    Connects the ConstitutionRegistry to the SoftSlashManager.

    On every ZK proof result, checks each active constitution rule
    against the proof's metrics and triggers slashing if violated.

    Usage:
        monitor = ConstitutionSlashMonitor(registry, slash_mgr)
        await monitor.evaluate(proof, proof_ok, verifier_violations)
    """

    def __init__(
        self,
        registry = None,     # ConstitutionRegistry
        slash_manager: Optional[SoftSlashManager] = None,
    ):
        self._registry   = registry
        self._slash_mgr  = slash_manager
        self._eval_count = 0

    async def evaluate(
        self,
        proof,
        proof_ok: bool,
        verifier_violations: List[str],
    ) -> Optional[SlashRecord]:
        """
        Evaluate proof against active constitution rules.
        Returns a SlashRecord if a penalty was applied.
        """
        self._eval_count += 1

        # If ZK verifier already found violations, pass them through
        if not proof_ok and self._slash_mgr:
            return await self._slash_mgr.process_violation(proof, verifier_violations)

        # Even for "passing" proofs, check constitution rules directly
        sc = getattr(proof, "safety_checks", None)
        if sc is None or self._registry is None:
            return None

        const_violations: List[str] = []

        # Evaluate each active rule against the revealed metrics
        if _CONST:
            bundle = getattr(self._registry, "_active_bundle", None)
            if bundle:
                for rule in getattr(bundle, "rules", []):
                    rule_id = getattr(rule, "rule_id", "")
                    try:
                        # Rules use check_expr like "lambda sc: sc.max_speed_ms <= 1.5"
                        check_fn = getattr(rule, "_compiled_check", None)
                        if check_fn and not check_fn(sc):
                            const_violations.append(
                                f"Constitution rule {rule_id} failed"
                            )
                    except Exception:
                        pass

        if const_violations and self._slash_mgr:
            return await self._slash_mgr.process_violation(proof, const_violations)

        return None

    def stats(self) -> dict:
        return {
            "evaluations":  self._eval_count,
            "slash_stats":  self._slash_mgr.stats() if self._slash_mgr else {},
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import asyncio

    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def demo():
        print("\n" + "=" * 60)
        print("  P-MCP Soft-Slash Demo")
        print("=" * 60)

        # Minimal stubs so demo runs without full stack
        class StubNode:
            def __init__(self):
                self.stake_credits = 1000.0
                self.reputation    = 80.0
                self.state         = "available"

        class StubBroker:
            def __init__(self):
                self._nodes = {
                    "ur5-01":       StubNode(),
                    "turtlebot-01": StubNode(),
                }

        class StubSC:
            def __init__(self, speed=0.5, energy=100.0, human=False):
                self.zone_id      = "grow_zone_a"
                self.max_speed_ms = speed
                self.energy_j     = energy
                self.check_human  = not human
                self.check_speed  = speed <= 1.5
                self.check_energy = energy <= 5000.0

        class StubProof:
            def __init__(self, robot_id, speed=0.5, energy=100.0, human=False):
                self.proof_id       = str(uuid.uuid4())[:12]
                self.call_id        = str(uuid.uuid4())[:12]
                self.robot_id       = robot_id
                self.safety_checks  = StubSC(speed, energy, human)

        broker   = StubBroker()
        slash_mgr = SoftSlashManager(depin_broker=broker)

        # ── Test 1: Speed violation (MINOR) ──────────────────────────────
        print("\n--- Test 1: Speed violation (UR5 at 2.5 m/s) ---")
        proof1 = StubProof("ur5-01", speed=2.5)
        record1 = await slash_mgr.process_violation(
            proof1, ["PROOF: speed check FAILED (2.50 m/s)"]
        )
        if record1:
            print(f"  Slash record: {record1.penalty_summary()}")
            print(f"  Stake: {broker._nodes['ur5-01'].stake_credits:.1f}")
            print(f"  Rep:   {broker._nodes['ur5-01'].reputation:.1f}")

        # ── Test 2: Human clearance violation (CRITICAL) ─────────────────
        print("\n--- Test 2: Human clearance violation (TurtleBot) ---")
        proof2 = StubProof("turtlebot-01", human=True)
        record2 = await slash_mgr.process_violation(
            proof2, ["PROOF: human clearance FAILED"]
        )
        if record2:
            print(f"  Slash record: {record2.penalty_summary()}")
            print(f"  Stake: {broker._nodes['turtlebot-01'].stake_credits:.1f}")

        # ── Test 3: Appeal ───────────────────────────────────────────────
        if record1:
            print("\n--- Test 3: Appeal against speed slash ---")
            sp_id   = record1.slash_proof_id
            ok, msg = slash_mgr.submit_appeal(
                sp_id,
                counter_proof_commitment="a" * 32,
                counter_nonce="b" * 16,
            )
            print(f"  Appeal result: {ok} — {msg}")
            print(f"  Stake restored: {broker._nodes['ur5-01'].stake_credits:.1f}")

        # ── ZK proof verify ───────────────────────────────────────────────
        print("\n--- Violation Proof Integrity Check ---")
        detector = ViolationDetector()
        sp = detector.detect(proof1, ["PROOF: speed check FAILED (2.50 m/s)"])
        if sp:
            ok, msg = detector.verify_violation_proof(sp)
            print(f"  Proof {sp.slash_proof_id}: {ok} — {msg}")
            print(f"  {sp.describe()}")

        print("\n--- Slash Manager Stats ---")
        import json
        print(json.dumps(slash_mgr.stats(), indent=2))

    asyncio.run(demo())
