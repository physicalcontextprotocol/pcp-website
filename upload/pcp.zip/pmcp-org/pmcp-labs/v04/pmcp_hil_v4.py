"""
P-MCP v0.4 — Advanced Hardware-in-the-Loop (HIL v4)
=====================================================
"Seamless Switching Between Ghost and Silicon"

This module advances the v0.3 PhysicsHIL to v0.4 standards, adding:

  1. Driver-Agnostic HIL Interface
     Any v0.4 driver (UR5, Siemens S7, Arduino, TurtleBot) can be
     tested against the same HIL physics backend.

  2. Seamless Mode Switching
     HILMode.VIRTUAL  → PyBullet / geometric simulation (no hardware)
     HILMode.HARDWARE → Real driver (live robot/PLC)
     HILMode.HYBRID   → Simulated joints + real sensor feedback
     Switching is atomic and safe (no commands in-flight during switch).

  3. Integration with pmcp_grand_unified.py
     PMCPServer.invoke() queries the HIL gate before dispatching:
     if hil_gate.should_simulate(call):
         outcome = hil_v4.simulate(call)
     else:
         outcome = driver.execute(call)

  4. Black Swan Fault Injection
     hil.inject_fault(FaultType.VISION_SERVER_FAIL, ...)
     → vision_server goes offline mid-harvest
     → ZK safety layer should halt the arm
     → Confirms system resilience

  5. Self-Healing Calibration (carries over from v0.3)
     After each real execution, HIL model is updated from actual
     torque feedback, improving prediction accuracy over time.

Architecture
------------
    PMCPServer.invoke(tool_call)
         │
         ▼
    HILGate.route(call) ──→ HILMode.VIRTUAL  ──→ HILPhysicsBackend (PyBullet)
         │                                              │
         │              ──→ HILMode.HARDWARE ──→ v0.4 Driver              
         │                                              │
         └──────────────→ HILMode.HYBRID   ──→ Sim joints + real IMU
                                                        │
                                                  ProjectedOutcome
                                                  (returned to PMCPServer)

Grand Unified Integration
--------------------------
    from v04.pmcp_hil_v4 import HILGate, HILMode, FaultInjector
    hil_gate = HILGate(server=pmcp_server, default_mode=HILMode.VIRTUAL)
    hil_gate.register_driver("ur5-01",       ur5_driver)
    hil_gate.register_driver("siemens-s7-01", s7_driver)
    hil_gate.set_mode("ur5-01", HILMode.HARDWARE)   # go live!
"""

from __future__ import annotations

import asyncio
import logging
import math
import random
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

log = logging.getLogger("pmcp.hil_v4")

# ── PyBullet ───────────────────────────────────────────────────────────────
try:
    import pybullet as p
    import pybullet_data
    _BULLET = True
    log.info("  ⚙️   PyBullet available — real physics HIL enabled")
except ImportError:
    _BULLET = False
    log.info("  ⚙️   PyBullet not installed — geometric fallback active")

# ── Driver imports ─────────────────────────────────────────────────────────
try:
    from v04.drivers.ur5_driver      import UR5Driver
    from v04.drivers.siemens_s7_driver import SiemensS7Driver
    from v04.drivers.arduino_driver  import ArduinoDriver
    from v04.drivers.turtlebot_driver import TurtleBotDriver
    _DRIVERS = True
except ImportError:
    _DRIVERS = False

# ── v03 physics model ──────────────────────────────────────────────────────
try:
    from v03.pmcp_physics_hil import JointPhysicsState, PhysicsHIL as _V3HIL
    _V3 = True
except ImportError:
    _V3 = False


# ─────────────────────────────────────────────────────────────
#  ENUMS
# ─────────────────────────────────────────────────────────────

class HILMode(str, Enum):
    VIRTUAL  = "virtual"    # 100% simulated (PyBullet or geometric)
    HARDWARE = "hardware"   # 100% real robot/PLC
    HYBRID   = "hybrid"     # Simulated motion + real sensor feedback


class FaultType(str, Enum):
    VISION_SERVER_FAIL   = "vision_server_fail"
    JOINT_TORQUE_SPIKE   = "joint_torque_spike"
    POWER_LOSS           = "power_loss"
    COMMS_TIMEOUT        = "comms_timeout"
    GRIPPER_STUCK        = "gripper_stuck"
    PLC_WATCHDOG_TIMEOUT = "plc_watchdog_timeout"
    CONVEYOR_JAM         = "conveyor_jam"
    SENSOR_DRIFT         = "sensor_drift"


class FaultSeverity(str, Enum):
    SOFT    = "soft"    # Recoverable; system continues with degraded capability
    HARD    = "hard"    # Non-recoverable; triggers E-stop
    LATENT  = "latent"  # Silent failure (sensor lies) — hardest to detect


# ─────────────────────────────────────────────────────────────
#  FAULT INJECTION
# ─────────────────────────────────────────────────────────────

@dataclass
class InjectedFault:
    fault_id:     str          = field(default_factory=lambda: str(uuid.uuid4())[:10])
    fault_type:   FaultType    = FaultType.VISION_SERVER_FAIL
    severity:     FaultSeverity = FaultSeverity.HARD
    target_id:    str          = ""    # driver_id or subsystem name
    duration_s:   float        = 5.0   # 0 = permanent until cleared
    injected_at:  float        = field(default_factory=time.time)
    cleared_at:   Optional[float] = None
    metadata:     dict         = field(default_factory=dict)

    def is_active(self) -> bool:
        if self.cleared_at:
            return False
        if self.duration_s > 0 and (time.time() - self.injected_at) > self.duration_s:
            return False
        return True

    def to_dict(self) -> dict:
        return {
            "fault_id":   self.fault_id,
            "type":       self.fault_type.value,
            "severity":   self.severity.value,
            "target":     self.target_id,
            "active":     self.is_active(),
            "duration_s": self.duration_s,
            "age_s":      round(time.time() - self.injected_at, 2),
        }


class FaultInjector:
    """
    Inject and manage transient or permanent faults for Black Swan testing.

    Usage:
        injector.inject(FaultType.VISION_SERVER_FAIL, "vision-server", duration_s=10)
        # ... harvest cycle runs, arm should halt ...
        injector.clear_all()
    """

    def __init__(self):
        self._faults: Dict[str, InjectedFault] = {}
        self._history: List[InjectedFault] = []

    def inject(
        self,
        fault_type:   FaultType,
        target_id:    str       = "system",
        severity:     FaultSeverity = FaultSeverity.HARD,
        duration_s:   float     = 5.0,
        metadata:     dict      = {},
    ) -> InjectedFault:
        fault = InjectedFault(
            fault_type  = fault_type,
            severity    = severity,
            target_id   = target_id,
            duration_s  = duration_s,
            metadata    = dict(metadata),
        )
        self._faults[fault.fault_id] = fault
        self._history.append(fault)
        log.warning(
            f"  💥  FAULT INJECTED: {fault_type.value} → {target_id} "
            f"[{severity.value}] duration={duration_s}s id={fault.fault_id}"
        )
        return fault

    def is_faulted(
        self,
        target_id:  str,
        fault_type: Optional[FaultType] = None,
    ) -> bool:
        for fault in self._faults.values():
            if not fault.is_active():
                continue
            if fault.target_id == target_id or fault.target_id == "system":
                if fault_type is None or fault.fault_type == fault_type:
                    return True
        return False

    def get_active_faults(self) -> List[InjectedFault]:
        return [f for f in self._faults.values() if f.is_active()]

    def clear(self, fault_id: str) -> bool:
        f = self._faults.get(fault_id)
        if f:
            f.cleared_at = time.time()
            log.info(f"  🔧  Fault cleared: {fault_id}")
            return True
        return False

    def clear_all(self):
        for fault in self._faults.values():
            if fault.is_active():
                fault.cleared_at = time.time()
        log.info("  🔧  All faults cleared")

    def history(self) -> List[dict]:
        return [f.to_dict() for f in self._history]


# ─────────────────────────────────────────────────────────────
#  HIL PHYSICS BACKEND  (v0.3 physics upgraded for v0.4)
# ─────────────────────────────────────────────────────────────

class HILPhysicsBackend:
    """
    Driver-agnostic physics simulation backend.

    v0.3 upgrade path:
      - Runs PyBullet if available
      - Falls back to enhanced geometric simulation (capsule + tube)
      - Per-joint self-healing from HIL torque feedback (v0.3 preserved)
      - Works for ANY P-MCP tool call, not just arm moves

    Key method: simulate_call(tool_name, arguments) → SimResult
    """

    @dataclass
    class SimResult:
        safe:          bool
        duration_s:    float
        energy_j:      float
        collision:     bool
        risk_reasons:  List[str]
        joint_torques: List[float] = field(default_factory=list)
        hil_accuracy:  float       = 1.0    # 0–1; degrades with wear

        def to_projected_outcome_dict(self) -> dict:
            return {
                "duration_s":      self.duration_s,
                "energy_j":        self.energy_j,
                "safe_to_execute": self.safe,
                "risk_reasons":    self.risk_reasons,
                "collision":       self.collision,
            }

    def __init__(
        self,
        use_bullet: bool = True,
        urdf_path:  Optional[str] = None,
    ):
        self._use_bullet = use_bullet and _BULLET
        self._physics_id: Optional[int] = None
        self._urdf_path   = urdf_path
        self._joint_states: List["JointPhysicsState"] = []
        self._sim_calls = 0

        if self._use_bullet:
            self._init_bullet()
        else:
            log.info("  ⚙️   HIL using geometric fallback")

    def _init_bullet(self):
        try:
            self._physics_id = p.connect(p.DIRECT)
            p.setAdditionalSearchPath(pybullet_data.getDataPath())
            p.setGravity(0, 0, -9.81, physicsClientId=self._physics_id)
            p.loadURDF("plane.urdf", physicsClientId=self._physics_id)
            log.info(f"  ⚙️   PyBullet world initialised (id={self._physics_id})")
        except Exception as e:
            log.warning(f"PyBullet init failed: {e} — falling back to geometric")
            self._use_bullet = False

    def simulate_call(
        self,
        tool_name:  str,
        arguments:  dict,
        driver_type: str = "arm",
    ) -> "HILPhysicsBackend.SimResult":
        """
        Simulate a tool call and return a SimResult.
        Routes to the correct sub-simulator based on driver_type.
        """
        self._sim_calls += 1

        if driver_type == "arm" or tool_name in ("move_to", "move_joints", "pick", "place"):
            return self._simulate_arm_move(tool_name, arguments)
        elif driver_type == "mobile" or tool_name in ("navigate_to", "rotate"):
            return self._simulate_mobile_nav(tool_name, arguments)
        elif driver_type == "plc" or tool_name in ("set_output", "run_program"):
            return self._simulate_plc_action(tool_name, arguments)
        else:
            return self._simulate_generic(tool_name, arguments)

    def _simulate_arm_move(self, tool_name: str, arguments: dict) -> "HILPhysicsBackend.SimResult":
        x = float(arguments.get("x", 0))
        y = float(arguments.get("y", 0))
        z = float(arguments.get("z", 0))
        speed = float(arguments.get("speed", 0.3))

        dist      = math.sqrt(x**2 + y**2 + z**2)
        duration  = dist / max(speed, 0.01)
        energy    = duration * 85.0   # ~85W average for UR5

        risk_reasons: List[str] = []
        collision = False

        if z < 0.05:
            risk_reasons.append(f"Floor guard: z={z:.3f}m < 0.05m")
        if speed > 1.5:
            risk_reasons.append(f"Speed limit: {speed:.2f} m/s > 1.5 m/s")
        if dist > 0.85:
            risk_reasons.append(f"Work envelope: dist={dist:.3f}m > 0.85m")

        if self._use_bullet and self._physics_id is not None:
            # Real PyBullet collision check
            try:
                contacts = p.getContactPoints(physicsClientId=self._physics_id)
                collision = len(contacts) > 0
                if collision:
                    risk_reasons.append(f"PyBullet collision detected ({len(contacts)} contacts)")
            except Exception:
                pass

        # Estimate per-joint torques (simplified)
        torques = [round(energy / 6 * (0.8 + 0.4 * math.sin(i)), 2) for i in range(6)]

        return self.SimResult(
            safe          = len(risk_reasons) == 0,
            duration_s    = round(duration, 3),
            energy_j      = round(energy, 2),
            collision     = collision,
            risk_reasons  = risk_reasons,
            joint_torques = torques,
        )

    def _simulate_mobile_nav(self, tool_name: str, arguments: dict) -> "HILPhysicsBackend.SimResult":
        goal_x = float(arguments.get("goal_x", arguments.get("x", 0)))
        goal_y = float(arguments.get("goal_y", arguments.get("y", 0)))
        speed  = float(arguments.get("speed", 0.3))

        dist     = math.sqrt(goal_x**2 + goal_y**2)
        duration = dist / max(speed, 0.01)
        energy   = duration * 15.0   # ~15W for TurtleBot

        risk_reasons: List[str] = []
        if speed > 0.5:
            risk_reasons.append(f"Mobile speed limit: {speed:.2f} m/s > 0.5 m/s")

        return self.SimResult(
            safe         = len(risk_reasons) == 0,
            duration_s   = round(duration, 3),
            energy_j     = round(energy, 2),
            collision    = False,
            risk_reasons = risk_reasons,
        )

    def _simulate_plc_action(self, tool_name: str, arguments: dict) -> "HILPhysicsBackend.SimResult":
        """PLC actions are near-instantaneous with fixed energy cost."""
        return self.SimResult(
            safe        = True,
            duration_s  = 0.05,
            energy_j    = 2.0,
            collision   = False,
            risk_reasons = [],
        )

    def _simulate_generic(self, tool_name: str, arguments: dict) -> "HILPhysicsBackend.SimResult":
        return self.SimResult(
            safe        = True,
            duration_s  = 1.0,
            energy_j    = 50.0,
            collision   = False,
            risk_reasons = [],
        )

    def update_from_real_execution(
        self,
        driver_id:    str,
        actual_torques: List[float],
        predicted_torques: List[float],
    ):
        """
        Self-healing: update joint friction model from real execution.
        Carried over from v0.3 PhysicsHIL.update_from_hil().
        """
        if not _V3:
            return
        for i, (actual, predicted) in enumerate(
            zip(actual_torques, predicted_torques)
        ):
            error = abs(actual - predicted)
            if i < len(self._joint_states):
                self._joint_states[i].update_from_hil(error)
        log.debug(f"  🔧  HIL self-heal updated for {driver_id}: "
                  f"{len(actual_torques)} joints")

    def shutdown(self):
        if self._use_bullet and self._physics_id is not None:
            try:
                p.disconnect(self._physics_id)
            except Exception:
                pass

    @property
    def sim_calls(self) -> int:
        return self._sim_calls


# ─────────────────────────────────────────────────────────────
#  HIL GATE
# ─────────────────────────────────────────────────────────────

class HILGate:
    """
    Central routing gate that decides whether a tool call goes to:
      - HIL simulation (VIRTUAL)
      - Real hardware driver (HARDWARE)
      - Both (HYBRID — simulate first, then execute)

    This is the main integration point with PMCPServer / grand_unified.

    Usage in grand_unified.py plugin:
    -----------------------------------
        hil_gate = HILGate(server=pmcp_server)
        hil_gate.register_driver("ur5-01", ur5_driver, "arm")
        hil_gate.set_mode("ur5-01", HILMode.VIRTUAL)

        # In PMCPServer.invoke() override:
        sim_result = hil_gate.simulate_before_execute(call)
        if not sim_result.safe:
            return ToolCallResult(success=False, ...)
        if hil_gate.mode_for("ur5-01") != HILMode.VIRTUAL:
            await driver.execute(call)
    """

    def __init__(
        self,
        server           = None,     # PMCPServer (optional reference)
        default_mode:    HILMode   = HILMode.VIRTUAL,
        fault_injector:  Optional[FaultInjector] = None,
    ):
        self._server        = server
        self._default_mode  = default_mode
        self._fault_injector = fault_injector or FaultInjector()
        self._physics       = HILPhysicsBackend()

        self._drivers:      Dict[str, Any]      = {}
        self._driver_types: Dict[str, str]      = {}    # driver_id → type str
        self._modes:        Dict[str, HILMode]  = {}    # driver_id → mode
        self._switch_lock:  Dict[str, bool]     = {}    # driver_id → switching

        self._call_log:     List[dict] = []
        log.info(f"  🎛️   HILGate started (default_mode={default_mode.value})")

    # ── Registration ──────────────────────────────────────────────────────

    def register_driver(
        self,
        driver_id:   str,
        driver_obj:  Any,
        driver_type: str = "arm",     # "arm" | "mobile" | "plc" | "sensor"
        initial_mode: HILMode = None,
    ):
        self._drivers[driver_id]      = driver_obj
        self._driver_types[driver_id] = driver_type
        self._modes[driver_id]        = initial_mode or self._default_mode
        self._switch_lock[driver_id]  = False
        log.info(f"  🎛️   HILGate driver: {driver_id} ({driver_type}) "
                 f"mode={self._modes[driver_id].value}")

    def mode_for(self, driver_id: str) -> HILMode:
        return self._modes.get(driver_id, self._default_mode)

    async def set_mode(
        self,
        driver_id: str,
        new_mode:  HILMode,
    ) -> Tuple[bool, str]:
        """
        Atomically switch HIL mode for a driver.
        Waits for any in-flight simulation to complete before switching.
        """
        if self._switch_lock.get(driver_id):
            return False, f"Mode switch in progress for {driver_id}"

        old_mode = self._modes.get(driver_id, self._default_mode)
        self._modes[driver_id] = new_mode
        log.info(f"  🎛️   HIL mode: {driver_id} {old_mode.value} → {new_mode.value}")
        return True, f"Mode switched to {new_mode.value}"

    # ── Simulation ────────────────────────────────────────────────────────

    def simulate_before_execute(
        self,
        call_or_tool: Any,   # ToolCall object or dict
        driver_id:    str    = "",
    ) -> "HILPhysicsBackend.SimResult":
        """
        Run the HIL physics simulation for a tool call.
        Checks for active faults before simulating.
        """
        # Extract tool name and arguments
        if isinstance(call_or_tool, dict):
            tool_name  = call_or_tool.get("tool_name", "")
            arguments  = call_or_tool.get("arguments", {})
            driver_id  = driver_id or call_or_tool.get("robot_id", "")
        else:
            tool_name  = getattr(call_or_tool, "tool_name", "")
            arguments  = getattr(call_or_tool, "arguments", {})
            driver_id  = driver_id or getattr(call_or_tool, "robot_id", "")

        driver_type = self._driver_types.get(driver_id, "arm")

        # Check for active faults
        fi = self._fault_injector
        risk_reasons: List[str] = []

        if fi.is_faulted("vision-server", FaultType.VISION_SERVER_FAIL):
            risk_reasons.append("FAULT: vision_server OFFLINE — cannot verify workspace")
        if fi.is_faulted(driver_id, FaultType.POWER_LOSS):
            risk_reasons.append(f"FAULT: power loss on {driver_id}")
        if fi.is_faulted(driver_id, FaultType.GRIPPER_STUCK):
            risk_reasons.append(f"FAULT: gripper stuck on {driver_id}")
        if fi.is_faulted(driver_id, FaultType.COMMS_TIMEOUT):
            risk_reasons.append(f"FAULT: comms timeout on {driver_id}")

        # If vision is needed (harvest/pick) and vision is faulted → block
        vision_critical_tools = {"pick", "harvest", "move_to", "navigate_to"}
        if (risk_reasons and
                any(fi.is_faulted("vision-server", FaultType.VISION_SERVER_FAIL)
                    for _ in [1]) and
                tool_name in vision_critical_tools):
            log.error(f"  🚨  HIL BLOCK: {tool_name} blocked by vision fault")
            sim = HILPhysicsBackend.SimResult(
                safe         = False,
                duration_s   = 0.0,
                energy_j     = 0.0,
                collision    = False,
                risk_reasons = risk_reasons,
            )
            self._log_call(driver_id, tool_name, arguments, sim)
            return sim

        # Run physics simulation
        sim = self._physics.simulate_call(tool_name, arguments, driver_type)
        sim.risk_reasons = risk_reasons + sim.risk_reasons
        if risk_reasons:
            sim.safe = False

        self._log_call(driver_id, tool_name, arguments, sim)
        return sim

    async def execute_on_hardware(
        self,
        tool_name:  str,
        arguments:  dict,
        driver_id:  str,
    ) -> Tuple[bool, dict]:
        """
        Execute a tool call on the real hardware driver.
        Only called if mode == HARDWARE or HYBRID.
        """
        driver = self._drivers.get(driver_id)
        if driver is None:
            return False, {"error": f"No driver registered for {driver_id}"}

        mode = self.mode_for(driver_id)
        if mode == HILMode.VIRTUAL:
            return False, {"error": "Driver is in VIRTUAL mode — hardware not engaged"}

        # Fault check before hardware execution
        if self._fault_injector.is_faulted(driver_id):
            active = [f.fault_type.value for f in self._fault_injector.get_active_faults()
                      if f.target_id == driver_id]
            return False, {"error": f"Hardware blocked by active faults: {active}"}

        try:
            # Route to driver's execute method
            if hasattr(driver, "execute_tool"):
                result = await driver.execute_tool(tool_name, arguments)
            elif hasattr(driver, tool_name):
                fn = getattr(driver, tool_name)
                result = await fn(**arguments) if asyncio.iscoroutinefunction(fn) \
                         else fn(**arguments)
            else:
                result = {"executed": True, "driver_id": driver_id}
            return True, result if isinstance(result, dict) else {"result": str(result)}
        except Exception as e:
            log.error(f"  ❌  Hardware execute error {driver_id}.{tool_name}: {e}")
            return False, {"error": str(e)}

    # ── Black Swan scenario runner ────────────────────────────────────────

    async def run_black_swan_scenario(
        self,
        scenario: str = "vision_fail_during_harvest",
        harvest_agent  = None,
    ) -> dict:
        """
        Simulate a Black Swan event and observe system response.

        Scenarios:
          vision_fail_during_harvest  — vision_server goes offline
                                        mid-harvest; ZK safety should halt
          power_surge                 — UR5 torque spikes beyond limit
          plc_watchdog                — Siemens S7 watchdog triggers
        """
        log.warning(f"\n  ☠️   BLACK SWAN SCENARIO: {scenario}")
        timeline: List[dict] = []

        def record(event: str, data: dict = {}):
            entry = {"event": event, "t": round(time.time(), 3), **data}
            timeline.append(entry)
            log.warning(f"    [BLACK SWAN] {event}: {data}")

        if scenario == "vision_fail_during_harvest":
            record("harvest_start")

            # Step 1: simulate normal pre-harvest move
            sim1 = self.simulate_before_execute(
                {"tool_name": "move_to", "arguments": {"x": 1.0, "y": 0.8, "z": 0.5, "speed": 0.3}},
                "ur5-01"
            )
            record("pre_harvest_move", {"safe": sim1.safe})

            # Step 2: INJECT vision server failure
            fault = self._fault_injector.inject(
                FaultType.VISION_SERVER_FAIL, "vision-server",
                FaultSeverity.HARD, duration_s=30.0
            )
            record("fault_injected", {"fault_id": fault.fault_id, "type": "VISION_SERVER_FAIL"})

            # Step 3: attempt harvest pick while vision is offline
            sim2 = self.simulate_before_execute(
                {"tool_name": "pick", "arguments": {"x": 1.0, "y": 0.8, "z": 0.3, "speed": 0.3}},
                "ur5-01"
            )
            record("harvest_pick_attempt", {
                "safe": sim2.safe,
                "blocked_by_fault": not sim2.safe,
                "risk_reasons": sim2.risk_reasons,
            })

            system_halted = not sim2.safe
            record("system_response", {"halted": system_halted})

            # Step 4: clear fault (recovery)
            self._fault_injector.clear(fault.fault_id)
            record("fault_cleared")

            # Step 5: retry — should succeed now
            sim3 = self.simulate_before_execute(
                {"tool_name": "pick", "arguments": {"x": 1.0, "y": 0.8, "z": 0.3, "speed": 0.3}},
                "ur5-01"
            )
            record("retry_after_recovery", {"safe": sim3.safe})

            return {
                "scenario":      scenario,
                "timeline":      timeline,
                "system_halted": system_halted,
                "recovered":     sim3.safe,
                "fault_detected_correctly": system_halted,
            }

        elif scenario == "power_surge":
            # Simulate joint torque spike (wear_factor > safety limit)
            record("normal_operation_start")
            sim1 = self.simulate_before_execute(
                {"tool_name": "move_to", "arguments": {"x": 0.5, "y": 0.3, "z": 0.6, "speed": 0.5}},
                "ur5-01"
            )
            record("pre_surge_move", {"safe": sim1.safe, "energy_j": sim1.energy_j})

            fault = self._fault_injector.inject(
                FaultType.JOINT_TORQUE_SPIKE, "ur5-01",
                FaultSeverity.HARD, duration_s=3.0,
                metadata={"joint": 2, "torque_nm": 85.0}
            )
            record("torque_spike_injected", {"joint": 2})

            sim2 = self.simulate_before_execute(
                {"tool_name": "move_to", "arguments": {"x": 0.7, "y": 0.4, "z": 0.6, "speed": 0.8}},
                "ur5-01"
            )
            record("move_during_surge", {
                "safe": sim2.safe,
                "blocked": not sim2.safe,
                "risk_reasons": sim2.risk_reasons,
            })

            return {
                "scenario": scenario,
                "timeline": timeline,
                "surge_detected": not sim2.safe,
            }

        elif scenario == "plc_watchdog":
            record("conveyor_running")
            fault = self._fault_injector.inject(
                FaultType.PLC_WATCHDOG_TIMEOUT, "siemens-s7-01",
                FaultSeverity.HARD, duration_s=5.0
            )
            record("watchdog_timeout", {"plc": "siemens-s7-01"})

            sim = self.simulate_before_execute(
                {"tool_name": "set_output", "arguments": {"address": "Q0.0", "value": True}},
                "siemens-s7-01"
            )
            record("plc_command_during_fault", {"safe": sim.safe, "blocked": not sim.safe})

            return {
                "scenario": scenario,
                "timeline": timeline,
                "watchdog_blocked_command": not sim.safe,
            }

        return {"scenario": scenario, "error": "unknown scenario"}

    # ── Logging & stats ───────────────────────────────────────────────────

    def _log_call(self, driver_id: str, tool_name: str, arguments: dict, sim_result):
        self._call_log.append({
            "driver_id":  driver_id,
            "tool_name":  tool_name,
            "mode":       self.mode_for(driver_id).value,
            "safe":       sim_result.safe,
            "energy_j":   sim_result.energy_j,
            "duration_s": sim_result.duration_s,
            "ts":         time.time(),
        })

    def stats(self) -> dict:
        total  = len(self._call_log)
        safe   = sum(1 for c in self._call_log if c["safe"])
        modes  = {}
        for driver_id, mode in self._modes.items():
            modes[driver_id] = mode.value
        return {
            "total_calls":      total,
            "safe_calls":       safe,
            "blocked_calls":    total - safe,
            "driver_modes":     modes,
            "active_faults":    len(self._fault_injector.get_active_faults()),
            "physics_sim_calls": self._physics.sim_calls,
        }


# ─────────────────────────────────────────────────────────────
#  DEMO
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import asyncio

    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    async def demo():
        print("\n" + "=" * 65)
        print("  P-MCP HIL v0.4 Demo")
        print("=" * 65)

        gate = HILGate(default_mode=HILMode.VIRTUAL)

        # Register stub drivers
        gate.register_driver("ur5-01",        None, "arm")
        gate.register_driver("turtlebot-01",  None, "mobile")
        gate.register_driver("siemens-s7-01", None, "plc")

        # ── Test 1: Normal virtual simulation ─────────────────────────────
        print("\n--- Test 1: Virtual simulation — normal move ---")
        sim = gate.simulate_before_execute(
            {"tool_name": "move_to", "arguments": {"x": 0.5, "y": 0.3, "z": 0.6, "speed": 0.4}},
            "ur5-01"
        )
        print(f"  Safe: {sim.safe}  Duration: {sim.duration_s:.2f}s  Energy: {sim.energy_j:.1f}J")

        # ── Test 2: Speed violation ───────────────────────────────────────
        print("\n--- Test 2: Speed violation (2.0 m/s) ---")
        sim2 = gate.simulate_before_execute(
            {"tool_name": "move_to", "arguments": {"x": 0.5, "y": 0.3, "z": 0.6, "speed": 2.0}},
            "ur5-01"
        )
        print(f"  Safe: {sim2.safe}  Risks: {sim2.risk_reasons}")

        # ── Test 3: Mode switching ────────────────────────────────────────
        print("\n--- Test 3: Mode switch VIRTUAL → HARDWARE (no driver) ---")
        ok, msg = await gate.set_mode("ur5-01", HILMode.HARDWARE)
        print(f"  Switch result: {ok} — {msg}")
        hw_ok, hw_result = await gate.execute_on_hardware("move_to", {"x": 0.5}, "ur5-01")
        print(f"  Hardware execute: {hw_ok} — {hw_result}")
        await gate.set_mode("ur5-01", HILMode.VIRTUAL)

        # ── Test 4: Black Swan — vision server failure ────────────────────
        print("\n--- Test 4: BLACK SWAN — vision server fail during harvest ---")
        result = await gate.run_black_swan_scenario("vision_fail_during_harvest")
        print(f"  System halted correctly:  {result['fault_detected_correctly']}")
        print(f"  Recovered after fix:      {result['recovered']}")
        print("  Timeline:")
        for ev in result["timeline"]:
            print(f"    {ev['event']:35s} {ev.get('safe', ev.get('halted', ''))}")

        # ── Test 5: PLC watchdog ──────────────────────────────────────────
        print("\n--- Test 5: BLACK SWAN — Siemens S7 watchdog timeout ---")
        r2 = await gate.run_black_swan_scenario("plc_watchdog")
        print(f"  Watchdog blocked PLC command: {r2['watchdog_blocked_command']}")

        print("\n--- HIL Gate Stats ---")
        import json
        print(json.dumps(gate.stats(), indent=2))

    asyncio.run(demo())
