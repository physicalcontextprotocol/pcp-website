"""
P-MCP v0.4 — Vision Server
============================
"The Eyes of the Robot — VisionDetection as a P-MCP Resource"

Architecture:
    Camera(s)
        ↓  OpenCV VideoCapture  (or RTSP stream)
    YOLOv8 Detector  (ultralytics — optional; falls back to stub)
        ↓  List[VisionDetection]
    PMCPVisionServer
        ↓  injects voxels into DigitalTwin
        ↓  publishes  robot://<id>/vision_voxels  resource
    ShadowValidator — sees dynamic obstacles in real-time
        ↓  blocks tool call if YOLO detects human/obstacle in path

Key Design Decisions
--------------------
- Every detection becomes a DigitalTwin voxel (TTL = 500 ms)
- Human detection → EMERGENCY HALT flag in twin (instant block)
- Confidence threshold configurable per class (humans higher)
- Frame pipeline is async; shadow validation stays synchronous
- Works without a real camera: stub mode loops test frames

Real YOLO install:
    pip install ultralytics opencv-python-headless
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.vision")

# ── Optional YOLO ──────────────────────────────────────────────────────────
try:
    from ultralytics import YOLO as _YOLO
    _YOLO_AVAILABLE = True
except ImportError:
    _YOLO_AVAILABLE = False
    log.info("  👁️  ultralytics not installed — vision stub mode active")

# ── Optional OpenCV ────────────────────────────────────────────────────────
try:
    import cv2 as _cv2
    _CV2_AVAILABLE = True
except ImportError:
    _CV2_AVAILABLE = False
    log.info("  👁️  opencv not installed — vision stub mode active")


# ─────────────────────────────────────────────────────────────
#  DATA MODELS
# ─────────────────────────────────────────────────────────────

class ObjectClass(str, Enum):
    HUMAN        = "human"
    ROBOT        = "robot"
    OBSTACLE     = "obstacle"
    PLANT_TRAY   = "plant_tray"
    TOOL         = "tool"
    CONVEYOR     = "conveyor"
    PALLET       = "pallet"
    UNKNOWN      = "unknown"


@dataclass
class BoundingBox3D:
    """3-D axis-aligned bounding box in world coordinates (metres)."""
    x_min: float = 0.0
    y_min: float = 0.0
    z_min: float = 0.0
    x_max: float = 0.0
    y_max: float = 0.0
    z_max: float = 0.0

    @property
    def center_x(self) -> float: return (self.x_min + self.x_max) / 2
    @property
    def center_y(self) -> float: return (self.y_min + self.y_max) / 2
    @property
    def center_z(self) -> float: return (self.z_min + self.z_max) / 2

    def to_voxel(self) -> dict:
        return {
            "x": self.center_x, "y": self.center_y, "z": self.center_z,
            "size_x": self.x_max - self.x_min,
            "size_y": self.y_max - self.y_min,
            "size_z": self.z_max - self.z_min,
        }


@dataclass
class VisionDetection:
    """One object detected in the workspace."""
    detection_id:  str   = field(default_factory=lambda: str(uuid.uuid4())[:8])
    object_class:  ObjectClass = ObjectClass.UNKNOWN
    confidence:    float = 0.0          # 0.0–1.0
    bbox3d:        BoundingBox3D = field(default_factory=BoundingBox3D)
    velocity_ms:   Tuple[float, float, float] = (0.0, 0.0, 0.0)
    track_id:      int   = -1           # DeepSORT / ByteTrack ID
    camera_id:     str   = "cam-0"
    timestamp:     float = field(default_factory=time.time)
    raw_pixel_bbox: Optional[Tuple[int,int,int,int]] = None   # x1,y1,x2,y2
    depth_m:       float = 0.0          # from depth camera

    def is_human(self) -> bool:
        return self.object_class == ObjectClass.HUMAN

    def to_voxel_dict(self) -> dict:
        v = self.bbox3d.to_voxel()
        v.update({
            "detection_id": self.detection_id,
            "label":        self.object_class.value,
            "confidence":   self.confidence,
            "track_id":     self.track_id,
            "camera_id":    self.camera_id,
            "is_human":     self.is_human(),
            "velocity":     self.velocity_ms,
        })
        return v


# ─────────────────────────────────────────────────────────────
#  CAMERA CONFIG
# ─────────────────────────────────────────────────────────────

@dataclass
class CameraConfig:
    camera_id:     str   = "cam-0"
    source:        Any   = 0              # int (USB) or str (RTSP URL)
    fps:           float = 30.0
    width:         int   = 1280
    height:        int   = 720
    # Extrinsic calibration — transform pixel→world
    mount_x_m:     float = 2.0           # Camera position in world frame
    mount_y_m:     float = 1.0
    mount_z_m:     float = 2.5
    pitch_deg:     float = -45.0         # Looking down-forward
    fov_h_deg:     float = 90.0
    depth_scale:   float = 0.001         # For Intel RealSense raw → metres
    # Detection thresholds
    conf_human:    float = 0.45          # Conservative for humans
    conf_generic:  float = 0.55
    model_path:    str   = "yolov8n.pt"  # nano model — fastest


# ─────────────────────────────────────────────────────────────
#  DEPTH PROJECTION UTILITY
# ─────────────────────────────────────────────────────────────

def pixel_to_world(px: int, py: int, depth_m: float, cam: CameraConfig) -> Tuple[float, float, float]:
    """
    Simplified pin-hole projection: pixel + depth → world (x, y, z).
    Replace with proper camera matrix in production.
    """
    if depth_m <= 0.001:
        depth_m = 1.5   # fallback depth estimate

    # Normalised image coords
    nx = (px / 640 - 0.5) * 2   # assume 1280w
    ny = (py / 360 - 0.5) * 2   # assume 720h

    fov_rad = math.radians(cam.fov_h_deg)
    fx = depth_m * math.tan(fov_rad / 2)

    wx = cam.mount_x_m + nx * fx
    wy = cam.mount_y_m + ny * fx * (720 / 1280)
    wz = cam.mount_z_m - depth_m * math.sin(math.radians(abs(cam.pitch_deg)))
    return wx, wy, wz


# ─────────────────────────────────────────────────────────────
#  STUB DETECTOR (no hardware needed)
# ─────────────────────────────────────────────────────────────

class StubDetector:
    """
    Generates synthetic detections for testing without real hardware.
    Simulates a plant tray + occasional human incursion.
    """
    def __init__(self):
        self._tick = 0

    def detect(self, cam: CameraConfig) -> List[VisionDetection]:
        self._tick += 1
        detections = []

        # Permanent plant trays
        for i, (x, y) in enumerate([(0.5, 0.5), (1.5, 0.5), (2.5, 0.5)]):
            detections.append(VisionDetection(
                object_class=ObjectClass.PLANT_TRAY,
                confidence=0.92,
                bbox3d=BoundingBox3D(x-0.2, y-0.15, 0.8, x+0.2, y+0.15, 1.0),
                track_id=100 + i,
                camera_id=cam.camera_id,
                depth_m=1.2,
            ))

        # Human incursion every 30 ticks
        if self._tick % 30 < 5:
            detections.append(VisionDetection(
                object_class=ObjectClass.HUMAN,
                confidence=0.89,
                bbox3d=BoundingBox3D(1.0, 1.0, 0.0, 1.5, 1.6, 1.8),
                track_id=1,
                camera_id=cam.camera_id,
                depth_m=1.8,
            ))
            log.warning(f"  👤  [VISION] Human detected in workspace!")

        return detections


# ─────────────────────────────────────────────────────────────
#  YOLO DETECTOR (real hardware)
# ─────────────────────────────────────────────────────────────

class YOLODetector:
    """
    YOLOv8 detector wrapper.
    Maps COCO class labels to ObjectClass enum.
    Fuses 2D bbox with depth channel (if available) for 3D bboxes.
    """

    COCO_TO_CLASS: Dict[str, ObjectClass] = {
        "person":   ObjectClass.HUMAN,
        "robot":    ObjectClass.ROBOT,
        "bottle":   ObjectClass.TOOL,
        "box":      ObjectClass.OBSTACLE,
        "suitcase": ObjectClass.PALLET,
    }

    def __init__(self, cam_cfg: CameraConfig):
        if not _YOLO_AVAILABLE:
            raise RuntimeError("ultralytics not installed: pip install ultralytics")
        self._model = _YOLO(cam_cfg.model_path)
        self._cam   = cam_cfg
        log.info(f"  👁️  YOLO model loaded: {cam_cfg.model_path}")

    def detect(self, frame, depth_frame=None) -> List[VisionDetection]:
        results = self._model(frame, verbose=False)
        detections = []

        for box in results[0].boxes:
            cls_name = results[0].names[int(box.cls)]
            conf     = float(box.conf)
            x1, y1, x2, y2 = map(int, box.xyxy[0])

            obj_class = self.COCO_TO_CLASS.get(cls_name, ObjectClass.UNKNOWN)
            threshold = (self._cam.conf_human if obj_class == ObjectClass.HUMAN
                         else self._cam.conf_generic)
            if conf < threshold:
                continue

            # Depth lookup
            px, py = (x1 + x2) // 2, (y1 + y2) // 2
            depth = 1.5
            if depth_frame is not None:
                d = depth_frame[py, px] * self._cam.depth_scale
                if d > 0.1:
                    depth = d

            wx, wy, wz = pixel_to_world(px, py, depth, self._cam)
            half_w = (x2 - x1) * depth / (self._cam.width / 2) * 0.25
            half_h = (y2 - y1) * depth / (self._cam.height / 2) * 0.25

            detections.append(VisionDetection(
                object_class    = obj_class,
                confidence      = conf,
                bbox3d          = BoundingBox3D(wx - half_w, wy - half_w, wz - half_h,
                                                wx + half_w, wy + half_w, wz + half_h),
                camera_id       = self._cam.camera_id,
                raw_pixel_bbox  = (x1, y1, x2, y2),
                depth_m         = depth,
            ))

        return detections


# ─────────────────────────────────────────────────────────────
#  P-MCP VISION SERVER
# ─────────────────────────────────────────────────────────────

class PMCPVisionServer:
    """
    Runs one or more cameras asynchronously, converting detections to
    P-MCP resources and DigitalTwin voxels.

    Usage:
        vs = PMCPVisionServer(twin)
        vs.add_camera(CameraConfig(camera_id="cam-0", source=0))
        await vs.start()

    The vision server publishes:
        robot://<camera_id>/vision_voxels  — list of 3D detections
        twin._vision_voxels                — live obstacle map

    Emergency halt:
        vs.human_present()  → True while a human is in the workspace
        PMCPServer will block all tool calls while this is True
    """

    def __init__(self, twin):
        self._twin      = twin
        self._cameras:  List[CameraConfig] = []
        self._detectors: Dict[str, Any]   = {}   # cam_id → detector
        self._latest:   Dict[str, List[VisionDetection]] = {}
        self._running   = False
        self._tasks:    List[asyncio.Task] = []
        self._frame_count: int = 0
        self._human_zone: Dict[str, bool] = {}   # zone_id → human present

    def add_camera(self, cfg: CameraConfig):
        self._cameras.append(cfg)
        if _YOLO_AVAILABLE and _CV2_AVAILABLE:
            try:
                self._detectors[cfg.camera_id] = YOLODetector(cfg)
            except Exception as e:
                log.warning(f"  👁️  YOLO init failed ({e}) — using stub")
                self._detectors[cfg.camera_id] = StubDetector()
        else:
            self._detectors[cfg.camera_id] = StubDetector()
        self._latest[cfg.camera_id] = []
        log.info(f"  📷  Camera registered: {cfg.camera_id} source={cfg.source}")

    def human_present(self) -> bool:
        return any(self._human_zone.values())

    def latest_detections(self, camera_id: str) -> List[VisionDetection]:
        return self._latest.get(camera_id, [])

    def all_voxels(self) -> List[dict]:
        voxels = []
        for dets in self._latest.values():
            for d in dets:
                voxels.append(d.to_voxel_dict())
        return voxels

    async def start(self):
        self._running = True
        for cfg in self._cameras:
            t = asyncio.create_task(self._camera_loop(cfg), name=f"cam-{cfg.camera_id}")
            self._tasks.append(t)
        log.info(f"  📷  VisionServer started: {len(self._cameras)} camera(s)")

    async def stop(self):
        self._running = False
        for t in self._tasks:
            t.cancel()
        self._tasks.clear()

    async def _camera_loop(self, cfg: CameraConfig):
        detector = self._detectors[cfg.camera_id]
        cap = None

        if _CV2_AVAILABLE and isinstance(cfg.source, (int, str)):
            try:
                cap = _cv2.VideoCapture(cfg.source)
                cap.set(_cv2.CAP_PROP_FRAME_WIDTH, cfg.width)
                cap.set(_cv2.CAP_PROP_FRAME_HEIGHT, cfg.height)
            except Exception:
                cap = None

        interval_s = 1.0 / cfg.fps

        while self._running:
            t0 = time.perf_counter()

            if cap is not None and cap.isOpened():
                ret, frame = cap.read()
                if ret:
                    dets = detector.detect(frame)
                else:
                    dets = detector.detect(None)
            else:
                dets = detector.detect(cfg)

            self._latest[cfg.camera_id] = dets
            self._frame_count += 1

            # Update twin voxels (TTL handled by twin)
            self._twin.clear_expired_voxels(max_age_s=0.5)
            human_in_ws = False

            for det in dets:
                voxel = det.to_voxel_dict()
                self._twin.inject_vision_voxel(voxel)
                if det.is_human():
                    human_in_ws = True
                    # Map human to nearest zone
                    from pmcp_grand_unified import Vec3 as V3  # type: ignore
                    try:
                        zone = self._twin.get_zone_at(
                            V3(det.bbox3d.center_x, det.bbox3d.center_y, det.bbox3d.center_z)
                        )
                        if zone:
                            self._twin.set_human_present(zone.name, True)
                            self._human_zone[zone.name] = True
                    except Exception:
                        pass

            if not human_in_ws:
                for z in list(self._human_zone.keys()):
                    self._human_zone[z] = False

            elapsed = time.perf_counter() - t0
            await asyncio.sleep(max(0, interval_s - elapsed))

        if cap is not None:
            cap.release()

    def stats(self) -> dict:
        return {
            "cameras": len(self._cameras),
            "frames_processed": self._frame_count,
            "human_present": self.human_present(),
            "active_detections": sum(len(v) for v in self._latest.values()),
            "voxel_count": len(self._twin.get_vision_voxels()),
        }


# ─────────────────────────────────────────────────────────────
#  DEMO / TEST
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    sys.path.insert(0, "..")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

    # Inline minimal twin for standalone test
    class _FakeTwin:
        def __init__(self):
            self._voxels = []
        def inject_vision_voxel(self, v): self._voxels.append(v)
        def clear_expired_voxels(self, max_age_s=0.5):
            now = time.time()
            self._voxels = [x for x in self._voxels
                            if now - x.get("injected_at", now) < max_age_s]
        def get_vision_voxels(self): return self._voxels
        def get_zone_at(self, p): return None
        def set_human_present(self, z, v): pass

    async def _demo():
        twin = _FakeTwin()
        vs   = PMCPVisionServer(twin)
        vs.add_camera(CameraConfig(camera_id="cam-stub", source=0, fps=5.0))
        await vs.start()
        for i in range(6):
            await asyncio.sleep(0.25)
            stats = vs.stats()
            print(f"  Frame {i+1}: {stats}")
        await vs.stop()

    asyncio.run(_demo())
