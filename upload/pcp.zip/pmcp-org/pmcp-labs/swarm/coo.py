"""
P-MCP Swarm Chief Operating Officer (COO)
==========================================
Autonomous multi-agent coordinator that:

  1. Maintains a live world model (robot positions, task queue, resource map)
  2. Assigns tasks to robots using multi-criteria optimisation
      - Distance to task (spatial cost)
      - Battery level (energy cost)
      - Current load (load balancing)
      - Specialisation score (capability match)
  3. Monitors execution via P-MCP heartbeats and re-assigns on failure
  4. Publishes Swarm KPIs over a JSON-RPC telemetry endpoint

Architecture
------------
  WorldModel   — live snapshot of fleet state
  TaskQueue    — priority-ordered work items
  Dispatcher   — assigns/re-assigns tasks using a weighted scoring function
  Monitor      — watches heartbeats, detects failures, triggers re-dispatch
  SwarmCOO     — top-level coordinator; runs all loops and exposes RPC
"""
from __future__ import annotations

import asyncio
import heapq
import logging
import math
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("pmcp.swarm_coo")


# ─────────────────────────────────────────────────────────────────────────────
#  World Model
# ─────────────────────────────────────────────────────────────────────────────

class RobotStatus(str, Enum):
    IDLE = "idle"
    BUSY = "busy"
    CHARGING = "charging"
    FAULT = "fault"
    OFFLINE = "offline"


@dataclass
class RobotState:
    robot_id: str
    url: str
    x: float = 0.0
    y: float = 0.0
    battery: float = 1.0
    status: RobotStatus = RobotStatus.IDLE
    capabilities: List[str] = field(default_factory=list)
    current_task: Optional[str] = None
    last_heartbeat: float = field(default_factory=time.time)
    completed_tasks: int = 0
    failed_tasks: int = 0


class WorldModel:
    def __init__(self) -> None:
        self._robots: Dict[str, RobotState] = {}
        self._lock = asyncio.Lock()

    async def register(self, robot: RobotState) -> None:
        async with self._lock:
            self._robots[robot.robot_id] = robot
            log.info("Registered robot %s at %s", robot.robot_id, robot.url)

    async def update(self, robot_id: str, **kwargs: Any) -> None:
        async with self._lock:
            if robot_id in self._robots:
                for k, v in kwargs.items():
                    setattr(self._robots[robot_id], k, v)

    async def get_idle_robots(self) -> List[RobotState]:
        async with self._lock:
            return [r for r in self._robots.values() if r.status == RobotStatus.IDLE and r.battery > 0.2]

    async def get_robot(self, robot_id: str) -> Optional[RobotState]:
        async with self._lock:
            return self._robots.get(robot_id)

    async def snapshot(self) -> List[Dict]:
        async with self._lock:
            return [
                {"robot_id": r.robot_id, "x": r.x, "y": r.y,
                 "battery": r.battery, "status": r.status.value,
                 "task": r.current_task, "completed": r.completed_tasks}
                for r in self._robots.values()
            ]


# ─────────────────────────────────────────────────────────────────────────────
#  Task Queue
# ─────────────────────────────────────────────────────────────────────────────

class TaskPriority(int, Enum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3


@dataclass(order=True)
class Task:
    priority: int
    created_at: float
    task_id: str = field(compare=False)
    task_type: str = field(compare=False)
    params: Dict = field(compare=False, default_factory=dict)
    required_capabilities: List[str] = field(compare=False, default_factory=list)
    target_x: float = field(compare=False, default=0.0)
    target_y: float = field(compare=False, default=0.0)
    deadline: Optional[float] = field(compare=False, default=None)
    attempts: int = field(compare=False, default=0)
    max_attempts: int = field(compare=False, default=3)
    assigned_to: Optional[str] = field(compare=False, default=None)


class PriorityTaskQueue:
    def __init__(self) -> None:
        self._heap: List[Task] = []
        self._all: Dict[str, Task] = {}

    def push(self, task: Task) -> None:
        heapq.heappush(self._heap, task)
        self._all[task.task_id] = task

    def pop(self) -> Optional[Task]:
        while self._heap:
            task = heapq.heappop(self._heap)
            if task.task_id in self._all:
                return task
        return None

    def requeue(self, task: Task) -> None:
        task.assigned_to = None
        task.attempts += 1
        if task.attempts < task.max_attempts:
            heapq.heappush(self._heap, task)

    def complete(self, task_id: str) -> None:
        self._all.pop(task_id, None)

    def __len__(self) -> int:
        return len(self._heap)

    def pending_tasks(self) -> List[Dict]:
        return [
            {"task_id": t.task_id, "type": t.task_type, "priority": t.priority,
             "assigned_to": t.assigned_to, "attempts": t.attempts}
            for t in self._all.values()
        ]


# ─────────────────────────────────────────────────────────────────────────────
#  Dispatcher
# ─────────────────────────────────────────────────────────────────────────────

class Dispatcher:
    """Assigns tasks to robots using weighted multi-criteria scoring."""

    # Weights for scoring criteria
    W_DISTANCE = 0.4
    W_BATTERY = 0.3
    W_CAPABILITY = 0.2
    W_LOAD = 0.1

    def score(self, robot: RobotState, task: Task) -> float:
        # Distance score (lower distance → higher score)
        dist = math.sqrt((robot.x - task.target_x)**2 + (robot.y - task.target_y)**2)
        dist_score = 1.0 / (1.0 + dist / 10.0)

        # Battery score
        battery_score = robot.battery

        # Capability match
        if task.required_capabilities:
            matched = sum(1 for c in task.required_capabilities if c in robot.capabilities)
            cap_score = matched / len(task.required_capabilities)
        else:
            cap_score = 1.0

        # Load score (prefer less loaded robots — fewer completed tasks means fresher)
        load_score = 1.0 / (1.0 + robot.completed_tasks * 0.01)

        return (self.W_DISTANCE * dist_score +
                self.W_BATTERY * battery_score +
                self.W_CAPABILITY * cap_score +
                self.W_LOAD * load_score)

    def select_robot(self, robots: List[RobotState], task: Task) -> Optional[RobotState]:
        if not robots:
            return None
        scored = [(self.score(r, task), r) for r in robots]
        scored.sort(reverse=True, key=lambda x: x[0])
        return scored[0][1]


# ─────────────────────────────────────────────────────────────────────────────
#  Monitor
# ─────────────────────────────────────────────────────────────────────────────

class Monitor:
    """Watches robot heartbeats and detects failures."""

    def __init__(self, world: WorldModel, task_queue: PriorityTaskQueue,
                 heartbeat_timeout: float = 30.0) -> None:
        self._world = world
        self._queue = task_queue
        self._timeout = heartbeat_timeout
        self._assigned: Dict[str, Task] = {}  # robot_id → task

    def record_assignment(self, robot_id: str, task: Task) -> None:
        self._assigned[robot_id] = task

    def record_completion(self, robot_id: str, task_id: str) -> None:
        self._assigned.pop(robot_id, None)
        self._queue.complete(task_id)

    async def check_failures(self) -> List[str]:
        """Return list of robot_ids that appear to have failed."""
        failed = []
        snapshot = await self._world.snapshot()
        now = time.time()
        for r in snapshot:
            robot = await self._world.get_robot(r["robot_id"])
            if robot and robot.status == RobotStatus.BUSY:
                if now - robot.last_heartbeat > self._timeout:
                    failed.append(robot.robot_id)
                    await self._world.update(robot.robot_id, status=RobotStatus.FAULT)
                    # Requeue the task
                    task = self._assigned.pop(robot.robot_id, None)
                    if task:
                        log.warning("Robot %s failed on task %s — requeueing",
                                    robot.robot_id, task.task_id)
                        self._queue.requeue(task)
        return failed


# ─────────────────────────────────────────────────────────────────────────────
#  Swarm COO
# ─────────────────────────────────────────────────────────────────────────────

class SwarmCOO:
    """Top-level swarm coordinator."""

    def __init__(self) -> None:
        self.world = WorldModel()
        self.task_queue = PriorityTaskQueue()
        self.dispatcher = Dispatcher()
        self.monitor = Monitor(self.world, self.task_queue)
        self._dispatch_interval = 2.0
        self._monitor_interval = 10.0
        self._running = False
        self._kpis: Dict[str, Any] = {
            "total_tasks": 0, "completed": 0, "failed": 0,
            "started_at": time.time(),
        }

    async def register_robot(self, robot_id: str, url: str,
                             capabilities: List[str],
                             x: float = 0.0, y: float = 0.0) -> None:
        await self.world.register(RobotState(
            robot_id=robot_id, url=url, x=x, y=y,
            capabilities=capabilities,
        ))

    def submit_task(self, task_type: str, params: Dict = {},
                    priority: TaskPriority = TaskPriority.NORMAL,
                    required_capabilities: List[str] = [],
                    target_x: float = 0.0, target_y: float = 0.0,
                    deadline: Optional[float] = None) -> str:
        task_id = str(uuid.uuid4())
        task = Task(
            priority=priority.value,
            created_at=time.time(),
            task_id=task_id,
            task_type=task_type,
            params=params,
            required_capabilities=required_capabilities,
            target_x=target_x,
            target_y=target_y,
            deadline=deadline,
        )
        self.task_queue.push(task)
        self._kpis["total_tasks"] += 1
        log.info("Task submitted: %s (%s) priority=%d", task_id, task_type, priority.value)
        return task_id

    async def _dispatch_loop(self) -> None:
        while self._running:
            idle_robots = await self.world.get_idle_robots()
            while idle_robots and len(self.task_queue) > 0:
                task = self.task_queue.pop()
                if task is None:
                    break
                robot = self.dispatcher.select_robot(idle_robots, task)
                if robot is None:
                    self.task_queue.requeue(task)
                    break
                idle_robots = [r for r in idle_robots if r.robot_id != robot.robot_id]
                task.assigned_to = robot.robot_id
                await self.world.update(robot.robot_id, status=RobotStatus.BUSY,
                                        current_task=task.task_id)
                self.monitor.record_assignment(robot.robot_id, task)
                asyncio.ensure_future(self._execute_task(robot, task))
            await asyncio.sleep(self._dispatch_interval)

    async def _execute_task(self, robot: RobotState, task: Task) -> None:
        import aiohttp
        log.info("Executing task %s on robot %s", task.task_id, robot.robot_id)
        success = False
        try:
            payload = {
                "jsonrpc": "2.0", "id": 1,
                "method": "actuations/execute",
                "params": {"name": task.task_type, **task.params},
            }
            async with aiohttp.ClientSession() as sess:
                async with sess.post(robot.url, json=payload,
                                     timeout=aiohttp.ClientTimeout(total=30)) as resp:
                    data = await resp.json()
                    success = "result" in data
        except Exception as exc:
            log.error("Task %s execution error on %s: %s", task.task_id, robot.robot_id, exc)

        if success:
            self._kpis["completed"] += 1
            await self.world.update(robot.robot_id, status=RobotStatus.IDLE,
                                    current_task=None,
                                    completed_tasks=robot.completed_tasks + 1)
            self.monitor.record_completion(robot.robot_id, task.task_id)
        else:
            self._kpis["failed"] += 1
            await self.world.update(robot.robot_id, status=RobotStatus.IDLE, current_task=None)
            self.task_queue.requeue(task)

    async def _monitor_loop(self) -> None:
        while self._running:
            await asyncio.sleep(self._monitor_interval)
            failed = await self.monitor.check_failures()
            if failed:
                log.warning("Failed robots detected: %s", failed)

    async def start(self) -> None:
        self._running = True
        asyncio.ensure_future(self._dispatch_loop())
        asyncio.ensure_future(self._monitor_loop())
        log.info("Swarm COO started")

    async def stop(self) -> None:
        self._running = False
        log.info("Swarm COO stopped")

    async def kpis(self) -> Dict:
        fleet = await self.world.snapshot()
        elapsed = time.time() - self._kpis["started_at"]
        throughput = self._kpis["completed"] / (elapsed / 3600) if elapsed > 0 else 0
        return {
            **self._kpis,
            "throughput_per_hour": round(throughput, 2),
            "pending_tasks": len(self.task_queue),
            "fleet": fleet,
            "uptime_s": elapsed,
        }

    async def dispatch(self, request: Dict) -> Dict:
        """JSON-RPC handler for external control."""
        method = request.get("method", "")
        params = request.get("params", {})
        rpc_id = request.get("id")
        try:
            if method == "swarm/submit_task":
                task_id = self.submit_task(
                    params["task_type"], params.get("params", {}),
                    TaskPriority(params.get("priority", 2)),
                    params.get("required_capabilities", []),
                    float(params.get("target_x", 0)), float(params.get("target_y", 0)),
                )
                result = {"task_id": task_id}
            elif method == "swarm/kpis":
                result = await self.kpis()
            elif method == "swarm/fleet":
                result = {"fleet": await self.world.snapshot()}
            elif method == "swarm/pending_tasks":
                result = {"tasks": self.task_queue.pending_tasks()}
            elif method == "swarm/register_robot":
                await self.register_robot(
                    params["robot_id"], params["url"],
                    params.get("capabilities", []),
                    float(params.get("x", 0)), float(params.get("y", 0)),
                )
                result = {"ok": True}
            else:
                return {"jsonrpc": "2.0", "id": rpc_id,
                        "error": {"code": -32601, "message": f"Unknown method: {method}"}}
            return {"jsonrpc": "2.0", "id": rpc_id, "result": result}
        except Exception as exc:
            return {"jsonrpc": "2.0", "id": rpc_id,
                    "error": {"code": -32603, "message": str(exc)}}


async def run_swarm_server(port: int = 9010) -> None:
    from aiohttp import web
    coo = SwarmCOO()
    await coo.start()

    async def handler(req: web.Request) -> web.Response:
        body = await req.json()
        result = await coo.dispatch(body)
        return web.json_response(result)

    app = web.Application()
    app["coo"] = coo
    app.router.add_post("/rpc", handler)
    app.router.add_get("/health", lambda r: web.json_response({"status": "ok"}))
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    log.info("Swarm COO server running on port %d", port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run_swarm_server())
