# pmcp-rust

Rust implementation of the P-MCP protocol, currently split across two
independent crates:

- `pmcp-core/` — protocol core: consensus (Raft), identity, safety,
  transport, networking, plugin system, rate limiting, telemetry,
  Python bindings (`python.rs`).
- `ledger/` (`pmcp-ledger`) — CRDT ledger layer: state, sync,
  partitioning, storage, RPC/API surface.

## Status: real code, not release-ready

Both crates contain real implementations (not stubs). `pmcp-core/src/lib.rs`
declares 18 public modules, `ledger/src/lib.rs` declares 6. Combined,
~350 KB of Rust source with ~66 embedded `#[test]` unit tests.

### Known build issues to resolve before release

- **`pmcp-core/Cargo.toml` misconfigures `pyo3`.** It declares
  `pyo3 = { version = "0.20", features = ["extension-module"] }` as a
  **top-level dependency** (not gated behind a feature). But
  `pmcp-core/src/lib.rs:36` gates `pub mod python;` behind
  `#[cfg(feature = "python")]`, and the `[features]` table only
  declares `default = ["std"]` and `std = []` — there is **no `python`
  feature**. Consequences:
  - `python.rs` (~13 KB) is compiled but never linked in.
  - `extension-module` requires the caller to be building a Python
    extension (specific link flags, Python interpreter available at
    build time); plain `cargo build` on a CI runner without CPython
    dev headers or `PYO3_PYTHON` set will fail or link incorrectly.
  - **Fix**: add a `python = ["pyo3/extension-module"]` feature and
    move `pyo3` behind it (`pyo3 = { version = "0.20", optional = true }`).
    Or, if `pyo3` bindings aren't going to be maintained here, remove
    the dep and the module.
- **No workspace `Cargo.toml`.** `pmcp-core` and `ledger` are two
  independent crates with independent versions. Whether they should
  become members of one Cargo workspace is undecided (see
  `MIGRATION_MAP.md`).
- **`Cargo.lock` present only in `pmcp-core/`, not in `ledger/`.** For a
  library crate that's the usual convention (only apps commit
  `Cargo.lock`), but the asymmetry is worth resolving.
- **No integration tests directory (`tests/`) in either crate**, only
  embedded `#[cfg(test)]` modules.

## Build (once the pyo3 misconfig is resolved)

```bash
cd pmcp-core && cargo build --release && cargo test
cd ../ledger && cargo build --release && cargo test
```

## License

Apache 2.0 (see [`LICENSE`](LICENSE)).
