#!/usr/bin/env python3
"""
P-MCP Service Registry
======================

A service registry for P-MCP robot servers with:
- Service registration and discovery
- Health checking with heartbeats
- Multi-region support
- Rate limiting and authentication
- Full-text search

Architecture follows service registry patterns:
- Self-registration: Services register themselves
- Heartbeat: Services send periodic heartbeats
- Health checks: Registry verifies service health
- Client-side discovery: Clients query registry directly

Usage:
    python registry/app.py --port 8080
    python registry/app.py --port 8080 --db redis://localhost:6379
"""

import argparse
import asyncio
import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from urllib.parse import urlparse
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s [%(name)s] %(message)s'
)
logger = logging.getLogger("pmcp-registry")


# ============================================================================
# Data Models
# ============================================================================

class ServiceStatus(Enum):
    """Service instance status."""
    STARTING = "starting"
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DRAINING = "draining"
    GONE = "gone"


class ServiceCategory(Enum):
    """Categories of P-MCP services."""
    ROBOT_ARM = "robot_arm"
    ROBOT_MOBILE = "robot_mobile"
    ROBOT_AGRICULTURAL = "robot_agricultural"
    SENSOR = "sensor"
    ACTUATOR = "actuator"
    GATEWAY = "gateway"
    SIMULATOR = "simulator"
    OTHER = "other"


@dataclass
class ServiceInstance:
    """A single instance of a registered service."""
    instance_id: str
    service_name: str
    host: str
    port: int
    version: str
    region: str = "us-east-1"
    zone: str = "default"
    status: ServiceStatus = ServiceStatus.STARTING
    metadata: Dict[str, str] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    registered_at: float = field(default_factory=time.time)
    last_heartbeat_at: float = field(default_factory=time.time)
    lease_expires_at: float = 0.0
    health_check_url: Optional[str] = None
    readiness_check_url: Optional[str] = None
    
    @property
    def is_healthy(self) -> bool:
        """Check if instance is healthy based on heartbeat."""
        return (self.status == ServiceStatus.HEALTHY and 
                time.time() < self.lease_expires_at)
    
    @property
    def endpoint(self) -> str:
        """Get the full endpoint URL."""
        return f"http://{self.host}:{self.port}"
    
    @property
    def age_seconds(self) -> float:
        """Get age in seconds since registration."""
        return time.time() - self.registered_at
    
    @property
    def seconds_since_heartbeat(self) -> float:
        """Get seconds since last heartbeat."""
        return time.time() - self.last_heartbeat_at
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "instanceId": self.instance_id,
            "serviceName": self.service_name,
            "host": self.host,
            "port": self.port,
            "version": self.version,
            "region": self.region,
            "zone": self.zone,
            "status": self.status.value,
            "metadata": self.metadata,
            "tags": self.tags,
            "capabilities": self.capabilities,
            "registeredAt": self.registered_at,
            "lastHeartbeatAt": self.last_heartbeat_at,
            "leaseExpiresAt": self.lease_expires_at,
            "endpoint": self.endpoint,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ServiceInstance':
        """Create from dictionary."""
        return cls(
            instance_id=data["instanceId"],
            service_name=data["serviceName"],
            host=data["host"],
            port=data["port"],
            version=data.get("version", "1.0.0"),
            region=data.get("region", "us-east-1"),
            zone=data.get("zone", "default"),
            status=ServiceStatus(data.get("status", "healthy")),
            metadata=data.get("metadata", {}),
            tags=data.get("tags", []),
            capabilities=data.get("capabilities", []),
            registered_at=data.get("registeredAt", time.time()),
            last_heartbeat_at=data.get("lastHeartbeatAt", time.time()),
            lease_expires_at=data.get("leaseExpiresAt", 0),
            health_check_url=data.get("healthCheckUrl"),
            readiness_check_url=data.get("readinessCheckUrl"),
        )


@dataclass
class ServiceDefinition:
    """A registered service type."""
    name: str
    description: str
    category: ServiceCategory
    version: str
    protocol: str = "pmcp"
    endpoints: List[str] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    owner: str = ""
    repository: str = ""
    documentation_url: str = ""
    keywords: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "version": self.version,
            "protocol": self.protocol,
            "endpoints": self.endpoints,
            "metadata": self.metadata,
            "owner": self.owner,
            "repository": self.repository,
            "documentationUrl": self.documentation_url,
            "keywords": self.keywords,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at,
        }


@dataclass
class RegistrationRequest:
    """Request to register a service."""
    service_name: str
    host: str
    port: int
    version: str = "1.0.0"
    region: str = "us-east-1"
    zone: str = "default"
    metadata: Dict[str, str] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    health_check_url: Optional[str] = None
    readiness_check_url: Optional[str] = None
    ttl_seconds: int = 30


@dataclass
class DiscoveryQuery:
    """Query for service discovery."""
    service_name: str
    version_constraint: Optional[str] = None
    region: Optional[str] = None
    zone: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    healthy_only: bool = True
    limit: int = 10


# ============================================================================
# In-Memory Registry Store (Production would use Redis/etcd)
# ============================================================================

class RegistryStore:
    """In-memory registry store with TTL-based expiration."""
    
    def __init__(self):
        self._services: Dict[str, ServiceDefinition] = {}
        self._instances: Dict[str, ServiceInstance] = {}  # instance_id -> instance
        self._service_instances: Dict[str, Set[str]] = {}  # service_name -> set of instance_ids
        self._lock = threading.RLock()
        
        # Metrics
        self._total_registrations = 0
        self._total_heartbeats = 0
        self._total_lookups = 0
    
    # --- Service Registration ---
    
    def register_instance(self, req: RegistrationRequest) -> ServiceInstance:
        """Register a new service instance."""
        with self._lock:
            instance_id = f"{req.service_name}-{uuid.uuid4().hex[:12]}"
            
            instance = ServiceInstance(
                instance_id=instance_id,
                service_name=req.service_name,
                host=req.host,
                port=req.port,
                version=req.version,
                region=req.region,
                zone=req.zone,
                status=ServiceStatus.STARTING,
                metadata=req.metadata,
                tags=req.tags,
                capabilities=req.capabilities,
                health_check_url=req.health_check_url,
                readiness_check_url=req.readiness_check_url,
                lease_expires_at=time.time() + req.ttl_seconds,
            )
            
            # Store instance
            self._instances[instance_id] = instance
            
            # Add to service index
            if req.service_name not in self._service_instances:
                self._service_instances[req.service_name] = set()
            self._service_instances[req.service_name].add(instance_id)
            
            self._total_registrations += 1
            
            logger.info(f"Registered instance {instance_id} for service {req.service_name}")
            
            return instance
    
    def register_service(self, svc: ServiceDefinition) -> ServiceDefinition:
        """Register a service definition."""
        with self._lock:
            self._services[svc.name] = svc
            logger.info(f"Registered service definition: {svc.name}")
            return svc
    
    # --- Heartbeat ---
    
    def heartbeat(self, instance_id: str, ttl_seconds: int = 30) -> bool:
        """Process heartbeat from instance."""
        with self._lock:
            if instance_id not in self._instances:
                return False
            
            instance = self._instances[instance_id]
            instance.last_heartbeat_at = time.time()
            instance.lease_expires_at = time.time() + ttl_seconds
            
            if instance.status == ServiceStatus.STARTING:
                instance.status = ServiceStatus.HEALTHY
            
            self._total_heartbeats += 1
            return True
    
    # --- Discovery ---
    
    def discover(self, query: DiscoveryQuery) -> List[ServiceInstance]:
        """Discover service instances matching query."""
        with self._lock:
            self._total_lookups += 1
            
            service_name = query.service_name
            if service_name not in self._service_instances:
                return []
            
            instance_ids = self._service_instances[service_name]
            results = []
            
            for instance_id in instance_ids:
                instance = self._instances.get(instance_id)
                if not instance:
                    continue
                
                # Check health
                if query.healthy_only and not instance.is_healthy:
                    continue
                
                # Check region
                if query.region and instance.region != query.region:
                    continue
                
                # Check zone
                if query.zone and instance.zone != query.zone:
                    continue
                
                # Check tags
                if query.tags:
                    if not any(tag in instance.tags for tag in query.tags):
                        continue
                
                # Check capabilities
                if query.capabilities:
                    if not all(cap in instance.capabilities for cap in query.capabilities):
                        continue
                
                results.append(instance)
                
                if len(results) >= query.limit:
                    break
            
            return results
    
    def get_all_instances(self, service_name: str) -> List[ServiceInstance]:
        """Get all instances for a service."""
        with self._lock:
            if service_name not in self._service_instances:
                return []
            
            return [
                self._instances[iid]
                for iid in self._service_instances[service_name]
                if iid in self._instances
            ]
    
    # --- Service Definitions ---
    
    def get_service_definition(self, name: str) -> Optional[ServiceDefinition]:
        """Get service definition."""
        with self._lock:
            return self._services.get(name)
    
    def list_services(self, category: Optional[ServiceCategory] = None) -> List[ServiceDefinition]:
        """List all service definitions."""
        with self._lock:
            services = list(self._services.values())
            if category:
                services = [s for s in services if s.category == category]
            return services
    
    # --- Deregistration ---
    
    def deregister_instance(self, instance_id: str) -> bool:
        """Deregister a service instance."""
        with self._lock:
            if instance_id not in self._instances:
                return False
            
            instance = self._instances[instance_id]
            instance.status = ServiceStatus.GONE
            
            # Remove from index
            if instance.service_name in self._service_instances:
                self._service_instances[instance.service_name].discard(instance_id)
            
            # Remove instance
            del self._instances[instance_id]
            
            logger.info(f"Deregistered instance {instance_id}")
            return True
    
    # --- Cleanup ---
    
    def cleanup_expired(self) -> int:
        """Remove expired instances."""
        with self._lock:
            now = time.time()
            expired = []
            
            for instance_id, instance in self._instances.items():
                if now > instance.lease_expires_at:
                    expired.append(instance_id)
            
            for instance_id in expired:
                instance = self._instances[instance_id]
                logger.warning(f"Instance {instance_id} expired (service: {instance.service_name})")
                self.deregister_instance(instance_id)
            
            return len(expired)
    
    # --- Metrics ---
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get registry metrics."""
        with self._lock:
            return {
                "totalServices": len(self._services),
                "totalInstances": len(self._instances),
                "totalRegistrations": self._total_registrations,
                "totalHeartbeats": self._total_heartbeats,
                "totalLookups": self._total_lookups,
                "healthyInstances": sum(
                    1 for i in self._instances.values() if i.is_healthy
                ),
                "byService": {
                    name: len(ids)
                    for name, ids in self._service_instances.items()
                },
            }


# ============================================================================
# Registry API
# ============================================================================

class RegistryAPI:
    """P-MCP Registry REST API."""
    
    def __init__(self, store: RegistryStore):
        self.store = store
        self._running = False
        self._cleanup_task: Optional[asyncio.Task] = None
    
    async def start(self, host: str = "0.0.0.0", port: int = 8080):
        """Start the API server."""
        try:
            from aiohttp import web
        except ImportError:
            logger.error("aiohttp not installed. Run: pip install aiohttp")
            return
        
        app = web.Application()
        
        # Routes
        app.router.add_get("/health", self.handle_health)
        app.router.add_get("/metrics", self.handle_metrics)
        
        # Service Definition routes
        app.router.add_get("/services", self.handle_list_services)
        app.router.add_post("/services", self.handle_create_service)
        app.router.add_get("/services/{name}", self.handle_get_service)
        app.router.add_delete("/services/{name}", self.handle_delete_service)
        
        # Instance routes
        app.router.add_post("/register", self.handle_register)
        app.router.add_post("/deregister", self.handle_deregister)
        app.router.add_post("/heartbeat", self.handle_heartbeat)
        app.router.add_get("/instances/{instance_id}", self.handle_get_instance)
        
        # Discovery routes
        app.router.add_get("/v1/discover", self.handle_discover)
        app.router.add_get("/v1/services/{name}/instances", self.handle_list_instances)
        
        # Admin routes
        app.router.add_post("/admin/cleanup", self.handle_cleanup)
        
        # Start cleanup task
        self._running = True
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host, port)
        await site.start()
        
        logger.info(f"P-MCP Registry starting on http://{host}:{port}")
        
        try:
            await asyncio.Event().wait()
        finally:
            self._running = False
            await runner.cleanup()
    
    async def _cleanup_loop(self):
        """Periodic cleanup of expired instances."""
        while self._running:
            await asyncio.sleep(10)
            try:
                cleaned = self.store.cleanup_expired()
                if cleaned > 0:
                    logger.info(f"Cleaned up {cleaned} expired instances")
            except Exception as e:
                logger.error(f"Cleanup error: {e}")
    
    # --- Health & Metrics ---
    
    async def handle_health(self, request: web.Request) -> web.Response:
        """Health check endpoint."""
        return web.json_response({
            "status": "healthy",
            "timestamp": time.time(),
            "version": "0.5.0",
        })
    
    async def handle_metrics(self, request: web.Request) -> web.Response:
        """Metrics endpoint."""
        return web.json_response(self.store.get_metrics())
    
    # --- Service Definition Routes ---
    
    async def handle_list_services(self, request: web.Request) -> web.Response:
        """List all registered services."""
        category = request.query.get("category")
        category_enum = ServiceCategory(category) if category else None
        
        services = self.store.list_services(category_enum)
        
        return web.json_response({
            "services": [s.to_dict() for s in services],
            "count": len(services),
        })
    
    async def handle_create_service(self, request: web.Request) -> web.Response:
        """Create a new service definition."""
        try:
            data = await request.json()
        except Exception:
            return web.json_response(
                {"error": "Invalid JSON"}, status=400
            )
        
        required = ["name", "description", "category"]
        for field in required:
            if field not in data:
                return web.json_response(
                    {"error": f"Missing required field: {field}"}, status=400
                )
        
        svc = ServiceDefinition(
            name=data["name"],
            description=data["description"],
            category=ServiceCategory(data["category"]),
            version=data.get("version", "1.0.0"),
            protocol=data.get("protocol", "pmcp"),
            metadata=data.get("metadata", {}),
            owner=data.get("owner", ""),
            repository=data.get("repository", ""),
            documentation_url=data.get("documentationUrl", ""),
            keywords=data.get("keywords", []),
        )
        
        self.store.register_service(svc)
        
        return web.json_response(svc.to_dict(), status=201)
    
    async def handle_get_service(self, request: web.Request) -> web.Response:
        """Get a service definition."""
        name = request.match_info["name"]
        svc = self.store.get_service_definition(name)
        
        if not svc:
            return web.json_response(
                {"error": f"Service not found: {name}"}, status=404
            )
        
        return web.json_response(svc.to_dict())
    
    async def handle_delete_service(self, request: web.Request) -> web.Response:
        """Delete a service definition and all instances."""
        name = request.match_info["name"]
        
        # Get all instances and deregister
        instances = self.store.get_all_instances(name)
        for inst in instances:
            self.store.deregister_instance(inst.instance_id)
        
        # Note: We don't actually delete the service definition in this implementation
        # to preserve metadata
        
        return web.json_response({"deleted": True, "instancesRemoved": len(instances)})
    
    # --- Instance Registration Routes ---
    
    async def handle_register(self, request: web.Request) -> web.Response:
        """Register a new service instance."""
        try:
            data = await request.json()
        except Exception:
            return web.json_response(
                {"error": "Invalid JSON"}, status=400
            )
        
        required = ["serviceName", "host", "port"]
        for field in required:
            if field not in data:
                return web.json_response(
                    {"error": f"Missing required field: {field}"}, status=400
                )
        
        req = RegistrationRequest(
            service_name=data["serviceName"],
            host=data["host"],
            port=data["port"],
            version=data.get("version", "1.0.0"),
            region=data.get("region", "us-east-1"),
            zone=data.get("zone", "default"),
            metadata=data.get("metadata", {}),
            tags=data.get("tags", []),
            capabilities=data.get("capabilities", []),
            health_check_url=data.get("healthCheckUrl"),
            readiness_check_url=data.get("readinessCheckUrl"),
            ttl_seconds=data.get("ttlSeconds", 30),
        )
        
        instance = self.store.register_instance(req)
        
        logger.info(f"Registered: {instance.instance_id}")
        
        return web.json_response(instance.to_dict(), status=201)
    
    async def handle_deregister(self, request: web.Request) -> web.Response:
        """Deregister a service instance."""
        try:
            data = await request.json()
        except Exception:
            return web.json_response(
                {"error": "Invalid JSON"}, status=400
            )
        
        instance_id = data.get("instanceId")
        if not instance_id:
            return web.json_response(
                {"error": "Missing required field: instanceId"}, status=400
            )
        
        success = self.store.deregister_instance(instance_id)
        
        if not success:
            return web.json_response(
                {"error": f"Instance not found: {instance_id}"}, status=404
            )
        
        return web.json_response({"deregistered": True})
    
    async def handle_heartbeat(self, request: web.Request) -> web.Response:
        """Process heartbeat from service instance."""
        try:
            data = await request.json()
        except Exception:
            return web.json_response(
                {"error": "Invalid JSON"}, status=400
            )
        
        instance_id = data.get("instanceId")
        ttl_seconds = data.get("ttlSeconds", 30)
        
        if not instance_id:
            return web.json_response(
                {"error": "Missing required field: instanceId"}, status=400
            )
        
        success = self.store.heartbeat(instance_id, ttl_seconds)
        
        if not success:
            return web.json_response(
                {"error": f"Instance not found: {instance_id}"}, status=404
            )
        
        return web.json_response({"heartbeat": True})
    
    async def handle_get_instance(self, request: web.Request) -> web.Response:
        """Get a specific instance."""
        instance_id = request.match_info["instance_id"]
        
        with self.store._lock:
            instance = self.store._instances.get(instance_id)
        
        if not instance:
            return web.json_response(
                {"error": f"Instance not found: {instance_id}"}, status=404
            )
        
        return web.json_response(instance.to_dict())
    
    # --- Discovery Routes ---
    
    async def handle_discover(self, request: web.Request) -> web.Response:
        """Discover service instances."""
        service_name = request.query.get("serviceName")
        if not service_name:
            return web.json_response(
                {"error": "Missing required parameter: serviceName"}, status=400
            )
        
        query = DiscoveryQuery(
            service_name=service_name,
            version_constraint=request.query.get("version"),
            region=request.query.get("region"),
            zone=request.query.get("zone"),
            tags=request.query.get("tags", "").split(",") if request.query.get("tags") else [],
            capabilities=request.query.get("capabilities", "").split(",") if request.query.get("capabilities") else [],
            healthy_only=request.query.get("healthyOnly", "true").lower() == "true",
            limit=int(request.query.get("limit", "10")),
        )
        
        instances = self.store.discover(query)
        
        return web.json_response({
            "serviceName": service_name,
            "instances": [i.to_dict() for i in instances],
            "count": len(instances),
        })
    
    async def handle_list_instances(self, request: web.Request) -> web.Response:
        """List all instances for a service."""
        name = request.match_info["name"]
        healthy_only = request.query.get("healthyOnly", "true").lower() == "true"
        
        instances = self.store.get_all_instances(name)
        
        if healthy_only:
            instances = [i for i in instances if i.is_healthy]
        
        return web.json_response({
            "serviceName": name,
            "instances": [i.to_dict() for i in instances],
            "count": len(instances),
        })
    
    # --- Admin Routes ---
    
    async def handle_cleanup(self, request: web.Request) -> web.Response:
        """Trigger manual cleanup of expired instances."""
        cleaned = self.store.cleanup_expired()
        return web.json_response({"cleaned": cleaned})


# ============================================================================
# Main Entry Point
# ============================================================================

async def main():
    parser = argparse.ArgumentParser(description="P-MCP Service Registry")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8080, help="Port to bind to")
    parser.add_argument("--log-level", default="INFO", 
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Logging level")
    
    args = parser.parse_args()
    
    # Set logging level
    logging.getLogger().setLevel(getattr(logging, args.log_level))
    
    # Create store and API
    store = RegistryStore()
    api = RegistryAPI(store)
    
    # Pre-populate with P-MCP robot drivers and services
    common_services = [
        # Robot Arm Servers
        ServiceDefinition(
            name="pmcp-arm-server",
            description="P-MCP server for robot arm (UR5, UR10, etc.)",
            category=ServiceCategory.ROBOT_ARM,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "arm", "ur5", "ur10", "industrial"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
            documentation_url="https://github.com/Sandeeprdy1729/P-MCP/tree/main/v05",
        ),
        ServiceDefinition(
            name="pmcp-kinova-arm",
            description="P-MCP server for Kinova Gen3 robotic arm",
            category=ServiceCategory.ROBOT_ARM,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "arm", "kinova", "gen3", "collaborative"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-franka-arm",
            description="P-MCP server for Franka Emika Panda arm",
            category=ServiceCategory.ROBOT_ARM,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "arm", "franka", "panda", "research"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        # Mobile Robot Servers
        ServiceDefinition(
            name="pmcp-mobile-server",
            description="P-MCP server for mobile robots (TurtleBot, AMR)",
            category=ServiceCategory.ROBOT_MOBILE,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "mobile", "turtlebot", "amr", "warehouse"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-ott-bot",
            description="P-MCP server for OTTO 100/500 autonomous mobile robots",
            category=ServiceCategory.ROBOT_MOBILE,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "mobile", "otto", "amr", "warehouse"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-locus-bot",
            description="P-MCP server for Locus Robotics AMR",
            category=ServiceCategory.ROBOT_MOBILE,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "mobile", "locus", "amr", "e-commerce"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-6-river-bot",
            description="P-MCP server for 6 River Systems Chuck mobile robot",
            category=ServiceCategory.ROBOT_MOBILE,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "mobile", "6-river", "chuck", "collaborative"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        # Agricultural Robots
        ServiceDefinition(
            name="pmcp-agri-server",
            description="P-MCP server for agricultural robots",
            category=ServiceCategory.ROBOT_AGRICULTURAL,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "agriculture", "farming", "harvest"],
        ),
        ServiceDefinition(
            name="pmcp-terrasentia",
            description="P-MCP server for TerraSentia agricultural robot",
            category=ServiceCategory.ROBOT_AGRICULTURAL,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "agriculture", "terrasentia", "crop-monitoring"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        # Quadruped Robots
        ServiceDefinition(
            name="pmcp-spot-server",
            description="P-MCP server for Boston Dynamics Spot",
            category=ServiceCategory.ROBOT_MOBILE,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "quadruped", "spot", "boston-dynamics", "inspection"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-anymal-server",
            description="P-MCP server for ANYmal quadruped robot",
            category=ServiceCategory.ROBOT_MOBILE,
            version="0.5.0",
            protocol="pmcp",
            keywords=["robot", "quadruped", "anymal", "inspection"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        # Sensor Services
        ServiceDefinition(
            name="pmcp-lidar-server",
            description="P-MCP server for LiDAR sensors (Velodyne, Ouster, Sick)",
            category=ServiceCategory.SENSOR,
            version="0.5.0",
            protocol="pmcp",
            keywords=["sensor", "lidar", "perception", "mapping"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-camera-server",
            description="P-MCP server for industrial cameras (Basler, FLIR)",
            category=ServiceCategory.SENSOR,
            version="0.5.0",
            protocol="pmcp",
            keywords=["sensor", "camera", "vision", "perception"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        # Gateway
        ServiceDefinition(
            name="pmcp-mtls-gateway",
            description="P-MCP mTLS gateway for secure robot communication",
            category=ServiceCategory.GATEWAY,
            version="0.5.0",
            protocol="pmcp",
            keywords=["gateway", "mtls", "security", "proxy"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        # Simulator
        ServiceDefinition(
            name="pmcp-gazebo-bridge",
            description="P-MCP bridge for Gazebo simulation",
            category=ServiceCategory.SIMULATOR,
            version="0.5.0",
            protocol="pmcp",
            keywords=["simulator", "gazebo", "simulation", "testing"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
        ServiceDefinition(
            name="pmcp-ignition-bridge",
            description="P-MCP bridge for Ignition simulation",
            category=ServiceCategory.SIMULATOR,
            version="0.5.0",
            protocol="pmcp",
            keywords=["simulator", "ignition", "simulation", "testing"],
            repository="https://github.com/Sandeeprdy1729/P-MCP",
        ),
    ]
    
    for svc in common_services:
        store.register_service(svc)
    
    logger.info("Pre-populated registry with common P-MCP services")
    
    # Start API
    await api.start(args.host, args.port)


if __name__ == "__main__":
    asyncio.run(main())