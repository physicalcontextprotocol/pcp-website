import React, { useEffect, useState, useCallback } from 'react';

// ─── Types ────────────────────────────────────────────────────────────────

interface Robot {
  robot_id: string;
  host: string;
  port: number;
  status: 'healthy' | 'unhealthy' | 'starting';
  robot_class?: string;
  region?: string;
  registered_at?: number;
  last_heartbeat?: number;
  firmware_ver?: string;
  location?: string;
}

interface RegistryMetrics {
  total: number;
  healthy: number;
  unhealthy: number;
  timestamp: number;
}

// ─── API ─────────────────────────────────────────────────────────────────

const API = '/api/v1';

async function fetchRobots(): Promise<Robot[]> {
  const r = await fetch(`${API}/robots`);
  const data = await r.json();
  return data.robots ?? [];
}

async function fetchMetrics(): Promise<RegistryMetrics> {
  const r = await fetch(`${API}/metrics`);
  return r.json();
}

async function deregisterRobot(robotId: string): Promise<void> {
  await fetch(`${API}/robots/${robotId}`, { method: 'DELETE' });
}

// ─── Components ───────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    healthy: '#22c55e',
    unhealthy: '#ef4444',
    starting: '#f59e0b',
  };
  return (
    <span
      style={{
        display: 'inline-block',
        padding: '2px 10px',
        borderRadius: 12,
        background: colors[status] ?? '#6b7280',
        color: '#fff',
        fontSize: 12,
        fontWeight: 600,
      }}
    >
      {status}
    </span>
  );
}

function RobotCard({ robot, onDeregister }: { robot: Robot; onDeregister: (id: string) => void }) {
  const lastSeen = robot.last_heartbeat
    ? `${Math.round((Date.now() - robot.last_heartbeat) / 1000)}s ago`
    : 'unknown';

  return (
    <div
      style={{
        background: '#1e293b',
        border: '1px solid #334155',
        borderRadius: 10,
        padding: '16px 20px',
        marginBottom: 12,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}
    >
      <div>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>
          {robot.robot_id}
        </div>
        <div style={{ color: '#94a3b8', fontSize: 13 }}>
          {robot.host}:{robot.port}
          {robot.robot_class ? ` · ${robot.robot_class}` : ''}
          {robot.region ? ` · ${robot.region}` : ''}
          {robot.location ? ` · ${robot.location}` : ''}
        </div>
        <div style={{ color: '#64748b', fontSize: 12, marginTop: 4 }}>
          Last heartbeat: {lastSeen}
          {robot.firmware_ver ? ` · fw ${robot.firmware_ver}` : ''}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <StatusBadge status={robot.status} />
        <button
          onClick={() => onDeregister(robot.robot_id)}
          style={{
            background: 'transparent',
            border: '1px solid #ef4444',
            color: '#ef4444',
            borderRadius: 6,
            padding: '4px 10px',
            cursor: 'pointer',
            fontSize: 12,
          }}
        >
          Remove
        </button>
      </div>
    </div>
  );
}

function MetricsBar({ metrics }: { metrics: RegistryMetrics | null }) {
  if (!metrics) return null;
  const pct = metrics.total > 0 ? (metrics.healthy / metrics.total) * 100 : 0;

  return (
    <div
      style={{
        display: 'flex',
        gap: 20,
        background: '#0f172a',
        borderRadius: 10,
        padding: '12px 20px',
        marginBottom: 24,
        border: '1px solid #1e293b',
      }}
    >
      {[
        { label: 'Total', value: metrics.total, color: '#60a5fa' },
        { label: 'Healthy', value: metrics.healthy, color: '#22c55e' },
        { label: 'Unhealthy', value: metrics.unhealthy, color: '#ef4444' },
        { label: 'Health %', value: `${pct.toFixed(0)}%`, color: '#a78bfa' },
      ].map(({ label, value, color }) => (
        <div key={label} style={{ textAlign: 'center', flex: 1 }}>
          <div style={{ fontSize: 22, fontWeight: 700, color }}>{value}</div>
          <div style={{ fontSize: 12, color: '#64748b' }}>{label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────

export default function App() {
  const [robots, setRobots] = useState<Robot[]>([]);
  const [metrics, setMetrics] = useState<RegistryMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      const [r, m] = await Promise.all([fetchRobots(), fetchMetrics()]);
      setRobots(r);
      setMetrics(m);
      setError('');
    } catch (e) {
      setError(`Failed to fetch registry: ${e}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 10_000);
    return () => clearInterval(id);
  }, [refresh]);

  const handleDeregister = async (robotId: string) => {
    if (!window.confirm(`Remove robot ${robotId}?`)) return;
    await deregisterRobot(robotId);
    await refresh();
  };

  const filtered = robots.filter(
    (r) =>
      r.robot_id.toLowerCase().includes(filter.toLowerCase()) ||
      (r.robot_class ?? '').toLowerCase().includes(filter.toLowerCase()) ||
      (r.region ?? '').toLowerCase().includes(filter.toLowerCase()),
  );

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#0f172a',
        color: '#e2e8f0',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        padding: '32px',
      }}
    >
      <header style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, margin: 0 }}>
          P-MCP Fleet Registry
        </h1>
        <p style={{ color: '#64748b', marginTop: 4 }}>
          Physical Model Context Protocol — Robot Discovery
        </p>
      </header>

      {error && (
        <div
          style={{
            background: '#450a0a',
            border: '1px solid #ef4444',
            borderRadius: 8,
            padding: '10px 16px',
            marginBottom: 16,
            color: '#fca5a5',
          }}
        >
          {error}
        </div>
      )}

      <MetricsBar metrics={metrics} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter by robot ID, class, or region..."
          style={{
            background: '#1e293b',
            border: '1px solid #334155',
            color: '#e2e8f0',
            borderRadius: 8,
            padding: '8px 14px',
            width: 320,
            fontSize: 14,
          }}
        />
        <button
          onClick={refresh}
          style={{
            background: '#1d4ed8',
            border: 'none',
            color: '#fff',
            borderRadius: 8,
            padding: '8px 18px',
            cursor: 'pointer',
            fontWeight: 600,
          }}
        >
          Refresh
        </button>
      </div>

      {loading ? (
        <div style={{ color: '#64748b', textAlign: 'center', paddingTop: 60 }}>Loading…</div>
      ) : filtered.length === 0 ? (
        <div style={{ color: '#64748b', textAlign: 'center', paddingTop: 60 }}>
          {robots.length === 0 ? 'No robots registered.' : 'No robots match the filter.'}
        </div>
      ) : (
        filtered.map((r) => (
          <RobotCard key={r.robot_id} robot={r} onDeregister={handleDeregister} />
        ))
      )}
    </div>
  );
}
