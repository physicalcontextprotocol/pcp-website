#!/usr/bin/env python3
"""
P-MCP Registry Client
====================

Python client library for interacting with the P-MCP Service Registry.

Usage:
    from registry.client import RegistryClient
    
    client = RegistryClient("http://localhost:8080")
    
    # Register a robot server
    instance = await client.register(
        service_name="my-robot",
        host="192.168.1.100",
        port=8080,
        version="0.5.0",
    )
    
    # Discover services
    instances = await client.discover("pmcp-arm-server")
    
    # Heartbeat
    await client.heartbeat(instance.instance_id)
"""

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin

try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False

logger = logging.getLogger("pmcp-registry-client")


# ============================================================================
# Data Models
# ============================================================================

@dataclass
class ServiceInstance:
    """A registered service instance."""
    instance_id: str
    service_name: str
    host: str
    port: int
    version: str
    region: str
    zone: str
    status: str
    registered_at: float
    last_heartbeat_at: float
    endpoint: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ServiceInstance':
        return cls(
            instance_id=data["instanceId"],
            service_name=data["serviceName"],
            host=data["host"],
            port=data["port"],
            version=data.get("version", "1.0.0"),
            region=data.get("region", "us-east-1"),
            zone=data.get("zone", "default"),
            status=data.get("status", "healthy"),
            registered_at=data.get("registeredAt", 0),
            last_heartbeat_at=data.get("lastHeartbeatAt", 0),
            endpoint=data.get("endpoint", f"http://{data['host']}:{data['port']}"),
        )


@dataclass
class ServiceDefinition:
    """A registered service type."""
    name: str
    description: str
    category: str
    version: str
    protocol: str
    owner: str
    repository: str
    keywords: List[str]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ServiceDefinition':
        return cls(
            name=data["name"],
            description=data["description"],
            category=data.get("category", "other"),
            version=data.get("version", "1.0.0"),
            protocol=data.get("protocol", "pmcp"),
            owner=data.get("owner", ""),
            repository=data.get("repository", ""),
            keywords=data.get("keywords", []),
        )


@dataclass
class DiscoveryResult:
    """Result of a discovery query."""
    service_name: str
    instances: List[ServiceInstance]
    count: int


# ============================================================================
# Exceptions
# ============================================================================

class RegistryError(Exception):
    """Base exception for registry errors."""
    pass


class RegistryNotFoundError(RegistryError):
    """Requested resource not found."""
    pass


class RegistryAuthError(RegistryError):
    """Authentication failed."""
    pass


class RegistryTimeoutError(RegistryError):
    """Request timed out."""
    pass


# ============================================================================
# Client
# ============================================================================

class RegistryClient:
    """Client for the P-MCP Service Registry."""
    
    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        timeout: float = 30.0,
        retry_count: int = 3,
        retry_delay: float = 1.0,
    ):
        """
        Initialize the registry client.
        
        Args:
            base_url: Base URL of the registry API
            timeout: Request timeout in seconds
            retry_count: Number of retries for failed requests
            retry_delay: Delay between retries in seconds
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.retry_count = retry_count
        self.retry_delay = retry_delay
        
        self._session: Optional[Any] = None
        self._connected = False
        
        logger.info(f"Registry client initialized: {base_url}")
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()
    
    async def connect(self):
        """Connect to the registry."""
        if not HAS_AIOHTTP:
            raise RegistryError("aiohttp not installed. Run: pip install aiohttp")
        
        timeout = aiohttp.ClientTimeout(total=self.timeout)
        self._session = aiohttp.ClientSession(timeout=timeout)
        self._connected = True
        
        # Verify connection with health check
        try:
            await self.health()
            logger.info("Connected to registry")
        except Exception as e:
            await self.disconnect()
            raise RegistryError(f"Failed to connect: {e}")
    
    async def disconnect(self):
        """Disconnect from the registry."""
        if self._session:
            await self._session.close()
            self._session = None
        self._connected = False
        logger.info("Disconnected from registry")
    
    def _check_connected(self):
        """Check if connected."""
        if not self._connected:
            raise RegistryError("Not connected. Call connect() first.")
    
    async def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make a request to the registry."""
        self._check_connected()
        
        url = urljoin(self.base_url, path)
        
        for attempt in range(self.retry_count):
            try:
                async with self._session.request(
                    method,
                    url,
                    params=params,
                    json=json_data,
                ) as response:
                    if response.status == 404:
                        raise RegistryNotFoundError(f"Resource not found: {path}")
                    
                    if response.status == 401:
                        raise RegistryAuthError("Authentication required")
                    
                    if response.status >= 400:
                        text = await response.text()
                        raise RegistryError(f"HTTP {response.status}: {text}")
                    
                    return await response.json()
                    
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                if attempt < self.retry_count - 1:
                    logger.warning(f"Request failed (attempt {attempt+1}): {e}")
                    await asyncio.sleep(self.retry_delay)
                else:
                    raise RegistryTimeoutError(f"Request failed after {self.retry_count} attempts: {e}")
    
    # --- Health & Metrics ---
    
    async def health(self) -> Dict[str, Any]:
        """Check registry health."""
        return await self._request("GET", "/health")
    
    async def metrics(self) -> Dict[str, Any]:
        """Get registry metrics."""
        return await self._request("GET", "/metrics")
    
    # --- Service Registration ---
    
    async def register(
        self,
        service_name: str,
        host: str,
        port: int,
        version: str = "1.0.0",
        region: str = "us-east-1",
        zone: str = "default",
        metadata: Optional[Dict[str, str]] = None,
        tags: Optional[List[str]] = None,
        capabilities: Optional[List[str]] = None,
        health_check_url: Optional[str] = None,
        readiness_check_url: Optional[str] = None,
        ttl_seconds: int = 30,
    ) -> ServiceInstance:
        """
        Register a new service instance.
        
        Args:
            service_name: Name of the service
            host: Hostname or IP address
            port: Port number
            version: Service version
            region: Region identifier
            zone: Zone identifier
            metadata: Additional metadata
            tags: List of tags
            capabilities: List of capabilities
            health_check_url: URL for health checks
            readiness_check_url: URL for readiness checks
            ttl_seconds: TTL for lease in seconds
        
        Returns:
            ServiceInstance: The registered instance
        """
        data = {
            "serviceName": service_name,
            "host": host,
            "port": port,
            "version": version,
            "region": region,
            "zone": zone,
            "metadata": metadata or {},
            "tags": tags or [],
            "capabilities": capabilities or [],
            "healthCheckUrl": health_check_url,
            "readinessCheckUrl": readiness_check_url,
            "ttlSeconds": ttl_seconds,
        }
        
        result = await self._request("POST", "/register", json_data=data)
        
        logger.info(f"Registered instance: {result['instanceId']}")
        
        return ServiceInstance.from_dict(result)
    
    async def deregister(self, instance_id: str) -> bool:
        """
        Deregister a service instance.
        
        Args:
            instance_id: ID of the instance to deregister
        
        Returns:
            bool: True if deregistered successfully
        """
        result = await self._request("POST", "/deregister", json_data={
            "instanceId": instance_id,
        })
        
        logger.info(f"Deregistered instance: {instance_id}")
        
        return result.get("deregistered", False)
    
    async def heartbeat(
        self,
        instance_id: str,
        ttl_seconds: int = 30,
    ) -> bool:
        """
        Send heartbeat for a service instance.
        
        Args:
            instance_id: ID of the instance
            ttl_seconds: New TTL for the lease
        
        Returns:
            bool: True if heartbeat was accepted
        """
        result = await self._request("POST", "/heartbeat", json_data={
            "instanceId": instance_id,
            "ttlSeconds": ttl_seconds,
        })
        
        return result.get("heartbeat", False)
    
    # --- Service Definition ---
    
    async def create_service(
        self,
        name: str,
        description: str,
        category: str,
        version: str = "1.0.0",
        protocol: str = "pmcp",
        owner: str = "",
        repository: str = "",
        documentation_url: str = "",
        keywords: Optional[List[str]] = None,
    ) -> ServiceDefinition:
        """
        Create a service definition.
        
        Args:
            name: Service name
            description: Service description
            category: Service category
            version: Service version
            protocol: Protocol name
            owner: Owner organization
            repository: Repository URL
            documentation_url: Documentation URL
            keywords: List of keywords
        
        Returns:
            ServiceDefinition: The created service definition
        """
        data = {
            "name": name,
            "description": description,
            "category": category,
            "version": version,
            "protocol": protocol,
            "owner": owner,
            "repository": repository,
            "documentationUrl": documentation_url,
            "keywords": keywords or [],
        }
        
        result = await self._request("POST", "/services", json_data=data)
        
        logger.info(f"Created service definition: {name}")
        
        return ServiceDefinition.from_dict(result)
    
    async def get_service(self, name: str) -> ServiceDefinition:
        """
        Get a service definition.
        
        Args:
            name: Service name
        
        Returns:
            ServiceDefinition: The service definition
        """
        result = await self._request("GET", f"/services/{name}")
        
        return ServiceDefinition.from_dict(result)
    
    async def list_services(
        self,
        category: Optional[str] = None,
    ) -> List[ServiceDefinition]:
        """
        List all service definitions.
        
        Args:
            category: Optional category filter
        
        Returns:
            List[ServiceDefinition]: List of service definitions
        """
        params = {}
        if category:
            params["category"] = category
        
        result = await self._request("GET", "/services", params=params)
        
        return [ServiceDefinition.from_dict(s) for s in result.get("services", [])]
    
    # --- Service Discovery ---
    
    async def discover(
        self,
        service_name: str,
        version: Optional[str] = None,
        region: Optional[str] = None,
        zone: Optional[str] = None,
        tags: Optional[List[str]] = None,
        capabilities: Optional[List[str]] = None,
        healthy_only: bool = True,
        limit: int = 10,
    ) -> DiscoveryResult:
        """
        Discover service instances.
        
        Args:
            service_name: Name of service to discover
            version: Version constraint
            region: Region filter
            zone: Zone filter
            tags: Tag filter
            capabilities: Capability filter
            healthy_only: Only return healthy instances
            limit: Maximum number of instances
        
        Returns:
            DiscoveryResult: Discovery results
        """
        params = {
            "serviceName": service_name,
            "limit": limit,
            "healthyOnly": str(healthy_only).lower(),
        }
        
        if version:
            params["version"] = version
        if region:
            params["region"] = region
        if zone:
            params["zone"] = zone
        if tags:
            params["tags"] = ",".join(tags)
        if capabilities:
            params["capabilities"] = ",".join(capabilities)
        
        result = await self._request("GET", "/v1/discover", params=params)
        
        instances = [
            ServiceInstance.from_dict(i)
            for i in result.get("instances", [])
        ]
        
        return DiscoveryResult(
            service_name=service_name,
            instances=instances,
            count=result.get("count", 0),
        )
    
    async def list_instances(
        self,
        service_name: str,
        healthy_only: bool = True,
    ) -> List[ServiceInstance]:
        """
        List all instances for a service.
        
        Args:
            service_name: Name of the service
            healthy_only: Only return healthy instances
        
        Returns:
            List[ServiceInstance]: List of instances
        """
        params = {}
        if healthy_only:
            params["healthyOnly"] = "true"
        
        result = await self._request(
            "GET",
            f"/v1/services/{service_name}/instances",
            params=params,
        )
        
        return [ServiceInstance.from_dict(i) for i in result.get("instances", [])]
    
    async def get_instance(self, instance_id: str) -> ServiceInstance:
        """
        Get a specific instance.
        
        Args:
            instance_id: ID of the instance
        
        Returns:
            ServiceInstance: The instance
        """
        result = await self._request("GET", f"/instances/{instance_id}")
        
        return ServiceInstance.from_dict(result)
    
    # --- Admin ---
    
    async def cleanup(self) -> int:
        """
        Trigger cleanup of expired instances.
        
        Returns:
            int: Number of instances cleaned up
        """
        result = await self._request("POST", "/admin/cleanup")
        
        return result.get("cleaned", 0)


# ============================================================================
# Convenience Functions
# ============================================================================

async def quick_register(
    registry_url: str,
    service_name: str,
    host: str,
    port: int,
    **kwargs,
) -> ServiceInstance:
    """
    Quickly register a service and keep it alive.
    
    This is a convenience function that registers a service
    and starts sending heartbeats automatically.
    
    Args:
        registry_url: Registry URL
        service_name: Service name
        host: Host
        port: Port
        **kwargs: Additional registration parameters
    
    Returns:
        ServiceInstance: The registered instance
    """
    client = RegistryClient(registry_url)
    
    try:
        await client.connect()
        
        # Register
        instance = await client.register(
            service_name=service_name,
            host=host,
            port=port,
            **kwargs,
        )
        
        # Start heartbeat task
        async def heartbeat_loop():
            while True:
                await asyncio.sleep(15)  # Heartbeat every 15 seconds
                try:
                    await client.heartbeat(instance.instance_id)
                except Exception as e:
                    logger.warning(f"Heartbeat failed: {e}")
        
        asyncio.create_task(heartbeat_loop())
        
        return instance
        
    except Exception:
        await client.disconnect()
        raise


# ============================================================================
# Example Usage
# ============================================================================

async def main():
    """Example usage of the registry client."""
    
    async with RegistryClient("http://localhost:8080") as client:
        # Check health
        health = await client.health()
        print(f"Registry: {health['status']}")
        
        # List available services
        services = await client.list_services()
        print(f"Available services: {len(services)}")
        for svc in services:
            print(f"  - {svc.name}: {svc.description}")
        
        # Discover a service
        result = await client.discover("pmcp-arm-server")
        print(f"Found {result.count} instances")
        
        # Register a new instance
        instance = await client.register(
            service_name="my-custom-server",
            host="192.168.1.100",
            port=8080,
            version="0.5.0",
            tags=["custom", "experimental"],
            capabilities=["move_to", "gripper"],
        )
        print(f"Registered: {instance.instance_id}")
        
        # Send heartbeat
        await client.heartbeat(instance.instance_id)
        print("Heartbeat sent")
        
        # Get metrics
        metrics = await client.metrics()
        print(f"Total instances: {metrics.get('totalInstances', 0)}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())