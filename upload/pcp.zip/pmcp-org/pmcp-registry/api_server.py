"""
P-MCP Registry — REST API Extension
=====================================
Adds FastAPI-compatible REST endpoints on top of the existing registry
for the web dashboard and external integrations.

Security notes for operators
----------------------------
- No authentication is enforced. Deploy behind a reverse proxy that
  provides mTLS or a bearer-token gate before exposing to any untrusted
  network.
- CORS is controlled by the PMCP_REGISTRY_CORS_ORIGIN environment
  variable. Default is empty (no CORS header emitted) so browsers on
  other origins cannot call state-changing endpoints. Set it to "*"
  only for local development.
- JSON body size is capped at 1 MiB.
- host/port sent to /register are still not validated against an
  allowlist — do not expose /register to callers you do not trust.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from aiohttp import web

log = logging.getLogger("pmcp.registry.api")

MAX_JSON_BYTES = 1 * 1024 * 1024  # 1 MiB
CORS_ORIGIN = os.environ.get("PMCP_REGISTRY_CORS_ORIGIN", "").strip()

_SPA_DIST = Path(__file__).resolve().parent / "frontend" / "dist"


# ─────────────────────────────────────────────────────────────────────────────
#  REST API Routes (aiohttp)
# ─────────────────────────────────────────────────────────────────────────────

def create_api_app(registry) -> web.Application:
    """Build an aiohttp Application that wraps the in-memory registry."""
    app = web.Application(
        middlewares=[_cors_middleware],
        client_max_size=MAX_JSON_BYTES,
    )
    app["registry"] = registry

    router = app.router
    # Robots
    router.add_get("/api/v1/robots", list_robots)
    router.add_get("/api/v1/robots/{robot_id}", get_robot)
    router.add_post("/api/v1/robots/register", register_robot)
    router.add_delete("/api/v1/robots/{robot_id}", deregister_robot)
    router.add_post("/api/v1/robots/{robot_id}/heartbeat", heartbeat)
    # Discovery
    router.add_get("/api/v1/discover", discover)
    # Metrics
    router.add_get("/api/v1/metrics", api_metrics)
    # Health
    router.add_get("/health", health)
    # Static (React SPA)
    router.add_get("/", serve_spa)
    if _SPA_DIST.is_dir():
        router.add_static(
            "/static",
            path=str(_SPA_DIST),
            name="static",
            show_index=False,
        )

    return app


@web.middleware
async def _cors_middleware(request: web.Request, handler):
    resp = await handler(request)
    if CORS_ORIGIN:
        resp.headers["Access-Control-Allow-Origin"] = CORS_ORIGIN
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
    return resp


# ─────────────────────────────────────────────────────────────────────────────
#  Handlers
# ─────────────────────────────────────────────────────────────────────────────

async def health(request: web.Request) -> web.Response:
    registry = request.app["registry"]
    stats = registry.get_stats() if hasattr(registry, "get_stats") else {}
    return web.json_response({"status": "ok", "timestamp": int(time.time() * 1000), **stats})


async def list_robots(request: web.Request) -> web.Response:
    """GET /api/v1/robots  — list all registered robots."""
    registry = request.app["registry"]
    robots = registry.list_services() if hasattr(registry, "list_services") else []

    status_filter = request.rel_url.query.get("status")
    class_filter = request.rel_url.query.get("robot_class")
    region_filter = request.rel_url.query.get("region")

    if status_filter:
        robots = [r for r in robots if r.get("status") == status_filter]
    if class_filter:
        robots = [r for r in robots if r.get("robot_class") == class_filter]
    if region_filter:
        robots = [r for r in robots if r.get("region") == region_filter]

    return web.json_response({
        "robots": robots,
        "total": len(robots),
        "timestamp": int(time.time() * 1000),
    })


async def get_robot(request: web.Request) -> web.Response:
    """GET /api/v1/robots/{robot_id}"""
    registry = request.app["registry"]
    robot_id = request.match_info["robot_id"]
    robot = registry.get_service(robot_id) if hasattr(registry, "get_service") else None
    if robot is None:
        raise web.HTTPNotFound(reason=f"Robot {robot_id} not found")
    return web.json_response(robot)


async def register_robot(request: web.Request) -> web.Response:
    """POST /api/v1/robots/register"""
    registry = request.app["registry"]
    try:
        body = await request.json()
    except Exception:
        raise web.HTTPBadRequest(reason="Invalid JSON body")

    required = {"robot_id", "host", "port"}
    missing = required - body.keys()
    if missing:
        raise web.HTTPBadRequest(reason=f"Missing fields: {missing}")

    robot_id = str(body["robot_id"])
    result = registry.register(
        robot_id=robot_id,
        host=str(body["host"]),
        port=int(body["port"]),
        metadata=body,
    ) if hasattr(registry, "register") else {"registered": True, "robot_id": robot_id}

    return web.json_response(result, status=201)


async def deregister_robot(request: web.Request) -> web.Response:
    """DELETE /api/v1/robots/{robot_id}"""
    registry = request.app["registry"]
    robot_id = request.match_info["robot_id"]
    if hasattr(registry, "deregister"):
        registry.deregister(robot_id)
    return web.json_response({"deregistered": True, "robot_id": robot_id})


async def heartbeat(request: web.Request) -> web.Response:
    """POST /api/v1/robots/{robot_id}/heartbeat"""
    registry = request.app["registry"]
    robot_id = request.match_info["robot_id"]
    if hasattr(registry, "heartbeat"):
        registry.heartbeat(robot_id)
    return web.json_response({"robot_id": robot_id, "timestamp": int(time.time() * 1000)})


async def discover(request: web.Request) -> web.Response:
    """GET /api/v1/discover?robot_class=arm&region=us-east-1"""
    registry = request.app["registry"]
    query = dict(request.rel_url.query)
    robots = registry.discover(query) if hasattr(registry, "discover") else []
    return web.json_response({
        "query": query,
        "results": robots,
        "count": len(robots),
    })


async def api_metrics(request: web.Request) -> web.Response:
    """GET /api/v1/metrics"""
    registry = request.app["registry"]
    metrics = registry.metrics() if hasattr(registry, "metrics") else {}
    return web.json_response(metrics)


async def serve_spa(request: web.Request) -> web.Response:
    """Serve the React SPA index.html."""
    spa_index = _SPA_DIST / "index.html"
    if spa_index.is_file():
        return web.Response(
            text=spa_index.read_text(encoding="utf-8"),
            content_type="text/html",
        )
    return web.Response(
        text=(
            "<h1>P-MCP Registry</h1>"
            "<p>Frontend not built. Run: <code>cd frontend &amp;&amp; "
            "npm install &amp;&amp; npm run build</code></p>"
        ),
        content_type="text/html",
    )


# ─────────────────────────────────────────────────────────────────────────────
#  Simple In-Memory Registry (standalone fallback)
# ─────────────────────────────────────────────────────────────────────────────

class InMemoryRegistry:
    """Thread-safe in-memory registry for development/testing."""

    def __init__(self, heartbeat_ttl_ms: int = 60_000):
        self._robots: Dict[str, Dict[str, Any]] = {}
        self._last_heartbeat: Dict[str, int] = {}
        self._ttl = heartbeat_ttl_ms

    def register(self, robot_id: str, host: str, port: int, metadata: Dict[str, Any] = None) -> Dict:
        now = int(time.time() * 1000)
        record = {
            "robot_id": robot_id,
            "host": host,
            "port": port,
            "status": "healthy",
            "registered_at": now,
            "last_heartbeat": now,
            **(metadata or {}),
        }
        self._robots[robot_id] = record
        self._last_heartbeat[robot_id] = now
        log.info("Registered robot %s at %s:%d", robot_id, host, port)
        return {"registered": True, "robot_id": robot_id}

    def deregister(self, robot_id: str) -> None:
        self._robots.pop(robot_id, None)
        self._last_heartbeat.pop(robot_id, None)

    def heartbeat(self, robot_id: str) -> None:
        now = int(time.time() * 1000)
        self._last_heartbeat[robot_id] = now
        if robot_id in self._robots:
            self._robots[robot_id]["last_heartbeat"] = now
            self._robots[robot_id]["status"] = "healthy"

    def get_service(self, robot_id: str) -> Optional[Dict]:
        return self._robots.get(robot_id)

    def list_services(self) -> List[Dict]:
        now = int(time.time() * 1000)
        result = []
        for robot_id, record in self._robots.items():
            last_hb = self._last_heartbeat.get(robot_id, 0)
            r = dict(record)
            r["status"] = "healthy" if (now - last_hb) < self._ttl else "unhealthy"
            result.append(r)
        return result

    def discover(self, query: Dict[str, str]) -> List[Dict]:
        services = self.list_services()
        for key, value in query.items():
            services = [s for s in services if str(s.get(key, "")) == value]
        return services

    def metrics(self) -> Dict:
        services = self.list_services()
        return {
            "total": len(services),
            "healthy": sum(1 for s in services if s["status"] == "healthy"),
            "unhealthy": sum(1 for s in services if s["status"] == "unhealthy"),
            "timestamp": int(time.time() * 1000),
        }

    def get_stats(self) -> Dict:
        return self.metrics()

    async def expire_loop(self) -> None:
        """Background coroutine to expire stale entries."""
        while True:
            await asyncio.sleep(30)
            now = int(time.time() * 1000)
            stale = [
                rid for rid, ts in list(self._last_heartbeat.items())
                if (now - ts) > self._ttl * 3
            ]
            for rid in stale:
                self.deregister(rid)
                log.info("Expired stale robot %s", rid)


# ─────────────────────────────────────────────────────────────────────────────
#  Entry Point
# ─────────────────────────────────────────────────────────────────────────────

async def main(port: int = 8888) -> None:
    registry = InMemoryRegistry()
    app = create_api_app(registry)
    asyncio.create_task(registry.expire_loop())

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    log.info("P-MCP Registry running on http://0.0.0.0:%d", port)
    await asyncio.Event().wait()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8888)
    args = parser.parse_args()
    asyncio.run(main(args.port))
