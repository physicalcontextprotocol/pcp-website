# pmcp-registry

An HTTP registry for P-MCP servers/plugins and a lightweight
Vite/React dashboard for browsing it.

## Contents

- `app.py` — main aiohttp registry (~940 LOC). Endpoints:
  `/health`, `/metrics`, `/services`, `/services/{name}`, `/register`,
  `/deregister`, `/heartbeat`, `/instances/{id}`,
  `/v1/discover`, `/v1/services/{name}/instances`, `/admin/cleanup`.
  Defaults: `host=0.0.0.0 port=8080`.
- `api_server.py` — a smaller **parallel** aiohttp app (~280 LOC)
  serving `/api/v1/robots*`, `/api/v1/discover`, `/api/v1/metrics`,
  `/health`. Defaults: port `8888`. It also serves the built React
  frontend from `frontend/dist`. This app is **not** wired into
  `app.py`; they are two disjoint services with different data
  models. The frontend talks to this smaller app.
- `client.py` — async HTTP client SDK targeting `app.py`.
- `frontend/` — minimal Vite + React 18 + TypeScript SPA with two
  source files. Talks to `api_server.py`.

## Run

```bash
pip install aiohttp
python app.py            # port 8080
python api_server.py     # port 8888 (also serves frontend/dist if built)
```

For the frontend:

```bash
cd frontend
npm install
npm run build            # writes frontend/dist/
npm run dev              # or: dev server on http://localhost:5173
```

## Honest limitations — do not expose to untrusted networks yet

- **No authentication.** `app.py`'s docstring mentions "rate limiting
  and authentication"; the code has neither. `/admin/cleanup` and
  `DELETE /services/{name}` are open. `client.py` defines
  `RegistryAuthError` but the server never issues 401s.
- **CORS wildcard on state-changing verbs.** `api_server.py` sets
  `Access-Control-Allow-Origin: *` and permits `POST`, `DELETE` from
  any origin. Any web page reaching the port can register or
  deregister robots.
- **No request-size limit.** All handlers call `await request.json()`
  with aiohttp defaults — trivial DoS via large bodies.
- **No host/port validation on `register`.** A caller can register a
  service instance pointing at `169.254.169.254` or any internal
  address; `discover()` will hand that back to any client, forming an
  SSRF pivot once someone builds a proxy on top.
- **Static-file listing enabled.** `api_server.py` mounts
  `frontend/dist` with `show_index=True`, so directory contents are
  browsable.
- **Two disjoint apps.** `app.py` and `api_server.py` do not share a
  store; a service registered in one is not visible from the other.
  The frontend only talks to `api_server.py`. The intended split
  between them is not documented.
- **Frontend `dist` path assumes pre-split layout.**
  `api_server.py` serves from a path relative to the pre-split
  monorepo (`registry/frontend/dist`); expect a small path adjustment
  when running from the current layout.

Before public release, at minimum: add an auth middleware (token or
mTLS), lock CORS down to known origins, cap JSON body size, and
validate `host`/`port` against an allowlist.

## Status

Experimental. Not on the v0.5 shipping surface.

## License

Apache 2.0 (see [`LICENSE`](LICENSE)).
