# Security policy

## Reporting a vulnerability

Please **do not** open a public GitHub issue for a suspected
vulnerability in any P-MCP sub-project.

Instead, email the maintainers privately with the details:

1. A description of the vulnerability and its impact.
2. Steps to reproduce, ideally with a minimal proof-of-concept.
3. Any known affected versions or sub-projects
   (`pmcp-python`, `pmcp-registry`, …).
4. Your suggested severity, if you'd like to propose one.

Contact: open a security advisory via GitHub
(<https://github.com/Sandeeprdy1729/P-MCP/security/advisories/new>) if
this repository is on github.com by the time you're reading this;
otherwise contact the maintainer address listed in
`pmcp-python/pyproject.toml`.

We will acknowledge receipt within **5 business days** and aim to
publish a fix or mitigation within **90 days** for high-severity issues,
sooner for actively exploited ones.

## Supported versions

The v0.5 line of `pmcp-python` (the Python SDK) is the currently
supported version. Older lines (`v01`–`v04`, preserved in
`pmcp-labs/`) are **not** supported and will not receive security
updates.

Other sub-projects (`pmcp-typescript`, `pmcp-rust`, `pmcp-registry`,
`pmcp-safety`, `pmcp-servers`, `pmcp-labs`) are pre-release. Their
security guarantees are best-effort until each carries its own
supported-version table. See the sub-project READMEs for their honest
maturity assessments — several of them (in particular
`pmcp-registry` and `pmcp-safety`'s TEE attestator) explicitly call
out known unsafe defaults and should not be exposed to untrusted
networks yet.

## What is in scope

- Correctness or safety-pipeline bypasses in the P-MCP protocol
  (`pmcp-spec`) or the shipping v05 code
  (`pmcp-python/v05/`).
- Auth, authz, injection, deserialization, resource-exhaustion, or
  SSRF issues in `pmcp-registry` and other network-facing components.
- Supply-chain issues in the SDKs (`pmcp-python`, `pmcp-typescript`,
  `pmcp-rust`).
- Secrets or credentials committed to the repository.

## What is not in scope

- Placeholder mock code that is clearly labelled as such (e.g.
  `pmcp-safety/tee-attestator/*` currently ships `MOCK_QUOTE`; that is
  a known limitation, not a vulnerability).
- Examples or demos under `pmcp-servers/examples/` and
  `pmcp-labs/` — these are illustrative.
- Docker/compose files under `pmcp-labs/infra/` — these are broken
  post-split and are being reworked.
