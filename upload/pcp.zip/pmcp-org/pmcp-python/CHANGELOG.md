# Changelog — pmcp-python

Changes to the Python SDK (`pip install pmcp`). Org-level changes live
in [`../CHANGELOG.md`](../CHANGELOG.md).

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added
- Optional Gate 4 — `HNNConservationRule` checks Hamiltonian energy conservation
  via a trained neural network (`H(q, p) → ℜ`). Off by default; activate with
  `pip install pmcp[hnn]` and pass `hnn_rule=` to `SafetyMiddleware`.
- New extra: `pip install pmcp[hnn]` (torch + numpy).
- 12 new tests for Gate 4: off-by-default, opt-in, consistent motion passes,
  conservation violation surfaces warning, stats tracking.
- `tests/__init__.py` (and one per subdirectory) so pytest imports the
  suite as a package.

### Changed
- `SafetyMiddleware.check()` now returns all accumulated warnings (not just
  shadow or constitution) — HNN WARNING-severity messages appear in the
  violations list without blocking the call.
- `[tool.setuptools.packages.find]` reduced from 19 include patterns to
  three (`v05*`, `pmcp*`, `sdk*`), matching what actually lives in this
  package.

### Removed
- Six broken `[project.scripts]` entry points (`pmcp-hub`,
  `pmcp-marketplace`, `pmcp-depin`, `pmcp-multisig`, `pmcp-swarm-coo`,
  `pmcp-compliance`) whose target modules moved out of this package
  during the pmcp-org split and whose target functions were coroutines
  in any case. Only `pmcp-server`, `pmcp-demo`, `pmcp-registry`
  remain — the three that back the shipping `v05/` code.

### Fixed
- `pyproject.toml` `readme = "docs/README.md"` pointed at a directory
  that does not exist here; corrected to `README.md`.

## [0.5.0] — 2026-06-07

The first release of the v0.5 line: MCP 2024-11-05 wire compatibility with a
mandatory three-gate safety pipeline. This release also marks a deliberate
scope cut: many experimental features from earlier versions were removed so
the protocol surface is small, testable, and honest about what it ships.

### Added
- `PMCPServer` — JSON-RPC 2.0 server over stdio and HTTP, exposing robot
  actuations as MCP tools, sensors as MCP resources, and mission templates
  as MCP prompts.
- `PMCPClient` — client with `connect_stdio`, `connect_http`, and
  `connect_server` (in-process) transports.
- `SafetyConstitution` with 6 default rules: speed limit, floor guard,
  workspace box, energy budget, human proximity, E-Stop, plus an optional
  force-limit rule.
- `ShadowSimulator` — three-engine ladder: PyBullet → 6-DOF forward-kinematic
  reachability → geometric bounding-box. Each preview reports which engine
  actually ran.
- `pmcp_kinematics` — DH-parameter forward kinematics for 6-DOF arms, with a
  UR5e preset, joint-limit checking, and reachability tests.
- `pmcp_replay` — recorded-trajectory replay harness. JSONL in, pipeline out,
  with a canonical pick-and-place reference trajectory and an unsafe
  trajectory that the pipeline correctly blocks.
- `PMCPRegistry` — in-process + HTTP-backed fleet registry, MCP registry
  format compatible.
- `RobotIdentity` — W3C DID + Ed25519 (via `cryptography`).
- Three console-script entry points: `pmcp-server`, `pmcp-demo`,
  `pmcp-registry`.
- Three reference robot servers (arm, mobile, agricultural) as illustrative
  clients of the decorator API.
- 213-test suite with 82% coverage on the shipping `v05/` code.
- Dockerfile and docker-compose for the reference stack.

### Changed
- **Scope cut**: many non-shipping top-level modules removed from the
  packaged wheel (cloud, SDKs in Rust/TypeScript, marketplace, depin,
  multisig, swarm, compliance, edge, ledger, registry-server,
  simulator, community, reference_impl, tee-attestator,
  physics-federation, gateway, safety-loop, ros2-bridge). Earlier
  protocol versions (v0.1–v0.4) are preserved in `pmcp-labs/` for
  reference.
- **Core dependencies reduced** from `cryptography + torch + numpy` to just
  `cryptography`. The shadow sim works without numpy using a pure-Python
  math path; numpy/pybullet are now optional extras.
- **README** rewritten to be honest about scope: drops the "USB-C for Mars"
  framing and the long "Planned" list, focuses on what `pip install pmcp`
  actually delivers.

### Fixed
- `pyproject.toml` build backend was `setuptools.backends.legacy:build`, a
  non-existent module that made `pip install pmcp` fail silently. Now
  `setuptools.build_meta`.
- Module self-imports in `v05/` (e.g. `from v05.pmcp_v5_types import …`)
  were unreachable without a working install. Now reachable.
- `CommandValidator` (test-only utility) was missing error messages for
  unknown command types and had over-verbose messages for missing fields.
- `FleetManager` (test-only utility) was not setting `status = "pending"`
  on `assign_task`, so `get_fleet_stats()["pending_tasks"]` was always 0.
- Three CLI console scripts (`pmcp-server`, `pmcp-demo`, `pmcp-registry`)
  referenced `main` / `main_cli` entry points that did not exist. Added.
- `v05/__init__.py` was missing `ShadowSimulator`, `PMCPRegistry`, and
  `RegistryEntry` from the public surface. Added.

### Known limitations
- The shadow simulator's reachability check is a workspace-sphere test; it
  does not solve inverse kinematics. A deployment that needs joint-level
  IK validation should call into MoveIt or the vendor IK solver and feed
  the result back through the constitution.
- Reference robot servers (arm, mobile, agricultural) are illustrative.
  No real-robot driver ships in v0.5.
- The HTTP transport uses stdlib only; the HTTP *registry server* is
  optional and requires `aiohttp`.

## [0.1.0] – [0.4.0] — earlier development

See `pmcp-labs/v01/` … `pmcp-labs/v04/` for the source of the
v0.1–v0.4 series. These versions are preserved for historical reference
and are not on the supported path.
