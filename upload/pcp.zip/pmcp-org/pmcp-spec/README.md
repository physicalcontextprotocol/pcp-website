# pmcp-spec

The Physical Model Context Protocol (P-MCP) specification. This is the
source-of-truth repo — every SDK (`pmcp-python`, `pmcp-typescript`,
`pmcp-rust`) and the conformance suite (`pmcp-conformance`) implement
against what's defined here. Per the migration sequencing, this repo
(plus `pmcp-conformance`) should stabilize before SDK work proceeds.

## Contents
- `docs/PROTOCOL_SPEC.md` — the wire protocol: five-layer architecture
  (TEE, Ed25519 identity, CRDT ledger, HNN physics validation,
  application layer), gate ordering, message types.
- `docs/FOUNDATION_CHARTER.md` — project charter / governance.
- `docs/PROJECT_EXPLANATION.md` — narrative overview.
- `docs/PROTOCOL_README.md` — original `docs/README.md`.

## ⚠️ Known open item

- `schemas/` (JSON Schema definitions) is now populated at
  `schema/v0.6.0/pmcp.schema.json` — validated against the JSON Schema
  2020-12 meta-schema and round-tripped against example valid/invalid
  messages (see `schema/v0.6.0/README.md`). Still missing: the
  per-message JSON-RPC method registry (which `method` name maps to
  which request/response `$defs`).
- `formal/` now has two model-checked TLA+ specs (`PMCPCore.tla`,
  `PMCPRecovery.tla`) — see `formal/README.md` for what's verified and
  what isn't (multi-robot spatial conflicts, liveness/timing
  properties, and composing the two models together are the open
  pieces).
