# P-MCP canonical schema — v0.6.0

`pmcp.schema.json` is the canonical, language-neutral source of truth
for the P-MCP wire format (JSON Schema 2020-12; see
`docs/SAFETY_ARCHITECTURE.md` §8 for why JSON Schema and not
TypeScript is canonical here).

## Verified, not just written

```bash
pip install jsonschema
python3 -c "
import json
from jsonschema import Draft202012Validator
schema = json.load(open('pmcp.schema.json'))
Draft202012Validator.check_schema(schema)   # schema itself is valid 2020-12
"
```

Every `$def` compiles into a standalone validator, and each one has
been round-tripped against the `examples/valid/` and `examples/invalid/`
fixtures — confirming the schema both accepts what it should and
(more importantly, for a safety-critical protocol) **rejects what it
should**. Three invalid-example checks specifically probe safety-load-
bearing constraints:

- `EStopMessage` with `stop_category != 0` → rejected (E-Stop is always
  Stop Category 0, §4)
- `ShadowResult` with only `verdict`, missing confidence/monitoring/
  determinism → rejected (§10.2 explicitly forbids the bare-boolean
  anti-pattern)
- `LeaseGrant` with `state: "GRANTED"` → rejected (not a valid
  `LeaseState` value — this is the exact kind of drift that caused the
  original four-duplicate-client problem; `ACTIVE` is correct)

## What this schema resolves from the type-consolidation work

- **`ErrorCode`** — union of `pmcp/types.py`'s 10 codes and `v05`'s 5
  additions (no conflict, just different completeness — kept as one
  superset)
- **`SensorType`** — same pattern, union of the generic and
  robotics-specific vocabularies
- **`ShadowResult`/verdict** — replaces both the old lowercase
  (`pmcp`/`sdk`) and uppercase (`v05`) `ShadowStatus` enums, which
  genuinely conflicted in members and casing. Neither is reused as-is;
  this is the §10.1/§10.2 monitor-controller design instead.
- **`LeaseState`** — based on `v05`'s enum (the only file that had one)
  plus the `PENDING` state the recovery/Raft work required.

## What's NOT in this schema yet

- **No per-message JSON-RPC method registry** — the schema defines the
  types (`$defs`), but not yet the mapping from JSON-RPC `method` names
  to which request/response types apply. That's the natural next
  artifact.
- **`BatchActuationRequest`/`Result`** carried forward from
  `pmcp/types.py` as-is, but §3 invariant 7
  (`SingleActuationPerLease`) isn't yet reconciled with what batching
  actually means — flagged, not resolved, in the schema's description
  field.
- **No Rust-idiomatic generated types yet** — quicktype's Rust output
  tends not to be idiomatic; plan is to hand-author `pmcp-rust`'s types
  against this schema rather than blindly codegen them (see
  `docs/SAFETY_ARCHITECTURE.md` §8's directory layout note).
- Field-level numeric constraints tied to the still-open `T_safe` /
  `T_leader_unknown` / `epsilon_max` values (§11) are documented in
  `description` fields but not yet enforced as JSON Schema
  `minimum`/`maximum` constraints, since the numbers themselves don't
  exist yet.
